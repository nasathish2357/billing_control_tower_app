"""
Vertex AI Gemini LLM and Embedding provider.

Validates required environment variables at startup and fails fast with
a clear error if credentials are missing.
"""

import logging
import os
from functools import lru_cache

from langchain_google_vertexai import ChatVertexAI, VertexAIEmbeddings
from app.config import get_settings

logger = logging.getLogger(__name__)


def _validate_vertexai_config(settings) -> None:
    """Fail fast if Vertex AI is misconfigured."""
    missing = []
    if not settings.vertexai_project:
        missing.append("VERTEXAI_PROJECT")
    if not settings.vertexai_location:
        missing.append("VERTEXAI_LOCATION")
    if not settings.vertexai_model:
        missing.append("VERTEXAI_MODEL")
    if missing:
        raise EnvironmentError(
            f"Missing required Vertex AI configuration: {', '.join(missing)}. "
            "Please populate .env before starting."
        )
    # Warn if credential file is set but not found
    creds = settings.google_application_credentials
    if creds and not os.path.exists(creds):
        logger.warning(
            "GOOGLE_APPLICATION_CREDENTIALS is set to '%s' but the file was not found. "
            "Ensure the service-account JSON is mounted or ADC is configured.",
            creds,
        )


@lru_cache()
def get_llm(streaming: bool = False, temperature: float = 0.0) -> ChatVertexAI:
    settings = get_settings()
    _validate_vertexai_config(settings)

    creds_path = settings.google_application_credentials
    if creds_path and os.path.exists(creds_path):
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = creds_path

    return ChatVertexAI(
        model_name=settings.vertexai_model,
        project=settings.vertexai_project,
        location=settings.vertexai_location,
        temperature=temperature,
        streaming=streaming,
    )


@lru_cache()
def get_embeddings() -> VertexAIEmbeddings:
    settings = get_settings()
    _validate_vertexai_config(settings)

    creds_path = settings.google_application_credentials
    if creds_path and os.path.exists(creds_path):
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = creds_path

    return VertexAIEmbeddings(
        model_name=settings.vertexai_embedding_model or "text-embedding-004",
        project=settings.vertexai_project,
        location=settings.vertexai_location,
    )
