"""
Database seeder — creates tables and populates seed data for MVP1.

Run:  python -m app.db.seed
"""

import asyncio
import datetime
import logging

from app.db.database import engine, Base, AsyncSessionFactory
from app.models.models import UseCase, Customer, BillingAccount, Bill, Issue

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


USE_CASES = [
    {
        "id": "P1", "priority": "P1", "flow_type": "deterministic", "status": "active",
        "name": "Missing or Delayed Usage Feed into Billing",
        "description": "Usage records are delayed or missing in the billing engine, leading to potential under-billing or late bill dispatch.",
    },
    {
        "id": "P2", "priority": "P2", "flow_type": "full", "status": "active",
        "name": "Duplicate Charging / Duplicate Usage Rating",
        "description": "Customer is charged twice for the same usage event due to a mediation or rating engine fault.",
    },
    {
        "id": "P3", "priority": "P3", "flow_type": "full", "status": "active",
        "name": "Zombie PDU Session Causing Unfair Data Charging",
        "description": "A ghost/zombie PDU session persists in the network after the customer disconnected, continuing to accrue data charges.",
    },
    {
        "id": "P4", "priority": "P4", "flow_type": "deterministic", "status": "active",
        "name": "QoS or Slice Entitlement Mismatch with Premium Charging",
        "description": "Customer is charged for premium 5G slice/QoS tier but the network did not deliver promised performance.",
    },
    {
        "id": "P5", "priority": "P5", "flow_type": "deterministic", "status": "active",
        "name": "Service Degradation Requiring Commercial Compensation",
        "description": "SLA breach or prolonged service degradation requires automatic or manual commercial compensation.",
    },
    {
        "id": "P6", "priority": "P6", "flow_type": "deterministic", "status": "active",
        "name": "Collections Hold Required During Billing Dispute",
        "description": "While a dispute is active, the disputed amount must be placed on hold to prevent unjust collections proceedings.",
    },
    {
        "id": "P7", "priority": "P7", "flow_type": "deterministic", "status": "active",
        "name": "Partner or Wholesale Charge Discrepancy",
        "description": "Mismatch between the CSP's internal billing and a partner/MVNO wholesale settlement record.",
    },
    {
        "id": "P8", "priority": "P8", "flow_type": "full", "status": "active",
        "name": "Confusing Invoice with Technically Valid but Opaque Charges",
        "description": "Customer cannot understand a bill with legitimate but complex charges; AI generates a plain-language explanation.",
    },
    {
        "id": "P9", "priority": "P9", "flow_type": "deterministic", "status": "active",
        "name": "Internal Anomaly Discovered by Monitoring Before Customer Impact",
        "description": "Proactive internal detection of a billing risk or anomaly before it appears on a customer bill.",
    },
    {
        "id": "P10", "priority": "P10", "flow_type": "deterministic", "status": "active",
        "name": "Governed End-to-End Dispute Handling Across BSS, OSS, and Network",
        "description": "Complex dispute requiring coordinated resolution across billing (BSS), service assurance (OSS), and network teams.",
    },
]

CUSTOMERS = [
    {"id": "CUST-100001", "name": "Alice Nguyen", "email": "alice@example.com", "segment": "Consumer"},
    {"id": "CUST-100002", "name": "Broadcom Enterprises", "email": "billing@broadcom.example.com", "segment": "Enterprise"},
    {"id": "CUST-100003", "name": "Marco Rossi", "email": "marco@example.com", "segment": "Consumer"},
]

BILLING_ACCOUNTS = [
    {"id": "BA-100001", "customer_id": "CUST-100001", "status": "Active"},
    {"id": "BA-100002", "customer_id": "CUST-100002", "status": "Active"},
    {"id": "BA-100003", "customer_id": "CUST-100003", "status": "Active"},
]

BILLS = [
    {
        "id": "BILL-202604",
        "billing_account_id": "BA-100001",
        "billing_period": "2026-04",
        "amount_due": 142.50,
        "previous_amount": 95.00,
        "due_date": datetime.datetime(2026, 5, 15),
        "status": "Disputed",
        "payload": {
            "line_items": [
                {"description": "Monthly plan", "amount": 65.00},
                {"description": "International data roaming", "amount": 32.50},
                {"description": "Premium 5G slice add-on", "amount": 25.00},
                {"description": "Duplicate data session charge", "amount": 12.50, "dispute_flag": True},
                {"description": "Taxes & surcharges", "amount": 7.50},
            ],
            "payments": [],
        },
    },
    {
        "id": "BILL-202603",
        "billing_account_id": "BA-100001",
        "billing_period": "2026-03",
        "amount_due": 95.00,
        "previous_amount": 90.00,
        "due_date": datetime.datetime(2026, 4, 15),
        "status": "Paid",
        "payload": {
            "line_items": [
                {"description": "Monthly plan", "amount": 65.00},
                {"description": "Taxes & surcharges", "amount": 7.50},
                {"description": "Miscellaneous usage", "amount": 22.50},
            ],
            "payments": [{"amount": 95.00, "date": "2026-04-10"}],
        },
    },
]

ISSUES = [
    {
        "id": "ISSUE-P1-001", "use_case_id": "P1", "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002", "bill_id": None,
        "description": "Enterprise customer reports that March usage events are missing from the April bill run.",
        "status": "open",
    },
    {
        "id": "ISSUE-P2-001", "use_case_id": "P2", "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
        "description": "Customer Alice Nguyen is charged twice for a 2 GB data session on April 15th — duplicate charge of $12.50.",
        "status": "open",
    },
    {
        "id": "ISSUE-P3-001", "use_case_id": "P3", "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
        "description": "Zombie PDU session detected: Session ID PDU-4491 continued charging for 6 hours after customer device was switched off.",
        "status": "open",
    },
    {
        "id": "ISSUE-P4-001", "use_case_id": "P4", "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002", "bill_id": None,
        "description": "Enterprise customer charged for premium 5G Ultra slice but network delivered standard 4G QoS for 72 hours.",
        "status": "open",
    },
    {
        "id": "ISSUE-P5-001", "use_case_id": "P5", "customer_id": "CUST-100003",
        "billing_account_id": "BA-100003", "bill_id": None,
        "description": "Customer Marco Rossi experienced voice call drops for 8 hours on April 20th. SLA breach detected, compensation required.",
        "status": "open",
    },
    {
        "id": "ISSUE-P6-001", "use_case_id": "P6", "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
        "description": "Active billing dispute requires collections hold on disputed $12.50 balance to prevent dunning.",
        "status": "open",
    },
    {
        "id": "ISSUE-P7-001", "use_case_id": "P7", "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002", "bill_id": None,
        "description": "Wholesale partner MVNO-X settlement record shows $3,200 discrepancy vs CSP internal record for March.",
        "status": "open",
    },
    {
        "id": "ISSUE-P8-001", "use_case_id": "P8", "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
        "description": "Customer cannot understand why April bill is $47.50 higher than March. Requests plain-language explanation.",
        "status": "open",
    },
    {
        "id": "ISSUE-P9-001", "use_case_id": "P9", "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001", "bill_id": None,
        "description": "Proactive monitoring detected abnormal data usage spike pattern on account BA-100001 likely to cause billing complaint.",
        "status": "open",
    },
    {
        "id": "ISSUE-P10-001", "use_case_id": "P10", "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002", "bill_id": None,
        "description": "Complex dispute spanning BSS charge correction, OSS service problem closure, and network session audit for Enterprise account.",
        "status": "open",
    },
]


async def seed():
    logger.info("Creating database tables...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionFactory() as db:
        logger.info("Seeding use cases...")
        for uc_data in USE_CASES:
            uc = UseCase(**uc_data)
            await db.merge(uc)

        logger.info("Seeding customers...")
        for c in CUSTOMERS:
            await db.merge(Customer(**c))

        logger.info("Seeding billing accounts...")
        for ba in BILLING_ACCOUNTS:
            await db.merge(BillingAccount(**ba))

        logger.info("Seeding bills...")
        for b in BILLS:
            await db.merge(Bill(**b))

        logger.info("Seeding issues (10 issues)...")
        for issue_data in ISSUES:
            await db.merge(Issue(**issue_data))

        await db.commit()
    logger.info("✅ Seeding complete.")


if __name__ == "__main__":
    asyncio.run(seed())
