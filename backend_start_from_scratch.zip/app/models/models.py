"""
SQLAlchemy ORM models for Billing Control Tower MVP1.

Design principle: Large TMF-style payloads are stored in JSON/JSONB columns
on the database rows. Only compact references (IDs, summaries) are placed in
LangGraph state, keeping checkpointed state lightweight.
"""

import datetime
from typing import List, Optional
from sqlalchemy import String, ForeignKey, DateTime, Float, JSON, Text, Boolean, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class UseCase(Base):
    __tablename__ = "use_cases"

    id: Mapped[str] = mapped_column(String(10), primary_key=True)   # P1 … P10
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    priority: Mapped[str] = mapped_column(String(10))
    flow_type: Mapped[str] = mapped_column(String(20), default="deterministic")  # "full" or "deterministic"
    status: Mapped[str] = mapped_column(String(20), default="active")


class Customer(Base):
    __tablename__ = "customers"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # CUST-100001
    name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str] = mapped_column(String(200))
    segment: Mapped[str] = mapped_column(String(50))                 # Consumer, Enterprise

    billing_accounts: Mapped[List["BillingAccount"]] = relationship(back_populates="customer")


class BillingAccount(Base):
    __tablename__ = "billing_accounts"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # BA-100001
    customer_id: Mapped[str] = mapped_column(ForeignKey("customers.id"))
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    status: Mapped[str] = mapped_column(String(30))

    customer: Mapped["Customer"] = relationship(back_populates="billing_accounts")
    bills: Mapped[List["Bill"]] = relationship(back_populates="billing_account")


class Bill(Base):
    __tablename__ = "bills"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # BILL-202604
    billing_account_id: Mapped[str] = mapped_column(ForeignKey("billing_accounts.id"))
    billing_period: Mapped[str] = mapped_column(String(20))         # 2026-04
    amount_due: Mapped[float] = mapped_column(Float)
    previous_amount: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    due_date: Mapped[datetime.datetime] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(30))                  # Paid, Disputed, Pending
    # Full TMF-style bill payload stored here, NOT in graph state
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    billing_account: Mapped["BillingAccount"] = relationship(back_populates="bills")


class Issue(Base):
    __tablename__ = "issues"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # ISSUE-P2-001
    use_case_id: Mapped[str] = mapped_column(ForeignKey("use_cases.id"))
    customer_id: Mapped[str] = mapped_column(String(50))
    billing_account_id: Mapped[str] = mapped_column(String(50))
    bill_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="open")  # open, investigating, remediated, closed
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    use_case: Mapped["UseCase"] = relationship()
    control_cases: Mapped[List["ControlCase"]] = relationship(back_populates="issue")


class ControlCase(Base):
    __tablename__ = "control_cases"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # CC-P2-001
    issue_id: Mapped[str] = mapped_column(ForeignKey("issues.id"))
    status: Mapped[str] = mapped_column(String(30))                  # created, investigating, resolved, closed
    thread_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    requires_human_approval: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)

    issue: Mapped["Issue"] = relationship(back_populates="control_cases")
    evidence_packs: Mapped[List["EvidencePack"]] = relationship(back_populates="control_case")
    audit_traces: Mapped[List["AuditTrace"]] = relationship(back_populates="control_case")


class EvidencePack(Base):
    __tablename__ = "evidence_packs"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # EVP-P2-L3-001
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    source_layer: Mapped[str] = mapped_column(String(10))            # L1, L2, L3, L4
    summary: Mapped[str] = mapped_column(Text)
    # Full evidence payload stored in DB, only ID+summary go into graph state
    payload: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)

    control_case: Mapped["ControlCase"] = relationship(back_populates="evidence_packs")


class AuditTrace(Base):
    __tablename__ = "audit_traces"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # TRACE-P2-001
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    action_type: Mapped[str] = mapped_column(String(50))             # analysis, remediation, explanation, escalation
    actor: Mapped[str] = mapped_column(String(50))                   # agent, human
    summary: Mapped[str] = mapped_column(Text)
    details: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)

    control_case: Mapped["ControlCase"] = relationship(back_populates="audit_traces")
