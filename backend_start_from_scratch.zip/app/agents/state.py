"""
LangGraph lightweight state definition.

Per the engineering addendum:
  - Store only compact references (IDs, summaries) here.
  - Large payloads (bills, evidence, audit details) are in PostgreSQL.
  - evidence_pack_ids is a list of DB row IDs, NOT the full payloads.
"""

from typing import Annotated, List, Optional
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages


class RemediationState(TypedDict):
    """State for P2 / P3 remediation flows."""
    # Core identifiers
    issue_id: str
    control_case_id: str
    thread_id: str
    customer_id: str
    billing_account_id: str
    bill_id: Optional[str]

    # Evidence references (IDs only — full payload lives in DB)
    evidence_pack_ids: List[str]
    evidence_summary: str           # Short human-readable summary for LLM reasoning

    # Decision outputs
    playbook_summary: str
    policy_decision: Optional[str]  # "auto_remediation_allowed" | "human_approval_required"
    planned_action_ids: List[str]

    # Outcome
    final_response_summary: Optional[str]
    audit_trace_id: Optional[str]
    is_remediated: bool
    requires_human_approval: bool
    error: Optional[str]


class ChatState(TypedDict):
    """State for P8 bill-explanation / chat flow."""
    # Core identifiers
    conversation_id: str
    customer_id: str
    billing_account_id: str
    thread_id: str

    # Chat messages (accumulated via LangGraph reducer)
    messages: Annotated[List[dict], add_messages]

    # Detected intent
    intent: Optional[str]   # bill_explanation | compare_previous_bill | issue_status | remediate_issue | escalate_to_human

    # Evidence references
    current_bill_id: Optional[str]
    previous_bill_ids: List[str]
    evidence_summary: str
    playbook_summary: str

    # Decision
    escalation_required: bool

    # Output
    final_response: Optional[str]
    audit_trace_id: Optional[str]
    error: Optional[str]
