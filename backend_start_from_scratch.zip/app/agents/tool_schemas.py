"""
Shallow Pydantic tool schemas for Gemini-compatible tool binding.

Rules (from master prompt):
- Small input schemas with IDs and simple filters only.
- No deeply nested TMF objects.
- No recursive schemas.
"""

from typing import Literal, Optional
from pydantic import BaseModel, Field


class GetCustomerBillInput(BaseModel):
    billing_account_id: str = Field(description="Billing account ID, e.g. BA-100001")
    bill_id: Optional[str] = Field(default=None, description="Specific bill ID; if null, returns the latest bill")


class GetPreviousBillsInput(BaseModel):
    billing_account_id: str = Field(description="Billing account ID")
    months: int = Field(default=3, description="Number of previous months to retrieve")


class GetIssueInput(BaseModel):
    issue_id: str = Field(description="Issue ID, e.g. ISSUE-P2-001")


class ApplyAdjustmentInput(BaseModel):
    issue_id: str = Field(description="Issue ID the adjustment is tied to")
    billing_account_id: str = Field(description="Billing account ID")
    adjustment_type: Literal["credit", "rebill", "waiver"] = Field(description="Type of adjustment")
    amount: float = Field(description="Adjustment amount in account currency")
    reason_code: str = Field(description="Short machine-readable reason, e.g. duplicate_charge")


class GetSessionEvidenceInput(BaseModel):
    session_id: str = Field(description="PDU session ID, e.g. PDU-4491")
    billing_account_id: str = Field(description="Billing account ID")


class CleanupSessionInput(BaseModel):
    session_id: str = Field(description="PDU session ID to terminate")


class GetMediationEvidenceInput(BaseModel):
    billing_account_id: str = Field(description="Billing account ID")
    bill_id: str = Field(description="Bill ID to check mediation records for")


class RetrievePlaybookInput(BaseModel):
    query: str = Field(description="Short natural language query to find the relevant playbook")
