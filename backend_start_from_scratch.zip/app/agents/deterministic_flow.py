"""
Deterministic remediation handler for use cases P1, P4, P5, P6, P7, P9, P10.

Each flow:
  1. Loads the issue.
  2. Creates a ControlCase.
  3. Applies a predefined evidence/action template.
  4. Updates issue status.
  5. Creates an audit trace.
  6. Returns a realistic response.

These flows do NOT use LangGraph (as per MVP1 scope). Full LangGraph
flows for these use cases will be implemented in MVP2.
"""

import datetime
import logging
import uuid
from typing import Dict, Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Issue, ControlCase, EvidencePack, AuditTrace
from app.services import l2_bss_service, l3_oss_service, l4_network_service

logger = logging.getLogger(__name__)


DETERMINISTIC_TEMPLATES: Dict[str, Dict[str, Any]] = {
    "P1": {
        "summary": "Missing usage feed detected. L3 mediation backlog identified. Bill protection hold applied pending usage replay.",
        "action": "bill_protection_hold",
        "layer": "L3",
        "evidence": "Mediation backlog: 847 usage events delayed. Bill protection hold placed. Replay scheduled.",
    },
    "P4": {
        "summary": "QoS/Slice entitlement mismatch confirmed. Premium surcharge removed for the affected period.",
        "action": "surcharge_removal",
        "layer": "L3-L4",
        "evidence": "L3: Slice performance 15 Mbps vs promised 100 Mbps. L4: NSSAI mismatch. Premium surcharge $25.00 removed.",
    },
    "P5": {
        "summary": "Service degradation confirmed. SLA breach detected. Commercial compensation applied.",
        "action": "compensation_credit",
        "layer": "L3",
        "evidence": "L3: 8-hour voice service outage on April 20th. SLA threshold: 60 min. Credit $20.00 applied as per SLA agreement.",
    },
    "P6": {
        "summary": "Billing dispute active. Collections hold placed on disputed balance.",
        "action": "collections_hold",
        "layer": "L2",
        "evidence": "Disputed amount $12.50 placed on collections hold. Undisputed balance remains collectible. Dunning paused.",
    },
    "P7": {
        "summary": "Partner/wholesale charge discrepancy identified. Settlement record flagged for reconciliation.",
        "action": "reconciliation_flagged",
        "layer": "L2",
        "evidence": "CSP record: $48,200. Partner MVNO-X record: $45,000. Discrepancy: $3,200 flagged for manual settlement review.",
    },
    "P9": {
        "summary": "Proactive anomaly detected by monitoring. Preventive action taken before customer impact.",
        "action": "proactive_hold",
        "layer": "L1",
        "evidence": "Unusual data spike 3x normal on BA-100001. Proactive billing review initiated. No customer-visible impact yet.",
    },
    "P10": {
        "summary": "End-to-end governed dispute resolution initiated across BSS, OSS, and Network layers.",
        "action": "cross_domain_dispute",
        "layer": "L1-L2-L3-L4",
        "evidence": "L2: Bill correction queued. L3: Service problem SP-9900 opened. L4: Network audit initiated. Governance checkpoint created.",
    },
}


async def run_deterministic_flow(db: AsyncSession, issue_id: str) -> Dict[str, Any]:
    """Execute a deterministic remediation flow and return a structured response."""

    # Load the issue
    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {issue_id} not found."}

    use_case_id = issue.use_case_id
    template = DETERMINISTIC_TEMPLATES.get(use_case_id)
    if not template:
        return {"error": f"No deterministic template for use case {use_case_id}."}

    # Create control case
    cc_id = f"CC-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    cc = ControlCase(
        id=cc_id,
        issue_id=issue_id,
        status="resolved",
        resolved_at=datetime.datetime.utcnow(),
    )
    db.add(cc)
    await db.flush()

    # Create evidence pack
    evp_id = f"EVP-DET-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    evp = EvidencePack(
        id=evp_id,
        control_case_id=cc_id,
        source_layer=template["layer"],
        summary=template["evidence"],
        payload={
            "template": template,
            "applied_at": datetime.datetime.utcnow().isoformat(),
        },
    )
    db.add(evp)

    # Update issue status
    issue.status = "remediated"
    issue.updated_at = datetime.datetime.utcnow()

    # Create audit trace
    trace_id = f"TRACE-DET-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    trace = AuditTrace(
        id=trace_id,
        control_case_id=cc_id,
        action_type="deterministic_remediation",
        actor="agent",
        summary=template["summary"],
        details={
            "use_case_id": use_case_id,
            "action": template["action"],
            "evidence_pack_id": evp_id,
        },
    )
    db.add(trace)
    await db.commit()

    logger.info("Deterministic flow completed for %s: %s", issue_id, trace_id)
    return {
        "issue_id": issue_id,
        "use_case_id": use_case_id,
        "control_case_id": cc_id,
        "evidence_pack_id": evp_id,
        "audit_trace_id": trace_id,
        "action": template["action"],
        "summary": template["summary"],
        "status": "remediated",
    }
