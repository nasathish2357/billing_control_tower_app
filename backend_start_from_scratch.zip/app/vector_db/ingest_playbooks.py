"""
Playbook ingestion script — run once to populate ChromaDB.

Run:  python -m app.vector_db.ingest_playbooks
"""

import asyncio
import logging

from app.vector_db.vector_store import add_playbooks

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PLAYBOOKS = [
    {
        "id": "PB-P2-001",
        "text": (
            "Playbook: Duplicate Charging Resolution (P2)\n"
            "1. Retrieve the billing account and identify the duplicate charge line item.\n"
            "2. Obtain mediation evidence from L3 confirming the double processing event.\n"
            "3. Obtain rating evidence from L4 showing two rating triggers for a single session.\n"
            "4. Issue a credit adjustment via L2 for the duplicate amount.\n"
            "5. Update the control case and create an audit trace.\n"
            "Outcome: Credit applied, bill corrected, customer notified."
        ),
        "metadata": {"use_case": "P2", "layer": "L1-L4", "action": "credit"},
    },
    {
        "id": "PB-P3-001",
        "text": (
            "Playbook: Zombie PDU Session Resolution (P3)\n"
            "1. Identify the session ID and the time range of anomalous charging.\n"
            "2. Request L4 network evidence to confirm the session was not legitimately active.\n"
            "3. Execute L4 mock session cleanup/termination for the zombie session ID.\n"
            "4. Calculate the erroneous charge amount and apply a billing correction via L2.\n"
            "5. Create audit trace with L4 session evidence and L2 correction record.\n"
            "Outcome: Session cleaned, billing corrected."
        ),
        "metadata": {"use_case": "P3", "layer": "L4", "action": "session_cleanup+credit"},
    },
    {
        "id": "PB-P8-001",
        "text": (
            "Playbook: Bill Explanation (P8)\n"
            "1. Load the current bill and all line items for the billing account.\n"
            "2. Load the previous 3 months of bills for comparison.\n"
            "3. Identify line items that changed significantly month-over-month.\n"
            "4. Use Gemini to generate a plain-language explanation of each change.\n"
            "5. If no discrepancy is found, return the explanation without escalation.\n"
            "6. If a discrepancy is detected, escalate to the remediation flow.\n"
            "Outcome: Customer receives a clear, plain-language bill explanation."
        ),
        "metadata": {"use_case": "P8", "layer": "L2", "action": "explanation"},
    },
    {
        "id": "PB-P1-001",
        "text": (
            "Playbook: Missing Usage Feed (P1)\n"
            "1. Check mediation backlog for delayed usage events for the billing account.\n"
            "2. Identify the affected bill run and the exposure period.\n"
            "3. Request L3 mediation replay if usage records can be recovered.\n"
            "4. Apply a bill protection hold via L2 to prevent incorrect charges.\n"
            "Outcome: Usage replayed or bill protected until records are recovered."
        ),
        "metadata": {"use_case": "P1", "layer": "L3", "action": "mediation_replay"},
    },
    {
        "id": "PB-P4-001",
        "text": (
            "Playbook: QoS/Slice Entitlement Mismatch (P4)\n"
            "1. Retrieve the product/entitlement record to confirm the promised QoS tier.\n"
            "2. Retrieve L3 service performance evidence for the disputed period.\n"
            "3. Retrieve L4 slice performance evidence.\n"
            "4. If delivered QoS < promised QoS, remove premium surcharge via L2.\n"
            "Outcome: Premium surcharge removed or prorated."
        ),
        "metadata": {"use_case": "P4", "layer": "L3-L4", "action": "surcharge_removal"},
    },
]


async def main():
    texts = [p["text"] for p in PLAYBOOKS]
    metadatas = [p["metadata"] for p in PLAYBOOKS]
    ids = [p["id"] for p in PLAYBOOKS]
    await add_playbooks(texts, metadatas, ids)
    logger.info("Playbook ingestion complete.")


if __name__ == "__main__":
    asyncio.run(main())
