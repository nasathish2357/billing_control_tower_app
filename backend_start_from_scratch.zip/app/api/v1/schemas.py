from pydantic import BaseModel
from typing import List, Optional, Any
from datetime import datetime


class UseCaseOut(BaseModel):
    id: str
    name: str
    description: str
    priority: str
    flow_type: str
    status: str

    class Config:
        from_attributes = True


class IssueOut(BaseModel):
    id: str
    use_case_id: str
    customer_id: str
    billing_account_id: str
    bill_id: Optional[str] = None
    description: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class ControlCaseOut(BaseModel):
    id: str
    issue_id: str
    status: str
    thread_id: Optional[str] = None
    requires_human_approval: bool
    created_at: datetime
    resolved_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class AuditTraceOut(BaseModel):
    id: str
    control_case_id: str
    action_type: str
    actor: str
    summary: str
    details: Optional[dict] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ChatRequest(BaseModel):
    conversation_id: str
    message: str
    customer_id: str
    billing_account_id: str


class RemediateRequest(BaseModel):
    """Optional body — issue_id is taken from the path parameter."""
    pass
