"""
MVP1 API Endpoints — all 9 required routes.

Routes:
  GET  /health
  GET  /use-cases
  GET  /issues
  GET  /issues/{issue_id}
  POST /issues/{issue_id}/remediate
  POST /chat/stream
  POST /chat
  GET  /audit-traces/{audit_trace_id}
  GET  /control-cases/{control_case_id}
"""

import logging
import uuid
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import UseCase, Issue, ControlCase, AuditTrace
from app.api.v1.schemas import (
    UseCaseOut, IssueOut, ControlCaseOut, AuditTraceOut,
    ChatRequest, RemediateRequest,
)
from app.agents.chat_graph import chat_stream_generator
from app.agents.deterministic_flow import run_deterministic_flow, DETERMINISTIC_TEMPLATES

logger = logging.getLogger(__name__)
router = APIRouter()

FULL_FLOW_USE_CASES = {"P2", "P3", "P8"}


# ─────────────────────────────────────────────
#  Health
# ─────────────────────────────────────────────

@router.get("/health")
async def health():
    return {"status": "ok", "service": "Billing Control Tower MVP1"}


# ─────────────────────────────────────────────
#  Use Cases — returns all 10
# ─────────────────────────────────────────────

@router.get("/use-cases", response_model=List[UseCaseOut])
async def list_use_cases(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(UseCase).order_by(UseCase.priority))
    return result.scalars().all()


# ─────────────────────────────────────────────
#  Issues — returns all 10
# ─────────────────────────────────────────────

@router.get("/issues", response_model=List[IssueOut])
async def list_issues(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Issue).order_by(Issue.id))
    return result.scalars().all()


@router.get("/issues/{issue_id}", response_model=IssueOut)
async def get_issue(issue_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise HTTPException(status_code=404, detail=f"Issue {issue_id} not found")
    return issue


# ─────────────────────────────────────────────
#  Remediation
# ─────────────────────────────────────────────

@router.post("/issues/{issue_id}/remediate")
async def remediate_issue(issue_id: str, db: AsyncSession = Depends(get_db)):
    """
    Trigger remediation for an issue.
    - P2 / P3: runs the LangGraph agentic flow.
    - P1, P4–P7, P9–P10: runs the deterministic flow.
    - P8: is handled via /chat/stream.
    """
    # Verify issue exists
    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise HTTPException(status_code=404, detail=f"Issue {issue_id} not found")

    use_case_id = issue.use_case_id

    if use_case_id in ("P2", "P3"):
        # Create a ControlCase for the graph run
        from app.models.models import ControlCase as CC
        cc_id = f"CC-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
        thread_id = f"THREAD-{issue_id}"
        cc = CC(id=cc_id, issue_id=issue_id, status="investigating", thread_id=thread_id)
        db.add(cc)
        await db.commit()

        # Build initial state and run the remediation graph
        from app.agents.remediation_graph import remediation_graph
        from app.agents.state import RemediationState

        initial_state: RemediationState = {
            "issue_id": issue_id,
            "control_case_id": cc_id,
            "thread_id": thread_id,
            "customer_id": issue.customer_id,
            "billing_account_id": issue.billing_account_id,
            "bill_id": issue.bill_id,
            "evidence_pack_ids": [],
            "evidence_summary": "",
            "playbook_summary": "",
            "policy_decision": None,
            "planned_action_ids": [],
            "final_response_summary": None,
            "audit_trace_id": None,
            "is_remediated": False,
            "requires_human_approval": False,
            "error": None,
        }

        final_state = await remediation_graph.ainvoke(initial_state)

        return {
            "issue_id": issue_id,
            "use_case_id": use_case_id,
            "control_case_id": cc_id,
            "audit_trace_id": final_state.get("audit_trace_id"),
            "evidence_pack_ids": final_state.get("evidence_pack_ids", []),
            "policy_decision": final_state.get("policy_decision"),
            "is_remediated": final_state.get("is_remediated", False),
            "summary": final_state.get("final_response_summary"),
            "status": "remediated",
        }

    elif use_case_id == "P8":
        raise HTTPException(
            status_code=400,
            detail="P8 (Bill Explanation) is handled via POST /api/v1/chat/stream — not via remediate endpoint.",
        )

    else:
        # Deterministic flow for P1, P4–P7, P9–P10
        response = await run_deterministic_flow(db, issue_id)
        if "error" in response:
            raise HTTPException(status_code=500, detail=response["error"])
        return response


# ─────────────────────────────────────────────
#  Chat — streaming (primary) and non-streaming
# ─────────────────────────────────────────────

@router.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    """
    Primary demo endpoint. Returns SSE stream per the MVP1 chat contract.
    Events: conversation_started, intent_detected, tool_started, tool_completed,
            evidence_loaded, token, audit_written, final, error
    """
    return StreamingResponse(
        chat_stream_generator(request.model_dump()),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/chat")
async def chat_simple(request: ChatRequest):
    """
    Non-streaming variant — collects all SSE chunks and returns the final_response.
    Useful for automated tests.
    """
    final_response = None
    audit_trace_id = None

    async for chunk in chat_stream_generator(request.model_dump()):
        # Parse out the "final" event
        if chunk.startswith("event: final"):
            import json
            data_line = [l for l in chunk.split("\n") if l.startswith("data:")]
            if data_line:
                payload = json.loads(data_line[0].replace("data: ", ""))
                final_response = payload.get("final_response")
                audit_trace_id = payload.get("audit_trace_id")

    return {
        "conversation_id": request.conversation_id,
        "final_response": final_response or "Unable to generate explanation.",
        "audit_trace_id": audit_trace_id,
    }


# ─────────────────────────────────────────────
#  Audit Traces
# ─────────────────────────────────────────────

@router.get("/audit-traces/{audit_trace_id}", response_model=AuditTraceOut)
async def get_audit_trace(audit_trace_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(AuditTrace).where(AuditTrace.id == audit_trace_id))
    trace = result.scalar_one_or_none()
    if not trace:
        raise HTTPException(status_code=404, detail=f"Audit trace {audit_trace_id} not found")
    return trace


# ─────────────────────────────────────────────
#  Control Cases
# ─────────────────────────────────────────────

@router.get("/control-cases/{control_case_id}", response_model=ControlCaseOut)
async def get_control_case(control_case_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ControlCase).where(ControlCase.id == control_case_id))
    cc = result.scalar_one_or_none()
    if not cc:
        raise HTTPException(status_code=404, detail=f"Control case {control_case_id} not found")
    return cc
