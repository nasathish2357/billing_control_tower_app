# MVP1 Progress Tracking

- [x] **Foundation & Infrastructure**
    - [x] Initialize project structure in `backend/`
    - [x] Create `requirements.txt` (chromadb, sse-starlette installed in .venv)
    - [x] Create `.env.example` and `.gitignore`, `.dockerignore`
    - [x] Implement `app/main.py` (async lifespan, structured logging, CORS)
    - [x] Implement `app/config.py` (pydantic-settings, fail-fast validation)

- [x] **Database & Models**
    - [x] `app/db/database.py` — Async SQLAlchemy engine + session (psycopg3)
    - [x] `app/models/models.py` — UseCase, Customer, BillingAccount, Bill, Issue, ControlCase, EvidencePack, AuditTrace
    - [x] `app/db/seed.py` — Seeds 10 use cases, 3 customers, 2 bills, 10 issues

- [x] **LLM & Vector Store**
    - [x] `app/llm/gemini_provider.py` — Vertex AI Gemini + Embeddings with fail-fast validation
    - [x] `app/vector_db/vector_store.py` — ChromaDB persistent client + Vertex AI embedding adapter
    - [x] `app/vector_db/ingest_playbooks.py` — Playbook ingestion script (P1–P5 playbooks)

- [x] **Orchestration (LangGraph)**
    - [x] `app/agents/state.py` — Lightweight RemediationState + ChatState (references only)
    - [x] `app/agents/tool_schemas.py` — Shallow Gemini-compatible tool schemas
    - [x] `app/agents/remediation_graph.py` — Full LangGraph for P2/P3 (all 12 nodes)
    - [x] `app/agents/chat_graph.py` — Full LangGraph for P8 (all 9 nodes) + SSE generator
    - [x] `app/agents/deterministic_flow.py` — Deterministic flows for P1, P4–P7, P9–P10
    - [x] `app/services/l2_bss_service.py` — L2 BSS: bills, adjustments, collections hold
    - [x] `app/services/l3_oss_service.py` — L3 OSS: mediation evidence, service degradation
    - [x] `app/services/l4_network_service.py` — L4 Network: session evidence, zombie cleanup, rating

- [x] **API Development**
    - [x] `GET /api/v1/health`
    - [x] `GET /api/v1/use-cases` — returns 10 use cases
    - [x] `GET /api/v1/issues` — returns 10 issues
    - [x] `GET /api/v1/issues/{id}`
    - [x] `POST /api/v1/issues/{id}/remediate` — LangGraph (P2/P3) + deterministic (rest)
    - [x] `POST /api/v1/chat/stream` — SSE streaming (P8 LangGraph)
    - [x] `POST /api/v1/chat` — Non-streaming (collects SSE, returns final)
    - [x] `GET /api/v1/audit-traces/{id}`
    - [x] `GET /api/v1/control-cases/{id}`

- [x] **Infrastructure Files**
    - [x] `Dockerfile`
    - [x] `.dockerignore`
    - [x] `.gitignore`
    - [x] `README.md`
    - [x] `requirements.txt`
    - [x] `pytest.ini`

- [x] **Testing**
    - [x] `tests/test_mvp1.py` — Health, use-cases (10), issues (10), deterministic flows, non-streaming chat

## Next Steps (Before Running)
1. Copy `.env.example` → `.env` and fill in `VERTEXAI_PROJECT`, `VERTEXAI_LOCATION`, `GOOGLE_APPLICATION_CREDENTIALS`
2. Create PostgreSQL database: `CREATE DATABASE billing_dispute_ai;`
3. Run seeder: `.venv\Scripts\python.exe -m app.db.seed`
4. (Optional) Ingest playbooks: `.venv\Scripts\python.exe -m app.vector_db.ingest_playbooks`
5. Start server: `.venv\Scripts\uvicorn.exe app.main:app --reload`
