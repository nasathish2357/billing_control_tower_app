"""
MVP1 integration tests — verify all acceptance criteria.

Run:  pytest tests/ -v

Note: Tests that require PostgreSQL or Vertex AI are marked with markers.
      Run with --co to list tests without executing.
"""

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

from app.main import app


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest_asyncio.fixture
async def client():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c


# ─────────────────────────────────────────────
#  Health
# ─────────────────────────────────────────────

@pytest.mark.anyio
async def test_health(client):
    response = await client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"


# ─────────────────────────────────────────────
#  Use Cases — must return 10
# ─────────────────────────────────────────────

@pytest.mark.anyio
async def test_use_cases_returns_10(client):
    response = await client.get("/api/v1/use-cases")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 10
    ids = [uc["id"] for uc in data]
    for p in ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10"]:
        assert p in ids, f"{p} not found in use cases"


# ─────────────────────────────────────────────
#  Issues — must return 10
# ─────────────────────────────────────────────

@pytest.mark.anyio
async def test_issues_returns_10(client):
    response = await client.get("/api/v1/issues")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 10


@pytest.mark.anyio
async def test_get_single_issue(client):
    response = await client.get("/api/v1/issues/ISSUE-P2-001")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == "ISSUE-P2-001"
    assert data["use_case_id"] == "P2"


@pytest.mark.anyio
async def test_issue_not_found(client):
    response = await client.get("/api/v1/issues/ISSUE-FAKE-999")
    assert response.status_code == 404


# ─────────────────────────────────────────────
#  P8 Deterministic flows (no LLM required)
# ─────────────────────────────────────────────

@pytest.mark.anyio
async def test_remediate_p1_deterministic(client):
    response = await client.post("/api/v1/issues/ISSUE-P1-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "remediated"
    assert data["use_case_id"] == "P1"
    assert "audit_trace_id" in data


@pytest.mark.anyio
async def test_remediate_p6_deterministic(client):
    response = await client.post("/api/v1/issues/ISSUE-P6-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "remediated"


# ─────────────────────────────────────────────
#  P8 via /chat endpoint (non-streaming, LLM optional due to fallback)
# ─────────────────────────────────────────────

@pytest.mark.anyio
async def test_chat_non_streaming(client):
    payload = {
        "conversation_id": "TEST-CONV-001",
        "message": "Why is my bill higher this month?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    }
    response = await client.post("/api/v1/chat", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]  # not empty
