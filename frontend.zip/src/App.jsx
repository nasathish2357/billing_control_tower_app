import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  Search, 
  MessageSquare, 
  CheckCircle2, 
  AlertCircle, 
  ChevronRight, 
  Play, 
  Cpu, 
  Database, 
  ShieldCheck,
  Send,
  Loader2,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { getUsecases, investigateCase, chatCase } from './api';

const App = () => {
  const [usecases, setUsecases] = useState([]);
  const [selectedCaseId, setSelectedCaseId] = useState(null);
  const [runData, setRunData] = useState(null);
  const [messages, setMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [isInvestigating, setIsInvestigating] = useState(false);
  const [isChatting, setIsChatting] = useState(false);
  
  // Known cases for demo
  const demoCases = [
    { id: 'CASE_TELCO_UC01', title: 'Delayed Usage Feed', sub: 'Emma (Consumer)' },
    { id: 'CASE_TELCO_UC03', title: 'Zombie PDU Session', sub: 'Sophie (Consumer)' },
    { id: 'CASE_TELCO_UC04', title: 'Slice Entitlement', sub: 'Amelia (Enterprise)' },
    { id: 'CASE_TELCO_UC07', title: 'Roaming Variance', sub: 'Sophia (Partner)' },
    { id: 'CASE_TELCO_UC09', title: 'Proactive Anomaly', sub: 'Leo (Enterprise)' },
  ];

  useEffect(() => {
    getUsecases().then(res => setUsecases(res.data)).catch(console.error);
  }, []);

  const handleInvestigate = async () => {
    if (!selectedCaseId) return;
    setIsInvestigating(true);
    try {
      const res = await investigateCase(selectedCaseId);
      setRunData(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsInvestigating(false);
    }
  };

  const handleSendChat = async () => {
    if (!chatInput.trim() || !selectedCaseId) return;
    const userMsg = { role: 'user', content: chatInput };
    setMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatting(true);
    
    try {
      const res = await chatCase(selectedCaseId, chatInput);
      setMessages(prev => [...prev, { role: 'assistant', content: res.data.content }]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsChatting(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="w-80 bg-slate-950 border-r border-white/5 flex flex-col p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-primary/20 rounded-lg">
            <Cpu className="text-primary w-6 h-6" />
          </div>
          <h1 className="text-xl font-extrabold tracking-tight">Control Tower</h1>
        </div>

        <div className="space-y-4 custom-scrollbar overflow-y-auto pr-2">
          <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-widest px-2">Active Cases</h2>
          {demoCases.map(c => (
            <motion.button
              key={c.id}
              whileHover={{ x: 4 }}
              onClick={() => setSelectedCaseId(c.id)}
              className={`w-full text-left p-4 rounded-xl transition-all border ${
                selectedCaseId === c.id 
                  ? 'bg-primary/10 border-primary/50' 
                  : 'bg-white/5 border-transparent hover:border-white/10'
              }`}
            >
              <div className="text-[10px] font-mono text-primary mb-1">{c.id}</div>
              <div className="font-semibold text-sm">{c.title}</div>
              <div className="text-xs text-slate-500 mt-1">{c.sub}</div>
            </motion.button>
          ))}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col p-8 gap-8 overflow-y-auto custom-scrollbar bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950">
        {!selectedCaseId ? (
          <div className="flex-1 flex flex-col items-center justify-center opacity-40">
            <Layers className="w-16 h-16 mb-4 text-slate-600" />
            <p className="text-lg">Select a case from the dashboard to begin investigation</p>
          </div>
        ) : (
          <>
            <header className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold">{selectedCaseId}</h2>
                <div className="flex items-center gap-2 mt-2 text-slate-400">
                  <ShieldCheck className="w-4 h-4 text-success" />
                  <span>3GPP Standard Aligned</span>
                </div>
              </div>
              <button 
                onClick={handleInvestigate}
                disabled={isInvestigating}
                className="flex items-center gap-2 px-6 py-3 bg-primary text-slate-950 font-bold rounded-xl hover:scale-105 transition-transform disabled:opacity-50"
              >
                {isInvestigating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5" />}
                {isInvestigating ? 'Analyzing...' : 'Run Investigation'}
              </button>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Trace Timeline */}
              <section className="glass-card p-6 flex flex-col gap-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold flex items-center gap-2">
                    <Activity className="w-5 h-5 text-primary" />
                    Agentic Trace
                  </h3>
                  {runData && <span className="text-xs font-mono text-slate-500">{runData.runId}</span>}
                </div>
                
                <div className="space-y-4">
                  {!runData ? (
                    <div className="h-40 flex items-center justify-center border-2 border-dashed border-white/5 rounded-xl text-slate-600">
                      Waiting for execution...
                    </div>
                  ) : (
                    runData.trace.map((t, i) => (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        key={i} 
                        className="flex gap-4 group"
                      >
                        <div className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold ${
                            t.node.includes('layer') ? 'bg-accent/20 text-accent' : 'bg-primary/20 text-primary'
                          }`}>
                            {i + 1}
                          </div>
                          {i < runData.trace.length - 1 && <div className="w-px h-full bg-white/10 mt-2" />}
                        </div>
                        <div className="flex-1 pb-4">
                          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">{t.node}</div>
                          <div className="text-sm bg-white/5 p-3 rounded-lg border border-transparent group-hover:border-white/10 transition-all">
                            {t.message}
                          </div>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </section>

              <div className="flex flex-col gap-8">
                {/* Findings */}
                <section className="glass-card p-6 flex flex-col gap-6">
                  <h3 className="text-lg font-bold flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-warning" />
                    Key Findings
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    {runData?.findings.map((f, i) => (
                      <div key={i} className="p-4 bg-yellow-500/5 border border-yellow-500/20 rounded-xl">
                        <div className="font-bold text-sm mb-1">{f.title}</div>
                        <div className="text-xs text-slate-400">{f.detail}</div>
                      </div>
                    ))}
                    {!runData?.findings.length && <div className="text-slate-600 text-sm">No findings yet.</div>}
                  </div>
                </section>

                {/* Chat Interface */}
                <section className="glass-card p-6 flex flex-col h-[400px]">
                  <h3 className="text-lg font-bold flex items-center gap-2 mb-4">
                    <MessageSquare className="w-5 h-5 text-accent" />
                    AI Assistant
                  </h3>
                  <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-2 mb-4">
                    <AnimatePresence>
                      {messages.map((m, i) => (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          key={i}
                          className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[85%] p-4 rounded-2xl text-sm ${
                            m.role === 'user' 
                              ? 'bg-accent text-white rounded-br-none' 
                              : 'bg-white/10 text-slate-200 rounded-bl-none border border-white/5'
                          }`}>
                            {m.content}
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                    {isChatting && (
                      <div className="flex justify-start">
                        <div className="bg-white/10 p-4 rounded-2xl rounded-bl-none animate-pulse text-xs">AI is typing...</div>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendChat()}
                      placeholder="Ask about the RCA..."
                      className="flex-1 bg-black/20 border border-white/10 rounded-xl px-4 text-sm focus:outline-none focus:border-primary/50"
                    />
                    <button 
                      onClick={handleSendChat}
                      className="p-3 bg-accent rounded-xl hover:scale-105 transition-transform"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                </section>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default App;
