import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8000/api',
});

export const getUsecases = () => api.get('/usecases');
export const createCase = (data) => api.post('/cases', data);
export const getCase = (id) => api.get(`/cases/${id}`);
export const investigateCase = (id) => api.post(`/cases/${id}/investigate`);
export const chatCase = (id, message) => api.post(`/cases/${id}/chat`, { message });
export const searchPlaybooks = (q) => api.get(`/search?q=${q}`);

export default api;
