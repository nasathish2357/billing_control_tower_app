# TMForum Catalyst Agentic AI Driven Billing Dispute - Final Pack

## Added refinements
- Added KPI Guide page in left navigation with metric calculation logic.
- Refined Chat into a case assistant with selected-case context, active work queue, richer quick actions, and dynamic responses based on the chosen issue.
- Preserved existing dashboard, agent trace, tool calls, summary narrative, Bills DrillDown, and realistic KPI calibration.

## Files
- `index.html`
- `styles.css`
- `app.js`
- `README.md`
