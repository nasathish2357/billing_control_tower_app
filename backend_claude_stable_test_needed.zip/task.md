# Billing Control Tower - Backend Task Tracker

Last updated: 2026-05-02
Scope: backend only

---

## Current Status

- [x] MVP1 complete and regression-tested.
- [x] MVP2 complete after assessment and fixes.
- [x] MVP2 backend tests pass: `.venv\Scripts\python.exe -m pytest tests -v` -> 21 passed.
- [x] LangGraph approval checkpointing verified with PostgreSQL `AsyncPostgresSaver`.
- [x] KG sanity check completed against the local DB.
- [x] MVP3 **complete**. All 14 phases delivered in two sessions. 2026-05-02.
- [x] test_mvp2.py regression updated: P7/P10 now full_graph, health mvp field accepts "3".

---

## MVP3 Execution Log

### Phase 1 — Planning and Baseline ✅
- [x] Re-read MVP3 sections in `reference/master_prompt/*.txt`.
- [x] Confirmed MVP3 scope with owner (2026-05-02).
- [x] MVP2 regression baseline: 21 tests passing.
- [x] Decided: continue with idempotent `create_all` + seed-time DDL (no Alembic).
- [x] Confirmed: mock data first, then flows.
- [x] Confirmed: backend only, no frontend.

### Phase 10 — Mock Data Expansion ✅
- [x] Added 15 new ORM models to `app/models/models.py`:
  - `Product`, `ProductOffering`, `BillLineItem`
  - `Device`, `PaymentRecord`
  - `UsageEvent`, `MediationRecord`, `RatedUsage`, `PDUSession`
  - `ServiceInventory`, `NetworkFunction`
  - `PartnerAccount`, `PartnerSettlement`
  - `SimulationRun`, `Appointment`
- [x] Extended `Customer` model: `phone`, `address`, `customer_type`.
- [x] Extended `BillingAccount` model: `account_type`, `credit_limit`.
- [x] Created `app/db/seed_mvp3.py` with:
  - [x] 7 new customers (total 10: B2C majority, 2 B2B enterprise, 1 B2B2X MVNO)
  - [x] 9 new billing accounts (total 12, including 2 enterprise multi-account)
  - [x] ~24 historical bills (5 months Nov 2025 – Apr 2026, multiple accounts)
  - [x] 11 bill line items with charge_type, dispute_flag, rated_usage_id linkage
  - [x] 10 products and 10 product offerings
  - [x] 8 devices (iPhone, Samsung, Google Pixel, etc.)
  - [x] 14 payment records (credit card, bank transfer, direct debit)
  - [x] 14 network functions (UPF, AMF, SMF, PCF, NWDAF, CHF, CTF, CGF, SEPP, NEF)
  - [x] 5 PDU sessions (zombie, duplicate, normal, QoS mismatch, roaming)
  - [x] 8 usage events (CDR/xDR: data, voice, roaming, zombie, duplicate, anomaly)
  - [x] 7 mediation records (rated, duplicate, error, raw states)
  - [x] 4 rated usage records (with linkage to bills and mediation records)
  - [x] 8 service inventory records
  - [x] 2 partner accounts (MVNO-X, GlobalRoam)
  - [x] 2 partner settlements (MVNO-X disputed $3,200, GlobalRoam resolved)
  - [x] 2 new trouble tickets (P7, P10)
  - [x] 2 new service problems (P7 CDR gap, P10 multi-domain)
  - [x] DDL patches for new nullable columns on existing tables

### Phase 9 — RAG Completion (partial) ✅
- [x] `data/playbooks/p2_duplicate_charging.md`
- [x] `data/playbooks/p3_zombie_pdu_session.md`
- [x] `data/playbooks/p7_partner_charge_discrepancy.md`
- [x] `data/playbooks/p8_bill_explanation.md`
- [x] `data/playbooks/p10_governed_dispute.md`
- [x] `data/playbooks/audit_governance_policy.md`
- [x] `data/playbooks/human_approval_policy.md`
- [x] `data/playbooks/5g_charging_and_mediation_context.md`
- [ ] `data/playbooks/collections_and_dunning_rules.md` (deferred)
- [ ] `data/playbooks/partner_settlement_rules.md` (deferred)
- [ ] `data/playbooks/qos_slice_entitlement_rules.md` (deferred)
- [ ] `data/playbooks/customer_communication_templates.md` (deferred)
- [ ] `data/playbooks/tmf_api_mock_guidelines.md` (deferred)

### Phase 2 — Full P7 Partner/Wholesale Flow ✅
- [x] `app/components/l4_roaming_exposure.py` — SEPP CDR export, CHF roaming records, NEF evidence
- [x] `app/components/l2_roaming_partner_settlement.py` — retail impact assessment, credit, partner recovery case
- [x] `app/agents/p7_graph.py` — 15-node flow with approval interrupt for high-value retail credits
- [x] Updated P7 use-case seed flow_type to `full_graph` in `app/db/seed.py`
- [x] Wired P7 in `app/api/v1/endpoints.py` (graph_map + full_flow set)
- [x] Updated `/health` mvp field to "3", app version to "3.0.0"
- [ ] Add P7 tests (Phase 14)

### Phase 3 — Full P10 Governed Multi-Team Flow ✅
- [x] `app/agents/p10_graph.py` — 15-node governed flow with cross-domain synchronization
  - L1 orchestrates L2 (BSS), L3 (OSS), L4 (Network) with explicit bounded responsibilities
  - Approval interrupt for enterprise correction ($320) above threshold
  - `synchronize_domain_outcomes` node verifies all 3 domains before case closes
  - `kg_context` used as compact cross-domain completion tracker
- [x] Updated P10 use-case seed flow_type to `full_graph` in `app/db/seed.py`
- [x] Wired P10 in `app/api/v1/endpoints.py` (graph_map + full_flow set)
- [ ] Add P10 tests (Phase 14)

### Phase 8 — KG Completion ✅
- [x] Expanded `app/kg/kg_builder.py` with 11 new MVP3 entity type sections:
  - BillLineItem → Bill (HAS_LINE_ITEM)
  - Product → BillingAccount, ProductOffering → Product
  - Device → Customer, PaymentRecord → BillingAccount
  - UsageEvent → BillingAccount, MediationRecord → UsageEvent, RatedUsage → MediationRecord → Bill
  - PDUSession → BillingAccount, ServiceInventory → Customer/BillingAccount/ProductOffering
  - NetworkFunction (standalone nodes — 5G NF registry)
  - PartnerAccount, PartnerSettlement → PartnerAccount → Issue/ControlCase
- [x] Added 4 new trace queries in `app/kg/kg_queries.py`:
  - `get_customer_billing_context()` — enhanced with device/service counts
  - `get_control_case_impact()` — downstream + upstream traversal with entity buckets
  - `get_bill_to_usage_trace()` — Bill → BillLineItem → RatedUsage → MediationRecord → UsageEvent
  - `get_service_to_nf_trace()` — ServiceInventory → ProductOffering + correlated NFs
- [x] Added 5 new routes in `app/api/v1/kg.py`:
  - `GET /kg/customer/{customer_id}/billing-context`
  - `GET /kg/control-case/{control_case_id}/impact`
  - `GET /kg/trace/bill/{bill_id}`
  - `GET /kg/trace/service/{service_id}`
  - `POST /kg/rebuild` — now returns entity_types breakdown

### Phase 4 — Complete Component Ecosystem ✅
- [x] `l4_roaming_exposure.py` — completed in Phase 2 (P7)
- [x] `l2_roaming_partner_settlement.py` — completed in Phase 2 (P7)
- [x] `app/components/l2_billing_correction.py` — General L2 BSS charge reversal + compensation credit
- [x] `app/components/l1_proactive_risk.py` — L1 proactive risk scorer (PDU zombie, usage anomaly, mediation error signals)

### Phase 5 — Chat Expansion ✅
- [x] 7 new intents added to `app/agents/chat_graph.py`:
  - `schedule_callback`, `dispute_creation`
  - `partner_charge_explanation`, `roaming_charge_explanation`
  - `premium_qos_charge_explanation`, `proactive_risk_summary`, `governed_case_summary`
- [x] Intent-aware system prompts: each intent gets a tailored LLM system prompt
- [x] Fallback responses for all new intents
- [x] `proactive_risk_summary` fetches live L1 risk assessment before LLM call
- [x] Total intents supported: 16

### Phase 6 — Simulation Component ✅
- [x] `app/components/l1_simulation.py` — 7 simulation types (P1–P7 triggers)
- [x] `app/api/v1/simulation.py` — 5 routes (types, inject, status, active, reset)
- [x] Dry-run mode: preview artifacts without DB writes
- [x] Simulation reset: deletes all [SIMULATION] issues and usage events

### Phase 7 — TMF Mock API Expansion ✅
- [x] `app/api/v1/mock_tmf.py` — 17 routes covering:
  - TMF620: Product Catalog (product, productOffering)
  - TMF621: Trouble Ticket (list, get, patch status)
  - TMF638: Service Inventory (list, get)
  - TMF656: Service Problem (list, get)
  - TMF678: Customer Bill (list, get, line-items)
  - TMF688: Event Management (list, hub registration stub)
  - TMF700 proxy: Audit Records

### Phase 11 — Dashboard APIs ✅
- [x] `app/api/v1/dashboard.py` — 5 routes:
  - `GET /dashboard/summary` — system-wide KPIs
  - `GET /dashboard/prebill-risks` — accounts above risk score threshold
  - `GET /dashboard/postbill-disputes` — active disputed bills
  - `GET /dashboard/layer-health` — L1/L2/L3/L4 health with NF breakdown
  - `GET /dashboard/audit-summary` — recent audit traces

### Phase 12 — Governance and Audit Completion ✅
- [x] `app/api/v1/audit.py` — 4 routes:
  - `GET /audit/search` — multi-filter search (control_case_id, action_type, actor, use_case_id)
  - `GET /audit/traces/{trace_id}` — single trace detail
  - `GET /audit/export/{control_case_id}` — full JSON export with Content-Disposition header
  - `GET /audit/actions` — distinct action types + actors

### Phase 13 — Human Approval Hardening ✅
- [x] `approvals.py` approve/reject bodies extended: `approver_id`, `approver_name`, `reason_code`
- [x] Resume endpoint expanded: now supports P1, P4, P5, P6, P7, P9, P10 (all graphs with approval interrupt)
- [x] Notes field enriched with approver metadata for audit trail

### Phase 14 — MVP3 Testing and Hardening ✅
- [x] `tests/test_mvp3.py` — 35 tests covering:
  - MVP3 health check (mvp == "3")
  - All 10 use cases have full_graph flow_type
  - KG rebuild, issue relationships, customer billing context, bill trace
  - Simulation: types, dry_run, active, invalid type (400)
  - TMF Mock: all resource types
  - Dashboard: all 5 routes
  - Audit: search, export, actions
  - Approvals: pending, approve nonexistent (400)
  - Regression: MVP1 issues, use-cases, P2/P7/P10 issue lookup, P8 chat

---

## Folder Structure Notes

- `app/services/` remains the MVP1 service layer used by P2/P3 remediation, P8 chat, and remaining shared/simple logic.
- `app/components/` is valid for MVP2. It contains bounded layer components introduced by the MVP2 prompt.
- MVP2 flows should use `app/components/` for explicit L1/L2/L3 bounded responsibilities.
- MVP3 should continue this pattern and avoid creating another parallel backend structure.

---

## MVP1 - Complete

### Foundation and Infrastructure

- [x] Backend project structure in `backend/`.
- [x] `app/main.py` with async lifespan, logging, CORS, and API router registration.
- [x] `app/config.py` with pydantic-settings configuration.
- [x] Docker and project metadata files: `Dockerfile`, `.dockerignore`, `.gitignore`, `README.md`, `requirements.txt`, `pytest.ini`.

### Database and Models

- [x] Async SQLAlchemy engine/session in `app/db/database.py`.
- [x] MVP1 ORM models: `UseCase`, `Customer`, `BillingAccount`, `Bill`, `Issue`, `ControlCase`, `EvidencePack`, `AuditTrace`.
- [x] MVP1 seed data in `app/db/seed.py`.

### LLM, RAG, and Vector Store

- [x] Vertex AI Gemini provider in `app/llm/gemini_provider.py`.
- [x] Chroma vector store integration in `app/vector_db/vector_store.py`.
- [x] Playbook ingestion in `app/vector_db/ingest_playbooks.py`.

### MVP1 Flows

- [x] P2 full LangGraph remediation flow.
- [x] P3 full LangGraph remediation flow.
- [x] P8 chat/bill explanation flow with SSE and non-streaming helper endpoint.
- [x] P7 and P10 deterministic flows remain available after MVP2.

### MVP1 APIs

- [x] `GET /api/v1/health`
- [x] `GET /api/v1/use-cases`
- [x] `GET /api/v1/issues`
- [x] `GET /api/v1/issues/{issue_id}`
- [x] `POST /api/v1/issues/{issue_id}/remediate`
- [x] `POST /api/v1/chat/stream`
- [x] `POST /api/v1/chat`
- [x] `GET /api/v1/audit-traces/{audit_trace_id}`
- [x] `GET /api/v1/control-cases/{control_case_id}`

### MVP1 Tests

- [x] `tests/test_mvp1.py`
- [x] MVP1 tests pass as part of full backend regression.

---

## MVP2 - Complete

### Database and Models

- [x] Added MVP2 ORM models in `app/models/models.py`:
- [x] `TMFEvent`
- [x] `Approval`
- [x] `ServiceProblem`
- [x] `TroubleTicket`
- [x] `MediationJob`
- [x] `CollectionsHold`
- [x] `CompensationDecision`
- [x] `KGSnapshot`
- [x] Added MVP2 seed data in `app/db/seed_mvp2.py`.
- [x] Updated `UseCase.flow_type` to support MVP2 values:
- [x] P1, P2, P3, P4, P5, P6, P8, P9 -> `full_graph`
- [x] P7, P10 -> `simplified_deterministic`

### Bounded Components

- [x] `app/components/l1_monitoring.py` - event-to-case correlation.
- [x] `app/components/l1_closed_loop_control.py` - explicit MVP2 policy/approval decision component.
- [x] `app/components/l1_audit_governance.py` - richer audit trace writer.
- [x] `app/components/l2_ticketing.py` - trouble ticket and collections-state helpers.
- [x] `app/components/l2_product_entitlement.py` - product, tier, QoS entitlement, surcharge actions.
- [x] `app/components/l2_collections_dunning.py` - hold policy and disputed/undisputed balance handling.
- [x] `app/components/l3_service_problem.py` - service problem and SLA breach evidence.
- [x] `app/components/l3_qos_slice.py` - QoS/slice evidence.
- [x] `app/components/l3_mediation_replay.py` - mediation backlog/replay and bill protection helpers.

### MVP2 LangGraph Flows

- [x] `app/agents/p1_graph.py` - Missing or delayed usage feed.
- [x] `app/agents/p4_graph.py` - QoS/slice entitlement mismatch.
- [x] `app/agents/p5_graph.py` - Service degradation compensation with approval interrupt.
- [x] `app/agents/p6_graph.py` - Collections hold, L2-only.
- [x] `app/agents/p9_graph.py` - Proactive anomaly, KG-correlated.
- [x] `app/agents/deterministic_flow.py` now only covers P7 and P10.
- [x] `app/agents/state.py` remains lightweight and reference-based.
- [x] `app/agents/tool_schemas.py` includes MVP2 shallow tool schemas.

### Human Approval and Checkpointing

- [x] `app/agents/approval_manager.py` supports create, get, pending list, approve, reject, resume.
- [x] `app/agents/checkpoint_setup.py` initializes PostgreSQL `AsyncPostgresSaver`.
- [x] Checkpointer context is kept open for FastAPI app lifespan and closed on shutdown.
- [x] SQLAlchemy-style Postgres URLs are normalized for LangGraph saver compatibility.
- [x] Missing `langgraph-checkpoint-postgres` dependency installed in `backend/.venv`.
- [x] P5 approval/resume verified under FastAPI lifespan.

### Event, Context, Approval, and KG APIs

- [x] `app/api/v1/events.py`
- [x] `app/api/v1/approvals.py`
- [x] `app/api/v1/context.py`
- [x] `app/api/v1/kg.py`
- [x] `app/main.py` registers MVP2 routers.
- [x] `app/api/v1/endpoints.py` routes P1/P4/P5/P6/P9 to full LangGraph flows.

### Chat Expansion

- [x] Added MVP2 chat intents:
- [x] `issue_analysis`
- [x] `remediation_explanation`
- [x] `collections_hold_request`
- [x] `compensation_eligibility_check`
- [x] Streaming endpoint remains `/api/v1/chat/stream`.

### RAG Expansion

- [x] Added playbooks:
- [x] `data/playbooks/p1_missing_usage_feed.md`
- [x] `data/playbooks/p4_qos_slice_mismatch.md`
- [x] `data/playbooks/p5_service_degradation_compensation.md`
- [x] `data/playbooks/p6_collections_hold.md`
- [x] `data/playbooks/p9_proactive_anomaly.md`
- [x] P2/P3/P8 still have inline/fallback playbook support.

### MVP2 Fixes Completed During Assessment

- [x] Fixed PostgresSaver initialization for current `langgraph-checkpoint-postgres` API.
- [x] Added checkpointer shutdown cleanup in `app/main.py`.
- [x] Fixed `postgresql+psycopg://` checkpoint URL compatibility.
- [x] Removed stray unclosed DB session in `p6_graph.py`.
- [x] Updated seed data to report MVP2 flow types correctly.
- [x] Added test coverage for MVP2 flow type labels.
- [x] Added explicit L1 Closed-Loop Control component and wired MVP2 policy nodes to it.

---

## KG Assessment - 2026-05-01

### MVP2 KG Status

- [x] KG is implemented as a NetworkX `DiGraph` derived from PostgreSQL.
- [x] PostgreSQL remains source of truth.
- [x] KG is read-oriented; no transactional graph writes.
- [x] KG rebuilds from DB records and caches for 60 seconds.
- [x] Snapshot metadata is persisted in `kg_snapshots`.
- [x] `GET /api/v1/kg/issue/{issue_id}/relationships` is available.
- [x] `POST /api/v1/kg/rebuild` is available.
- [x] Query helpers exist:
- [x] `get_issue_relationships()`
- [x] `get_customer_billing_context()`
- [x] `find_impacted_entities()`

### Current KG Coverage

- [x] Customer
- [x] BillingAccount
- [x] Bill
- [x] Issue
- [x] ControlCase
- [x] EvidencePack
- [x] AuditTrace
- [x] TMFEvent
- [x] TroubleTicket
- [x] ServiceProblem
- [x] Approval

### KG Sanity Check Result

Command run from `backend/` with Windows selector event loop policy:

```powershell
.venv\Scripts\python.exe - <kg sanity script>
```

Observed local DB result:

- Graph built successfully.
- Nodes: 560
- Edges: 610
- `ISSUE-P5-001` relationships returned 238 total nodes and 237 total edges.
- Relationship types included `HAS_ISSUE`, `HAS_CONTROL_CASE`, `HAS_EVIDENCE`, `HAS_AUDIT`, `REQUIRES_APPROVAL`, `TRIGGERED_ISSUE`, `RELATED_TO_ISSUE`, `RELATES_TO_ISSUE`.
- `CUST-100001` billing context query returned a billing tree.
- `EVT-P9-001` impacted entity query returned 51 impacted nodes.

Note: Counts reflect the current local DB, including test/demo-generated control cases, evidence packs, approvals, snapshots, and audit traces. Fresh seed counts will be smaller.

### KG MVP2 Limitations To Carry Into MVP3

- [ ] No BillLineItem nodes yet.
- [ ] No Product, ProductOffering, Plan, AddOn, Promotion nodes yet.
- [ ] No ServiceInventory, ResourceInventory, Resource, or NetworkFunction nodes yet.
- [ ] No UsageEvent, MediationRecord, RatedUsage, CDR/xDR path yet.
- [ ] No bill-line-item to usage/session trace yet.
- [ ] No similar historical issue lookup yet.
- [ ] No KG API for customer billing context or control-case impact yet, though helper logic exists for customer billing context.

---

## MVP2 Acceptance Criteria

- [x] All MVP1 acceptance criteria still pass.
- [x] P1, P4, P5, P6, and P9 converted from deterministic to full executable flows.
- [x] 8 of 10 use cases are `full_graph`.
- [x] P7 and P10 remain `simplified_deterministic`.
- [x] Event DB APIs available.
- [x] Event simulation available for MVP2 use cases.
- [x] L1 Monitoring can create/trigger control cases from events.
- [x] Human approval APIs work using LangGraph checkpoint interrupt/resume.
- [x] More explicit bounded components exist with clear boundaries.
- [x] NetworkX KG introduced as derived read model from PostgreSQL.
- [x] RAG includes playbooks for P1, P2, P3, P4, P5, P6, P8, and P9 through markdown and fallback content.
- [x] Chat supports MVP2 issue analysis and remediation explanation flows through streaming/non-streaming endpoints.
- [x] Audit traces include evidence/action/approval references.
- [x] Tests pass.

---

## MVP2 Verification Commands

```powershell
cd backend
.venv\Scripts\python.exe -m app.db.seed
.venv\Scripts\python.exe -m app.db.seed_mvp2
.venv\Scripts\python.exe -m pytest tests -v
```

Latest regression result:

- 21 tests passed.
- Non-blocking warnings remain for Pydantic class config, `datetime.utcnow()`, and pytest cache write permission.

---

## MVP3 - Not Started

Do not start coding MVP3 until explicitly requested.

MVP3 goal: complete the original catalyst-grade mock/demo backend by converting the remaining use cases to full flows, expanding component coverage, deepening KG/RAG, adding simulation, broadening TMF-inspired APIs, and hardening governance/audit.

### Phase 1 - MVP3 Planning and Baseline

- [ ] Re-read MVP3 sections in `reference/master_prompt/tmforum_billing_dispute_agentic_ai_3_incremental_mvp_scopes_updated.txt`.
- [ ] Confirm MVP3 scope with owner before implementation begins.
- [ ] Freeze MVP2 regression baseline.
- [ ] Decide whether to add migrations or continue idempotent `create_all` plus seed-time DDL.
- [ ] Define MVP3 demo scenarios and acceptance data.
- [ ] Confirm no frontend work is in scope unless separately requested.

### Phase 2 - Full P7 Partner/Wholesale Flow

- [ ] Add P7 full LangGraph flow: `app/agents/p7_graph.py`.
- [ ] Add L2 partner-charge/roaming trouble ticket step.
- [ ] Add L2 decision for whether partner/network evidence is needed.
- [ ] Add L1 escalation path for cross-domain/partner evidence.
- [ ] Add L4 roaming/exposure evidence component.
- [ ] Add L2 roaming and partner settlement component.
- [ ] Separate retail customer correction from partner settlement recovery.
- [ ] Apply customer-facing correction when needed.
- [ ] Create partner settlement recovery case.
- [ ] Write audit trace linking retail outcome to wholesale recovery.
- [ ] Route P7 through full graph in `/issues/{issue_id}/remediate`.
- [ ] Update use-case seed flow type for P7 to `full_graph`.
- [ ] Add P7 tests.

### Phase 3 - Full P10 Governed Multi-Team Flow

- [ ] Add P10 full LangGraph flow: `app/agents/p10_graph.py`.
- [ ] Create governed control case from event/escalation trigger.
- [ ] Request BSS evidence/actions through L2 orchestrator.
- [ ] Request service evidence/actions through L3 orchestrator.
- [ ] Request network evidence/actions through L4 orchestrator.
- [ ] Enforce owner-layer execution boundaries.
- [ ] Add approval interrupt for high-risk cross-domain actions.
- [ ] Synchronize BSS, OSS, and network outcomes before closure.
- [ ] Write complete evidence/action/approval audit chain.
- [ ] Route P10 through full graph in `/issues/{issue_id}/remediate`.
- [ ] Update use-case seed flow type for P10 to `full_graph`.
- [ ] Add P10 tests.

### Phase 4 - Complete Component Ecosystem

L1 CSP Control Tower:

- [ ] Layer orchestration/master component.
- [ ] Billing Control Tower UI backend support APIs.
- [ ] Monitoring component hardening.
- [ ] Closed-Loop Control component hardening.
- [ ] Party and Identity component.
- [ ] Human-in-the-Loop Approval component hardening.
- [ ] Simulation component.
- [ ] Audit and Compliance component.

L2 BSS Revenue, Care, and Back Office:

- [ ] L2 BSS orchestration component.
- [ ] Bill Insight component.
- [ ] Usage Integrity component.
- [ ] Backoffice Adjustment component.
- [ ] Scheduling and Follow-up component.
- [ ] Roaming and Partner Settlement component.

L3 OSS / Service Assurance and Mediation Control:

- [ ] L3 OSS orchestration component.
- [ ] Service Topology component.
- [ ] Troubleshooting component.
- [ ] Harden Service Problem, QoS/Slice, and Mediation Replay components.

L4 Network / Resource / Charging Trigger Layer:

- [ ] L4 Network orchestration component.
- [ ] Resource RCA component.
- [ ] Core Session component.
- [ ] Charging NF Correlation component.
- [ ] Remediation Orchestrator component.
- [ ] Roaming / Exposure component.

Component rules:

- [ ] Each component documents owner layer.
- [ ] Each component documents allowed tools.
- [ ] Each component documents forbidden actions.
- [ ] L1 communicates with owner-layer orchestrators, not arbitrary sub-components.
- [ ] Sub-components do not bypass their layer orchestrator for cross-layer actions.
- [ ] Tool schemas remain shallow.

### Phase 5 - Chat and Self-Service Expansion

- [ ] Add `schedule_callback` intent.
- [ ] Add `schedule_appointment` intent.
- [ ] Add `paper_bill_to_ebill` intent.
- [ ] Add `dispute_creation` intent.
- [ ] Add `dispute_update` intent.
- [ ] Add `partner_charge_explanation` intent.
- [ ] Add `roaming_charge_explanation` intent.
- [ ] Add `premium_qos_charge_explanation` intent.
- [ ] Add `proactive_risk_summary` intent.
- [ ] Add `governed_case_summary` intent.
- [ ] Add `billing_policy_qa_limited_to_playbooks` intent.
- [ ] Preserve streaming-first behavior through `/api/v1/chat/stream`.
- [ ] Audit chat intent, tools used, evidence references, and final response summary.
- [ ] Enforce guardrails against raw sensitive payload exposure.
- [ ] Prevent high-risk financial actions from chat without approval.

### Phase 6 - L1 Simulation Component

- [ ] Add L1 simulation component.
- [ ] Add simulation run model/table.
- [ ] Inject events for P1-P10.
- [ ] Support dry-run remediation without changing issue state.
- [ ] Compare simulated action plan vs executed action plan.
- [ ] Validate policy gating.
- [ ] Generate synthetic evidence packs for demo scenarios.
- [ ] Reset mock dataset to baseline.
- [ ] Add `POST /api/v1/simulation/use-cases/{use_case_id}/inject`.
- [ ] Add `POST /api/v1/simulation/use-cases/{use_case_id}/dry-run`.
- [ ] Add `POST /api/v1/simulation/reset`.
- [ ] Add `GET /api/v1/simulation/runs/{simulation_run_id}`.
- [ ] Add simulation tests.

### Phase 7 - TMF-Inspired Mock API Expansion

L2 mock APIs:

- [ ] TMF621 TroubleTicket.
- [ ] TMF678 CustomerBill.
- [ ] TMF629 Customer.
- [ ] TMF632 Party.
- [ ] TMF635 ProductUsage.
- [ ] TMF666 Account.
- [ ] TMF646 Appointment.
- [ ] TMF620 Product Catalog.
- [ ] TMF637 Product Inventory.
- [ ] TMF679 Product Offering Qualification.

L3 mock APIs:

- [ ] TMF656 ServiceProblem.
- [ ] TMF638 ServiceInventory.
- [ ] TMF639 ResourceInventory.
- [ ] TMF628 Performance.
- [ ] TMF640 ServiceActivation.
- [ ] TMF688 Event.

L4 mock APIs:

- [ ] TMF642 Alarm.
- [ ] TMF628 Performance.
- [ ] TMF639 ResourceInventory.
- [ ] TMF702 ResourceActivation.
- [ ] TMF688 Event.

Route candidates:

- [ ] `GET /api/v1/mock-tmf/trouble-ticket/{ticket_id}`
- [ ] `PATCH /api/v1/mock-tmf/trouble-ticket/{ticket_id}`
- [ ] `GET /api/v1/mock-tmf/customer-bill/{bill_id}`
- [ ] `GET /api/v1/mock-tmf/product-usage`
- [ ] `GET /api/v1/mock-tmf/service-problem/{service_problem_id}`
- [ ] `POST /api/v1/mock-tmf/event`
- [ ] `GET /api/v1/mock-tmf/alarm`
- [ ] `GET /api/v1/mock-tmf/performance`
- [ ] `POST /api/v1/mock-tmf/resource-activation`

### Phase 8 - KG Completion

- [ ] Expand KG nodes for Party.
- [ ] Expand KG nodes for ServiceAccount.
- [ ] Expand KG nodes for BillLineItem.
- [ ] Expand KG nodes for Product, ProductOffering, Plan, Bundle, AddOn, Promotion.
- [ ] Expand KG nodes for Device.
- [ ] Expand KG nodes for Service and ServiceInventory.
- [ ] Expand KG nodes for Resource and ResourceInventory.
- [ ] Expand KG nodes for NetworkFunction, UPF, AMF, SMF, PCF, NWDAF, CTF, CHF, CGF.
- [ ] Expand KG nodes for CDR/xDR, RawUsageEvent, MediationRecord, RatedUsage.
- [ ] Expand KG nodes for RemediationAction.
- [ ] Add customer-to-bill-to-usage-to-session trace query.
- [ ] Add bill line item to rated usage to mediation record trace query.
- [ ] Add mediation record to raw network event trace query.
- [ ] Add service to resource to network function trace query.
- [ ] Add trouble ticket to service problem to control case trace query.
- [ ] Add similar historical issue lookup query.
- [ ] Add impacted customers/services/resources query for event.
- [ ] Add `GET /api/v1/kg/customer/{customer_id}/billing-context`.
- [ ] Add `GET /api/v1/kg/control-case/{control_case_id}/impact`.
- [ ] Add KG path tests.

### Phase 9 - RAG Completion

Use-case playbooks:

- [ ] `p2_duplicate_charging.md`
- [ ] `p3_zombie_pdu_session.md`
- [ ] `p7_partner_charge_discrepancy.md`
- [ ] `p8_bill_explanation.md`
- [ ] `p10_governed_dispute.md`

Policy and support playbooks:

- [ ] `audit_governance_policy.md`
- [ ] `human_approval_policy.md`
- [ ] `customer_communication_templates.md`
- [ ] `tmf_api_mock_guidelines.md`
- [ ] `5g_charging_and_mediation_context.md`
- [ ] `collections_and_dunning_rules.md`
- [ ] `partner_settlement_rules.md`
- [ ] `qos_slice_entitlement_rules.md`

Retrieval behavior:

- [ ] Layer-specific retrieval.
- [ ] Use-case-specific retrieval.
- [ ] Policy retrieval.
- [ ] Customer communication template retrieval.
- [ ] Evidence checklist retrieval.
- [ ] Tests for correct playbook retrieval.

### Phase 10 - Mock Data Completion

- [ ] Expand to 10-20 customers.
- [ ] Add multiple billing accounts.
- [ ] Add B2C majority plus 1-2 B2B/B2B2X examples.
- [ ] Add previous 3-6 months of bills.
- [ ] Add product plans, offers, promotions, add-ons, devices, VAS.
- [ ] Add payment details and payment history.
- [ ] Add address/contact/consent details.
- [ ] Add usage details and rated usage.
- [ ] Add CDR/xDR examples.
- [ ] Add raw mediation examples.
- [ ] Add network usage/event examples.
- [ ] Add charging trigger examples.
- [ ] Add PDU session examples.
- [ ] Add UPF/SMF/AMF/PCF/NWDAF evidence.
- [ ] Add CHF/CTF/CGF references.
- [ ] Add service and resource topology.
- [ ] Add alarms and performance metrics.
- [ ] Add trouble tickets and service problems.
- [ ] Add approval records.
- [ ] Add simulation runs.
- [ ] Add audit traces.

### Phase 11 - API Additions

Dashboard:

- [ ] `GET /api/v1/dashboard/summary`
- [ ] `GET /api/v1/dashboard/prebill-risks`
- [ ] `GET /api/v1/dashboard/postbill-disputes`
- [ ] `GET /api/v1/dashboard/layer-health`
- [ ] `GET /api/v1/dashboard/audit-summary`

Appointments/self-service:

- [ ] `POST /api/v1/self-service/ebill`
- [ ] `POST /api/v1/appointments`
- [ ] `GET /api/v1/appointments/{appointment_id}`

Evidence and KG:

- [ ] `GET /api/v1/evidence-packs/{evidence_pack_id}`
- [ ] `GET /api/v1/kg/customer/{customer_id}/billing-context`
- [ ] `GET /api/v1/kg/control-case/{control_case_id}/impact`

Audit:

- [ ] `GET /api/v1/audit-traces`
- [ ] `GET /api/v1/audit-traces/by-issue/{issue_id}`
- [ ] `GET /api/v1/audit-traces/by-control-case/{control_case_id}`
- [ ] `GET /api/v1/audit-traces/{audit_trace_id}/export`

### Phase 12 - Governance and Audit Completion

- [ ] Audit prompt summaries.
- [ ] Audit tool calls.
- [ ] Audit evidence references.
- [ ] Audit policy decisions.
- [ ] Audit human approvals and rejections.
- [ ] Audit payload redaction status.
- [ ] Audit remediation actions.
- [ ] Audit rollback actions if any.
- [ ] Audit final outcomes.
- [ ] Audit customer communication summaries.
- [ ] Audit streaming chat event summaries.
- [ ] Add audit search by issue, control case, customer, action type, and component.
- [ ] Add audit JSON export.

### Phase 13 - Human Approval Completion

- [ ] Add approver metadata.
- [ ] Add approval expiry.
- [ ] Add policy reason codes.
- [ ] Add approval decision audit trail.
- [ ] Optional: add multi-level approval for very high impact actions.
- [ ] Optional: add approval dry-run explanation.
- [ ] Ensure approve/reject/resume remains checkpoint-backed.

### Phase 14 - MVP3 Testing and Hardening

- [ ] All MVP1 and MVP2 tests still pass.
- [ ] P7 full partner discrepancy flow works.
- [ ] P10 full governed orchestration flow works.
- [ ] All 10 use cases are `full_graph`.
- [ ] Simulation inject works for P1-P10.
- [ ] Simulation dry-run works.
- [ ] Chat supports appointment scheduling via streaming.
- [ ] Chat supports paper bill to eBill via streaming.
- [ ] Chat supports dispute creation/update via streaming.
- [ ] KG relationship APIs return expected cross-domain paths.
- [ ] RAG retrieves correct playbooks for all use cases.
- [ ] Approval resume works from checkpointed thread ID.
- [ ] Audit export works.
- [ ] Mock TMF APIs return realistic payloads.
- [ ] Gemini provider works with shallow tool schemas.
- [ ] Dockerized backend runs reliably.
- [ ] README includes demo scripts for all 10 use cases.

### MVP3 Acceptance Criteria

- [ ] All MVP1 and MVP2 acceptance criteria still pass.
- [ ] All 10 use cases are full executable flows.
- [ ] P7 and P10 are fully implemented.
- [ ] Complete original component ecosystem is represented with bounded components.
- [ ] L1 Simulation component is implemented.
- [ ] L1 Audit and Compliance component is implemented as first-class component.
- [ ] Human approval flow supports approve/reject/resume using LangGraph checkpointer.
- [ ] Chat supports original intended capabilities including limited self-service through streaming.
- [ ] KG supports cross-domain reasoning paths as derived read model from PostgreSQL.
- [ ] RAG includes all use case and policy playbooks.
- [ ] Mock data covers B2C and limited B2B/B2B2X examples.
- [ ] TMF-inspired mock API coverage is broad enough for demo/testing.
- [ ] Event DB and Audit DB support traceable cross-domain flows.
- [ ] Dockerized backend runs reliably.
- [ ] Test suite passes.
- [ ] README includes demo scripts for all 10 use cases.

