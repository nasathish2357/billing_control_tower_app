# P4 — QoS or Slice Entitlement Mismatch with Premium Charging

## Symptoms
- Customer billed for premium slice/5G tier but experienced standard or degraded throughput.
- NSSAI configured on UPF/SMF does not match the NSSAI in the customer's subscription entitlement.
- Customer complaints about slow speeds while paying premium rate.
- NWDAF reports persistent QoS shortfall across the billing period.

## Evidence Checklist
- [ ] L2: Customer entitlement — plan name, promised throughput (Mbps), NSSAI, monthly surcharge.
- [ ] L3: NWDAF QoS metrics — average and peak throughput, packet loss, latency, confidence score.
- [ ] L4: Slice/NSSAI configuration on SMF/PCF — active vs promised NSSAI.
- [ ] L2: Premium surcharge amount billed for the affected period.

## Layer Ownership Rules
- **L2**: Validates commercial entitlement, owns surcharge removal action.
- **L3**: Provides QoS correlation evidence (NWDAF).
- **L4**: Confirms slice configuration (NSSAI active on SMF/PCF).
- **L1**: Orchestrates evidence gathering, evaluates mismatch, decides action.

## Allowed Actions
- L2: Remove premium surcharge for period(s) where mismatch is confirmed.
- L2: Issue credit for overbilling during mismatch period.
- L3: Initiate slice re-configuration recommendation (advisory only — L4 executes).

## Approval Thresholds
- Surcharge removal: auto-allowed when mismatch > 20% shortfall or NSSAI mismatch confirmed.
- Credit above HUMAN_APPROVAL_CREDIT_THRESHOLD → approval required.

## Customer Communication Guidance
- Acknowledge the QoS shortfall proactively.
- Confirm surcharge removal and estimated credit timeline (1–2 billing cycles).
- Advise that slice configuration has been reviewed.

## Audit Requirements
- Log: entitlement record, QoS metrics (avg/peak Mbps, NSSAI), mismatch %, surcharge amount.
- Log: adjustment ID and amount removed.
- Log: NWDAF confidence score and measurement period.
