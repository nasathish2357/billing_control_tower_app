# P2 — Duplicate Charging / Duplicate Usage Rating

## Use Case Summary
Customer is charged twice for the same usage event due to a mediation or rating engine fault. A CDR is submitted to the rating engine more than once, producing a duplicate bill line item.

## Symptoms
- Customer bill shows two identical or near-identical line items for the same session
- Billing complaint referencing two data charges on the same date and time
- Internal mediation alert: duplicate CDR ID submitted to rating engine
- Two rated usage records with the same session_id or CDR reference
- Bill amount is exactly double what usage data justifies

## Root Cause Categories
1. **Mediation engine fault**: CDR re-submitted after a pipeline restart without deduplication check
2. **Rating engine idempotency failure**: Rating engine accepted same CDR twice
3. **CGF/CTF double-trigger**: Charging gateway forwarded the same CDR on two separate occasions
4. **Bill run error**: Batch billing job included same usage file twice

## Evidence Checklist

### L4 — Network / Charging NF
- [ ] CHF/CTF logs confirming single charging event origin
- [ ] Session-level CDR record confirming one data session
- [ ] Confirm only one charging trigger was issued for the session
- [ ] UPF session record confirming single session lifetime

### L3 — Mediation / OSS
- [ ] Mediation record status: check for `duplicate` flag on MediationRecord
- [ ] Compare original CDR ID vs duplicate CDR ID
- [ ] Confirm mediation pipeline restart event if applicable
- [ ] Rating attempt count > 1 on MediationRecord indicates re-submission

### L2 — BSS
- [ ] Bill line items: verify two line items reference same session_id
- [ ] RatedUsage records: confirm duplicate amount matches original
- [ ] Bill payload: `dispute_flag: true` on one of the duplicate line items
- [ ] Adjustment eligibility: confirm credit amount = duplicate charge amount

## Layer Ownership Rules
| Action | Owner Layer |
|---|---|
| Gather CDR/charging evidence | L4 |
| Confirm mediation dedup failure | L3 |
| Apply credit/rebill | L2 |
| Create audit trace | L1 |
| Escalate if credit > threshold | L1 → Human approval |

## Forbidden Actions
- L3/L4 must not directly modify bill or apply credits
- L2 must not request L4 session teardown (session is already ended)
- Do not reverse original charge; only credit the duplicate amount

## Allowed Actions
- L4: retrieve CHF logs, confirm single session origin
- L3: flag mediation record as duplicate, provide dedup evidence
- L2: apply credit equal to duplicate amount, update bill line item status
- L2: create rebill adjustment record

## Approval Thresholds
- Auto-remediation: credit ≤ $50 with clear duplicate evidence
- Human approval required: credit > $50, or when dedup evidence is ambiguous
- Escalate to L1: when multiple customers are affected by the same batch error

## Customer Communication Guidance
> "We identified a duplicate charge of [amount] on your [date] bill related to a [service] session. We have applied a credit of [amount] which will appear on your next statement. We apologise for the inconvenience."

## Audit Requirements
- Record: duplicate CDR IDs, original vs duplicate MediationRecord IDs
- Record: credit amount applied and approval status
- Record: L3 mediation evidence summary
- Record: L4 CHF evidence reference

## Typical Resolution Timeline
- Auto-remediation: < 5 minutes
- With human approval: < 24 hours
- Bulk correction (multiple customers): < 48 hours
