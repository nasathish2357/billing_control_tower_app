# P3 — Zombie PDU Session Causing Unfair Data Charging

## Use Case Summary
A ghost (zombie) PDU session persists in the network after the customer's device has disconnected. The UPF continues to accrue data charges against the session even though no actual data is consumed. The customer is billed for data they did not use.

## Symptoms
- Customer reports data charges far exceeding their typical usage pattern
- PDU session record shows `status: zombie` with no end_time
- UPF session active for 24–72+ hours after device last seen on network
- Data volume on session is non-zero but device was offline
- SMF did not receive session release from device (UE), causing cleanup failure
- Bill line item: large data charge for a session the customer was unaware of

## Root Cause Categories
1. **UE-triggered release failure**: Device powered off without proper PDU session release
2. **Network node failure**: AMF/SMF node restart dropped session state without cleanup
3. **UPF session anchor stuck**: UPF session anchor not removed after SMF context loss
4. **Idle timer not enforced**: PCF idle session policy not applied to terminate orphaned session

## Evidence Checklist

### L4 — Network / Charging NF
- [ ] UPF session record: confirm session active, no data plane traffic
- [ ] SMF session record: confirm session context exists without UE registration
- [ ] AMF record: confirm UE registration status (UE is deregistered)
- [ ] PCF: confirm idle session policy was or was not applied
- [ ] CHF charging record: confirm charging trigger fired for zero-usage session
- [ ] NWDAF: confirm anomaly pattern (data billed, device offline)

### L3 — Service / Mediation
- [ ] Mediation record: CDR duration vs actual UE activity window
- [ ] Session start/end timestamps vs device disconnect time
- [ ] Confirm no equivalent data usage in L4 traffic logs

### L2 — BSS
- [ ] Bill line item referencing zombie session_id
- [ ] Charged data volume vs customer's typical daily usage
- [ ] Correction eligibility: full or partial credit for zombie-charged amount

## Layer Ownership Rules
| Action | Owner Layer |
|---|---|
| Confirm zombie session evidence | L4 |
| Execute session cleanup (mock) | L4 |
| Validate mediation CDR | L3 |
| Apply billing correction | L2 |
| Create audit trace | L1 |

## Forbidden Actions
- L2 must not execute network session cleanup
- L3 must not apply billing credits
- L1 must not directly modify UPF session state

## Allowed Actions
- L4: confirm zombie session status, execute mock session cleanup, retrieve UPF/SMF/AMF evidence
- L3: pull mediation record, confirm CDR covers zero-usage period
- L2: apply credit/rebill for full zombie-charged amount
- L2: update BillLineItem dispute_flag

## Approval Thresholds
- Auto-remediation: credit ≤ $50 with confirmed zombie session evidence
- Human approval required: credit > $50 or if session evidence is inconclusive
- Always escalate: if multiple subscribers affected by same UPF node issue

## Customer Communication Guidance
> "We identified that a data session on your account (Session ID: [session_id]) continued to run after your device was offline. This resulted in an unfair data charge of [amount]. We have applied a full credit of [amount] and have resolved the underlying network session. Your corrected bill will reflect this adjustment."

## Audit Requirements
- Record: zombie session ID, UPF node, duration, charged volume vs actual usage
- Record: L4 session cleanup action reference
- Record: L3 mediation CDR evidence
- Record: credit amount and billing correction reference

## Typical Resolution Timeline
- Auto-remediation with confirmed evidence: < 10 minutes
- With human approval: < 24 hours
