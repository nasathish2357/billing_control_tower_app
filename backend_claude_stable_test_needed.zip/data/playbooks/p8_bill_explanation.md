# P8 — Confusing Invoice with Technically Valid but Opaque Charges

## Use Case Summary
A customer contacts support because their bill is significantly higher than expected, but all charges are technically correct. The customer cannot understand complex telecom charges such as roaming, add-ons, QoS surcharges, or proration. The AI generates a clear, plain-language explanation without triggering an incorrect dispute.

## Symptoms
- Customer query: "Why is my bill higher this month?"
- Bill amount increased by > 20% vs previous month
- No actual billing error — charges are technically valid
- Customer confused by: roaming line items, add-on activations, usage overages, prorated charges
- Customer cannot correlate bill line items to their usage events

## Common Charge Confusion Scenarios
1. **International roaming**: Customer used data/voice abroad; roaming charges apply
2. **Add-on mid-cycle activation**: Add-on activated mid-month; prorated charge appears
3. **Data overage**: Customer exceeded plan data allowance; overage rate applied
4. **Premium slice surcharge**: QoS/slice add-on charged separately from base plan
5. **Previous month adjustment**: Credit or debit from prior dispute resolution
6. **Early termination or plan change**: Prorated charges from plan switch
7. **Device instalment**: Monthly device repayment appearing for first time

## Evidence Checklist (Bill Explanation Flow)

### L2 — BSS / Bill Insight
- [ ] Current bill: all line items, amounts, billing period
- [ ] Previous 2–3 bills: compare amount trends
- [ ] Bill payload: line items with charge_type (recurring, usage, roaming, tax, adjustment)
- [ ] Product offerings: plan details, allowances, overage rates
- [ ] Payment history: confirm previous payments cleared

### L3 — Usage (context only, no action)
- [ ] Usage summary: data consumed, roaming data consumed (for context)
- [ ] Session summary: confirm legitimate usage behind charges (no dispute trigger)

## Explanation Generation Rules
- Use plain language; avoid telecom jargon in customer-facing explanation
- Identify the specific line item(s) driving the increase
- Explain each charge category with amount: recurring plan, roaming, usage, add-on, tax
- Do not apologise for correct charges; explain and educate
- If a discrepancy is discovered during explanation, escalate to remediation flow

## Escalation Trigger
If during bill explanation a genuine error is detected (e.g., duplicate charge, zombie session, unauthorised add-on), escalate immediately to the appropriate remediation use case (P2, P3, P4, etc.) and notify the customer.

## Layer Ownership Rules
| Action | Owner Layer |
|---|---|
| Retrieve bill and line items | L2 |
| Retrieve previous bills | L2 |
| Generate plain-language explanation | L1 (LLM node) |
| Determine escalation need | L1 |
| Retrieve usage context | L3 (read-only) |
| Write audit trace | L1 |

## Forbidden Actions
- Do not apply any credits or adjustments during explanation flow unless escalation is triggered
- Do not expose raw CDR IDs, session IDs, or internal system references in customer explanation
- Do not deny or minimise valid charges
- Do not initiate a dispute without customer consent

## Streaming Events (SSE)
The explanation is delivered as a stream:
1. `conversation_started` — session initialised
2. `intent_detected` — `bill_explanation`
3. `tool_started` — loading current bill
4. `tool_completed` — bill loaded
5. `tool_started` — loading previous bills
6. `tool_completed` — comparison ready
7. `token` — streaming explanation text
8. `audit_written` — audit trace created
9. `final` — full explanation delivered

## Customer Communication Template
> "Your [month] bill of [amount] is [difference] higher than last month's [previous_amount].
>
> Here's what changed:
> - **[Charge type]**: [amount] — [plain language reason]
> - **[Charge type]**: [amount] — [plain language reason]
>
> Your base plan charge remained the same at [plan_amount].
>
> Is there anything specific you'd like me to explain further?"

## Audit Requirements
- Record: bill_id, billing_period, amount, previous amount
- Record: line items summarised (no raw payload exposed)
- Record: explanation generated (summary only)
- Record: escalation decision (escalated or not)
- Record: customer channel (chat, phone, web portal)
