# P6 — Collections Hold Required During Billing Dispute

## Symptoms
- Customer formally disputes an invoice or line item charge.
- Collections / dunning action is active or imminent for the disputed account.
- Risk of customer credit impact while dispute is being investigated.

## Evidence Checklist
- [ ] L2: Trouble Ticket — dispute type, disputed charge reference.
- [ ] L2: Collections state — dunning stage, overdue days, total balance.
- [ ] L2: Disputed amount vs total balance.
- [ ] L2: Undisputed portion that remains collectible.

## Layer Ownership Rules
- **L2**: Owns all actions for P6 — dispute registration, hold, debt separation.
- **L1**: Should not be involved unless cross-domain evidence is explicitly required.
- **L3 / L4**: Not involved in P6 unless billing discrepancy requires network proof.

## Allowed Actions
- L2: Open Trouble Ticket for the billing dispute.
- L2: Apply collections hold on the disputed portion of the balance.
- L2: Pause dunning for the disputed portion only.
- L2: Allow undisputed balance to continue through normal collections.
- L2: Separate disputed from undisputed debt in the collections system.

## Approval Thresholds
- Collections hold: auto-allowed for all amounts (protecting customer during dispute).
- Hold release: requires resolution of the underlying dispute.

## Customer Communication Guidance
- Confirm the dispute has been registered and a ticket opened.
- Confirm that collections actions are paused for the disputed portion.
- Advise on expected resolution timeline (typically 5–10 business days).
- Remind customer that undisputed portions remain due.

## Audit Requirements
- Log: Trouble Ticket ID, disputed amount, undisputed amount.
- Log: Collections hold ID and policy basis.
- Log: Dunning stage at time of hold.
- Log: Debt separation decision.
