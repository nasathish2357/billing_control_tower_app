# Collections and Dunning Rules

## Purpose
Governs when dunning (collections escalation) must be paused, modified, or resumed during active billing disputes. Prevents unjust collections proceedings against customers with legitimate disputes in flight.

## Core Rule: Collections Hold During Dispute
If a customer has raised a formal billing dispute (Issue with use_case_id P6 or any open dispute flag), the dunning process for the **disputed portion** of the balance must be paused immediately.

- **Undisputed balance**: Continue normal dunning on the undisputed portion.
- **Disputed balance**: Place on `CollectionsHold` until dispute is resolved.
- **Total balance suspension**: Only if total bill is in dispute and cannot be separated.

## Dunning Stage Definitions
| Stage | Action | Hold Allowed |
|---|---|---|
| `first_notice` | Email/SMS reminder | Yes — hold immediately |
| `second_notice` | Formal written notice | Yes — hold immediately |
| `pre_legal` | Final notice before legal | Yes — hold immediately |
| `legal` | Legal proceedings initiated | Requires manager escalation |
| `debt_collection` | Transferred to agency | Requires senior approval |

## CollectionsHold Lifecycle
1. **Create hold**: `CollectionsHold.status = "active"`, link to `issue_id`
2. **Dispute resolved in customer favour**: Release hold, apply credit, resume on zero balance
3. **Dispute rejected**: Release hold, resume dunning from current stage
4. **Partial resolution**: Hold released on credited amount; dunning resumes on remaining

## Layer Ownership
| Action | Owner |
|---|---|
| Detect dunning risk from dispute event | L1 Monitoring |
| Create/manage CollectionsHold record | L2 Collections & Dunning |
| Validate undisputed balance separation | L2 BSS |
| Audit hold create/release | L1 Audit & Compliance |
| Escalate to legal stage hold | L1 → Human approval |

## Forbidden Actions
- Never progress dunning on a balance with an active `CollectionsHold`
- Never disclose legal action while hold is active
- Never transfer disputed balance to a debt collection agency without senior approval
- L3/L4 components must not modify customer payment or dunning state

## Approval Requirements
- Dunning hold for disputes under $500: auto-apply
- Dunning hold for disputes $500–$5,000: L2 manager notification
- Legal stage hold: human approval required
- Debt collection agency hold: senior manager approval required

## Customer Communication Guidance
> "We have placed your account on a billing dispute hold. No collections action will be taken on the disputed amount of [amount] while your dispute reference [id] is under review. Your next statement will clearly show the held balance separately."

## Audit Requirements
- Log: `CollectionsHold` ID, linked `issue_id`, held amount, hold start timestamp
- Log: undisputed balance that continues in normal dunning
- Log: hold release reason (resolved/rejected/partial) and timestamp
- Log: approver ID if escalation required
