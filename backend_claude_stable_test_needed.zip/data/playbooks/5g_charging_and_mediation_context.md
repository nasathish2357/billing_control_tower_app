# 5G Charging and Mediation Context

## Overview
This playbook provides background on 5G charging architecture and mediation concepts used across all P1–P10 use cases. It is used for RAG retrieval when agents need domain context on network charging and mediation.

## 5G Charging Architecture (3GPP TS 32.240 / 32.290)

### Online Charging (OCS / CHF)
- **CHF** (Charging Function): The 5G equivalent of the OCS. Handles real-time credit control.
- **Nchf interface**: Used by SMF/PCF/AMF to communicate with CHF for online charging
- **Credit reservation**: CHF grants credit units before data is consumed
- **Final report**: SMF sends final usage report to CHF when session ends
- **Re-authorisation**: CHF may request re-auth if credit nears exhaustion

### Offline Charging (CDR-based / CGF)
- **CTF** (Charging Trigger Function): Embedded in SMF/UPF, generates CDRs when trigger events occur
- **CGF** (Charging Gateway Function): Collects CDRs from CTF, validates, and forwards to mediation
- **CDR** (Charging Data Record): Structured record of session usage (duration, volume, location, QoS)
- **xDR** (extended Data Record): Broader term for any charging data record (includes CDR, EDR, SDR)

### Network Functions Involved in Charging
| NF | Role |
|---|---|
| UPF | User Plane Function — forwards data, reports usage to SMF |
| SMF | Session Management Function — manages PDU sessions, triggers charging |
| AMF | Access and Mobility Management — handles UE registration, mobility |
| PCF | Policy Control Function — enforces QoS policies, slice policies |
| CHF | Charging Function — online credit control |
| CTF | Charging Trigger Function — CDR generation |
| CGF | Charging Gateway Function — CDR collection and forwarding |
| NWDAF | Network Data Analytics Function — anomaly detection, slice analytics |
| SEPP | Security Edge Protection Proxy — roaming interface (N32) |
| NEF | Network Exposure Function — API exposure to partners/MVNOs |

## PDU Session Lifecycle

```
UE attaches → AMF registers UE → SMF creates PDU session →
UPF allocates tunnel → CHF authorises credit → Data flows →
SMF receives session release → CHF final usage report →
CTF generates CDR → CGF forwards to mediation → Rating engine rates CDR → Bill line item created
```

## Common Failure Points

### Zombie Session (P3)
- UE disconnects without sending PDU session release
- SMF does not receive release → session stays open in UPF
- UPF continues counting usage (even if zero)
- CTF keeps generating CDRs → CGF → Mediation → Bill
- Fix: SMF must detect idle session, initiate N4 session release on UPF

### Duplicate CDR (P2)
- CGF forwards same CDR twice to mediation due to pipeline restart
- Mediation engine lacks idempotency check → both CDRs rated
- Rating engine produces two identical RatedUsage records → two BillLineItems
- Fix: mediation dedup check on CDR ID; credit the duplicate rated amount

### Missing Usage Feed (P1)
- CDR delayed in CGF or mediation pipeline
- Bill run executes before CDR arrives → usage missing from bill
- Late CDR arrives after bill dispatch → next bill or adjustment needed
- Fix: mediation replay of delayed CDRs; bill protection hold on affected period

### QoS Mismatch (P4)
- PCF policies misconfigured: wrong NSSAI applied to session
- UE gets standard QoS but CHF bills premium slice surcharge
- SMF session context shows wrong slice ID
- Fix: PCF policy correction; L2 reverses premium surcharge

## Mediation Pipeline

```
CDR (from CTF/CGF) → Mediation Engine →
  [Dedup check] → [Format validation] → [Enrichment] →
  [Correlation] → Rating Engine → RatedUsage → Bill
```

### Mediation Record Statuses
- `raw`: CDR received, not yet processed
- `processing`: currently in mediation pipeline
- `rated`: successfully rated; amount applied to bill
- `duplicate`: flagged as duplicate of existing CDR (not re-rated)
- `error`: mediation or rating failure; requires manual review

## Roaming (SEPP / N32 Interface)
- Home CSP ↔ Visited Network via N32 (SEPP-to-SEPP)
- Visited network sends CDRs to home network via TAP (Transfer Account Procedure) files
- TAP files contain roaming CDRs for settlement between operators
- Discrepancies arise when TAP files are incomplete, delayed, or processed differently

## Slice / QoS Parameters
- **NSSAI**: Network Slice Selection Assistance Information (identifies slice)
  - Format: SST-SD (e.g., 01-000001 = eMBB slice, 01-000002 = standard)
- **QFI**: QoS Flow Identifier (identifies QoS within a slice)
- **GBR**: Guaranteed Bit Rate — premium slice guarantee
- **AMBR**: Aggregate Maximum Bit Rate — total UE throughput cap
- **5QI**: 5G QoS Indicator — standardised QoS class

## Key IDs for Traceability
| ID Type | Description |
|---|---|
| IMSI | International Mobile Subscriber Identity — subscriber identifier |
| IMEI | International Mobile Equipment Identity — device identifier |
| Session ID | PDU session identifier (per SMF session) |
| CDR ID | Unique CDR identifier from CTF |
| MR ID | MediationRecord ID in billing system |
| RU ID | RatedUsage ID after rating |
| BLI ID | BillLineItem ID on customer bill |
