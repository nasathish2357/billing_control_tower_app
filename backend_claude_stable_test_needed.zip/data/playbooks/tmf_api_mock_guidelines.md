# TMF API Mock Guidelines

## Purpose
Documents the TMF Open API specifications implemented as mock endpoints in this system, the data each endpoint returns, and how AI agents should use these APIs during evidence gathering and remediation flows.

## Implemented TMF Mock APIs

### TMF620 — Product Catalog Management
**Endpoints:**
- `GET /api/v1/mock-tmf/product-catalog/product` — list all products
- `GET /api/v1/mock-tmf/product-catalog/product/{product_id}` — single product
- `GET /api/v1/mock-tmf/product-catalog/productOffering` — list offerings (filter: `?tier=premium`)

**Agent Usage:**
- Use to verify what tier/QoS the customer is entitled to (`ProductOffering.tier`, `monthly_fee`, `payload.guaranteed_mbps`)
- Use when evaluating QoS mismatch (P4) to confirm billed tier vs entitled tier
- Use when calculating prorated credits based on monthly fee

**Response shape:**
```json
{
  "id": "PO-005",
  "name": "Premium 5G Slice - Monthly",
  "tier": "premium",
  "monthlyFee": {"amount": 25.00, "units": "USD"},
  "isActive": true,
  "@type": "ProductOffering"
}
```

---

### TMF621 — Trouble Ticket Management
**Endpoints:**
- `GET /api/v1/mock-tmf/trouble-ticket` — list tickets (filter: `?issue_id=`, `?ticket_type=`)
- `GET /api/v1/mock-tmf/trouble-ticket/{ticket_id}` — single ticket
- `PATCH /api/v1/mock-tmf/trouble-ticket/{ticket_id}?status=in_progress` — update status

**Agent Usage:**
- Retrieve existing trouble ticket for an issue before creating a duplicate
- Update ticket status as remediation progresses (`open` → `in_progress` → `resolved`)
- L2 Ticketing component owns all PATCH operations

**Valid statuses:** `open`, `in_progress`, `resolved`, `closed`, `cancelled`

---

### TMF638 — Service Inventory Management
**Endpoints:**
- `GET /api/v1/mock-tmf/service-inventory/service` — list (filter: `?customer_id=`, `?service_type=`)
- `GET /api/v1/mock-tmf/service-inventory/service/{service_id}` — single service

**Agent Usage:**
- Use to confirm what services are active for a customer (`service_type`, `status`, `product_offering_id`)
- Use in P4 to verify premium slice service is provisioned
- Use in P3 to correlate PDU session with active service record
- L3 QoS/Slice component uses this for entitlement validation

---

### TMF656 — Service Problem Management
**Endpoints:**
- `GET /api/v1/mock-tmf/service-problem` — list (filter: `?issue_id=`)
- `GET /api/v1/mock-tmf/service-problem/{problem_id}` — single problem

**Agent Usage:**
- Retrieve service problem evidence for P4 (qos_breach), P5 (service_degradation), P10 (multi_domain_outage)
- Confirm `sla_breach` flag and `affected_period_start/end`
- L3 Service Problem component owns evidence gathering here

---

### TMF678 — Customer Bill Management
**Endpoints:**
- `GET /api/v1/mock-tmf/customer-bill` — list bills (filter: `?billing_account_id=`, `?status=`)
- `GET /api/v1/mock-tmf/customer-bill/{bill_id}` — single bill
- `GET /api/v1/mock-tmf/customer-bill/{bill_id}/line-items` — line items for bill

**Agent Usage:**
- Use in P2 to identify duplicate line items (`dispute_flag: true`)
- Use in P8 to retrieve all line items for plain-language bill explanation
- Use in P6 to separate disputed vs undisputed balance
- `rated_usage_id` on a line item links to `RatedUsage` → `MediationRecord` → `UsageEvent`

**Response shape for line-items:**
```json
{
  "billId": "BILL-202604",
  "lineItems": [
    {
      "id": "BLI-202604-004",
      "description": "Data session charge - duplicate",
      "amount": 12.50,
      "chargeType": "usage",
      "disputeFlag": true,
      "@type": "BillLineItem"
    }
  ]
}
```

---

### TMF688 — Event Management
**Endpoints:**
- `GET /api/v1/mock-tmf/event` — list TMF events (filter: `?use_case_id=`, `?severity=`)
- `POST /api/v1/mock-tmf/hub` — register event notification hub (stub)

**Agent Usage:**
- L1 Monitoring retrieves events to correlate with issues
- Hub registration is a stub — real pub/sub not implemented in mock
- Use `?severity=critical` to surface high-priority events

---

### TMF700 (Proxy) — Audit Records
**Endpoints:**
- `GET /api/v1/mock-tmf/audit-record` — returns recent audit traces in TMF700 format

**Agent Usage:**
- Use to provide audit trail evidence in governance exports
- Returns `AuditTrace` records shaped as TMF700 AuditRecord objects

---

## Conventions (All Endpoints)
- All responses include `@type` and `@schemaLocation` TMF convention fields
- All IDs match the corresponding PostgreSQL ORM model primary keys
- Filtering is done via query parameters; multiple filters are AND-combined
- Empty results return `[]` not 404 (collection endpoints)
- 404 is returned for single-resource endpoints when ID not found

## What Is NOT Implemented
The following TMF specs are referenced but not mocked in this system:
- TMF629 Customer Management (use `GET /api/v1/customers/{id}/billing-context` instead)
- TMF632 Party Management (customer/contact data is in Customer model)
- TMF635 Product Usage (use UsageEvent ORM directly)
- TMF639 Resource Inventory (use NetworkFunction ORM directly)
- TMF640 Service Activation
- TMF642 Alarm Management
- TMF702 Resource Activation

## Agent Guidance
- Always retrieve existing records before creating new ones (check for existing trouble tickets, service problems)
- Prefer TMF mock endpoints for evidence gathering; prefer ORM/DB for write operations
- Do not expose raw TMF endpoint URLs or response payloads in customer communications
- TMF mock responses are read-only for L3/L4 agents; write operations belong to L2 and above
