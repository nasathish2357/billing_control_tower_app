# P9 — Internal Anomaly Discovered by Monitoring Before Customer Impact

## Symptoms
- Internal monitoring (NWDAF, billing analytics) detects unusual data usage spike.
- Usage volume is 2–5x above daily baseline for a specific billing account.
- No customer complaint yet — this is a pre-bill proactive detection.
- Pre-bill financial exposure identified before bill-run closes.

## Evidence Checklist
- [ ] L1/NWDAF: Usage spike factor vs baseline, detection confidence score.
- [ ] L1: Estimated pre-bill financial exposure in USD.
- [ ] L2: Bill-run status — whether bill is still open for correction.
- [ ] KG: Prior similar anomaly patterns for this account.

## Layer Ownership Rules
- **L1 Monitoring**: Detects anomaly, publishes BillingRiskDetectedEvent, creates control case.
- **L1 Closed-Loop**: Evaluates evidence, decides preventive action.
- **L2**: Applies pre-bill protection hold.
- **L3 / L4**: Provide focused evidence only if needed to confirm anomaly.

## Allowed Actions
- L1: Create proactive control case.
- L2: Apply pre-bill protection hold.
- L2: Flag billing account for manual review if confidence is low.
- L3/L4: Provide network evidence if anomaly source is unclear.

## Approval Thresholds
- Pre-bill hold: auto-allowed (preventive, no customer impact yet).
- If exposure > threshold and bill already issued: escalate to human approval for correction.

## Customer Communication Guidance
- Do NOT contact customer proactively until anomaly is confirmed.
- If confirmed and bill corrected: notify customer of proactive action taken.
- Emphasise that the correction was applied before any customer impact.

## Audit Requirements
- Log: Event ID (BillingRiskDetectedEvent), NWDAF confidence score.
- Log: Spike factor (current vs baseline daily GB).
- Log: Pre-bill exposure USD estimate.
- Log: KG context — prior similar patterns if found.
- Log: Pre-bill hold reference and protection period.
