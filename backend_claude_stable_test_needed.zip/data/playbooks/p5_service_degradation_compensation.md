# P5 — Service Degradation Requiring Commercial Compensation

## Symptoms
- Extended service outage or degradation beyond SLA tolerance.
- Customer or care agent raises a complaint referencing specific outage dates.
- L3 service problem record exists with sla_breach = true.
- Outage duration exceeds SLA maximum allowable downtime.

## Evidence Checklist
- [ ] L3: ServiceProblem record — outage duration, start/end timestamps, affected service.
- [ ] L3: SLA threshold for the customer's plan.
- [ ] L2: Commercial entitlement — SLA uptime %, max outage minutes, compensation policy.
- [ ] L2: Trouble Ticket — customer/care complaint reference.
- [ ] L2: Proposed compensation amount.

## Layer Ownership Rules
- **L2**: Opens Trouble Ticket, owns compensation decision and credit application.
- **L3**: Provides ServiceProblem and SLA breach evidence.
- **L1**: Orchestrates, evaluates breach vs threshold, gates compensation.
- **L4**: Not required unless network root-cause evidence is needed.

## Allowed Actions
- L2: Apply compensation credit for SLA breach.
- L2: Issue waiver or voucher as alternative compensation form.
- L2: Escalate to human approval if compensation exceeds threshold.

## Approval Thresholds
- Compensation amount > HUMAN_APPROVAL_CREDIT_THRESHOLD → interrupt for human approval.
- Below threshold → auto-apply.
- Bulk impact (multiple customers) → always require approval regardless of amount.

## Customer Communication Guidance
- Acknowledge the outage and SLA breach proactively.
- Communicate the compensation amount and expected timeline.
- Provide reference ticket number for follow-up.

## Audit Requirements
- Log: ServiceProblem ID, outage duration, SLA threshold, breach confirmation.
- Log: Trouble Ticket ID, compensation amount, approval ID if applicable.
- Log: Credit/waiver reference and applied timestamp.
