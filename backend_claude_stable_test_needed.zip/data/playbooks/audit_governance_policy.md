# Audit and Governance Policy

## Purpose
Every significant action taken by the Billing Control Tower must produce an auditable trace. This policy defines what must be recorded, how it is stored, and who is responsible for audit governance.

## Audit Coverage Requirements

### What Must Be Audited
- Every remediation action (credit, rebill, waiver, session cleanup, compensation)
- Every policy decision (auto_remediation_allowed, approval_required, rejected)
- Every human approval (approved, rejected, with approver notes)
- Every tool call that retrieves sensitive customer or billing data
- Every LLM prompt summary and response summary (no raw prompts stored)
- Every evidence pack created (source layer, summary, pack ID)
- Every chat interaction that touches billing or remediation
- Every simulation run (inject, dry_run, reset)
- Every KG snapshot rebuild

### What Must NOT Be Stored in Audit Traces
- Raw customer PII (full addresses, payment card numbers, passwords)
- Full LLM prompt text (only summary allowed)
- Full TMF payload responses (store pack_id reference only)
- Raw CDR data (store CDR reference only)

## Audit Trace Structure
Each AuditTrace record must contain:
- `id`: unique trace ID (TRACE-{use_case}-{sequence})
- `control_case_id`: linked control case
- `action_type`: category (agentic_remediation, human_approval, policy_decision, chat_interaction, simulation)
- `actor`: component or user that triggered the action (p1_graph, care_agent, system)
- `summary`: human-readable summary of what happened (max 500 chars)
- `details`: JSON with structured fields (evidence_pack_ids, approval_id, decision, actions_taken)
- `created_at`: UTC timestamp

## Layer Audit Responsibilities
| Layer | Responsibility |
|---|---|
| L1 Audit & Compliance | Writes final governance audit trace; owns cross-domain audit |
| L2 BSS | Records BSS-specific actions in evidence packs |
| L3 OSS | Records OSS evidence and service problem state changes |
| L4 Network | Records network evidence and session actions |

## Audit Retention
- Audit traces: retained for 7 years (regulatory requirement)
- Evidence packs: retained for 3 years
- Approval records: retained for 7 years
- Chat interaction summaries: retained for 2 years

## Audit Search and Export
Audit traces can be searched by:
- issue_id
- control_case_id
- customer_id
- action_type
- actor/component
- date range

Audit traces can be exported as JSON via:
`GET /api/v1/audit-traces/{trace_id}/export`

## Policy Decisions That Must Be Audited
- `auto_remediation_allowed`: action executed automatically
- `approval_required`: action held pending human approval
- `rejected_by_policy`: action blocked by policy rule
- `low_confidence_escalated`: LLM confidence too low; escalated to human

## Redaction Rules
Before any audit record is written:
1. Remove full payment card numbers (keep last 4 digits only)
2. Remove full IMEI if it can identify a specific stolen device
3. Remove raw CDR binary payloads
4. Summarise LLM interactions rather than logging full prompts
