# Partner Settlement Rules

## Purpose
Defines the rules governing partner and wholesale settlement reconciliation for roaming, MVNO, and interconnect charge discrepancies. Ensures retail customer outcomes are separated from wholesale partner recovery processes.

## Settlement Types
| Type | Description | Primary Evidence |
|---|---|---|
| MVNO wholesale | Revenue-share CDR reconciliation | SEPP logs, TAP files |
| Roaming visited-network | Inbound roaming CDR settlement | IR.21, TAP3, NRTRDE |
| Interconnect | Voice termination billing | CDR gateway records |
| IoT wholesale | Per-device connectivity billing | NEF API logs |

## Discrepancy Thresholds
| Discrepancy | Action |
|---|---|
| < $50 | Accept minor rounding differences; mark resolved |
| $50–$500 | Auto-initiate reconciliation request to partner |
| $500–$5,000 | Escalate to account manager; pause settlement payment |
| > $5,000 | Require human approval before any action; escalate to wholesale director |

## Evidence Hierarchy (L4 → L2)
1. **SEPP N32 interface logs** — authoritative CDR export record from CSP side
2. **TAP/NRTRDE files** — transfer files sent to partner; delivery confirmation
3. **CHF charging records** — charging trigger events that generated CDRs
4. **Partner-reported CDR count** — partner's ingestion confirmation
5. **PartnerSettlement DB record** — CSP's financial reconciliation record

## Separation Rule (Critical)
The retail customer correction and the partner settlement recovery are **always two separate processes**:

1. **Retail correction** — Apply credit to customer bill immediately if overcharged. Do not wait for partner to acknowledge.
2. **Partner recovery** — Create a separate settlement recovery case against the partner. Timeline: 5–30 business days.

These must never be conflated. Retail SLA is hours; partner SLA is days to weeks.

## PartnerSettlement Status Lifecycle
`pending` → `reconciling` → `disputed` → `escalated` → `resolved` / `written_off`

## Layer Ownership
| Action | Owner |
|---|---|
| Retrieve SEPP/NEF evidence | L4 Roaming Exposure |
| Validate CDR count against partner record | L3 Mediation |
| Apply retail customer credit | L2 Roaming & Partner Settlement |
| Create partner recovery settlement case | L2 Roaming & Partner Settlement |
| Approve high-value partner disputes | L1 → Human approval |
| Audit retail + wholesale chain | L1 Audit & Compliance |

## Forbidden Actions
- L4 must not modify `PartnerSettlement` records or apply customer credits
- L3 must not create settlement recovery cases
- Never credit the customer the full partner discrepancy amount without validating CSP-side evidence
- Never disclose partner settlement details (amounts, CDR counts) in customer-facing communications
- Never write off a discrepancy > $1,000 without human approval

## Approval Requirements
- Retail credit ≤ $100 with confirmed overcharge: auto-apply
- Retail credit $100–$500: L2 manager notification
- Retail credit > $500: human approval required
- Partner settlement write-off > $1,000: senior approval required

## Audit Requirements
- Record: `PartnerSettlement.id`, discrepancy amount, billing period, partner PLMN
- Record: L4 SEPP evidence reference and CDR export count
- Record: retail correction amount, bill reference, credit applied timestamp
- Record: partner recovery case ID and escalation status
- Record: approval decision if threshold exceeded
