# Human Approval Policy

## Purpose
This policy defines when the Billing Control Tower must pause an agentic flow and request human approval before executing a high-risk action. Approval uses LangGraph checkpoint interrupt/resume with PostgreSQL persistence.

## Approval Triggers

### Financial Thresholds
| Action | Auto-Approve Limit | Approval Required |
|---|---|---|
| Credit to customer account | ≤ $50.00 | > $50.00 |
| Compensation payment | ≤ $50.00 | > $50.00 |
| Rebill adjustment | ≤ $50.00 | > $50.00 |
| Partner settlement credit | ≤ $500.00 | > $500.00 |
| Bulk correction (multiple accounts) | Never auto | Always require |

### Operational Triggers
- Network session cleanup when root cause is ambiguous
- Collections hold release before dispute is resolved
- Any action with rollback risk (session teardown, bulk data correction)
- Low-confidence LLM decision (confidence score < 0.7)
- Cross-domain action affecting more than 2 domains simultaneously

### Policy Reason Codes
| Code | Description |
|---|---|
| CREDIT_ABOVE_THRESHOLD | Financial credit exceeds configured threshold |
| COMPENSATION_ABOVE_THRESHOLD | Compensation amount exceeds configured threshold |
| BULK_CUSTOMER_IMPACT | Action affects more than 1 customer account |
| LOW_CONFIDENCE | LLM decision confidence below threshold |
| NETWORK_REMEDIATION_IRREVERSIBLE | Network action without confirmed rollback |
| PARTNER_SETTLEMENT_HIGH_VALUE | Settlement recovery exceeds partner threshold |
| CROSS_DOMAIN_SCOPE | Action spans BSS + OSS + Network simultaneously |

## Approval Record (stored in PostgreSQL `approvals` table)
```json
{
  "id": "APPR-{use_case}-{seq}",
  "thread_id": "THREAD-{issue_id}-{uuid}",
  "issue_id": "ISSUE-P5-001",
  "control_case_id": "CC-P5-001",
  "action": "apply_compensation",
  "risk_reason": "Compensation amount $85.00 exceeds threshold $50.00",
  "amount": 85.00,
  "status": "pending",
  "approver_notes": null,
  "created_at": "2026-05-01T10:00:00Z",
  "decided_at": null
}
```

## LangGraph Interrupt/Resume Flow
1. Graph reaches a high-risk action node
2. `policy_decision` node sets `approval_required = True`
3. `request_approval` node creates Approval record in DB
4. Graph interrupts (via `interrupt_after=["request_approval"]`)
5. LangGraph checkpoint is saved to PostgreSQL
6. API returns `status: pending_approval`, `approval_id`, `thread_id`
7. Approver calls `POST /api/v1/approvals/{id}/approve` or `/reject`
8. Resume API: `POST /api/v1/issues/{id}/remediate/resume`
9. Graph reloads from checkpoint using `thread_id`
10. Executes approved action or gracefully closes if rejected

## Approval Expiry
- Approvals expire after 24 hours if not acted upon
- Expired approvals are automatically rejected
- Graph must handle expired approval state gracefully (close case, notify)

## Approver Guidance
When reviewing a pending approval:
- Read the `risk_reason` carefully — it explains why approval is needed
- Review the `action` field — confirms exactly what will be executed
- Check the `amount` — confirm it is proportional to the issue
- Add `approver_notes` explaining your decision (required for audit)
- Rejection notes must explain the reason for denial

## Rejection Handling
When an approval is rejected:
- Graph continues to `write_audit` node
- Control case status updated to `rejected`
- Audit trace records rejection with approver notes
- Customer is notified that manual review is required
- Issue remains open for alternative resolution path

## APIs
- `GET /api/v1/approvals/pending` — list pending approvals
- `GET /api/v1/approvals/{id}` — get specific approval
- `POST /api/v1/approvals/{id}/approve` — approve with optional notes
- `POST /api/v1/approvals/{id}/reject` — reject with required notes
- `POST /api/v1/issues/{id}/remediate/resume` — resume from checkpoint

## Audit Requirements
Every approval decision must be audited with:
- Approval ID and thread ID
- Approver identity (or system if auto-approved)
- Decision: approved / rejected
- Approver notes
- Timestamp of decision
- Resulting action taken after decision
