# P1 — Missing or Delayed Usage Feed into Billing

## Symptoms
- Customer bill shows zero or low usage for a period where usage was expected.
- Bill amount is lower than usual but customer reports heavy data usage.
- Mediation pipeline reports CDR/xDR backlog or delays.
- Bill-run completes before mediation events arrive.

## Evidence Checklist
- [ ] L4: CDR/usage event count vs expected volume.
- [ ] L4: Mediation pipeline stage and delay duration.
- [ ] L3: Mediation backlog event count and estimated financial impact.
- [ ] L2: Bill-run status and billing period exposure.
- [ ] L2: Whether bill protection hold is needed before close of billing period.

## Layer Ownership Rules
- **L4**: Detects CDR delay, publishes SuspectedUsageDelayEvent.
- **L3**: Owns mediation backlog evidence and replay execution.
- **L2**: Owns bill protection hold and final bill adjustment after replay.
- **L1**: Monitors event, creates control case, governs replay decision.

## Allowed Actions
- L3: Initiate mediation backlog replay for affected billing account.
- L2: Apply bill protection hold pending replay completion.
- L2: Issue bill adjustment or rebill after replay confirms impact.
- L1: Interrupt for human approval if replay exposure exceeds threshold.

## Approval Thresholds
- Mediation replay exposure > HUMAN_APPROVAL_CREDIT_THRESHOLD → interrupt for approval.
- Small exposure (< threshold) → auto-allow replay.

## Customer Communication Guidance
- Do not inform customer proactively unless bill is already issued.
- If bill issued: notify customer that a billing correction is pending.
- Estimated resolution: 24–48 hours after replay completes.

## Audit Requirements
- Log: event ID, mediation backlog count, replay job ID, bill protection hold reference.
- Log: approval decision if interrupt triggered.
- Log: final bill adjustment amount and billing period.
