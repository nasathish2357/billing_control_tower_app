# P10 — Governed End-to-End Dispute Handling Across BSS, OSS, and Network

## Use Case Summary
A complex billing dispute requires coordinated investigation and resolution across BSS (billing correction), OSS (service assurance), and Network (session/charging audit) teams. No single domain can resolve the issue independently. L1 governs the multi-team case centrally while each domain executes only its own approved actions.

## Symptoms
- Dispute touches more than one domain: billing error + service degradation + network session anomaly
- Multiple trouble tickets opened by different teams for the same root event
- Enterprise customer escalation with cross-domain SLA breach
- Evidence from different layers points to a shared root cause
- No single team can close the case without inputs from other domains

## Typical Cross-Domain Scenarios
1. **AMF/SMF failure cascade**: Network node failure causes service degradation (OSS) and incorrect session charges (BSS) simultaneously
2. **Charging NF + mediation fault**: CHF double-triggers cause duplicate CDRs (Network → Mediation → Bill)
3. **QoS + billing mismatch + root cause**: Network delivered wrong QoS (Network), OSS detected SLA breach (OSS), and BSS charged premium tier (BSS)
4. **MVNO dispute + service outage + overcharge**: Partner CDR gap (Network → Partner Settlement), customer outage (OSS), customer overcharged (BSS)

## Evidence Checklist

### L1 — CSP Control Tower
- [ ] Control case created with `cross_domain: true` flag
- [ ] Event or escalation trigger linked to control case
- [ ] Policy decision: which domains to involve
- [ ] Human approval triggered if high-risk action required

### L2 — BSS
- [ ] Bill line items under dispute
- [ ] Credit/rebill eligibility assessment
- [ ] Compensation eligibility (if SLA breach confirmed)
- [ ] Collections hold if balance disputed

### L3 — OSS / Service Assurance
- [ ] ServiceProblem record: affected service, duration, severity
- [ ] SLA breach confirmed: breach duration vs SLA threshold
- [ ] Service restoration status
- [ ] Trouble Ticket status and resolution

### L4 — Network
- [ ] UPF session record for disputed sessions
- [ ] SMF/AMF node status during incident period
- [ ] CHF/CTF charging record
- [ ] NWDAF anomaly report if applicable

## Layer Ownership Rules
| Action | Owner Layer |
|---|---|
| Create governed control case | L1 |
| Request BSS evidence/actions | L1 → L2 orchestrator |
| Request OSS evidence/actions | L1 → L3 orchestrator |
| Request Network evidence/actions | L1 → L4 orchestrator |
| Apply billing correction | L2 only |
| Apply compensation | L2 only (with L1 approval if > threshold) |
| Close service problem | L3 only |
| Session audit / cleanup | L4 only |
| Final case synchronisation | L1 |
| Audit of all actions | L1 Audit & Compliance |

## Orchestration Rules
- L1 communicates only with L2/L3/L4 orchestrators, not with sub-components directly
- Each domain executes its own actions after receiving L1 direction
- No domain bypasses its orchestrator to contact another domain directly
- Case does not close until all domain outcomes are synchronised at L1

## Human Approval Triggers (P10)
- Any financial action > $100 in a cross-domain case
- Network session cleanup when impact scope is unclear
- Partner settlement creation for amounts > $1,000
- When multiple domains recommend conflicting actions

## Approval Flow (LangGraph)
1. L1 reaches high-risk action
2. Policy node sets `approval_required = True`
3. Graph interrupts; checkpoint saved to PostgreSQL
4. Approval record created with thread_id and action details
5. Human approves or rejects via `/api/v1/approvals/{id}/approve`
6. Graph resumes from checkpoint; executes or gracefully closes

## Forbidden Actions
- L2 must not request network session teardown
- L3 must not apply billing credits
- L4 must not create or close trouble tickets
- L1 must not invoke sub-components below orchestrator level directly

## Synchronisation Before Close
Before the control case closes, L1 must confirm:
- [ ] BSS: billing correction applied or held pending approval
- [ ] OSS: service problem resolved or escalated
- [ ] Network: session audit complete, cleanup executed if needed
- [ ] Audit: complete evidence/action/approval chain recorded

## Customer Communication Guidance
> "We are investigating a complex issue on your account that involves our billing, service assurance, and network teams. We have opened a governed case (Ref: [control_case_id]) to coordinate resolution. You will receive an update within [SLA_hours] hours. In the meantime, any disputed amount has been placed on hold to prevent collection actions."

## Audit Requirements
- Record: all domain evidence pack IDs
- Record: cross-domain action sequence with timestamps
- Record: human approval decisions with approver reference
- Record: final outcome per domain (BSS, OSS, Network)
- Record: customer communication summary
- Record: SLA compliance status

## Acceptance Criteria for Case Closure
- All domain outcomes synchronised at L1
- Customer notified of resolution
- Audit trace complete and exportable
- Collections hold released or maintained appropriately
