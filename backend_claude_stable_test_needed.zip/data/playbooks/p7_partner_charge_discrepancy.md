# P7 — Partner or Wholesale Charge Discrepancy

## Use Case Summary
A mismatch exists between the CSP's internal billing records and a partner/MVNO wholesale settlement record for roaming or wholesale charges. The CSP has charged a higher amount than the partner acknowledges. Resolution requires separating the retail customer outcome from the wholesale partner recovery process.

## Symptoms
- Partner settlement record shows significantly fewer CDRs than CSP internal records
- PartnerSettlement.discrepancy_amount is significant (e.g., > $500)
- SEPP/NEF logs confirm CSP CDR export was complete, but partner ingestion was incomplete
- Bill line item flagged: `dispute_flag: true` on wholesale/roaming charge
- Trouble ticket type: `billing_dispute` with partner reference

## Root Cause Categories
1. **MVNO mediation gap**: MVNO rating engine did not ingest all SEPP-forwarded CDRs
2. **TAP file processing error**: Transfer Account Procedure file corruption or partial delivery
3. **SEPP interface failure**: N32 interface disruption caused CDR export gap to visiting network
4. **Rating engine version mismatch**: Partner and CSP using incompatible CDR formats
5. **Settlement cut-off timing**: Partner records CDRs in different billing period than CSP

## Evidence Checklist

### L4 — Network / Roaming / Exposure
- [ ] SEPP-01 N32 interface logs: confirm CDR export volume to partner PLMN
- [ ] NEF API exposure logs: confirm event notifications forwarded
- [ ] CHF records: confirm charging triggers issued for all roaming sessions
- [ ] TAP file export audit: confirm TAP file delivery status to partner

### L3 — Mediation / OSS
- [ ] Mediation records: CSP-side CDR count for settlement period
- [ ] Compare MediationRecord count vs partner-reported count
- [ ] Check for CDR format issues that might cause partner ingestion failure

### L2 — BSS / Roaming & Partner Settlement
- [ ] PartnerSettlement record: csp_record_amount vs partner_record_amount
- [ ] BillLineItem with dispute_flag: true referencing partner_id
- [ ] Retail customer impact: was retail customer incorrectly charged?
- [ ] Retail correction: if customer overcharged, apply credit
- [ ] Partner recovery: create partner settlement recovery case separately from retail correction

## Layer Ownership Rules
| Action | Owner Layer |
|---|---|
| Gather SEPP/N32 roaming evidence | L4 |
| Validate CDR export completeness | L3 |
| Retail customer correction (credit) | L2 |
| Partner settlement recovery case | L2 |
| Audit chain linking retail to wholesale | L1 |
| Escalate high-value disputes | L1 → Human approval |

## Critical Separation Rule
- **Retail customer outcome** and **partner settlement recovery** are SEPARATE processes
- L2 applies retail customer correction independently of partner settlement timeline
- Partner settlement case is created to recover from partner separately
- Audit trace must link retail resolution to wholesale recovery case

## Forbidden Actions
- L4 must not apply retail credits or modify bill records
- L3 must not perform financial actions against customer bills
- Do not delay retail customer correction while waiting for partner to respond
- Do not expose partner settlement details in customer-facing communications

## Allowed Actions
- L4: retrieve SEPP logs, N32 interface evidence, CDR export audit
- L3: pull mediation records for settlement period, count CDRs
- L2: apply retail customer credit if overcharged
- L2: create partner settlement recovery case with discrepancy evidence
- L2: update PartnerSettlement status to `escalated`

## Approval Thresholds
- Retail correction auto-applied: credit ≤ $100 with confirmed overcharge evidence
- Human approval required: retail credit > $100 or partner settlement > $1,000
- Always escalate to account manager: enterprise customer with dispute > $500

## Customer Communication Guidance (Retail)
> "We have identified a discrepancy in wholesale roaming charges applied to your account. We have applied a credit of [amount] to your account for any overcharge. Your next statement will reflect this correction. Our team is working with our partner network to resolve the underlying settlement issue."

## Partner Communication Guidance
> "We are raising a settlement dispute for period [period]. CSP records show [csp_count] CDRs totalling [csp_amount]. Partner records show [partner_count] CDRs totalling [partner_amount]. SEPP export logs confirm complete delivery. Please review and reconcile. Reference: [settlement_id]."

## Audit Requirements
- Record: PartnerSettlement ID, discrepancy amount, billing period
- Record: L4 SEPP evidence reference (CDR export log)
- Record: L3 mediation CDR count
- Record: retail customer correction amount and bill reference
- Record: partner settlement recovery case ID
- Record: audit chain linking retail outcome to wholesale recovery

## Typical Resolution Timeline
- Retail correction: < 1 hour with confirmed evidence
- Partner settlement reconciliation: 5–30 business days
