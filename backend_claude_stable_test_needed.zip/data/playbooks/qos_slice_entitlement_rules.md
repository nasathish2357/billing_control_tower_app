# QoS and 5G Slice Entitlement Rules

## Purpose
Defines entitlement verification rules and remediation actions for QoS tier mismatches, 5G network slice delivery failures, and premium-tier charging discrepancies.

## 5G Slice Tiers and Entitlements
| Tier | NSSAI | Guaranteed Throughput | Latency SLA | Monthly Fee |
|---|---|---|---|---|
| Standard 5G | 01-000000 | Best effort (100 Mbps typical) | <20ms | Base plan |
| Premium 5G Slice | 01-000001 | 100 Mbps guaranteed | <10ms | +$25/month |
| Enterprise Ultra Slice | 01-000002 | 500 Mbps guaranteed | <5ms | +$200/month |
| IoT NB-IoT/LTE-M | 80-000000 | 1 Mbps | <100ms | Per device |

## QoS Mismatch Detection Signals
1. **NSSAI mismatch**: `billed_nssai` ≠ `actual_nssai` in PDU session records
2. **Throughput deficit**: Delivered throughput < 80% of guaranteed throughput for > 1 hour
3. **Slice downgrade**: PCF policy changed slice assignment without billing correction
4. **Charging trigger mismatch**: CHF billed premium tier but UPF applied standard QFI

## Evidence Checklist

### L4 — Network / Charging / Session
- [ ] PDU session record: `payload.nssai` vs `payload.billed_nssai`
- [ ] PCF policy log: slice assignment for session period
- [ ] UPF QFI value applied vs purchased QFI
- [ ] NWDAF throughput measurement for affected period
- [ ] CHF charging record: tier applied at charging trigger time

### L3 — OSS / Service Assurance
- [ ] ServiceInventory record: `product_offering_id` → ProductOffering.tier
- [ ] ServiceProblem record: `problem_type = qos_breach`, `sla_breach` flag
- [ ] Compare service contracted tier vs delivered tier duration

### L2 — BSS / Product Entitlement
- [ ] BillLineItem: `charge_type = recurring`, `service_id` matching premium slice
- [ ] ProductOffering: `tier`, `monthly_fee`, `payload.guaranteed_mbps`
- [ ] Validate: customer was charged for tier that was not delivered

## Credit Calculation Rules
- **Prorated credit**: If delivered < 80% guaranteed throughput for N days, credit = (N/30) × monthly slice fee
- **Full month credit**: If 100% of billing period affected, credit = full slice fee
- **Minimum credit floor**: $5 regardless of duration (meaningful customer acknowledgement)
- **SLA breach compensation**: If enterprise SLA breach confirmed, apply SLA penalty per contract terms

## Layer Ownership
| Action | Owner |
|---|---|
| Detect NSSAI/QFI mismatch | L4 Charging NF Correlation |
| Retrieve NWDAF throughput evidence | L4 Network |
| Validate service entitlement | L3 QoS/Slice component |
| Calculate prorated credit | L2 Product Entitlement |
| Apply billing correction | L2 BSS |
| Approve high-value SLA credits | L1 → Human approval |

## Forbidden Actions
- L4 must not modify billing records or issue credits
- L3 must not perform financial adjustments
- Never apply a credit without confirmed NSSAI/QFI evidence from L4
- Do not expose internal NSSAI codes in customer communications (use tier name only)

## Approval Thresholds
- Prorated slice credit ≤ $50: auto-apply
- Prorated slice credit $50–$200: notify L2 manager
- Enterprise SLA breach credit > $200: human approval required
- Multi-month retrospective credit: always requires human approval

## Customer Communication Guidance
> "We have confirmed that your [Premium 5G Slice / Enterprise Ultra Slice] service did not meet its guaranteed performance level during the period [start_date] to [end_date]. We have applied a credit of [amount] to your account. We apologise for this service shortfall and have taken steps to prevent recurrence."

## Audit Requirements
- Log: ServiceProblem ID, affected period, NSSAI billed vs delivered
- Log: NWDAF throughput evidence reference
- Log: credit amount calculation method (prorated vs full)
- Log: BillLineItem IDs corrected
- Log: approval decision if threshold exceeded
