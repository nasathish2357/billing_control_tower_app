"""
L2 BSS Service — mock BSS/CRM/Billing operations.

All methods are async and return realistic mock payloads.
Large payloads are NOT passed to LangGraph state — only IDs and summaries are.
"""

import datetime
import logging
import uuid
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Bill, BillingAccount, Customer, EvidencePack, ControlCase, AuditTrace, Issue

logger = logging.getLogger(__name__)


async def get_current_bill(db: AsyncSession, billing_account_id: str, bill_id: Optional[str] = None) -> dict:
    """Retrieve the current or latest bill for a billing account."""
    if bill_id:
        result = await db.execute(select(Bill).where(Bill.id == bill_id))
        bill = result.scalar_one_or_none()
    else:
        result = await db.execute(
            select(Bill)
            .where(Bill.billing_account_id == billing_account_id)
            .order_by(Bill.billing_period.desc())
            .limit(1)
        )
        bill = result.scalar_one_or_none()

    if not bill:
        return {"error": f"No bill found for account {billing_account_id}"}

    return {
        "bill_id": bill.id,
        "billing_period": bill.billing_period,
        "amount_due": bill.amount_due,
        "previous_amount": bill.previous_amount,
        "status": bill.status,
        "line_items": bill.payload.get("line_items", []) if bill.payload else [],
    }


async def get_previous_bills(db: AsyncSession, billing_account_id: str, months: int = 3) -> list:
    """Retrieve last N months of bills for comparison."""
    result = await db.execute(
        select(Bill)
        .where(Bill.billing_account_id == billing_account_id)
        .order_by(Bill.billing_period.desc())
        .limit(months + 1)  # +1 to skip current
        .offset(1)
    )
    bills = result.scalars().all()
    return [
        {
            "bill_id": b.id,
            "billing_period": b.billing_period,
            "amount_due": b.amount_due,
            "status": b.status,
        }
        for b in bills
    ]


async def apply_adjustment(
    db: AsyncSession,
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    adjustment_type: str,
    amount: float,
    reason_code: str,
) -> dict:
    """Apply a billing adjustment (credit / rebill / waiver) and persist evidence."""
    evp_id = f"EVP-L2-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    payload = {
        "adjustment_type": adjustment_type,
        "amount": amount,
        "reason_code": reason_code,
        "applied_at": datetime.datetime.utcnow().isoformat(),
        "billing_account_id": billing_account_id,
    }

    evp = EvidencePack(
        id=evp_id,
        control_case_id=control_case_id,
        source_layer="L2",
        summary=f"L2 applied {adjustment_type} of ${amount:.2f} — reason: {reason_code}",
        payload=payload,
    )
    db.add(evp)
    await db.commit()

    logger.info("L2 adjustment applied: %s", evp_id)
    return {"evidence_pack_id": evp_id, "summary": evp.summary, "status": "applied"}


async def get_customer_context(db: AsyncSession, customer_id: str, billing_account_id: str) -> dict:
    """Return lightweight customer context for LLM reasoning."""
    result = await db.execute(select(Customer).where(Customer.id == customer_id))
    customer = result.scalar_one_or_none()
    result2 = await db.execute(select(BillingAccount).where(BillingAccount.id == billing_account_id))
    ba = result2.scalar_one_or_none()
    return {
        "customer_id": customer_id,
        "customer_name": customer.name if customer else "Unknown",
        "segment": customer.segment if customer else "Unknown",
        "account_status": ba.status if ba else "Unknown",
        "currency": ba.currency if ba else "USD",
    }


async def place_collections_hold(db: AsyncSession, control_case_id: str, issue_id: str, billing_account_id: str, amount: float) -> dict:
    """Place a collections hold on a disputed balance."""
    evp_id = f"EVP-L2-HOLD-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    payload = {
        "action": "collections_hold",
        "disputed_amount": amount,
        "billing_account_id": billing_account_id,
        "applied_at": datetime.datetime.utcnow().isoformat(),
    }
    evp = EvidencePack(
        id=evp_id, control_case_id=control_case_id, source_layer="L2",
        summary=f"L2 collections hold placed on ${amount:.2f} for account {billing_account_id}",
        payload=payload,
    )
    db.add(evp)
    await db.commit()
    return {"evidence_pack_id": evp_id, "summary": evp.summary, "status": "hold_placed"}
