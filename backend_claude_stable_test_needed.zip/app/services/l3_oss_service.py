"""
L3 OSS Service — mock OSS/mediation/service-assurance operations.
"""

import datetime
import logging
import uuid

from sqlalchemy.ext.asyncio import AsyncSession
from app.models.models import EvidencePack

logger = logging.getLogger(__name__)


async def get_mediation_evidence(db: AsyncSession, control_case_id: str, issue_id: str, billing_account_id: str, bill_id: str) -> dict:
    """
    Return mediation evidence for a billing dispute.
    In MVP1 this is a realistic mock payload stored in the DB.
    """
    evp_id = f"EVP-L3-MED-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    payload = {
        "mediation_records": [
            {
                "event_id": "MED-EVENT-001",
                "session_id": "SID-20260415-001",
                "rated_at": "2026-04-15T14:00:00Z",
                "usage_bytes": 2_000_000_000,
                "rating_trigger_count": 2,
                "duplicate_detected": True,
                "note": "Rating engine emitted two triggers for single CDR due to retry loop.",
            }
        ],
        "billing_account_id": billing_account_id,
        "bill_id": bill_id,
        "retrieved_at": datetime.datetime.utcnow().isoformat(),
    }
    summary = "L3 mediation: duplicate CDR rating confirmed — two rating triggers for a single data session."
    evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L3", summary=summary, payload=payload)
    db.add(evp)
    await db.commit()
    logger.info("L3 mediation evidence stored: %s", evp_id)
    return {"evidence_pack_id": evp_id, "summary": summary}


async def get_service_degradation_evidence(db: AsyncSession, control_case_id: str, issue_id: str, billing_account_id: str) -> dict:
    """Return service degradation / SLA evidence."""
    evp_id = f"EVP-L3-SVC-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    payload = {
        "service_problem_id": "SP-4422",
        "affected_service": "Voice",
        "degradation_start": "2026-04-20T08:00:00Z",
        "degradation_end": "2026-04-20T16:00:00Z",
        "duration_hours": 8,
        "sla_breach": True,
        "sla_threshold_minutes": 60,
        "billing_account_id": billing_account_id,
    }
    summary = "L3: Voice service degradation 8 hours on April 20th — SLA breached (threshold: 60 min)."
    evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L3", summary=summary, payload=payload)
    db.add(evp)
    await db.commit()
    return {"evidence_pack_id": evp_id, "summary": summary}
