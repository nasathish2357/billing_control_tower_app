"""
L4 Network Service — mock network/session/RAN operations.
"""

import datetime
import logging
import uuid

from sqlalchemy.ext.asyncio import AsyncSession
from app.models.models import EvidencePack

logger = logging.getLogger(__name__)


async def get_session_evidence(db: AsyncSession, control_case_id: str, issue_id: str, session_id: str, billing_account_id: str) -> dict:
    """Return network-level evidence for a specific PDU session."""
    evp_id = f"EVP-L4-SES-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    payload = {
        "session_id": session_id,
        "billing_account_id": billing_account_id,
        "session_start": "2026-04-15T08:00:00Z",
        "device_last_seen": "2026-04-15T10:00:00Z",
        "session_close_recorded_at": "2026-04-15T16:00:00Z",
        "zombie_hours": 6.0,
        "bytes_charged_during_zombie": 1_200_000_000,
        "estimated_erroneous_charge_usd": 12.00,
        "confirmed_zombie": True,
        "note": "Device disconnected at 10:00 UTC; session remained active in PCRF/UPF until 16:00 UTC.",
    }
    summary = f"L4: Zombie session {session_id} confirmed — 6 hours of illegitimate charges after device disconnect."
    evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L4", summary=summary, payload=payload)
    db.add(evp)
    await db.commit()
    logger.info("L4 session evidence stored: %s", evp_id)
    return {"evidence_pack_id": evp_id, "summary": summary, "session_id": session_id, "erroneous_charge_usd": payload["estimated_erroneous_charge_usd"]}


async def cleanup_zombie_session(db: AsyncSession, control_case_id: str, issue_id: str, session_id: str) -> dict:
    """Mock L4 session cleanup action."""
    evp_id = f"EVP-L4-CLEAN-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    payload = {
        "action": "session_cleanup",
        "session_id": session_id,
        "executed_at": datetime.datetime.utcnow().isoformat(),
        "pcrf_updated": True,
        "upf_session_released": True,
        "charging_stopped": True,
    }
    summary = f"L4: Zombie session {session_id} terminated — PCRF and UPF updated, charging stopped."
    evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L4", summary=summary, payload=payload)
    db.add(evp)
    await db.commit()
    logger.info("L4 session cleanup executed: %s", evp_id)
    return {"evidence_pack_id": evp_id, "summary": summary}


async def get_rating_evidence(db: AsyncSession, control_case_id: str, issue_id: str, billing_account_id: str, bill_id: str) -> dict:
    """Return rating/charging trigger evidence for duplicate charge detection."""
    evp_id = f"EVP-L4-RATE-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    payload = {
        "billing_account_id": billing_account_id,
        "bill_id": bill_id,
        "rating_events": [
            {"trigger_id": "RT-001", "session_id": "SID-20260415-001", "amount": 12.50, "triggered_at": "2026-04-15T14:00:00Z"},
            {"trigger_id": "RT-002", "session_id": "SID-20260415-001", "amount": 12.50, "triggered_at": "2026-04-15T14:00:05Z", "duplicate": True},
        ],
        "duplicate_confirmed": True,
        "duplicate_amount": 12.50,
    }
    summary = "L4: Two rating triggers (RT-001, RT-002) fired for the same session SID-20260415-001 — $12.50 duplicate charge confirmed."
    evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L4", summary=summary, payload=payload)
    db.add(evp)
    await db.commit()
    return {"evidence_pack_id": evp_id, "summary": summary, "duplicate_amount": 12.50}
