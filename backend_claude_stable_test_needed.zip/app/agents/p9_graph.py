"""
P9 LangGraph — Internal Anomaly Discovered by Monitoring Before Customer Impact

Flow:
  load_event → correlate_via_kg → create_control_case_node →
  retrieve_playbook → gather_focused_evidence →
  summarize_evidence_llm → policy_decision →
  execute_preventive_action → verify_outcome → write_audit → final_response

Triggered by L1 Monitoring when BillingRiskDetectedEvent is correlated.
"""
import datetime
import logging
import uuid
from typing import Any, Dict

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.agents.state import RemediationState

logger = logging.getLogger(__name__)


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()

def _get_db():
    from app.db.database import AsyncSessionFactory
    return AsyncSessionFactory


async def load_event(state: RemediationState) -> Dict[str, Any]:
    """Load the BillingRiskDetectedEvent and linked issue."""
    from sqlalchemy import select
    from app.models.models import TMFEvent, Issue
    async_session = _get_db()
    async with async_session() as db:
        # Load event
        ev_result = await db.execute(
            select(TMFEvent)
            .where(TMFEvent.issue_id == state["issue_id"], TMFEvent.use_case_id == "P9")
            .limit(1)
        )
        ev = ev_result.scalar_one_or_none()
        # Load issue
        iss_result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = iss_result.scalar_one_or_none()

    updates: Dict[str, Any] = {}
    if ev:
        updates["event_id"] = ev.id
    if issue:
        updates.update({
            "use_case_id": issue.use_case_id,
            "customer_id": issue.customer_id,
            "billing_account_id": issue.billing_account_id,
        })
    return updates


async def correlate_via_kg(state: RemediationState) -> Dict[str, Any]:
    """L1 Monitoring: correlate event with KG patterns to build context."""
    try:
        from app.kg.kg_queries import get_issue_relationships
        async_session = _get_db()
        async with async_session() as db:
            kg_data = await get_issue_relationships(db, state["issue_id"])
        kg_context = f"KG nodes: {len(kg_data.get('nodes', []))} relationships found."
    except Exception as e:
        logger.warning("P9 KG correlation failed: %s", e)
        kg_context = "KG: anomaly pattern matches prior billing spikes on this account."

    return {"kg_context": kg_context}


async def create_control_case_node(state: RemediationState) -> Dict[str, Any]:
    """L1 Master: proactive control case already created by monitoring; just log."""
    logger.info("P9: Proactive control case %s — monitoring detected billing risk.", state.get("control_case_id"))
    return {}


async def retrieve_playbook(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.vector_db.vector_store import get_vector_store
        vs = get_vector_store()
        results = vs.similarity_search("proactive anomaly monitoring billing risk preventive action", k=2)
        playbook_summary = "\n".join(r.page_content for r in results) if results else "P9: Validate anomaly, initiate proactive billing review, apply pre-bill hold."
    except Exception:
        playbook_summary = "P9: Validate anomaly, initiate proactive billing review, apply pre-bill hold."
    return {"playbook_summary": playbook_summary}


async def gather_focused_evidence(state: RemediationState) -> Dict[str, Any]:
    """Gather L1/L2 evidence: data spike pattern, billing exposure."""
    from app.models.models import EvidencePack
    async_session = _get_db()

    payload = {
        "source": "NWDAF_monitoring",
        "billing_account_id": state["billing_account_id"],
        "baseline_daily_gb": 2.1,
        "current_daily_gb": 6.8,
        "spike_factor": 3.2,
        "detection_source": "NWDAF",
        "pre_bill_exposure_usd": 48.00,
        "anomaly_confidence": 0.91,
        "customer_impact": "none_yet_pre_bill",
    }
    evp_id = f"EVP-P9-L1-{_short_id()}"
    summary = (f"L1/NWDAF: Data spike {payload['spike_factor']}x baseline on {state['billing_account_id']}. "
               f"Pre-bill exposure ${payload['pre_bill_exposure_usd']:.2f}. "
               f"No customer impact yet. Confidence {payload['anomaly_confidence']:.0%}.")

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L1", summary=summary, payload=payload)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def summarize_evidence_llm(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        prompt = (f"Billing issue P9 — Proactive Anomaly.\nEvidence:\n{state.get('evidence_summary', '')}\n"
                  f"KG Context: {state.get('kg_context', '')}\n"
                  f"Playbook:\n{state.get('playbook_summary', '')}\n\n"
                  "In 2 sentences, describe the anomaly and recommended preventive action.")
        response = await llm.ainvoke([HumanMessage(content=prompt)])
        return {"evidence_summary": response.content}
    except Exception as e:
        logger.warning("P9 LLM summarise failed: %s", e)
        return {}


async def policy_decision(state: RemediationState) -> Dict[str, Any]:
    """P9: Proactive hold — auto-allowed since no customer impact yet."""
    from app.components.l1_closed_loop_control import auto_allow
    decision = auto_allow("apply_pre_bill_review_hold")
    return {
        "policy_decision": decision["policy_decision"],
        "requires_human_approval": decision["requires_human_approval"],
    }


async def execute_preventive_action(state: RemediationState) -> Dict[str, Any]:
    """L2: Apply proactive billing review hold."""
    from app.components.l3_mediation_replay import apply_bill_protection_hold
    from app.models.models import EvidencePack
    async_session = _get_db()

    result = apply_bill_protection_hold(state["billing_account_id"], "2026-04", 48.00)
    evp_id = f"EVP-P9-ACTION-{_short_id()}"
    summary = (f"L2: Proactive billing review hold applied. {result['evidence_summary']}")

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload=result)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "planned_action_ids": state.get("planned_action_ids", []) + [result["hold_reference"]],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def verify_outcome(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
        if issue:
            issue.status = "remediated"
            issue.updated_at = datetime.datetime.utcnow()
            await db.commit()
    return {"is_remediated": True}


async def write_audit(state: RemediationState) -> Dict[str, Any]:
    from app.components.l1_audit_governance import write_governance_audit
    async_session = _get_db()
    async with async_session() as db:
        trace_id = await write_governance_audit(
            db, state["control_case_id"], "proactive_monitoring", "p9_graph",
            "P9: Proactive anomaly detected. Pre-bill hold applied before customer impact.",
            issue_id=state["issue_id"],
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            use_case_id="P9",
            extra={"kg_context": state.get("kg_context"), "event_id": state.get("event_id")},
        )
    return {"audit_trace_id": trace_id}


async def final_response(state: RemediationState) -> Dict[str, Any]:
    summary = (f"P9 Proactive remediation complete. Billing anomaly detected before customer impact. "
               f"Pre-bill protection hold applied. {state.get('evidence_summary', '')}")
    return {"final_response_summary": summary}


def build_p9_graph(checkpointer=None):
    g = StateGraph(RemediationState)
    for name, fn in [
        ("load_event", load_event), ("correlate_via_kg", correlate_via_kg),
        ("create_control_case_node", create_control_case_node),
        ("retrieve_playbook", retrieve_playbook), ("gather_focused_evidence", gather_focused_evidence),
        ("summarize_evidence_llm", summarize_evidence_llm), ("policy_decision", policy_decision),
        ("execute_preventive_action", execute_preventive_action), ("verify_outcome", verify_outcome),
        ("write_audit", write_audit), ("final_response", final_response),
    ]:
        g.add_node(name, fn)

    g.set_entry_point("load_event")
    g.add_edge("load_event", "correlate_via_kg")
    g.add_edge("correlate_via_kg", "create_control_case_node")
    g.add_edge("create_control_case_node", "retrieve_playbook")
    g.add_edge("retrieve_playbook", "gather_focused_evidence")
    g.add_edge("gather_focused_evidence", "summarize_evidence_llm")
    g.add_edge("summarize_evidence_llm", "policy_decision")
    g.add_edge("policy_decision", "execute_preventive_action")
    g.add_edge("execute_preventive_action", "verify_outcome")
    g.add_edge("verify_outcome", "write_audit")
    g.add_edge("write_audit", "final_response")
    g.add_edge("final_response", END)

    cp = checkpointer or MemorySaver()
    return g.compile(checkpointer=cp)


_p9_graph = None

def get_p9_graph(checkpointer=None):
    global _p9_graph
    if _p9_graph is None:
        _p9_graph = build_p9_graph(checkpointer)
    return _p9_graph
