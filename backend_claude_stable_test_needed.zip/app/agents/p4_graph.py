"""
P4 LangGraph — QoS / Slice Entitlement Mismatch with Premium Charging

Flow:
  load_issue → load_context → retrieve_playbook →
  gather_l2_entitlement → gather_l3_qos → gather_l4_slice →
  summarize_evidence_llm → policy_decision →
  execute_surcharge_removal → verify_outcome → write_audit → final_response
"""
import datetime
import logging
import uuid
from typing import Any, Dict

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.agents.state import RemediationState
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()

def _get_db():
    from app.db.database import AsyncSessionFactory
    return AsyncSessionFactory


async def load_issue(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {state['issue_id']} not found"}
    return {"use_case_id": issue.use_case_id, "customer_id": issue.customer_id,
            "billing_account_id": issue.billing_account_id, "bill_id": issue.bill_id}


async def load_context(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import TMFEvent
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(
            select(TMFEvent).where(TMFEvent.issue_id == state["issue_id"], TMFEvent.use_case_id == "P4").limit(1)
        )
        ev = result.scalar_one_or_none()
    return {"event_id": ev.id if ev else None}


async def retrieve_playbook(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.vector_db.vector_store import get_vector_store
        vs = get_vector_store()
        results = vs.similarity_search("QoS slice entitlement mismatch premium surcharge", k=2)
        playbook_summary = "\n".join(r.page_content for r in results) if results else "P4: Validate entitlement, check NSSAI, remove surcharge if mismatch confirmed."
    except Exception:
        playbook_summary = "P4: Validate entitlement, check NSSAI, remove surcharge if mismatch confirmed."
    return {"playbook_summary": playbook_summary}


async def gather_l2_entitlement(state: RemediationState) -> Dict[str, Any]:
    """L2 validates promised commercial tier."""
    from app.components.l2_product_entitlement import get_entitlement
    from app.models.models import EvidencePack
    async_session = _get_db()

    ent = get_entitlement(state["billing_account_id"])
    evp_id = f"EVP-P4-L2-{_short_id()}"
    summary = (f"L2 Entitlement: {ent['plan_name']} — promised {ent['promised_throughput_mbps']} Mbps, "
               f"surcharge ${ent['monthly_surcharge_usd']:.2f}/mo, NSSAI {ent.get('nssai')}.")

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload=ent)
        db.add(evp)
        await db.commit()

    return {"evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
            "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}"}


async def gather_l3_qos(state: RemediationState) -> Dict[str, Any]:
    """L3 retrieves QoS service evidence."""
    from app.components.l3_qos_slice import get_qos_evidence
    from app.models.models import EvidencePack
    async_session = _get_db()

    qos = get_qos_evidence(state["billing_account_id"])
    evp_id = f"EVP-P4-L3-{_short_id()}"
    summary = (f"L3 QoS: avg {qos['avg_throughput_mbps']} Mbps, NSSAI {qos['active_nssai']}, "
               f"packet loss {qos['packet_loss_pct']}%.")

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L3", summary=summary, payload=qos)
        db.add(evp)
        await db.commit()

    return {"evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
            "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}"}


async def gather_l4_slice(state: RemediationState) -> Dict[str, Any]:
    """L4 provides slice/NSSAI performance evidence."""
    from app.components.l3_qos_slice import get_slice_performance
    from app.models.models import EvidencePack
    async_session = _get_db()

    slice_ev = get_slice_performance(state["billing_account_id"])
    evp_id = f"EVP-P4-L4-{_short_id()}"
    summary = slice_ev["evidence_summary"]

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L4", summary=summary, payload=slice_ev)
        db.add(evp)
        await db.commit()

    return {"evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
            "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}"}


async def summarize_evidence_llm(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        prompt = (f"Billing issue P4 — QoS Mismatch.\nEvidence:\n{state.get('evidence_summary', '')}\n"
                  f"Playbook:\n{state.get('playbook_summary', '')}\n\n"
                  "Summarise the mismatch in 2 sentences and state the recommended action.")
        response = await llm.ainvoke([HumanMessage(content=prompt)])
        return {"evidence_summary": response.content}
    except Exception as e:
        logger.warning("P4 LLM summarise failed: %s", e)
        return {}


async def policy_decision(state: RemediationState) -> Dict[str, Any]:
    """P4: QoS mismatch — auto-remove surcharge, no approval needed."""
    from app.components.l1_closed_loop_control import auto_allow
    decision = auto_allow("remove_premium_surcharge")
    return {
        "policy_decision": decision["policy_decision"],
        "requires_human_approval": decision["requires_human_approval"],
    }


async def execute_surcharge_removal(state: RemediationState) -> Dict[str, Any]:
    """L2 removes premium surcharge."""
    from app.components.l2_product_entitlement import apply_surcharge_removal, get_entitlement
    from app.models.models import EvidencePack
    async_session = _get_db()

    ent = get_entitlement(state["billing_account_id"])
    result = apply_surcharge_removal(
        state["billing_account_id"], ent["monthly_surcharge_usd"],
        "QoS/NSSAI mismatch confirmed — premium surcharge not warranted."
    )
    evp_id = f"EVP-P4-ACTION-{_short_id()}"
    summary = f"L2: Surcharge ${ent['monthly_surcharge_usd']:.2f} removed. Adjustment ID {result['adjustment_id']}."

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload=result)
        db.add(evp)
        await db.commit()

    return {"evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
            "planned_action_ids": state.get("planned_action_ids", []) + [result["adjustment_id"]],
            "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}"}


async def verify_outcome(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
        if issue:
            issue.status = "remediated"
            issue.updated_at = datetime.datetime.utcnow()
            await db.commit()
    return {"is_remediated": True}


async def write_audit(state: RemediationState) -> Dict[str, Any]:
    from app.components.l1_audit_governance import write_governance_audit
    async_session = _get_db()
    async with async_session() as db:
        trace_id = await write_governance_audit(
            db, state["control_case_id"], "agentic_remediation", "p4_graph",
            "P4: QoS/NSSAI mismatch confirmed. Premium surcharge removed.",
            issue_id=state["issue_id"],
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            use_case_id="P4",
        )
    return {"audit_trace_id": trace_id}


async def final_response(state: RemediationState) -> Dict[str, Any]:
    summary = (f"P4 Remediation complete. QoS mismatch confirmed between promised and delivered slice performance. "
               f"Premium surcharge removed. {state.get('evidence_summary', '')}")
    return {"final_response_summary": summary}


def build_p4_graph(checkpointer=None):
    g = StateGraph(RemediationState)
    for name, fn in [
        ("load_issue", load_issue), ("load_context", load_context),
        ("retrieve_playbook", retrieve_playbook), ("gather_l2_entitlement", gather_l2_entitlement),
        ("gather_l3_qos", gather_l3_qos), ("gather_l4_slice", gather_l4_slice),
        ("summarize_evidence_llm", summarize_evidence_llm), ("policy_decision", policy_decision),
        ("execute_surcharge_removal", execute_surcharge_removal), ("verify_outcome", verify_outcome),
        ("write_audit", write_audit), ("final_response", final_response),
    ]:
        g.add_node(name, fn)

    g.set_entry_point("load_issue")
    g.add_edge("load_issue", "load_context")
    g.add_edge("load_context", "retrieve_playbook")
    g.add_edge("retrieve_playbook", "gather_l2_entitlement")
    g.add_edge("gather_l2_entitlement", "gather_l3_qos")
    g.add_edge("gather_l3_qos", "gather_l4_slice")
    g.add_edge("gather_l4_slice", "summarize_evidence_llm")
    g.add_edge("summarize_evidence_llm", "policy_decision")
    g.add_edge("policy_decision", "execute_surcharge_removal")
    g.add_edge("execute_surcharge_removal", "verify_outcome")
    g.add_edge("verify_outcome", "write_audit")
    g.add_edge("write_audit", "final_response")
    g.add_edge("final_response", END)

    cp = checkpointer or MemorySaver()
    return g.compile(checkpointer=cp)


_p4_graph = None

def get_p4_graph(checkpointer=None):
    global _p4_graph
    if _p4_graph is None:
        _p4_graph = build_p4_graph(checkpointer)
    return _p4_graph
