"""
Chat / Bill-Explanation LangGraph — handles P8 and general chat intents.

Graph nodes (per master prompt):
  classify_intent → load_customer_context → load_current_bill →
  load_previous_bills → retrieve_bill_playbook → generate_explanation_llm →
  determine_escalation → stream_response → write_audit → END

Supported intents (MVP3 expanded):
  bill_explanation | compare_previous_bill | issue_status |
  remediate_issue | escalate_to_human | issue_analysis |
  remediation_explanation | collections_hold_request |
  compensation_eligibility_check |
  schedule_callback | dispute_creation | partner_charge_explanation |
  roaming_charge_explanation | premium_qos_charge_explanation |
  proactive_risk_summary | governed_case_summary

SSE events emitted by the streaming generator:
  conversation_started | intent_detected | tool_started | tool_completed |
  evidence_loaded | token | audit_written | final | error
"""

import datetime
import json
import logging
import uuid
from typing import AsyncGenerator, Literal

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph
from sqlalchemy import select

from app.agents.state import ChatState
from app.db.database import AsyncSessionFactory
from app.models.models import AuditTrace, ControlCase, Issue
from app.services import l2_bss_service
from app.vector_db.vector_store import similarity_search

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────

def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


# ─────────────────────────────────────────────
#  Node: classify_intent
# ─────────────────────────────────────────────

async def classify_intent(state: ChatState) -> dict:
    # LangGraph's add_messages reducer converts dicts to LangChain Message objects
    msgs = state["messages"]
    if msgs:
        last = msgs[-1]
        user_msg = last.content if hasattr(last, "content") else last.get("content", "")
    else:
        user_msg = ""
    logger.info("[L1] classify_intent: '%s'", user_msg[:80])

    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        prompt = [
            SystemMessage(content=(
                "Classify the customer's message into one of these intents: "
                "bill_explanation, compare_previous_bill, issue_status, "
                "remediate_issue, escalate_to_human, "
                "issue_analysis, remediation_explanation, "
                "collections_hold_request, compensation_eligibility_check, "
                "schedule_callback, dispute_creation, "
                "partner_charge_explanation, roaming_charge_explanation, "
                "premium_qos_charge_explanation, proactive_risk_summary, "
                "governed_case_summary. "
                "Reply with ONLY the intent label, nothing else."
            )),
            HumanMessage(content=user_msg),
        ]
        response = await llm.ainvoke(prompt)
        raw = response.content.strip().lower().replace(" ", "_")
        valid = {
            "bill_explanation", "compare_previous_bill", "issue_status",
            "remediate_issue", "escalate_to_human", "issue_analysis",
            "remediation_explanation", "collections_hold_request",
            "compensation_eligibility_check",
            # MVP3 new intents
            "schedule_callback", "dispute_creation",
            "partner_charge_explanation", "roaming_charge_explanation",
            "premium_qos_charge_explanation", "proactive_risk_summary",
            "governed_case_summary",
        }
        intent = raw if raw in valid else "bill_explanation"
    except Exception as exc:
        logger.warning("Intent classification failed (%s). Defaulting to bill_explanation.", exc)
        intent = "bill_explanation"

    return {"intent": intent}


# ─────────────────────────────────────────────
#  Node: load_customer_context
# ─────────────────────────────────────────────

async def load_customer_context(state: ChatState) -> dict:
    logger.info("[L2] load_customer_context")
    async with AsyncSessionFactory() as db:
        ctx = await l2_bss_service.get_customer_context(db, state["customer_id"], state["billing_account_id"])
    summary = f"Customer: {ctx['customer_name']} | Segment: {ctx['segment']} | Account: {ctx['account_status']}"
    return {"evidence_summary": summary}


# ─────────────────────────────────────────────
#  Node: load_current_bill
# ─────────────────────────────────────────────

async def load_current_bill(state: ChatState) -> dict:
    logger.info("[L2] load_current_bill")
    async with AsyncSessionFactory() as db:
        bill = await l2_bss_service.get_current_bill(db, state["billing_account_id"])

    bill_id = bill.get("bill_id", "N/A")
    amount = bill.get("amount_due", 0)
    previous = bill.get("previous_amount", 0)
    items = bill.get("line_items", [])
    items_text = "; ".join([f"{li['description']}: ${li['amount']:.2f}" for li in items])
    summary = f"Current bill {bill_id}: ${amount:.2f} (prev: ${previous:.2f}) | Items: {items_text}"
    return {
        "current_bill_id": bill_id,
        "evidence_summary": (state.get("evidence_summary", "") + "\n" + summary).strip(),
    }


# ─────────────────────────────────────────────
#  Node: load_previous_bills
# ─────────────────────────────────────────────

async def load_previous_bills(state: ChatState) -> dict:
    logger.info("[L2] load_previous_bills")
    async with AsyncSessionFactory() as db:
        bills = await l2_bss_service.get_previous_bills(db, state["billing_account_id"], months=3)

    ids = [b["bill_id"] for b in bills]
    summary_parts = [f"{b['bill_id']} ({b['billing_period']}): ${b['amount_due']:.2f}" for b in bills]
    summary = "Previous bills: " + " | ".join(summary_parts) if summary_parts else "No previous bills found."
    return {
        "previous_bill_ids": ids,
        "evidence_summary": (state.get("evidence_summary", "") + "\n" + summary).strip(),
    }


# ─────────────────────────────────────────────
#  Node: retrieve_bill_playbook
# ─────────────────────────────────────────────

async def retrieve_bill_playbook(state: ChatState) -> dict:
    logger.info("[L1] retrieve_bill_playbook")
    query = f"Bill explanation playbook for: {state['intent']}"
    try:
        results = await similarity_search(query, n_results=1)
        playbook = results[0]["document"] if results else ""
    except Exception as exc:
        logger.warning("ChromaDB search failed (%s).", exc)
        playbook = "Explain each line item clearly comparing to the previous bill."
    return {"playbook_summary": playbook}


# ─────────────────────────────────────────────
#  Node: generate_explanation_llm
# ─────────────────────────────────────────────

_INTENT_SYSTEM_PROMPTS = {
    "bill_explanation": (
        "You are a helpful telecom billing assistant. "
        "Generate a clear, friendly, plain-language explanation of the customer's bill. "
        "Be concise (3–5 sentences). Explain any increases compared to the previous bill."
    ),
    "compare_previous_bill": (
        "You are a telecom billing assistant. "
        "Compare the customer's current bill to their previous bills. "
        "Highlight the key differences and explain what drove the change. "
        "Be specific with dollar amounts. Use 3–5 sentences."
    ),
    "issue_status": (
        "You are a telecom customer support agent. "
        "Provide a clear status update on the customer's billing issue. "
        "Mention the current status, what actions have been taken, and what to expect next. "
        "Be reassuring and specific. 3–4 sentences."
    ),
    "remediate_issue": (
        "You are a telecom billing specialist. "
        "Confirm that the billing issue has been escalated for automated remediation. "
        "Briefly explain what will happen next. 2–3 sentences."
    ),
    "escalate_to_human": (
        "You are a telecom customer support agent. "
        "Confirm the customer's request to speak with a human agent. "
        "Acknowledge their concern, reassure them, and confirm the escalation. 2–3 sentences."
    ),
    "dispute_creation": (
        "You are a telecom billing dispute specialist. "
        "Confirm the billing dispute has been registered and explain the dispute process. "
        "Mention the reference number, timeline, and what to expect. 3–4 sentences."
    ),
    "partner_charge_explanation": (
        "You are a telecom wholesale/partner billing specialist. "
        "Explain the partner or wholesale charge discrepancy clearly to the customer. "
        "Describe what the charge is, why there is a discrepancy, and what steps are being taken. "
        "3–4 sentences, avoid technical jargon."
    ),
    "roaming_charge_explanation": (
        "You are a telecom billing assistant specializing in international roaming. "
        "Explain the roaming charges on the bill in plain language. "
        "Cover which countries/dates caused the charges, the rate applied, and total amount. "
        "Be specific and helpful. 3–5 sentences."
    ),
    "premium_qos_charge_explanation": (
        "You are a 5G network services specialist at a telecom company. "
        "Explain the premium 5G slice or QoS tier charge to the customer. "
        "Describe what the premium slice offers, why they were charged, "
        "and whether the network delivered the promised performance. "
        "3–4 sentences, plain language."
    ),
    "proactive_risk_summary": (
        "You are a proactive telecom billing risk advisor. "
        "Summarize the billing risk assessment for the customer's account. "
        "Mention the risk level, detected signals, and recommended actions. "
        "Be factual and reassuring. 3–4 sentences."
    ),
    "governed_case_summary": (
        "You are a telecom billing case manager. "
        "Provide a summary of the governed multi-domain dispute case. "
        "Cover which domains are involved (BSS/OSS/Network), current status, "
        "and the coordinated resolution timeline. 3–5 sentences."
    ),
    "collections_hold_request": (
        "You are a telecom billing specialist. "
        "Confirm that a collections hold has been placed on the disputed balance. "
        "Explain what this means for the customer and confirm dunning is paused. 2–3 sentences."
    ),
    "compensation_eligibility_check": (
        "You are a telecom customer experience specialist. "
        "Assess the customer's eligibility for billing compensation based on their account data. "
        "State clearly whether they qualify, the amount, and next steps. 3–4 sentences."
    ),
    "remediation_explanation": (
        "You are a telecom billing resolution specialist. "
        "Explain the remediation actions taken on the customer's account. "
        "Be specific: what was found, what was corrected, and the outcome. 3–4 sentences."
    ),
    "issue_analysis": (
        "You are a telecom billing analyst. "
        "Provide a detailed analysis of the billing issue. "
        "Cover the root cause, affected amounts, and recommended resolution steps. "
        "Be thorough but clear. 4–6 sentences."
    ),
    "schedule_callback": (
        "You are a telecom customer support coordinator. "
        "Confirm the callback scheduling request. "
        "Ask for a preferred time if not provided, or confirm the requested slot. "
        "Be helpful and brief. 2–3 sentences."
    ),
}

_INTENT_FALLBACK_RESPONSES = {
    "partner_charge_explanation": (
        "There is a discrepancy between CSP billing records and the partner's settlement records. "
        "Our team is investigating the CDR export and partner ingestion gap. "
        "A retail correction will be applied to your account within 5 business days."
    ),
    "roaming_charge_explanation": (
        "Your roaming charges this period reflect international data usage. "
        "These charges are calculated at the standard roaming rate per MB for each country visited. "
        "If you believe any charge is incorrect, please contact support for a detailed breakdown."
    ),
    "premium_qos_charge_explanation": (
        "You were charged for the Premium 5G Slice add-on this period. "
        "If there was a service quality issue during the billing period, you may be eligible for a refund. "
        "Please use the remediate option to trigger an automated QoS mismatch check."
    ),
    "proactive_risk_summary": (
        "A proactive billing risk assessment has been performed on your account. "
        "No critical anomalies were detected in the current billing period. "
        "Your account is being monitored for any unusual usage patterns."
    ),
    "governed_case_summary": (
        "Your dispute case spans multiple teams — billing, service assurance, and network. "
        "All teams are coordinating resolution under a governed control case. "
        "You will receive an update once all domain outcomes are confirmed."
    ),
    "dispute_creation": (
        "Your billing dispute has been registered successfully. "
        "A dispute reference will be assigned and a collections hold placed on the disputed amount. "
        "You will receive a resolution within 10 business days."
    ),
    "schedule_callback": (
        "Your callback request has been noted. "
        "An agent will contact you within your requested time window. "
        "You will receive an SMS confirmation shortly."
    ),
}


async def generate_explanation_llm(state: ChatState) -> dict:
    logger.info("[L1] generate_explanation_llm — intent: %s", state.get("intent"))
    intent = state.get("intent", "bill_explanation")
    system_prompt = _INTENT_SYSTEM_PROMPTS.get(intent, _INTENT_SYSTEM_PROMPTS["bill_explanation"])

    # For proactive_risk_summary, fetch live risk data
    extra_context = ""
    if intent == "proactive_risk_summary":
        try:
            from app.components.l1_proactive_risk import assess_billing_risk
            async with AsyncSessionFactory() as db:
                risk = await assess_billing_risk(db, state["billing_account_id"])
            extra_context = (
                f"\nRisk assessment: level={risk['risk_level']} score={risk['risk_score']}/100 "
                f"signals={risk['signal_count']}."
            )
        except Exception as e:
            logger.warning("Risk assessment failed: %s", e)

    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        msgs = state.get("messages", [])
        if msgs:
            last = msgs[-1]
            user_question = last.content if hasattr(last, "content") else last.get("content", "")
        else:
            user_question = ""
        prompt = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=(
                f"Customer message: {user_question}\n\n"
                f"Billing data:\n{state.get('evidence_summary', '')}{extra_context}"
            )),
        ]
        response = await llm.ainvoke(prompt)
        explanation = response.content
    except Exception as exc:
        logger.warning("Gemini explanation failed (%s). Using deterministic fallback.", exc)
        explanation = _INTENT_FALLBACK_RESPONSES.get(
            intent,
            "Your bill is higher this month primarily due to international data roaming charges "
            "and the Premium 5G Slice add-on. Your base plan charge remains unchanged. "
            "There is also a disputed charge of $12.50 which has been flagged for review."
        )
    return {"final_response": explanation}


# ─────────────────────────────────────────────
#  Node: determine_escalation
# ─────────────────────────────────────────────

async def determine_escalation(state: ChatState) -> dict:
    """Escalate only if a dispute/discrepancy is detected."""
    evidence = state.get("evidence_summary", "").lower()
    disputed = "dispute" in evidence or "disputed" in evidence or "duplicate" in evidence
    return {"escalation_required": disputed}


# ─────────────────────────────────────────────
#  Node: stream_response (placeholder — actual SSE handled in generator)
# ─────────────────────────────────────────────

async def stream_response(state: ChatState) -> dict:
    """No-op in graph; SSE streaming is done by the generator wrapping the graph."""
    return {}


# ─────────────────────────────────────────────
#  Node: write_audit
# ─────────────────────────────────────────────

async def write_audit_chat(state: ChatState) -> dict:
    logger.info("[L1] write_audit (chat)")
    trace_id = f"TRACE-CHAT-{state['conversation_id']}-{str(uuid.uuid4())[:8].upper()}"
    async with AsyncSessionFactory() as db:
        cc_id = f"CC-CHAT-{state['conversation_id']}"
        result = await db.execute(select(ControlCase).where(ControlCase.id == cc_id))
        existing_cc = result.scalar_one_or_none()
        if not existing_cc:
            try:
                cc = ControlCase(
                    id=cc_id,
                    issue_id="ISSUE-P8-001",
                    status="chat_resolved",
                    thread_id=state["thread_id"],
                )
                db.add(cc)
                await db.flush()
            except Exception:
                await db.rollback()
                # If it was created concurrently, just proceed
                await db.execute(select(ControlCase).where(ControlCase.id == cc_id))

        trace = AuditTrace(
            id=trace_id,
            control_case_id=cc_id,
            action_type="explanation",
            actor="agent",
            summary=f"Bill explanation provided for {state['customer_id']}",
            details={
                "intent": state.get("intent"),
                "escalation_required": state.get("escalation_required", False),
                "current_bill_id": state.get("current_bill_id"),
            },
        )
        db.add(trace)
        await db.commit()
    return {"audit_trace_id": trace_id}



# ─────────────────────────────────────────────
#  Build graph
# ─────────────────────────────────────────────

def build_chat_graph():
    builder = StateGraph(ChatState)

    builder.add_node("classify_intent", classify_intent)
    builder.add_node("load_customer_context", load_customer_context)
    builder.add_node("load_current_bill", load_current_bill)
    builder.add_node("load_previous_bills", load_previous_bills)
    builder.add_node("retrieve_bill_playbook", retrieve_bill_playbook)
    builder.add_node("generate_explanation_llm", generate_explanation_llm)
    builder.add_node("determine_escalation", determine_escalation)
    builder.add_node("stream_response", stream_response)
    builder.add_node("write_audit", write_audit_chat)

    builder.set_entry_point("classify_intent")
    builder.add_edge("classify_intent", "load_customer_context")
    builder.add_edge("load_customer_context", "load_current_bill")
    builder.add_edge("load_current_bill", "load_previous_bills")
    builder.add_edge("load_previous_bills", "retrieve_bill_playbook")
    builder.add_edge("retrieve_bill_playbook", "generate_explanation_llm")
    builder.add_edge("generate_explanation_llm", "determine_escalation")
    builder.add_edge("determine_escalation", "stream_response")
    builder.add_edge("stream_response", "write_audit")
    builder.add_edge("write_audit", END)

    return builder.compile()


chat_graph = build_chat_graph()


# ─────────────────────────────────────────────
#  SSE streaming generator
# ─────────────────────────────────────────────

async def chat_stream_generator(request_data: dict) -> AsyncGenerator[str, None]:
    """
    Wraps the chat_graph execution and emits SSE events matching the MVP1 contract.
    Events: conversation_started, intent_detected, tool_started, tool_completed,
            evidence_loaded, token, audit_written, final, error
    """
    conversation_id = request_data.get("conversation_id", str(uuid.uuid4()))
    thread_id = conversation_id

    initial_state: ChatState = {
        "conversation_id": conversation_id,
        "customer_id": request_data["customer_id"],
        "billing_account_id": request_data["billing_account_id"],
        "thread_id": thread_id,
        "messages": [{"role": "user", "content": request_data["message"]}],
        "intent": None,
        "current_bill_id": None,
        "previous_bill_ids": [],
        "evidence_summary": "",
        "playbook_summary": "",
        "escalation_required": False,
        "final_response": None,
        "audit_trace_id": None,
        "error": None,
    }

    try:
        yield _sse("conversation_started", {"conversation_id": conversation_id})

        final_state = initial_state

        async for event in chat_graph.astream(initial_state, stream_mode="updates"):
            node_name = next(iter(event))
            updates = event[node_name]

            # Merge updates into running state view (guard against None)
            if isinstance(updates, dict):
                final_state = {**final_state, **updates}

            if node_name == "classify_intent":
                yield _sse("intent_detected", {"intent": updates.get("intent", "unknown")})

            elif node_name == "load_customer_context":
                yield _sse("tool_started", {"tool": "get_customer_context", "summary": "Loading customer profile"})
                yield _sse("tool_completed", {"tool": "get_customer_context", "status": "success"})

            elif node_name == "load_current_bill":
                yield _sse("tool_started", {"tool": "get_customer_bill", "summary": "Loading current bill"})
                yield _sse("tool_completed", {"tool": "get_customer_bill", "status": "success"})

            elif node_name == "load_previous_bills":
                yield _sse("tool_started", {"tool": "get_previous_bills", "summary": "Loading previous bills"})
                yield _sse("tool_completed", {"tool": "get_previous_bills", "status": "success"})
                yield _sse("evidence_loaded", {"bills_loaded": len(updates.get("previous_bill_ids", []))})

            elif node_name == "retrieve_bill_playbook":
                yield _sse("tool_started", {"tool": "retrieve_playbook", "summary": "Fetching remediation playbook"})
                yield _sse("tool_completed", {"tool": "retrieve_playbook", "status": "success"})

            elif node_name == "generate_explanation_llm":
                explanation = updates.get("final_response", "")
                # Stream token-by-token for demo UX
                words = explanation.split()
                for i in range(0, len(words), 5):
                    chunk = " ".join(words[i:i+5]) + " "
                    yield _sse("token", {"text": chunk})

            elif node_name == "write_audit":
                yield _sse("audit_written", {"audit_trace_id": updates.get("audit_trace_id")})

        # Final event
        yield _sse("final", {
            "conversation_id": conversation_id,
            "final_response": final_state.get("final_response", ""),
            "audit_trace_id": final_state.get("audit_trace_id"),
            "escalation_required": final_state.get("escalation_required", False),
        })

    except Exception as exc:
        logger.exception("Chat stream error: %s", exc)
        yield _sse("error", {"message": str(exc)})
