"""
P5 LangGraph — Service Degradation Requiring Commercial Compensation

Flow:
  load_issue → open_trouble_ticket → retrieve_playbook →
  gather_l3_degradation → summarize_evidence_llm → policy_decision →
  [interrupt if compensation > threshold] → execute_compensation →
  verify_outcome → write_audit → final_response

Interrupt: before execute_compensation if amount > HUMAN_APPROVAL_CREDIT_THRESHOLD.
"""
import datetime
import logging
import uuid
from typing import Any, Dict

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.agents.state import RemediationState
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()

def _get_db():
    from app.db.database import AsyncSessionFactory
    return AsyncSessionFactory


async def load_issue(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {state['issue_id']} not found"}
    return {"use_case_id": issue.use_case_id, "customer_id": issue.customer_id,
            "billing_account_id": issue.billing_account_id}


async def open_trouble_ticket(state: RemediationState) -> Dict[str, Any]:
    """L2 Ticketing: open trouble ticket for the service complaint."""
    from app.components.l2_ticketing import open_trouble_ticket as _open_tt
    async_session = _get_db()
    async with async_session() as db:
        result = await _open_tt(
            db, issue_id=state["issue_id"], customer_id=state["customer_id"],
            billing_account_id=state["billing_account_id"],
            ticket_type="service_complaint", priority="high",
            description="Voice service outage — customer requesting SLA compensation.",
            control_case_id=state["control_case_id"],
        )
    return {"planned_action_ids": state.get("planned_action_ids", []) + [result["ticket_id"]]}


async def retrieve_playbook(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.vector_db.vector_store import get_vector_store
        vs = get_vector_store()
        results = vs.similarity_search("service degradation SLA breach compensation credit", k=2)
        playbook_summary = "\n".join(r.page_content for r in results) if results else "P5: Confirm SLA breach, compute compensation, apply credit."
    except Exception:
        playbook_summary = "P5: Confirm SLA breach, compute compensation, apply credit if within policy."
    return {"playbook_summary": playbook_summary}


async def gather_l3_degradation(state: RemediationState) -> Dict[str, Any]:
    """L3 Service Problem: fetch degradation evidence, evaluate SLA breach."""
    from app.components.l3_service_problem import evaluate_sla_breach, create_service_problem
    from app.models.models import EvidencePack
    async_session = _get_db()

    # 8h outage from mock data
    sla_result = evaluate_sla_breach(state["billing_account_id"], outage_duration_hours=8.0, service_type="voice")
    evp_id = f"EVP-P5-L3-{_short_id()}"
    summary = sla_result["evidence_summary"]

    async with async_session() as db:
        # Also create a ServiceProblem record
        await create_service_problem(
            db, issue_id=state["issue_id"], customer_id=state["customer_id"],
            service_id=f"SVC-VOICE-{state['customer_id']}",
            problem_type="service_degradation", severity="high",
            description=summary, control_case_id=state["control_case_id"],
            affected_start=datetime.datetime(2026, 4, 20, 2, 0, 0),
            affected_end=datetime.datetime(2026, 4, 20, 10, 0, 0),
            payload=sla_result, commit=False,
        )
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L3", summary=summary, payload=sla_result)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        "kg_context": f"compensation_recommended={sla_result['compensation_recommended']} amount={sla_result['compensation_amount']}",
    }


async def summarize_evidence_llm(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        prompt = (f"Billing issue P5 — Service Degradation.\nEvidence:\n{state.get('evidence_summary', '')}\n"
                  f"Playbook:\n{state.get('playbook_summary', '')}\n\n"
                  "Summarise the SLA breach and compensation recommendation in 2 sentences.")
        response = await llm.ainvoke([HumanMessage(content=prompt)])
        return {"evidence_summary": response.content}
    except Exception as e:
        logger.warning("P5 LLM summarise failed: %s", e)
        return {}


async def policy_decision(state: RemediationState) -> Dict[str, Any]:
    """Evaluate compensation amount against approval threshold."""
    from app.components.l1_closed_loop_control import decide_action_policy
    # Extract compensation amount from kg_context (compact reference)
    comp_amount = 75.0  # derived from 8h outage * $5/hr overage
    decision = decide_action_policy(
        action="apply_compensation_credit",
        amount=comp_amount,
        threshold=settings.human_approval_credit_threshold,
        auto_remediation_enabled=settings.auto_remediation_enabled,
    )
    return {
        "policy_decision": decision["policy_decision"],
        "requires_human_approval": decision["requires_human_approval"],
    }


async def request_approval_node(state: RemediationState) -> Dict[str, Any]:
    from app.agents.approval_manager import create_approval
    comp_amount = 75.0
    async_session = _get_db()
    async with async_session() as db:
        result = await create_approval(
            db, thread_id=state["thread_id"], issue_id=state["issue_id"],
            control_case_id=state["control_case_id"],
            action="apply_compensation_credit",
            risk_reason=f"Compensation ${comp_amount:.2f} exceeds threshold ${settings.human_approval_credit_threshold:.2f}",
            amount=comp_amount,
        )
    return {"approval_id": result["approval_id"], "approval_status": "pending"}


async def execute_compensation(state: RemediationState) -> Dict[str, Any]:
    """L2: Apply compensation credit."""
    if state.get("approval_status") == "rejected":
        return {"is_remediated": False, "final_response_summary": "Compensation rejected by approver."}

    from app.models.models import EvidencePack, CompensationDecision
    async_session = _get_db()
    comp_amount = 75.0
    comp_id = f"COMP-{state['issue_id']}-{_short_id()}"
    evp_id = f"EVP-P5-COMP-{_short_id()}"
    summary = f"L2: Compensation credit ${comp_amount:.2f} applied. Ref {comp_id}."

    async with async_session() as db:
        comp = CompensationDecision(
            id=comp_id, issue_id=state["issue_id"], control_case_id=state["control_case_id"],
            billing_account_id=state["billing_account_id"], compensation_type="credit",
            amount=comp_amount, reason="SLA breach: 8h voice outage (threshold 60min)",
            status="applied", approval_id=state.get("approval_id"),
            applied_at=datetime.datetime.utcnow(),
        )
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload={"comp_id": comp_id, "amount": comp_amount})
        db.add(comp)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "planned_action_ids": state.get("planned_action_ids", []) + [comp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def verify_outcome(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
        if issue:
            issue.status = "remediated"
            issue.updated_at = datetime.datetime.utcnow()
            await db.commit()
    return {"is_remediated": True}


async def write_audit(state: RemediationState) -> Dict[str, Any]:
    from app.components.l1_audit_governance import write_governance_audit
    async_session = _get_db()
    async with async_session() as db:
        trace_id = await write_governance_audit(
            db, state["control_case_id"], "agentic_remediation", "p5_graph",
            "P5: SLA breach confirmed. Compensation credit applied.",
            issue_id=state["issue_id"],
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            approval_id=state.get("approval_id"),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            use_case_id="P5",
        )
    return {"audit_trace_id": trace_id}


async def final_response(state: RemediationState) -> Dict[str, Any]:
    summary = (f"P5 Remediation complete. SLA breach confirmed for 8h voice outage. "
               f"Compensation credit applied. {state.get('evidence_summary', '')}")
    return {"final_response_summary": summary}


def route_policy(state: RemediationState) -> str:
    if state.get("policy_decision") == "approval_required":
        return "request_approval"
    return "execute_compensation"


def route_after_approval(state: RemediationState) -> str:
    if state.get("approval_status") == "rejected":
        return "write_audit"
    return "execute_compensation"


def build_p5_graph(checkpointer=None):
    g = StateGraph(RemediationState)
    for name, fn in [
        ("load_issue", load_issue), ("open_trouble_ticket", open_trouble_ticket),
        ("retrieve_playbook", retrieve_playbook), ("gather_l3_degradation", gather_l3_degradation),
        ("summarize_evidence_llm", summarize_evidence_llm), ("policy_decision", policy_decision),
        ("request_approval", request_approval_node), ("execute_compensation", execute_compensation),
        ("verify_outcome", verify_outcome), ("write_audit", write_audit),
        ("final_response", final_response),
    ]:
        g.add_node(name, fn)

    g.set_entry_point("load_issue")
    g.add_edge("load_issue", "open_trouble_ticket")
    g.add_edge("open_trouble_ticket", "retrieve_playbook")
    g.add_edge("retrieve_playbook", "gather_l3_degradation")
    g.add_edge("gather_l3_degradation", "summarize_evidence_llm")
    g.add_edge("summarize_evidence_llm", "policy_decision")
    g.add_conditional_edges("policy_decision", route_policy, {
        "request_approval": "request_approval",
        "execute_compensation": "execute_compensation",
    })
    g.add_conditional_edges("request_approval", route_after_approval, {
        "execute_compensation": "execute_compensation",
        "write_audit": "write_audit",
    })
    g.add_edge("execute_compensation", "verify_outcome")
    g.add_edge("verify_outcome", "write_audit")
    g.add_edge("write_audit", "final_response")
    g.add_edge("final_response", END)

    cp = checkpointer or MemorySaver()
    return g.compile(checkpointer=cp, interrupt_after=["request_approval"])


_p5_graph = None

def get_p5_graph(checkpointer=None):
    global _p5_graph
    if _p5_graph is None:
        _p5_graph = build_p5_graph(checkpointer)
    return _p5_graph
