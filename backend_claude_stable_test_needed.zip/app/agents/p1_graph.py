"""
P1 LangGraph — Missing or Delayed Usage Feed into Billing

Flow:
  load_issue → load_context → retrieve_playbook → gather_l4_event →
  gather_l3_mediation → gather_l2_bill_exposure → summarize_evidence_llm →
  policy_decision → [interrupt if risk] → execute_mediation_replay →
  execute_bill_protection → verify_outcome → write_audit → final_response

Interrupt: before execute_mediation_replay if approval_required.
"""
import datetime
import logging
import uuid
from typing import Any, Dict

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.agents.state import RemediationState
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# ── Helpers ──────────────────────────────────────────────────────────────────

def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()


def _get_db():
    """Lazy import to avoid circular deps at module load."""
    from app.db.database import AsyncSessionFactory
    return AsyncSessionFactory


# ── Nodes ────────────────────────────────────────────────────────────────────

async def load_issue(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {state['issue_id']} not found"}
    return {
        "use_case_id": issue.use_case_id,
        "customer_id": issue.customer_id,
        "billing_account_id": issue.billing_account_id,
        "bill_id": issue.bill_id,
    }


async def load_context(state: RemediationState) -> Dict[str, Any]:
    """Load TMF event if linked."""
    from sqlalchemy import select
    from app.models.models import TMFEvent
    async_session = _get_db()
    event_id = None
    async with async_session() as db:
        result = await db.execute(
            select(TMFEvent)
            .where(TMFEvent.issue_id == state["issue_id"], TMFEvent.use_case_id == "P1")
            .limit(1)
        )
        ev = result.scalar_one_or_none()
        if ev:
            event_id = ev.id
    return {"event_id": event_id}


async def retrieve_playbook(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.vector_db.vector_store import get_vector_store
        vs = get_vector_store()
        results = vs.similarity_search("missing usage feed mediation delay billing", k=2)
        playbook_summary = "\n".join(r.page_content for r in results) if results else "P1: Replay delayed usage events, apply bill protection hold."
    except Exception:
        playbook_summary = "P1: Replay delayed usage events, apply bill protection hold pending replay."
    return {"playbook_summary": playbook_summary}


async def gather_l4_event(state: RemediationState) -> Dict[str, Any]:
    """L4 publishes suspected usage delay event evidence."""
    from app.models.models import EvidencePack, ControlCase
    from sqlalchemy import select
    async_session = _get_db()

    payload = {
        "source": "L4_charging_NF",
        "event_type": "SuspectedUsageDelayEvent",
        "delayed_events": 847,
        "delay_hours": 18,
        "pipeline_stage": "CDR_COLLECTION",
        "estimated_impact_usd": 38.50,
        "billing_period": "2026-04",
    }
    evp_id = f"EVP-P1-L4-{_short_id()}"
    summary = "L4: 847 CDR events delayed 18h in CDR_COLLECTION pipeline. Estimated bill impact $38.50."

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L4", summary=summary, payload=payload)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def gather_l3_mediation(state: RemediationState) -> Dict[str, Any]:
    """L3 provides mediation backlog evidence."""
    from app.components.l3_mediation_replay import get_mediation_backlog
    from app.models.models import EvidencePack
    async_session = _get_db()

    backlog = await get_mediation_backlog(state["billing_account_id"])
    evp_id = f"EVP-P1-L3-{_short_id()}"
    summary = backlog["evidence_summary"]

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L3", summary=summary, payload=backlog)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def gather_l2_bill_exposure(state: RemediationState) -> Dict[str, Any]:
    """L2 assesses bill-run exposure."""
    from app.models.models import EvidencePack
    async_session = _get_db()

    payload = {
        "source": "L2_bill_insight",
        "billing_account_id": state["billing_account_id"],
        "billing_period": "2026-04",
        "bill_run_status": "pending",
        "exposure_risk": "high",
        "estimated_exposure_usd": 38.50,
        "protection_recommended": True,
    }
    evp_id = f"EVP-P1-L2-{_short_id()}"
    summary = "L2: Bill-run pending for 2026-04. Exposure $38.50 if delayed usage not replayed. Bill protection recommended."

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload=payload)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def summarize_evidence_llm(state: RemediationState) -> Dict[str, Any]:
    """LLM summarises evidence and sets policy context."""
    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        prompt = (
            f"Billing issue P1 — Missing Usage Feed.\n"
            f"Evidence:\n{state.get('evidence_summary', '')}\n"
            f"Playbook:\n{state.get('playbook_summary', '')}\n\n"
            "In 2 sentences, summarise the root cause and recommended action."
        )
        response = await llm.ainvoke([HumanMessage(content=prompt)])
        return {"evidence_summary": response.content}
    except Exception as e:
        logger.warning("P1 LLM summarise failed: %s", e)
        return {}


async def policy_decision(state: RemediationState) -> Dict[str, Any]:
    """Decide if auto-remediation is allowed or approval required."""
    from app.components.l1_closed_loop_control import decide_action_policy
    exposure = 38.50  # from evidence
    decision = decide_action_policy(
        action="execute_mediation_replay",
        amount=exposure,
        threshold=settings.human_approval_credit_threshold,
        auto_remediation_enabled=settings.auto_remediation_enabled,
    )
    return {
        "policy_decision": decision["policy_decision"],
        "requires_human_approval": decision["requires_human_approval"],
    }


async def request_approval_node(state: RemediationState) -> Dict[str, Any]:
    """Create approval record and prepare for interrupt."""
    from app.agents.approval_manager import create_approval
    async_session = _get_db()
    async with async_session() as db:
        result = await create_approval(
            db,
            thread_id=state["thread_id"],
            issue_id=state["issue_id"],
            control_case_id=state["control_case_id"],
            action="execute_mediation_replay",
            risk_reason=f"Mediation replay exposure ${38.50:.2f} exceeds threshold ${settings.human_approval_credit_threshold:.2f}",
            amount=38.50,
        )
    return {"approval_id": result["approval_id"], "approval_status": "pending"}


async def execute_mediation_replay(state: RemediationState) -> Dict[str, Any]:
    """L3 executes mediation replay."""
    if state.get("approval_status") == "rejected":
        return {"is_remediated": False, "final_response_summary": "Mediation replay rejected by approver."}

    from app.components.l3_mediation_replay import create_mediation_replay_job
    from app.models.models import EvidencePack
    async_session = _get_db()

    async with async_session() as db:
        result = await create_mediation_replay_job(
            db, issue_id=state["issue_id"],
            billing_account_id=state["billing_account_id"],
            events_count=847, control_case_id=state["control_case_id"],
        )
    evp_id = f"EVP-P1-REPLAY-{_short_id()}"
    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L3", summary=result["evidence_summary"], payload=result)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{result['evidence_summary']}",
    }


async def execute_bill_protection(state: RemediationState) -> Dict[str, Any]:
    """L2 applies bill protection hold."""
    from app.components.l3_mediation_replay import apply_bill_protection_hold
    result = apply_bill_protection_hold(state["billing_account_id"], "2026-04", 38.50)
    return {
        "evidence_summary": state.get("evidence_summary", "") + f"\n{result['evidence_summary']}",
        "planned_action_ids": state.get("planned_action_ids", []) + [result["hold_reference"]],
    }


async def verify_outcome(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
        if issue:
            issue.status = "remediated"
            issue.updated_at = datetime.datetime.utcnow()
            await db.commit()
    return {"is_remediated": True}


async def write_audit(state: RemediationState) -> Dict[str, Any]:
    from app.components.l1_audit_governance import write_governance_audit
    async_session = _get_db()
    async with async_session() as db:
        trace_id = await write_governance_audit(
            db, state["control_case_id"], "agentic_remediation", "p1_graph",
            "P1: Mediation replay executed. Bill protection hold applied.",
            issue_id=state["issue_id"],
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            approval_id=state.get("approval_id"),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            use_case_id="P1",
        )
    return {"audit_trace_id": trace_id}


async def final_response(state: RemediationState) -> Dict[str, Any]:
    summary = (
        f"P1 Remediation complete. {state.get('evidence_summary', '')} "
        f"Mediation replay executed. Bill protection hold applied."
    )
    return {"final_response_summary": summary}


# ── Router ───────────────────────────────────────────────────────────────────

def route_policy(state: RemediationState) -> str:
    if state.get("policy_decision") == "approval_required":
        return "request_approval"
    return "execute_mediation_replay"


def route_after_approval(state: RemediationState) -> str:
    """Post-interrupt router — reads approval_status set by resume input."""
    if state.get("approval_status") == "rejected":
        return "write_audit"
    return "execute_mediation_replay"


# ── Build graph ───────────────────────────────────────────────────────────────

def build_p1_graph(checkpointer=None):
    g = StateGraph(RemediationState)
    g.add_node("load_issue", load_issue)
    g.add_node("load_context", load_context)
    g.add_node("retrieve_playbook", retrieve_playbook)
    g.add_node("gather_l4_event", gather_l4_event)
    g.add_node("gather_l3_mediation", gather_l3_mediation)
    g.add_node("gather_l2_bill_exposure", gather_l2_bill_exposure)
    g.add_node("summarize_evidence_llm", summarize_evidence_llm)
    g.add_node("policy_decision", policy_decision)
    g.add_node("request_approval", request_approval_node)
    g.add_node("execute_mediation_replay", execute_mediation_replay)
    g.add_node("execute_bill_protection", execute_bill_protection)
    g.add_node("verify_outcome", verify_outcome)
    g.add_node("write_audit", write_audit)
    g.add_node("final_response", final_response)

    g.set_entry_point("load_issue")
    g.add_edge("load_issue", "load_context")
    g.add_edge("load_context", "retrieve_playbook")
    g.add_edge("retrieve_playbook", "gather_l4_event")
    g.add_edge("gather_l4_event", "gather_l3_mediation")
    g.add_edge("gather_l3_mediation", "gather_l2_bill_exposure")
    g.add_edge("gather_l2_bill_exposure", "summarize_evidence_llm")
    g.add_edge("summarize_evidence_llm", "policy_decision")
    g.add_conditional_edges("policy_decision", route_policy, {
        "request_approval": "request_approval",
        "execute_mediation_replay": "execute_mediation_replay",
    })
    # Interrupt point — graph pauses here for human approval
    g.add_conditional_edges("request_approval", route_after_approval, {
        "execute_mediation_replay": "execute_mediation_replay",
        "write_audit": "write_audit",
    })
    g.add_edge("execute_mediation_replay", "execute_bill_protection")
    g.add_edge("execute_bill_protection", "verify_outcome")
    g.add_edge("verify_outcome", "write_audit")
    g.add_edge("write_audit", "final_response")
    g.add_edge("final_response", END)

    cp = checkpointer or MemorySaver()
    return g.compile(checkpointer=cp, interrupt_after=["request_approval"])


# Lazy-loaded singleton
_p1_graph = None

def get_p1_graph(checkpointer=None):
    global _p1_graph
    if _p1_graph is None:
        _p1_graph = build_p1_graph(checkpointer)
    return _p1_graph
