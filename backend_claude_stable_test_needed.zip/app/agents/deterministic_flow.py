"""
Deterministic remediation handler for use cases P7 and P10.

MVP2 Note: P1, P4, P5, P6, P9 have been promoted to full LangGraph flows
(p1_graph.py, p4_graph.py, p5_graph.py, p6_graph.py, p9_graph.py).
Only P7 (partner settlement) and P10 (cross-domain) remain here as
simplified deterministic flows pending their own LangGraph promotion.

Each flow:
  1. Loads the issue.
  2. Creates a ControlCase.
  3. Applies a predefined evidence/action template.
  4. Updates issue status.
  5. Creates an audit trace.
  6. Returns a realistic response.
"""

import datetime
import logging
import uuid
from typing import Dict, Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Issue, ControlCase, EvidencePack, AuditTrace
from app.services import l2_bss_service, l3_oss_service, l4_network_service

logger = logging.getLogger(__name__)


# P1, P4, P5, P6, P9 removed — now handled by dedicated LangGraph flows in MVP2.
# Only P7 and P10 remain as simplified deterministic placeholders.
DETERMINISTIC_TEMPLATES: Dict[str, Dict[str, Any]] = {
    "P7": {
        "summary": "Partner/wholesale charge discrepancy identified. Settlement record flagged for reconciliation.",
        "action": "reconciliation_flagged",
        "layer": "L2",
        "evidence": "CSP record: $48,200. Partner MVNO-X record: $45,000. Discrepancy: $3,200 flagged for manual settlement review.",
    },
    "P10": {
        "summary": "End-to-end governed dispute resolution initiated across BSS, OSS, and Network layers.",
        "action": "cross_domain_dispute",
        "layer": "L1-L2-L3-L4",
        "evidence": "L2: Bill correction queued. L3: Service problem SP-9900 opened. L4: Network audit initiated. Governance checkpoint created.",
    },
}


async def run_deterministic_flow(db: AsyncSession, issue_id: str) -> Dict[str, Any]:
    """Execute a deterministic remediation flow and return a structured response."""

    # Load the issue
    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {issue_id} not found."}

    use_case_id = issue.use_case_id
    template = DETERMINISTIC_TEMPLATES.get(use_case_id)
    if not template:
        return {"error": f"No deterministic template for use case {use_case_id}."}

    # Create control case
    cc_id = f"CC-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    cc = ControlCase(
        id=cc_id,
        issue_id=issue_id,
        status="resolved",
        resolved_at=datetime.datetime.utcnow(),
    )
    db.add(cc)
    await db.flush()

    # Create evidence pack
    evp_id = f"EVP-DET-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    evp = EvidencePack(
        id=evp_id,
        control_case_id=cc_id,
        source_layer=template["layer"],
        summary=template["evidence"],
        payload={
            "template": template,
            "applied_at": datetime.datetime.utcnow().isoformat(),
        },
    )
    db.add(evp)

    # Update issue status
    issue.status = "remediated"
    issue.updated_at = datetime.datetime.utcnow()

    # Create audit trace
    trace_id = f"TRACE-DET-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    trace = AuditTrace(
        id=trace_id,
        control_case_id=cc_id,
        action_type="deterministic_remediation",
        actor="agent",
        summary=template["summary"],
        details={
            "use_case_id": use_case_id,
            "action": template["action"],
            "evidence_pack_id": evp_id,
        },
    )
    db.add(trace)
    await db.commit()

    logger.info("Deterministic flow completed for %s: %s", issue_id, trace_id)
    return {
        "issue_id": issue_id,
        "use_case_id": use_case_id,
        "control_case_id": cc_id,
        "evidence_pack_id": evp_id,
        "audit_trace_id": trace_id,
        "action": template["action"],
        "summary": template["summary"],
        "status": "remediated",
    }
