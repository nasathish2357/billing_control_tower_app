"""
P10 LangGraph — Governed End-to-End Dispute Handling Across BSS, OSS, and Network

P10 is the capstone governed flow. It enforces L1 orchestration rules strictly:
  L1 is the sole coordinator — L2/L3/L4 execute only their own domain actions.
  All domains must synchronize before the control case closes.

Flow:
  load_issue → open_governed_case → retrieve_playbook →
  gather_l2_bss_evidence → gather_l3_oss_evidence → gather_l4_network_evidence →
  synthesize_cross_domain_evidence → policy_decision →
  [interrupt if enterprise correction > threshold] →
  execute_bss_correction → execute_oss_closure → execute_network_audit →
  synchronize_domain_outcomes → write_audit → final_response

Key design principles (from p10_governed_dispute.md):
  - L1 orchestrates; L2/L3/L4 never communicate directly.
  - All three domain outcomes must be confirmed before case closes.
  - Approval interrupt gates high-value enterprise corrections.
  - Audit trace captures full cross-domain action chain.
"""
import datetime
import logging
import uuid
from typing import Any, Dict

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.agents.state import RemediationState
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# Enterprise correction amount for P10 seed case (Broadcom, 16h outage)
# 16h outage × $5/hr × enterprise SLA multiplier (2.5) = $200
# Plus BSS charge correction for 3-domain impact: $320 total
_P10_CORRECTION_AMOUNT = 320.0
_P10_OUTAGE_HOURS = 16.0


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()


def _get_db():
    from app.db.database import AsyncSessionFactory
    return AsyncSessionFactory


# ── Nodes ─────────────────────────────────────────────────────────────────────

async def load_issue(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async with _get_db()() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {state['issue_id']} not found"}
    return {
        "use_case_id": issue.use_case_id,
        "customer_id": issue.customer_id,
        "billing_account_id": issue.billing_account_id,
    }


async def open_governed_case(state: RemediationState) -> Dict[str, Any]:
    """
    L2 Ticketing: open a multi-domain trouble ticket.
    This ticket tracks cross-team coordination for the governed dispute.
    """
    from app.components.l2_ticketing import open_trouble_ticket
    async with _get_db()() as db:
        result = await open_trouble_ticket(
            db,
            issue_id=state["issue_id"],
            customer_id=state["customer_id"],
            billing_account_id=state["billing_account_id"],
            ticket_type="governed_multi_domain_dispute",
            priority="critical",
            description=(
                "P10 governed dispute: multi-domain outage spanning BSS charge correction, "
                "OSS service problem closure, and network CDR audit for Enterprise account."
            ),
            control_case_id=state["control_case_id"],
            extra_payload={"domains": ["BSS", "OSS", "Network"], "sla_tier": "enterprise"},
        )
    logger.info("P10: governed trouble ticket %s opened", result["ticket_id"])
    return {
        "planned_action_ids": state.get("planned_action_ids", []) + [result["ticket_id"]],
    }


async def retrieve_playbook(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.vector_db.vector_store import get_vector_store
        vs = get_vector_store()
        results = vs.similarity_search(
            "governed end-to-end dispute BSS OSS network multi-domain cross-team synchronization", k=2
        )
        playbook_summary = "\n".join(r.page_content for r in results) if results else (
            "P10: L1 orchestrates all domains. Gather BSS, OSS, Network evidence independently. "
            "All domain outcomes must confirm before case closes. Approval required for high-value corrections."
        )
    except Exception:
        playbook_summary = (
            "P10: Governed dispute. L1 coordinates L2 (BSS), L3 (OSS), L4 (Network). "
            "Each layer acts only within its own domain. Case closes only after full synchronization."
        )
    return {"playbook_summary": playbook_summary}


async def gather_l2_bss_evidence(state: RemediationState) -> Dict[str, Any]:
    """
    L2 BSS: assess billing charge impact for the enterprise account.
    The 16-hour outage led to an incorrect premium slice charge during the degradation window.
    """
    from app.models.models import EvidencePack, BillingAccount, Bill
    from sqlalchemy import select

    async with _get_db()() as db:
        # Fetch latest bill for the account
        bill_result = await db.execute(
            select(Bill)
            .where(Bill.billing_account_id == state["billing_account_id"])
            .order_by(Bill.billing_period.desc())
            .limit(1)
        )
        bill = bill_result.scalar_one_or_none()
        bill_id = bill.id if bill else "N/A"
        bill_period = bill.billing_period if bill else "2026-04"

        summary = (
            f"L2 BSS: Enterprise account {state['billing_account_id']} — "
            f"premium 5G slice charged during {_P10_OUTAGE_HOURS:.0f}h outage window (bill {bill_id}, "
            f"period {bill_period}). "
            f"Incorrect charge: ${_P10_CORRECTION_AMOUNT:.2f} covering slice fee + SLA penalty refund. "
            f"BSS correction required: apply charge reversal + compensation credit."
        )
        evp_id = f"EVP-P10-L2-BSS-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L2", summary=summary,
            payload={
                "billing_account_id": state["billing_account_id"],
                "bill_id": bill_id,
                "billing_period": bill_period,
                "outage_hours": _P10_OUTAGE_HOURS,
                "correction_amount": _P10_CORRECTION_AMOUNT,
                "charge_types": ["premium_slice_reversal", "sla_compensation"],
            },
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        "kg_context": f"bss_correction_required=True amount={_P10_CORRECTION_AMOUNT}",
    }


async def gather_l3_oss_evidence(state: RemediationState) -> Dict[str, Any]:
    """
    L3 OSS: evaluate SLA breach from the multi-domain outage.
    Enterprise SLA threshold is 30 minutes; 16h outage is a critical breach.
    """
    from app.components.l3_service_problem import create_service_problem, evaluate_sla_breach
    from app.models.models import EvidencePack

    # Evaluate SLA breach — enterprise BA-100002 has stricter SLA
    sla_result = evaluate_sla_breach(
        state["billing_account_id"],
        outage_duration_hours=_P10_OUTAGE_HOURS,
        service_type="data_and_voice",
    )

    async with _get_db()() as db:
        await create_service_problem(
            db,
            issue_id=state["issue_id"],
            customer_id=state["customer_id"],
            service_id=f"SVC-ENT-{state['billing_account_id']}",
            problem_type="multi_domain_outage",
            severity="critical",
            description=(
                f"P10 multi-domain outage: {_P10_OUTAGE_HOURS:.0f}h service degradation "
                f"spanning BSS, OSS, and Network for Broadcom Enterprise. SLA breach confirmed."
            ),
            control_case_id=state["control_case_id"],
            affected_start=datetime.datetime(2026, 4, 18, 8, 0, 0),
            affected_end=datetime.datetime(2026, 4, 19, 0, 0, 0),
            payload=sla_result,
            commit=False,
        )

        evp_id = f"EVP-P10-L3-OSS-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L3", summary=sla_result["evidence_summary"], payload=sla_result,
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{sla_result['evidence_summary']}",
    }


async def gather_l4_network_evidence(state: RemediationState) -> Dict[str, Any]:
    """
    L4 Network: audit network session and CDR records for the outage window.
    Confirms whether session accounting correctly reflected the degradation period.
    """
    from app.models.models import EvidencePack, PDUSession, NetworkFunction
    from sqlalchemy import select

    async with _get_db()() as db:
        # Fetch PDU sessions for the billing account
        pdu_result = await db.execute(
            select(PDUSession).where(
                PDUSession.billing_account_id == state["billing_account_id"]
            ).limit(10)
        )
        pdu_sessions = pdu_result.scalars().all()

        # Fetch relevant network functions (UPF, AMF, SMF)
        nf_result = await db.execute(
            select(NetworkFunction).where(
                NetworkFunction.nf_type.in_(["UPF", "AMF", "SMF", "PCF"])
            ).limit(4)
        )
        nfs = nf_result.scalars().all()

        active_during_outage = [s for s in pdu_sessions if s.status in ("zombie", "active")]
        nf_ids = [nf.id for nf in nfs]

        summary = (
            f"L4 Network: {len(pdu_sessions)} PDU session(s) audited for {state['billing_account_id']}. "
            f"{len(active_during_outage)} session(s) active during outage window. "
            f"Network functions audited: {', '.join(nf_ids) if nf_ids else 'N/A'}. "
            f"CDR export confirmed: accounting records cover outage period. "
            f"Network audit complete — no session accounting anomalies detected beyond known outage cause."
        )

        evp_id = f"EVP-P10-L4-NET-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L4", summary=summary,
            payload={
                "pdu_session_count": len(pdu_sessions),
                "active_during_outage": len(active_during_outage),
                "pdu_session_ids": [s.id for s in pdu_sessions],
                "network_function_ids": nf_ids,
                "audit_conclusion": "network_audit_complete",
            },
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def synthesize_cross_domain_evidence(state: RemediationState) -> Dict[str, Any]:
    """L1: use LLM to synthesize evidence across all three domain layers."""
    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        prompt = (
            f"Billing issue P10 — Governed Multi-Domain Dispute (Enterprise).\n"
            f"Evidence from L2 (BSS), L3 (OSS), L4 (Network):\n"
            f"{state.get('evidence_summary', '')}\n"
            f"Playbook:\n{state.get('playbook_summary', '')}\n\n"
            "In 3 sentences: summarize the root cause, confirm which domains are impacted, "
            "and recommend the coordinated remediation actions for L1 to authorize."
        )
        response = await llm.ainvoke([HumanMessage(content=prompt)])
        return {"evidence_summary": response.content}
    except Exception as e:
        logger.warning("P10 LLM synthesize failed: %s", e)
        return {}


async def policy_decision(state: RemediationState) -> Dict[str, Any]:
    """
    L1 Closed-Loop Control: evaluate whether coordinated enterprise correction
    requires human approval. Enterprise accounts always flag for approval given
    bulk_customer_impact and high correction amount.
    """
    from app.components.l1_closed_loop_control import decide_action_policy
    decision = decide_action_policy(
        action="execute_p10_coordinated_correction",
        amount=_P10_CORRECTION_AMOUNT,
        threshold=settings.human_approval_credit_threshold,
        bulk_customer_impact=True,          # enterprise multi-service
        auto_remediation_enabled=settings.auto_remediation_enabled,
    )
    logger.info(
        "P10 policy decision: %s (correction=$%.2f, enterprise=True)",
        decision["policy_decision"], _P10_CORRECTION_AMOUNT,
    )
    return {
        "policy_decision": decision["policy_decision"],
        "requires_human_approval": decision["requires_human_approval"],
    }


async def request_approval_node(state: RemediationState) -> Dict[str, Any]:
    """L1 Human-in-the-Loop: create approval record and interrupt for human decision."""
    from app.agents.approval_manager import create_approval
    async with _get_db()() as db:
        result = await create_approval(
            db,
            thread_id=state["thread_id"],
            issue_id=state["issue_id"],
            control_case_id=state["control_case_id"],
            action="execute_p10_coordinated_correction",
            risk_reason=(
                f"P10 governed dispute — enterprise correction ${_P10_CORRECTION_AMOUNT:.2f} "
                f"exceeds threshold ${settings.human_approval_credit_threshold:.2f}. "
                f"Multi-domain impact: BSS charge reversal + OSS SLA remedy + Network audit. "
                f"Customer: {state.get('customer_id')} ({state.get('billing_account_id')})."
            ),
            amount=_P10_CORRECTION_AMOUNT,
        )
    return {"approval_id": result["approval_id"], "approval_status": "pending"}


async def execute_bss_correction(state: RemediationState) -> Dict[str, Any]:
    """
    L2 BSS: Apply charge reversal and compensation credit for the enterprise account.
    Skipped if approval was rejected (OSS and Network domains still execute their own closures).
    """
    if state.get("approval_status") == "rejected":
        summary = (
            "L2 BSS: Correction rejected by approver. "
            "BSS charge reversal not applied. OSS and Network closures will proceed."
        )
        return {
            "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
            "kg_context": (state.get("kg_context", "") or "") + " bss_correction_applied=False",
        }

    from app.models.models import EvidencePack, CompensationDecision

    comp_id = f"COMP-P10-{state['issue_id']}-{_short_id()}"
    evp_id = f"EVP-P10-BSS-CORR-{_short_id()}"
    summary = (
        f"L2 BSS: Charge reversal + compensation credit ${_P10_CORRECTION_AMOUNT:.2f} "
        f"applied to {state['billing_account_id']}. "
        f"Ref: {comp_id}. Covers premium slice reversal + enterprise SLA penalty."
    )

    async with _get_db()() as db:
        comp = CompensationDecision(
            id=comp_id,
            issue_id=state["issue_id"],
            control_case_id=state["control_case_id"],
            billing_account_id=state["billing_account_id"],
            compensation_type="credit",
            amount=_P10_CORRECTION_AMOUNT,
            reason=(
                f"P10 governed dispute: {_P10_OUTAGE_HOURS:.0f}h multi-domain outage. "
                "Premium slice reversal + enterprise SLA breach compensation."
            ),
            status="applied",
            approval_id=state.get("approval_id"),
            applied_at=datetime.datetime.utcnow(),
        )
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L2", summary=summary,
            payload={"comp_id": comp_id, "amount": _P10_CORRECTION_AMOUNT},
        )
        db.add(comp)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        "planned_action_ids": state.get("planned_action_ids", []) + [comp_id],
        "kg_context": (state.get("kg_context", "") or "") + " bss_correction_applied=True",
    }


async def execute_oss_closure(state: RemediationState) -> Dict[str, Any]:
    """
    L3 OSS: Close the service problem record and record the SLA remedy outcome.
    This executes regardless of BSS approval — OSS closure is always authorized.
    """
    from app.models.models import EvidencePack, ServiceProblem
    from sqlalchemy import select

    async with _get_db()() as db:
        # Find and close the service problem for this issue
        sp_result = await db.execute(
            select(ServiceProblem).where(ServiceProblem.issue_id == state["issue_id"]).limit(1)
        )
        sp = sp_result.scalar_one_or_none()
        if sp:
            sp.status = "closed"
            sp.resolved_at = datetime.datetime.utcnow()
            sp.payload = {**(sp.payload or {}), "closed_by": "p10_graph", "oss_remedy": "sla_breach_recorded"}

        summary = (
            f"L3 OSS: Service problem for issue {state['issue_id']} closed. "
            f"SLA breach recorded — {_P10_OUTAGE_HOURS:.0f}h multi-domain outage. "
            f"OSS closure confirmed. SLA remedy applied to account record."
        )
        evp_id = f"EVP-P10-L3-OSS-CLOSE-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L3", summary=summary,
            payload={"oss_outcome": "closed", "sla_remedy": "applied"},
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        "planned_action_ids": state.get("planned_action_ids", []) + [evp_id],
        "kg_context": (state.get("kg_context", "") or "") + " oss_closure=True",
    }


async def execute_network_audit(state: RemediationState) -> Dict[str, Any]:
    """
    L4 Network: Finalize network CDR audit and confirm session accounting is clean.
    Network audit closure is always authorized — no billing action, evidence only.
    """
    from app.models.models import EvidencePack
    from app.components.l3_mediation_replay import create_mediation_replay_job

    # For P10, the network action is CDR audit confirmation via mediation replay
    async with _get_db()() as db:
        replay = await create_mediation_replay_job(
            db,
            issue_id=state["issue_id"],
            billing_account_id=state["billing_account_id"],
            events_count=0,         # P10: audit confirms no replay needed — records are clean
            control_case_id=state["control_case_id"],
            commit=False,
        )

        summary = (
            f"L4 Network: CDR audit complete for {state['billing_account_id']}. "
            f"All session records confirmed clean during outage window. "
            f"No CDR replay required — network accounting is accurate. "
            f"Audit ref: {replay['job_id']}."
        )
        evp_id = f"EVP-P10-L4-NET-AUDIT-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L4", summary=summary,
            payload={"network_outcome": "audit_complete", "cdr_replay_required": False,
                     "audit_job_id": replay["job_id"]},
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        "planned_action_ids": state.get("planned_action_ids", []) + [replay["job_id"]],
        "kg_context": (state.get("kg_context", "") or "") + " network_audit=True",
    }


async def synchronize_domain_outcomes(state: RemediationState) -> Dict[str, Any]:
    """
    L1 Master Orchestration: verify all three domain outcomes are confirmed.
    Control case closes only when BSS, OSS, and Network all report outcomes.
    The kg_context string is used as compact domain completion tracker.
    """
    from sqlalchemy import select
    from app.models.models import Issue, ControlCase

    kg = state.get("kg_context", "") or ""
    bss_done = "bss_correction_applied" in kg
    oss_done = "oss_closure=True" in kg
    net_done = "network_audit=True" in kg
    all_synchronized = bss_done and oss_done and net_done

    async with _get_db()() as db:
        # Update Issue status
        issue_result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = issue_result.scalar_one_or_none()
        if issue:
            issue.status = "remediated" if all_synchronized else "partial_remediation"
            issue.updated_at = datetime.datetime.utcnow()

        # Update ControlCase status
        cc_result = await db.execute(select(ControlCase).where(ControlCase.id == state["control_case_id"]))
        cc = cc_result.scalar_one_or_none()
        if cc:
            cc.status = "closed" if all_synchronized else "partial"
            cc.resolved_at = datetime.datetime.utcnow() if all_synchronized else None

        await db.commit()

    sync_summary = (
        f"L1 Synchronization: BSS={'✓' if bss_done else '✗'} "
        f"OSS={'✓' if oss_done else '✗'} "
        f"Network={'✓' if net_done else '✗'}. "
        f"All domains synchronized: {all_synchronized}. "
        f"Control case {'closed' if all_synchronized else 'partially resolved'}."
    )
    logger.info("P10 domain sync: %s", sync_summary)

    return {
        "is_remediated": all_synchronized,
        "evidence_summary": state.get("evidence_summary", "") + f"\n{sync_summary}",
    }


async def write_audit(state: RemediationState) -> Dict[str, Any]:
    from app.components.l1_audit_governance import write_governance_audit
    async with _get_db()() as db:
        trace_id = await write_governance_audit(
            db, state["control_case_id"], "agentic_remediation", "p10_graph",
            (
                f"P10 governed dispute resolved. "
                f"BSS correction: ${_P10_CORRECTION_AMOUNT:.2f}. "
                f"OSS service problem closed. Network CDR audit complete. "
                f"All domains synchronized: {state.get('is_remediated', False)}."
            ),
            issue_id=state["issue_id"],
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            approval_id=state.get("approval_id"),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            use_case_id="P10",
            extra={
                "domains_covered": ["BSS", "OSS", "Network"],
                "enterprise_account": state.get("billing_account_id"),
                "kg_context": state.get("kg_context"),
            },
        )
    return {"audit_trace_id": trace_id}


async def final_response(state: RemediationState) -> Dict[str, Any]:
    bss_applied = "bss_correction_applied=True" in (state.get("kg_context") or "")
    summary = (
        f"P10 Governed Dispute complete. "
        f"L1 orchestrated full cross-domain resolution for enterprise account {state.get('billing_account_id')}. "
        f"BSS: {'Charge reversal + compensation $' + str(_P10_CORRECTION_AMOUNT) + ' applied' if bss_applied else 'Correction pending approval'}. "
        f"OSS: Service problem closed, SLA breach recorded. "
        f"Network: CDR audit confirmed clean. "
        f"All domain outcomes synchronized. Control case closed."
    )
    return {"final_response_summary": summary}


# ── Routers ────────────────────────────────────────────────────────────────────

def route_policy(state: RemediationState) -> str:
    if state.get("policy_decision") == "approval_required":
        return "request_approval"
    return "execute_bss_correction"


def route_after_approval(state: RemediationState) -> str:
    # Regardless of approval outcome, all 3 domain execution nodes run in sequence.
    # execute_bss_correction handles the rejected case internally (skips the credit).
    return "execute_bss_correction"


# ── Build graph ────────────────────────────────────────────────────────────────

def build_p10_graph(checkpointer=None):
    g = StateGraph(RemediationState)

    nodes = [
        ("load_issue", load_issue),
        ("open_governed_case", open_governed_case),
        ("retrieve_playbook", retrieve_playbook),
        ("gather_l2_bss_evidence", gather_l2_bss_evidence),
        ("gather_l3_oss_evidence", gather_l3_oss_evidence),
        ("gather_l4_network_evidence", gather_l4_network_evidence),
        ("synthesize_cross_domain_evidence", synthesize_cross_domain_evidence),
        ("policy_decision", policy_decision),
        ("request_approval", request_approval_node),
        ("execute_bss_correction", execute_bss_correction),
        ("execute_oss_closure", execute_oss_closure),
        ("execute_network_audit", execute_network_audit),
        ("synchronize_domain_outcomes", synchronize_domain_outcomes),
        ("write_audit", write_audit),
        ("final_response", final_response),
    ]
    for name, fn in nodes:
        g.add_node(name, fn)

    g.set_entry_point("load_issue")
    g.add_edge("load_issue", "open_governed_case")
    g.add_edge("open_governed_case", "retrieve_playbook")
    g.add_edge("retrieve_playbook", "gather_l2_bss_evidence")
    g.add_edge("gather_l2_bss_evidence", "gather_l3_oss_evidence")
    g.add_edge("gather_l3_oss_evidence", "gather_l4_network_evidence")
    g.add_edge("gather_l4_network_evidence", "synthesize_cross_domain_evidence")
    g.add_edge("synthesize_cross_domain_evidence", "policy_decision")
    g.add_conditional_edges("policy_decision", route_policy, {
        "request_approval": "request_approval",
        "execute_bss_correction": "execute_bss_correction",
    })
    # Interrupt point — graph pauses here; human approves/rejects via API
    g.add_conditional_edges("request_approval", route_after_approval, {
        "execute_bss_correction": "execute_bss_correction",
    })
    g.add_edge("execute_bss_correction", "execute_oss_closure")
    g.add_edge("execute_oss_closure", "execute_network_audit")
    g.add_edge("execute_network_audit", "synchronize_domain_outcomes")
    g.add_edge("synchronize_domain_outcomes", "write_audit")
    g.add_edge("write_audit", "final_response")
    g.add_edge("final_response", END)

    cp = checkpointer or MemorySaver()
    return g.compile(checkpointer=cp, interrupt_after=["request_approval"])


_p10_graph = None


def get_p10_graph(checkpointer=None):
    global _p10_graph
    if _p10_graph is None:
        _p10_graph = build_p10_graph(checkpointer)
    return _p10_graph