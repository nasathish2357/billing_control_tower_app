"""
LangGraph Checkpoint Setup — MVP2

Configures async PostgresSaver for graph state persistence.
Tables are created automatically on first use (idempotent — safe to call multiple times).
"""
import logging

from app.config import get_settings

logger = logging.getLogger(__name__)

_checkpointer = None
_checkpointer_context = None


def _normalize_postgres_conn_string(conn_string: str) -> str:
    """Convert SQLAlchemy-style Postgres URLs to psycopg-compatible URLs."""
    if conn_string.startswith("postgresql+psycopg://"):
        return conn_string.replace("postgresql+psycopg://", "postgresql://", 1)
    if conn_string.startswith("postgresql+asyncpg://"):
        return conn_string.replace("postgresql+asyncpg://", "postgresql://", 1)
    return conn_string


async def setup_checkpointer():
    """
    Initialize the PostgresSaver checkpointer.
    Creates checkpoint tables if they don't already exist (idempotent).
    Returns the configured saver instance.
    """
    global _checkpointer, _checkpointer_context
    if _checkpointer is not None:
        return _checkpointer

    settings = get_settings()
    conn_string = _normalize_postgres_conn_string(
        settings.langgraph_checkpoint_database_url or settings.database_url
    )

    try:
        from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
        _checkpointer_context = AsyncPostgresSaver.from_conn_string(conn_string)
        saver = await _checkpointer_context.__aenter__()
        # setup() creates tables if they don't exist (idempotent)
        await saver.setup()
        _checkpointer = saver
        logger.info("✅ LangGraph PostgresSaver checkpointer initialized.")
        return saver
    except ImportError:
        logger.warning(
            "langgraph-checkpoint-postgres not installed. "
            "Human approval interrupt/resume will use MemorySaver fallback."
        )
        from langgraph.checkpoint.memory import MemorySaver
        _checkpointer = MemorySaver()
        return _checkpointer
    except Exception as e:
        if _checkpointer_context is not None:
            try:
                await _checkpointer_context.__aexit__(None, None, None)
            except Exception:
                logger.exception("Error closing failed PostgresSaver context.")
            _checkpointer_context = None
        logger.error("Failed to initialize PostgresSaver: %s. Using MemorySaver fallback.", e)
        from langgraph.checkpoint.memory import MemorySaver
        _checkpointer = MemorySaver()
        return _checkpointer


def get_checkpointer():
    """Return the initialized checkpointer (must call setup_checkpointer() first)."""
    return _checkpointer


async def close_checkpointer():
    """Close the app-lifetime Postgres checkpointer context, if one is active."""
    global _checkpointer, _checkpointer_context
    if _checkpointer_context is not None:
        await _checkpointer_context.__aexit__(None, None, None)
    _checkpointer_context = None
    _checkpointer = None
