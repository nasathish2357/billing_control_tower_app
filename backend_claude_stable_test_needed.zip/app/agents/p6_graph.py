"""
P6 LangGraph — Collections Hold Required During Billing Dispute

Flow (L2-only — no cross-domain escalation unless evidence required):
  load_issue → open_trouble_ticket → check_collections_state →
  retrieve_playbook → evaluate_hold_policy →
  apply_disputed_hold → separate_debt → write_audit → final_response
"""
import datetime
import logging
import uuid
from typing import Any, Dict

from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.agents.state import RemediationState

logger = logging.getLogger(__name__)


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()

def _get_db():
    from app.db.database import AsyncSessionFactory
    return AsyncSessionFactory


async def load_issue(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {state['issue_id']} not found"}
    return {"use_case_id": issue.use_case_id, "customer_id": issue.customer_id,
            "billing_account_id": issue.billing_account_id}


async def open_trouble_ticket(state: RemediationState) -> Dict[str, Any]:
    """L2 Ticketing: open billing dispute ticket."""
    from app.components.l2_ticketing import open_trouble_ticket as _open_tt
    from app.models.models import EvidencePack
    async_session = _get_db()
    async with async_session() as db:
        result = await _open_tt(
            db, issue_id=state["issue_id"], customer_id=state["customer_id"],
            billing_account_id=state["billing_account_id"],
            ticket_type="billing_dispute", priority="medium",
            description="Customer disputes invoice charge. Collections hold evaluation required.",
            control_case_id=state["control_case_id"],
        )
    evp_id = f"EVP-P6-TT-{_short_id()}"
    summary = f"L2 Ticket {result['ticket_id']} opened: billing_dispute, priority {result['priority']}."
    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload=result)
        db.add(evp)
        await db.commit()
    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        "planned_action_ids": state.get("planned_action_ids", []) + [result["ticket_id"]],
    }


async def check_collections_state(state: RemediationState) -> Dict[str, Any]:
    """L2 Collections: check current dunning / collections state."""
    from app.models.models import EvidencePack
    async_session = _get_db()

    from app.components.l2_collections_dunning import get_dunning_state
    dunning = get_dunning_state(state["billing_account_id"])

    evp_id = f"EVP-P6-COL-{_short_id()}"
    summary = (f"L2 Collections: stage={dunning['stage']}, overdue={dunning['overdue_days']}d, "
               f"balance=${dunning['balance']:.2f}.")

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload=dunning)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        "kg_context": f"dunning_stage={dunning['stage']} balance={dunning['balance']}",
    }


async def retrieve_playbook(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.vector_db.vector_store import get_vector_store
        vs = get_vector_store()
        results = vs.similarity_search("collections hold billing dispute dunning pause", k=2)
        playbook_summary = "\n".join(r.page_content for r in results) if results else "P6: Place hold on disputed portion, pause dunning, allow undisputed to proceed."
    except Exception:
        playbook_summary = "P6: Place hold on disputed portion, pause dunning, allow undisputed to proceed."
    return {"playbook_summary": playbook_summary}


async def evaluate_hold_policy(state: RemediationState) -> Dict[str, Any]:
    """Evaluate whether a hold should be applied."""
    from app.components.l2_collections_dunning import evaluate_hold_policy as _eval
    # Disputed amount from mock event data for P6
    disputed_amount = 12.50
    policy = _eval(state["billing_account_id"], disputed_amount)
    return {
        "policy_decision": "auto_remediation_allowed" if policy["hold_recommended"] else "no_action",
        "evidence_summary": state.get("evidence_summary", "") + f"\n{policy.get('evidence_summary', '')}",
    }


async def apply_disputed_hold(state: RemediationState) -> Dict[str, Any]:
    """L2: Apply collections hold on disputed amount."""
    from app.components.l2_ticketing import apply_collections_hold
    from app.models.models import EvidencePack
    async_session = _get_db()

    disputed = 12.50
    undisputed = 77.49
    async with async_session() as db:
        result = await apply_collections_hold(
            db, issue_id=state["issue_id"],
            billing_account_id=state["billing_account_id"],
            disputed_amount=disputed, undisputed_amount=undisputed,
            hold_reason="Invoice dispute raised by customer",
            control_case_id=state["control_case_id"],
        )
    evp_id = f"EVP-P6-HOLD-{_short_id()}"
    summary = f"L2: Collections hold {result['hold_id']} — disputed ${disputed:.2f} held, undisputed ${undisputed:.2f} remains collectible."

    async with async_session() as db:
        evp = EvidencePack(id=evp_id, control_case_id=state["control_case_id"],
                           source_layer="L2", summary=summary, payload=result)
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "planned_action_ids": state.get("planned_action_ids", []) + [result["hold_id"]],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def separate_debt(state: RemediationState) -> Dict[str, Any]:
    """L2: Separate disputed from undisputed — dunning continues only on undisputed."""
    from app.components.l2_collections_dunning import separate_disputed_balance
    separation = separate_disputed_balance(89.99, 12.50)
    summary = (f"L2: Total balance ${separation['total_balance']:.2f} separated — "
               f"disputed ${separation['disputed_amount']:.2f} held, "
               f"undisputed ${separation['undisputed_amount']:.2f} collectible.")
    return {"evidence_summary": state.get("evidence_summary", "") + f"\n{summary}"}


async def verify_outcome(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async_session = _get_db()
    async with async_session() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
        if issue:
            issue.status = "remediated"
            issue.updated_at = datetime.datetime.utcnow()
            await db.commit()
    return {"is_remediated": True}


async def write_audit(state: RemediationState) -> Dict[str, Any]:
    from app.components.l1_audit_governance import write_governance_audit
    async_session = _get_db()
    async with async_session() as db:
        trace_id = await write_governance_audit(
            db, state["control_case_id"], "agentic_remediation", "p6_graph",
            "P6: Billing dispute registered. Collections hold applied on disputed portion. Dunning paused.",
            issue_id=state["issue_id"],
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            use_case_id="P6",
        )
    return {"audit_trace_id": trace_id}


async def final_response(state: RemediationState) -> Dict[str, Any]:
    summary = (f"P6 Remediation complete. Collections hold applied on disputed balance. "
               f"Dunning paused on disputed portion. Undisputed balance remains collectible. "
               f"{state.get('evidence_summary', '')}")
    return {"final_response_summary": summary}


def build_p6_graph(checkpointer=None):
    g = StateGraph(RemediationState)
    for name, fn in [
        ("load_issue", load_issue), ("open_trouble_ticket", open_trouble_ticket),
        ("check_collections_state", check_collections_state),
        ("retrieve_playbook", retrieve_playbook), ("evaluate_hold_policy", evaluate_hold_policy),
        ("apply_disputed_hold", apply_disputed_hold), ("separate_debt", separate_debt),
        ("verify_outcome", verify_outcome), ("write_audit", write_audit),
        ("final_response", final_response),
    ]:
        g.add_node(name, fn)

    g.set_entry_point("load_issue")
    g.add_edge("load_issue", "open_trouble_ticket")
    g.add_edge("open_trouble_ticket", "check_collections_state")
    g.add_edge("check_collections_state", "retrieve_playbook")
    g.add_edge("retrieve_playbook", "evaluate_hold_policy")
    g.add_edge("evaluate_hold_policy", "apply_disputed_hold")
    g.add_edge("apply_disputed_hold", "separate_debt")
    g.add_edge("separate_debt", "verify_outcome")
    g.add_edge("verify_outcome", "write_audit")
    g.add_edge("write_audit", "final_response")
    g.add_edge("final_response", END)

    cp = checkpointer or MemorySaver()
    return g.compile(checkpointer=cp)


_p6_graph = None

def get_p6_graph(checkpointer=None):
    global _p6_graph
    if _p6_graph is None:
        _p6_graph = build_p6_graph(checkpointer)
    return _p6_graph
