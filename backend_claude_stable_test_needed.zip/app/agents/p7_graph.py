"""
P7 LangGraph — Partner or Wholesale Charge Discrepancy

Flow:
  load_issue → load_partner_context → retrieve_playbook →
  gather_l2_billing_impact → gather_l4_sepp_evidence → gather_l4_chf_evidence →
  gather_l3_mediation_cdrs → summarize_evidence_llm → policy_decision →
  [interrupt if retail credit > threshold] →
  execute_retail_correction → create_partner_recovery → verify_outcome →
  write_audit → final_response

Key design principle (from P7 playbook):
  - Retail customer correction and partner settlement recovery are SEPARATE processes.
  - L2 applies retail credit immediately when overcharge is confirmed.
  - L2 creates partner recovery case separately; partner timeline is independent.
  - L4 provides SEPP/CHF evidence; L3 validates CDR counts.
  - Audit trace links retail outcome to wholesale recovery case.
"""
import datetime
import logging
import uuid
from typing import Any, Dict

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from app.agents.state import RemediationState
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()


def _get_db():
    from app.db.database import AsyncSessionFactory
    return AsyncSessionFactory


# ── Nodes ─────────────────────────────────────────────────────────────────────

async def load_issue(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async with _get_db()() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
    if not issue:
        return {"error": f"Issue {state['issue_id']} not found"}
    return {
        "use_case_id": issue.use_case_id,
        "customer_id": issue.customer_id,
        "billing_account_id": issue.billing_account_id,
    }


async def load_partner_context(state: RemediationState) -> Dict[str, Any]:
    """Load the partner settlement record linked to this issue."""
    from sqlalchemy import select
    from app.models.models import PartnerSettlement, TroubleTicket
    async with _get_db()() as db:
        # Find partner settlement by issue_id
        ps_result = await db.execute(
            select(PartnerSettlement).where(
                PartnerSettlement.issue_id == state["issue_id"]
            ).limit(1)
        )
        settlement = ps_result.scalar_one_or_none()

        # Find trouble ticket
        tt_result = await db.execute(
            select(TroubleTicket).where(
                TroubleTicket.issue_id == state["issue_id"]
            ).limit(1)
        )
        ticket = tt_result.scalar_one_or_none()

    context = {}
    if settlement:
        context["partner_account_id"] = settlement.partner_account_id
        context["billing_period"] = settlement.billing_period
        context["discrepancy_amount"] = settlement.discrepancy_amount
    else:
        # Fallback from issue description / seed data
        context["partner_account_id"] = "PARTNER-001"
        context["billing_period"] = "2026-03"
        context["discrepancy_amount"] = 3200.00

    if ticket:
        context["trouble_ticket_id"] = ticket.id

    logger.info("P7: loaded partner context — partner=%s period=%s discrepancy=$%.2f",
                context.get("partner_account_id"), context.get("billing_period"),
                context.get("discrepancy_amount", 0))
    return context


async def retrieve_playbook(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.vector_db.vector_store import get_vector_store
        vs = get_vector_store()
        results = vs.similarity_search(
            "partner wholesale charge discrepancy SEPP CDR roaming settlement", k=2
        )
        playbook_summary = "\n".join(r.page_content for r in results) if results else (
            "P7: Gather SEPP CDR export evidence. Confirm partner ingestion gap. "
            "Apply retail customer correction. Create partner settlement recovery case separately."
        )
    except Exception:
        playbook_summary = (
            "P7: Confirm CSP CDR export via SEPP. Validate partner CDR count mismatch. "
            "Apply retail correction if customer overcharged. Create partner recovery case."
        )
    return {"playbook_summary": playbook_summary}


async def gather_l2_billing_impact(state: RemediationState) -> Dict[str, Any]:
    """L2: assess retail customer's billing impact from the partner discrepancy."""
    from app.components.l2_roaming_partner_settlement import get_retail_billing_impact
    from app.models.models import EvidencePack

    async with _get_db()() as db:
        impact = await get_retail_billing_impact(
            db,
            billing_account_id=state["billing_account_id"],
            billing_period=state.get("billing_period", "2026-03"),
            partner_account_id=state.get("partner_account_id"),
        )
        evp_id = f"EVP-P7-L2-RETAIL-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L2", summary=impact["evidence_summary"], payload=impact,
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{impact['evidence_summary']}",
        "retail_overcharge_usd": impact.get("retail_overcharge_usd", 0.0),
        "retail_correction_required": impact.get("retail_correction_required", False),
    }


async def gather_l4_sepp_evidence(state: RemediationState) -> Dict[str, Any]:
    """L4: gather SEPP N32 CDR export evidence confirming CSP's side of the discrepancy."""
    from app.components.l4_roaming_exposure import get_sepp_cdr_export_evidence
    from app.models.models import EvidencePack

    async with _get_db()() as db:
        sepp_ev = await get_sepp_cdr_export_evidence(
            db,
            partner_account_id=state.get("partner_account_id", "PARTNER-001"),
            billing_period=state.get("billing_period", "2026-03"),
            issue_id=state["issue_id"],
        )
        evp_id = f"EVP-P7-L4-SEPP-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L4", summary=sepp_ev["evidence_summary"], payload=sepp_ev,
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{sepp_ev['evidence_summary']}",
        "sepp_export_complete": sepp_ev.get("csr_export_complete", True),
        "partner_ingestion_gap_confirmed": sepp_ev.get("partner_ingestion_gap_confirmed", False),
        "l4_evidence_ref": sepp_ev.get("sepp_log_ref"),
    }


async def gather_l4_chf_evidence(state: RemediationState) -> Dict[str, Any]:
    """L4: gather CHF charging records for disputed roaming sessions."""
    from app.components.l4_roaming_exposure import get_chf_roaming_charging_records
    from app.models.models import EvidencePack

    async with _get_db()() as db:
        chf_ev = await get_chf_roaming_charging_records(
            db,
            billing_account_id=state["billing_account_id"],
            billing_period=state.get("billing_period", "2026-03"),
        )
        evp_id = f"EVP-P7-L4-CHF-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L4", summary=chf_ev["evidence_summary"], payload=chf_ev,
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{chf_ev['evidence_summary']}",
    }


async def gather_l3_mediation_cdrs(state: RemediationState) -> Dict[str, Any]:
    """L3: validate CSP-side CDR count via mediation records for the settlement period."""
    from sqlalchemy import select, func
    from app.models.models import MediationRecord, EvidencePack

    async with _get_db()() as db:
        mr_result = await db.execute(
            select(MediationRecord).where(
                MediationRecord.billing_account_id == state["billing_account_id"],
                MediationRecord.billing_period == state.get("billing_period", "2026-03"),
            )
        )
        records = mr_result.scalars().all()

        cdr_count = len(records)
        rated_count = sum(1 for r in records if r.status == "rated")
        roaming_records = [r for r in records if "roam" in (r.payload or {}).get("charge_type", "")]

        summary = (
            f"L3 Mediation: {cdr_count} CDR(s) found for {state['billing_account_id']} "
            f"in {state.get('billing_period', '2026-03')}. "
            f"Rated: {rated_count}. Roaming-related: {len(roaming_records)}. "
            f"CSP mediation records confirm export was complete."
        )
        evp_id = f"EVP-P7-L3-MED-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L3", summary=summary,
            payload={"cdr_count": cdr_count, "rated_count": rated_count,
                     "roaming_records": len(roaming_records),
                     "mediation_record_ids": [r.id for r in records]},
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
    }


async def summarize_evidence_llm(state: RemediationState) -> Dict[str, Any]:
    try:
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        prompt = (
            f"Billing issue P7 — Partner/Wholesale Charge Discrepancy.\n"
            f"Evidence:\n{state.get('evidence_summary', '')}\n"
            f"Playbook:\n{state.get('playbook_summary', '')}\n\n"
            "In 2–3 sentences: summarise the root cause of the discrepancy, "
            "whether the retail customer was overcharged, and the recommended action."
        )
        response = await llm.ainvoke([HumanMessage(content=prompt)])
        return {"evidence_summary": response.content}
    except Exception as e:
        logger.warning("P7 LLM summarise failed: %s", e)
        return {}


async def policy_decision(state: RemediationState) -> Dict[str, Any]:
    """
    Decide if retail correction can be auto-applied or needs approval.
    Partner recovery case is always created; only retail credit is threshold-gated.
    """
    from app.components.l1_closed_loop_control import decide_action_policy
    retail_overcharge = state.get("retail_overcharge_usd", 0.0)
    decision = decide_action_policy(
        action="apply_retail_credit_p7",
        amount=retail_overcharge,
        threshold=settings.human_approval_credit_threshold,
        auto_remediation_enabled=settings.auto_remediation_enabled,
    )
    logger.info("P7 policy decision: %s (retail overcharge $%.2f)",
                decision["policy_decision"], retail_overcharge)
    return {
        "policy_decision": decision["policy_decision"],
        "requires_human_approval": decision["requires_human_approval"],
    }


async def request_approval_node(state: RemediationState) -> Dict[str, Any]:
    from app.agents.approval_manager import create_approval
    retail_overcharge = state.get("retail_overcharge_usd", 0.0)
    async with _get_db()() as db:
        result = await create_approval(
            db,
            thread_id=state["thread_id"],
            issue_id=state["issue_id"],
            control_case_id=state["control_case_id"],
            action="apply_retail_credit_p7",
            risk_reason=(
                f"Retail credit ${retail_overcharge:.2f} exceeds threshold "
                f"${settings.human_approval_credit_threshold:.2f}. "
                f"P7 partner discrepancy: {state.get('partner_account_id')} "
                f"settlement {state.get('billing_period')}."
            ),
            amount=retail_overcharge,
        )
    return {"approval_id": result["approval_id"], "approval_status": "pending"}


async def execute_retail_correction(state: RemediationState) -> Dict[str, Any]:
    """
    L2: Apply retail customer credit for the partner-related overcharge.
    Skipped if no overcharge, or proceeds to create recovery case only.
    """
    if state.get("approval_status") == "rejected":
        return {
            "is_remediated": False,
            "final_response_summary": "Retail correction rejected by approver. Partner recovery case will still be created.",
        }

    retail_overcharge = state.get("retail_overcharge_usd", 0.0)
    updates: Dict[str, Any] = {}

    if retail_overcharge > 0 and state.get("retail_correction_required"):
        from app.components.l2_roaming_partner_settlement import apply_retail_correction
        from app.models.models import EvidencePack

        async with _get_db()() as db:
            correction = await apply_retail_correction(
                db,
                issue_id=state["issue_id"],
                control_case_id=state["control_case_id"],
                billing_account_id=state["billing_account_id"],
                overcharge_amount=retail_overcharge,
                reason=(
                    f"P7 partner discrepancy — customer overcharged for roaming. "
                    f"Partner: {state.get('partner_account_id')}, "
                    f"Period: {state.get('billing_period')}."
                ),
                approval_id=state.get("approval_id"),
            )
            evp_id = f"EVP-P7-RETAIL-CORR-{_short_id()}"
            evp = EvidencePack(
                id=evp_id, control_case_id=state["control_case_id"],
                source_layer="L2", summary=correction["evidence_summary"], payload=correction,
            )
            db.add(evp)
            await db.commit()

        updates = {
            "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
            "evidence_summary": state.get("evidence_summary", "") + f"\n{correction['evidence_summary']}",
            "planned_action_ids": state.get("planned_action_ids", []) + [correction["comp_id"]],
        }
    else:
        summary = "L2: No retail overcharge detected. Retail correction not required. Proceeding to partner recovery."
        logger.info("P7: no retail overcharge — skipping retail correction")
        updates = {
            "evidence_summary": state.get("evidence_summary", "") + f"\n{summary}",
        }

    return updates


async def create_partner_recovery(state: RemediationState) -> Dict[str, Any]:
    """
    L2: Create partner settlement recovery case.
    Always executed regardless of retail correction outcome.
    Links to L4 SEPP evidence for partner escalation.
    """
    from app.components.l2_roaming_partner_settlement import create_partner_recovery_case
    from app.models.models import EvidencePack

    discrepancy = state.get("discrepancy_amount", 3200.00)

    async with _get_db()() as db:
        recovery = await create_partner_recovery_case(
            db,
            partner_account_id=state.get("partner_account_id", "PARTNER-001"),
            billing_period=state.get("billing_period", "2026-03"),
            discrepancy_amount=discrepancy,
            control_case_id=state["control_case_id"],
            issue_id=state["issue_id"],
            l4_evidence_ref=state.get("l4_evidence_ref"),
        )
        evp_id = f"EVP-P7-PARTNER-RECOVERY-{_short_id()}"
        evp = EvidencePack(
            id=evp_id, control_case_id=state["control_case_id"],
            source_layer="L2", summary=recovery["evidence_summary"], payload=recovery,
        )
        db.add(evp)
        await db.commit()

    return {
        "evidence_pack_ids": state.get("evidence_pack_ids", []) + [evp_id],
        "evidence_summary": state.get("evidence_summary", "") + f"\n{recovery['evidence_summary']}",
        "planned_action_ids": state.get("planned_action_ids", []) + [recovery["recovery_case_ref"]],
        "partner_recovery_ref": recovery["recovery_case_ref"],
    }


async def verify_outcome(state: RemediationState) -> Dict[str, Any]:
    from sqlalchemy import select
    from app.models.models import Issue
    async with _get_db()() as db:
        result = await db.execute(select(Issue).where(Issue.id == state["issue_id"]))
        issue = result.scalar_one_or_none()
        if issue:
            issue.status = "remediated"
            issue.updated_at = datetime.datetime.utcnow()
            await db.commit()
    return {"is_remediated": True}


async def write_audit(state: RemediationState) -> Dict[str, Any]:
    from app.components.l1_audit_governance import write_governance_audit
    async with _get_db()() as db:
        trace_id = await write_governance_audit(
            db, state["control_case_id"], "agentic_remediation", "p7_graph",
            (
                f"P7: Partner discrepancy resolved. "
                f"Retail correction: ${state.get('retail_overcharge_usd', 0):.2f}. "
                f"Partner recovery ref: {state.get('partner_recovery_ref', 'N/A')}."
            ),
            issue_id=state["issue_id"],
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            approval_id=state.get("approval_id"),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            use_case_id="P7",
        )
    return {"audit_trace_id": trace_id}


async def final_response(state: RemediationState) -> Dict[str, Any]:
    retail_amt = state.get("retail_overcharge_usd", 0.0)
    recovery_ref = state.get("partner_recovery_ref", "N/A")
    summary = (
        f"P7 Remediation complete. "
        f"SEPP CDR export confirmed complete from CSP side. "
        f"Partner ingestion gap identified as root cause. "
        f"Retail correction: ${retail_amt:.2f} credit applied to customer account. "
        f"Partner settlement recovery case created: {recovery_ref}. "
        f"Partner resolution timeline is independent of retail correction."
    )
    return {"final_response_summary": summary}


# ── Routers ────────────────────────────────────────────────────────────────────

def route_policy(state: RemediationState) -> str:
    if state.get("policy_decision") == "approval_required":
        return "request_approval"
    return "execute_retail_correction"


def route_after_approval(state: RemediationState) -> str:
    if state.get("approval_status") == "rejected":
        return "create_partner_recovery"
    return "execute_retail_correction"


# ── Build graph ────────────────────────────────────────────────────────────────

def build_p7_graph(checkpointer=None):
    g = StateGraph(RemediationState)

    nodes = [
        ("load_issue", load_issue),
        ("load_partner_context", load_partner_context),
        ("retrieve_playbook", retrieve_playbook),
        ("gather_l2_billing_impact", gather_l2_billing_impact),
        ("gather_l4_sepp_evidence", gather_l4_sepp_evidence),
        ("gather_l4_chf_evidence", gather_l4_chf_evidence),
        ("gather_l3_mediation_cdrs", gather_l3_mediation_cdrs),
        ("summarize_evidence_llm", summarize_evidence_llm),
        ("policy_decision", policy_decision),
        ("request_approval", request_approval_node),
        ("execute_retail_correction", execute_retail_correction),
        ("create_partner_recovery", create_partner_recovery),
        ("verify_outcome", verify_outcome),
        ("write_audit", write_audit),
        ("final_response", final_response),
    ]
    for name, fn in nodes:
        g.add_node(name, fn)

    g.set_entry_point("load_issue")
    g.add_edge("load_issue", "load_partner_context")
    g.add_edge("load_partner_context", "retrieve_playbook")
    g.add_edge("retrieve_playbook", "gather_l2_billing_impact")
    g.add_edge("gather_l2_billing_impact", "gather_l4_sepp_evidence")
    g.add_edge("gather_l4_sepp_evidence", "gather_l4_chf_evidence")
    g.add_edge("gather_l4_chf_evidence", "gather_l3_mediation_cdrs")
    g.add_edge("gather_l3_mediation_cdrs", "summarize_evidence_llm")
    g.add_edge("summarize_evidence_llm", "policy_decision")
    g.add_conditional_edges("policy_decision", route_policy, {
        "request_approval": "request_approval",
        "execute_retail_correction": "execute_retail_correction",
    })
    # Interrupt point — graph pauses here for human approval
    g.add_conditional_edges("request_approval", route_after_approval, {
        "execute_retail_correction": "execute_retail_correction",
        "create_partner_recovery": "create_partner_recovery",
    })
    g.add_edge("execute_retail_correction", "create_partner_recovery")
    g.add_edge("create_partner_recovery", "verify_outcome")
    g.add_edge("verify_outcome", "write_audit")
    g.add_edge("write_audit", "final_response")
    g.add_edge("final_response", END)

    cp = checkpointer or MemorySaver()
    return g.compile(checkpointer=cp, interrupt_after=["request_approval"])


_p7_graph = None


def get_p7_graph(checkpointer=None):
    global _p7_graph
    if _p7_graph is None:
        _p7_graph = build_p7_graph(checkpointer)
    return _p7_graph
