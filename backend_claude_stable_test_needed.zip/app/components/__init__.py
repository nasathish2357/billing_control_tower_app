"""MVP2 bounded components package."""
