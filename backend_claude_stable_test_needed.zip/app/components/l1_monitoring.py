"""
L1 Monitoring Component — MVP2

Responsibilities:
  - Poll/read TMFEvent table for new events.
  - Match event_type to use_case_id using deterministic correlation rules.
  - Create or update ControlCase for the correlated issue.
  - Mark event as correlated.
  - Emit structured logs for each correlation action.
"""
import datetime
import logging
import uuid
from typing import Optional, Dict, Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import TMFEvent, ControlCase, Issue, AuditTrace

logger = logging.getLogger(__name__)

# Deterministic correlation: event_type → use_case_id
EVENT_TO_USE_CASE: Dict[str, str] = {
    "SuspectedUsageDelayEvent": "P1",
    "DuplicateChargingEvent": "P2",
    "ZombieSessionSuspectedEvent": "P3",
    "QoSMismatchEvent": "P4",
    "ServiceDegradationEvent": "P5",
    "CollectionsRiskEvent": "P6",
    "BillingRiskDetectedEvent": "P9",
    "MediationReplayCompletedEvent": "P1",
    "RemediationCompletedEvent": None,  # generic — handled by control case status
}


async def correlate_event(db: AsyncSession, event_id: str) -> Dict[str, Any]:
    """
    Correlate a TMFEvent to an Issue and create/update a ControlCase.

    Returns a dict with correlation results.
    """
    result = await db.execute(select(TMFEvent).where(TMFEvent.id == event_id))
    event = result.scalar_one_or_none()
    if not event:
        return {"error": f"Event {event_id} not found"}

    if event.status == "correlated":
        return {"message": f"Event {event_id} already correlated", "event_id": event_id}

    # Resolve use_case_id from event_type
    use_case_id = event.use_case_id or EVENT_TO_USE_CASE.get(event.event_type)
    if not use_case_id:
        logger.warning("L1 Monitoring: no use_case_id mapping for event_type=%s", event.event_type)
        return {"warning": f"No use_case mapping for event_type={event.event_type}"}

    # Find associated issue
    issue: Optional[Issue] = None
    if event.issue_id:
        issue_result = await db.execute(select(Issue).where(Issue.id == event.issue_id))
        issue = issue_result.scalar_one_or_none()

    if not issue:
        logger.warning("L1 Monitoring: no issue found for event %s", event_id)
        return {"warning": f"No issue linked to event {event_id}"}

    # Create ControlCase
    cc_id = f"CC-MON-{event_id}-{str(uuid.uuid4())[:6].upper()}"
    thread_id = f"THREAD-MON-{event_id}"
    cc = ControlCase(
        id=cc_id,
        issue_id=issue.id,
        status="investigating",
        thread_id=thread_id,
        requires_human_approval=False,
    )
    db.add(cc)

    # Update event to correlated
    event.status = "correlated"
    event.control_case_id = cc_id
    event.correlated_at = datetime.datetime.utcnow()

    # Audit trace
    trace_id = f"TRACE-MON-{event_id}-{str(uuid.uuid4())[:6].upper()}"
    trace = AuditTrace(
        id=trace_id,
        control_case_id=cc_id,
        action_type="event_correlation",
        actor="l1_monitoring",
        summary=f"L1 Monitoring correlated {event.event_type} to issue {issue.id} — ControlCase {cc_id} created.",
        details={
            "event_id": event_id,
            "event_type": event.event_type,
            "use_case_id": use_case_id,
            "issue_id": issue.id,
            "control_case_id": cc_id,
        },
    )
    db.add(trace)
    await db.commit()

    logger.info(
        "L1 Monitoring: event=%s correlated → issue=%s cc=%s",
        event_id, issue.id, cc_id,
    )
    return {
        "event_id": event_id,
        "event_type": event.event_type,
        "use_case_id": use_case_id,
        "issue_id": issue.id,
        "control_case_id": cc_id,
        "thread_id": thread_id,
        "audit_trace_id": trace_id,
    }


async def get_new_events(db: AsyncSession, limit: int = 20):
    """Fetch all unprocessed (new) events."""
    result = await db.execute(
        select(TMFEvent)
        .where(TMFEvent.status == "new")
        .order_by(TMFEvent.created_at)
        .limit(limit)
    )
    return result.scalars().all()
