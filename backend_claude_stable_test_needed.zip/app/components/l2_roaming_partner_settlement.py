"""
L2 Roaming & Partner Settlement Component — MVP3

Owner layer: L2 BSS Revenue, Care & Back Office

Responsibilities:
  - Retrieve retail customer billing impact from partner/roaming charge discrepancy.
  - Apply retail customer credit when customer was overcharged (separate from partner process).
  - Create partner settlement recovery case in PartnerSettlement table.
  - Separate retail customer outcome from wholesale partner recovery timeline.

Allowed:
  - Read bills, bill line items, and partner settlement records.
  - Apply retail credits via CompensationDecision (if customer overcharged).
  - Update PartnerSettlement status and add escalation reference.
  - Create EvidencePack records for L1 audit.

Forbidden:
  - Must not gather SEPP/NEF/CHF network evidence (L4 responsibility).
  - Must not execute network session actions.
  - Must not expose raw partner settlement details in customer-facing messages.
"""
import datetime
import logging
import uuid
from typing import Any, Dict, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import (
    Bill, BillLineItem, PartnerSettlement, CompensationDecision, EvidencePack
)

logger = logging.getLogger(__name__)


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()


async def get_retail_billing_impact(
    db: AsyncSession,
    *,
    billing_account_id: str,
    billing_period: str,
    partner_account_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Assess retail customer billing impact from partner/roaming discrepancy.
    Checks whether disputed partner charges were passed through to the retail customer.
    """
    # Find bills for this account in the affected period
    bill_result = await db.execute(
        select(Bill).where(
            Bill.billing_account_id == billing_account_id,
            Bill.billing_period == billing_period,
        ).limit(1)
    )
    bill = bill_result.scalar_one_or_none()

    # Find disputed bill line items linked to partner charges
    disputed_items = []
    retail_overcharge = 0.0

    if bill:
        li_result = await db.execute(
            select(BillLineItem).where(
                BillLineItem.bill_id == bill.id,
                BillLineItem.dispute_flag == True,
            )
        )
        items = li_result.scalars().all()
        for item in items:
            payload = item.payload or {}
            if partner_account_id and payload.get("partner_id") == partner_account_id:
                disputed_items.append({
                    "line_item_id": item.id,
                    "description": item.description,
                    "charged_amount": item.amount,
                    "partner_id": partner_account_id,
                })
                retail_overcharge += item.amount

    bill_id = bill.id if bill else None
    bill_amount = bill.amount_due if bill else 0.0

    retail_impact_confirmed = retail_overcharge > 0
    summary = (
        f"L2 Retail Impact: {len(disputed_items)} disputed line item(s) on bill {bill_id} "
        f"(total bill: ${bill_amount:.2f}). "
        f"Partner-linked overcharge: ${retail_overcharge:.2f}. "
        f"Retail correction {'required' if retail_impact_confirmed else 'not required'}."
    )
    logger.info("L2 Partner Settlement: retail impact for %s — overcharge $%.2f",
                billing_account_id, retail_overcharge)

    return {
        "source": "L2_retail_billing_impact",
        "billing_account_id": billing_account_id,
        "bill_id": bill_id,
        "billing_period": billing_period,
        "disputed_line_items": disputed_items,
        "retail_overcharge_usd": retail_overcharge,
        "retail_correction_required": retail_impact_confirmed,
        "evidence_summary": summary,
    }


async def apply_retail_correction(
    db: AsyncSession,
    *,
    issue_id: str,
    control_case_id: str,
    billing_account_id: str,
    overcharge_amount: float,
    reason: str,
    approval_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Apply a retail customer credit for the partner-related overcharge.
    This is independent of the partner settlement recovery timeline.
    """
    comp_id = f"COMP-P7-{_short_id()}"
    comp = CompensationDecision(
        id=comp_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        billing_account_id=billing_account_id,
        compensation_type="credit",
        amount=overcharge_amount,
        reason=reason,
        status="applied",
        approval_id=approval_id,
        applied_at=datetime.datetime.utcnow(),
    )
    db.add(comp)
    await db.commit()

    summary = (
        f"L2 Retail Correction: credit ${overcharge_amount:.2f} applied to {billing_account_id}. "
        f"Ref: {comp_id}. Reason: {reason[:80]}."
    )
    logger.info("L2 Partner Settlement: retail correction %s applied — $%.2f", comp_id, overcharge_amount)

    return {
        "comp_id": comp_id,
        "billing_account_id": billing_account_id,
        "amount_credited_usd": overcharge_amount,
        "status": "applied",
        "evidence_summary": summary,
    }


async def create_partner_recovery_case(
    db: AsyncSession,
    *,
    partner_account_id: str,
    billing_period: str,
    discrepancy_amount: float,
    control_case_id: str,
    issue_id: str,
    l4_evidence_ref: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Escalate the PartnerSettlement to 'escalated' status and create a recovery case.
    Partner recovery is tracked separately from retail customer resolution.
    """
    # Find the existing partner settlement record
    result = await db.execute(
        select(PartnerSettlement).where(
            PartnerSettlement.partner_account_id == partner_account_id,
            PartnerSettlement.billing_period == billing_period,
        ).limit(1)
    )
    settlement = result.scalar_one_or_none()

    recovery_ref = f"PSR-{partner_account_id}-{billing_period}-{_short_id()}"

    if settlement:
        settlement.status = "escalated"
        settlement.control_case_id = control_case_id
        settlement.issue_id = issue_id
        existing_payload = settlement.payload or {}
        existing_payload["recovery_case_ref"] = recovery_ref
        existing_payload["l4_evidence_ref"] = l4_evidence_ref
        existing_payload["escalated_at"] = datetime.datetime.utcnow().isoformat()
        settlement.payload = existing_payload
        await db.commit()
        settlement_id = settlement.id
    else:
        # Create a new settlement record if not found
        settlement_id = f"PS-NEW-{_short_id()}"
        new_settlement = PartnerSettlement(
            id=settlement_id,
            partner_account_id=partner_account_id,
            billing_period=billing_period,
            csp_record_amount=discrepancy_amount,
            partner_record_amount=0.0,
            discrepancy_amount=discrepancy_amount,
            currency="USD",
            status="escalated",
            issue_id=issue_id,
            control_case_id=control_case_id,
            payload={
                "recovery_case_ref": recovery_ref,
                "l4_evidence_ref": l4_evidence_ref,
                "escalated_at": datetime.datetime.utcnow().isoformat(),
            },
        )
        db.add(new_settlement)
        await db.commit()

    summary = (
        f"L2 Partner Recovery: settlement {settlement_id} escalated. "
        f"Recovery case {recovery_ref} created for ${discrepancy_amount:.2f} "
        f"discrepancy with partner {partner_account_id} for {billing_period}. "
        f"L4 evidence ref: {l4_evidence_ref}."
    )
    logger.info("L2 Partner Settlement: recovery case %s created for %s — $%.2f",
                recovery_ref, partner_account_id, discrepancy_amount)

    return {
        "settlement_id": settlement_id,
        "recovery_case_ref": recovery_ref,
        "partner_account_id": partner_account_id,
        "billing_period": billing_period,
        "discrepancy_usd": discrepancy_amount,
        "status": "escalated",
        "evidence_summary": summary,
    }


async def get_partner_settlement_summary(
    db: AsyncSession,
    *,
    partner_account_id: str,
    billing_period: str,
) -> Dict[str, Any]:
    """Return partner settlement record for evidence gathering."""
    result = await db.execute(
        select(PartnerSettlement).where(
            PartnerSettlement.partner_account_id == partner_account_id,
            PartnerSettlement.billing_period == billing_period,
        ).limit(1)
    )
    settlement = result.scalar_one_or_none()

    if not settlement:
        return {
            "found": False,
            "evidence_summary": f"No settlement record found for {partner_account_id} {billing_period}.",
        }

    return {
        "found": True,
        "settlement_id": settlement.id,
        "partner_account_id": partner_account_id,
        "billing_period": billing_period,
        "csp_amount": settlement.csp_record_amount,
        "partner_amount": settlement.partner_record_amount,
        "discrepancy": settlement.discrepancy_amount,
        "currency": settlement.currency,
        "status": settlement.status,
        "payload": settlement.payload or {},
        "evidence_summary": (
            f"L2 Settlement: CSP records ${settlement.csp_record_amount:.2f}, "
            f"partner acknowledges ${settlement.partner_record_amount:.2f}. "
            f"Discrepancy: ${settlement.discrepancy_amount:.2f}. "
            f"Status: {settlement.status}."
        ),
    }
