"""
L1 Audit Governance Component — MVP2

Responsibilities:
  - Create richer audit traces that include evidence pack references,
    approval references, action references, and decision chains.
  - Provide a structured audit builder for graph nodes.
"""
import datetime
import logging
import uuid
from typing import Optional, List, Dict, Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import AuditTrace

logger = logging.getLogger(__name__)


async def write_governance_audit(
    db: AsyncSession,
    control_case_id: str,
    action_type: str,
    actor: str,
    summary: str,
    *,
    issue_id: Optional[str] = None,
    evidence_pack_ids: Optional[List[str]] = None,
    approval_id: Optional[str] = None,
    decision: Optional[str] = None,
    actions_taken: Optional[List[str]] = None,
    use_case_id: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
    commit: bool = True,
) -> str:
    """
    Write a rich governance audit trace.

    Returns the audit trace ID.
    """
    trace_id = f"TRACE-{use_case_id or 'GOV'}-{str(uuid.uuid4())[:8].upper()}"

    details: Dict[str, Any] = {}
    if issue_id:
        details["issue_id"] = issue_id
    if evidence_pack_ids:
        details["evidence_pack_ids"] = evidence_pack_ids
    if approval_id:
        details["approval_id"] = approval_id
    if decision:
        details["policy_decision"] = decision
    if actions_taken:
        details["actions_taken"] = actions_taken
    if use_case_id:
        details["use_case_id"] = use_case_id
    if extra:
        details.update(extra)

    details["recorded_at"] = datetime.datetime.utcnow().isoformat()

    trace = AuditTrace(
        id=trace_id,
        control_case_id=control_case_id,
        action_type=action_type,
        actor=actor,
        summary=summary,
        details=details,
    )
    db.add(trace)

    if commit:
        await db.commit()

    logger.info(
        "Audit [%s] cc=%s action=%s actor=%s",
        trace_id, control_case_id, action_type, actor,
    )
    return trace_id
