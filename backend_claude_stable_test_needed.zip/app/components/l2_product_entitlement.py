"""
L2 Product & Entitlement Component — MVP2

Responsibilities:
  - Validate promised commercial tier vs delivered.
  - Check QoS entitlement for a billing account / product.
  - Remove premium surcharge when mismatch is confirmed.
  - Return structured entitlement evidence.
"""
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Mock entitlement catalog keyed by billing_account_id
ENTITLEMENT_CATALOG: Dict[str, Dict[str, Any]] = {
    "BA-100001": {
        "plan_name": "Premium 5G Unlimited",
        "plan_tier": "premium",
        "promised_throughput_mbps": 100,
        "qos_profile": "eMBB_100Mbps",
        "slice_id": "SLICE-PREMIUM-001",
        "nssai": "01-000001",
        "monthly_surcharge_usd": 25.00,
        "sla_uptime_pct": 99.9,
        "sla_max_outage_minutes": 60,
    },
    "BA-100002": {
        "plan_name": "Standard 4G",
        "plan_tier": "standard",
        "promised_throughput_mbps": 20,
        "qos_profile": "eMBB_20Mbps",
        "slice_id": None,
        "nssai": None,
        "monthly_surcharge_usd": 0.0,
        "sla_uptime_pct": 99.5,
        "sla_max_outage_minutes": 120,
    },
    "BA-100003": {
        "plan_name": "Basic Voice & Data",
        "plan_tier": "basic",
        "promised_throughput_mbps": 5,
        "qos_profile": "best_effort",
        "slice_id": None,
        "nssai": None,
        "monthly_surcharge_usd": 0.0,
        "sla_uptime_pct": 98.0,
        "sla_max_outage_minutes": 240,
    },
}


def get_entitlement(billing_account_id: str) -> Dict[str, Any]:
    """Return commercial entitlement for a billing account."""
    entitlement = ENTITLEMENT_CATALOG.get(billing_account_id, {
        "plan_name": "Unknown Plan",
        "plan_tier": "unknown",
        "promised_throughput_mbps": 0,
        "qos_profile": "unknown",
        "slice_id": None,
        "nssai": None,
        "monthly_surcharge_usd": 0.0,
        "sla_uptime_pct": 0.0,
        "sla_max_outage_minutes": 0,
    })
    logger.info("L2 Entitlement: %s plan=%s tier=%s", billing_account_id, entitlement["plan_name"], entitlement["plan_tier"])
    return entitlement


def evaluate_qos_mismatch(
    billing_account_id: str,
    delivered_throughput_mbps: float,
    active_nssai: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Compare delivered QoS to promised entitlement.
    Returns mismatch assessment and recommended action.
    """
    entitlement = get_entitlement(billing_account_id)
    promised = entitlement["promised_throughput_mbps"]
    surcharge = entitlement["monthly_surcharge_usd"]
    promised_nssai = entitlement.get("nssai")

    mismatch_pct = 0.0
    if promised > 0:
        mismatch_pct = max(0.0, (promised - delivered_throughput_mbps) / promised * 100)

    nssai_mismatch = (active_nssai is not None) and (active_nssai != promised_nssai)
    mismatch_confirmed = mismatch_pct >= 20.0 or nssai_mismatch

    result = {
        "billing_account_id": billing_account_id,
        "plan_name": entitlement["plan_name"],
        "promised_throughput_mbps": promised,
        "delivered_throughput_mbps": delivered_throughput_mbps,
        "mismatch_pct": round(mismatch_pct, 1),
        "nssai_mismatch": nssai_mismatch,
        "promised_nssai": promised_nssai,
        "active_nssai": active_nssai,
        "mismatch_confirmed": mismatch_confirmed,
        "monthly_surcharge_usd": surcharge,
        "recommended_action": "remove_surcharge" if mismatch_confirmed else "no_action",
        "evidence_summary": (
            f"Promised {promised} Mbps ({entitlement['qos_profile']}), "
            f"delivered {delivered_throughput_mbps} Mbps — {mismatch_pct:.0f}% shortfall. "
            f"NSSAI mismatch: {nssai_mismatch}. Surcharge ${surcharge:.2f}/mo eligible for removal."
            if mismatch_confirmed else
            f"QoS within acceptable range ({mismatch_pct:.0f}% shortfall). No action required."
        ),
    }
    logger.info(
        "L2 Entitlement: QoS mismatch for %s: confirmed=%s pct=%.1f%%",
        billing_account_id, mismatch_confirmed, mismatch_pct,
    )
    return result


def apply_surcharge_removal(
    billing_account_id: str,
    surcharge_amount: float,
    reason: str,
) -> Dict[str, Any]:
    """Mock: remove premium surcharge from account."""
    adjustment_id = f"ADJ-QOS-{billing_account_id}-SURCHARGE"
    result = {
        "adjustment_id": adjustment_id,
        "billing_account_id": billing_account_id,
        "adjustment_type": "surcharge_removal",
        "amount_removed": surcharge_amount,
        "reason": reason,
        "status": "applied",
    }
    logger.info("L2 Entitlement: surcharge removal %s applied — $%.2f", adjustment_id, surcharge_amount)
    return result
