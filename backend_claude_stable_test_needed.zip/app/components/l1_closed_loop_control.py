"""
L1 Closed-Loop Control Component - MVP2

Responsibilities:
  - Make policy decisions for proposed remediation actions.
  - Identify approval triggers before owner-layer actions execute.
  - Return compact decisions suitable for LangGraph state.

This component does not execute BSS/OSS/network actions. It only decides
whether the proposed action is allowed automatically or needs human approval.
"""
from typing import Any, Dict, Optional


def decide_action_policy(
    *,
    action: str,
    amount: Optional[float] = None,
    threshold: float = 50.0,
    confidence: Optional[float] = None,
    bulk_customer_impact: bool = False,
    network_remediation: bool = False,
    rollback_available: bool = True,
    auto_remediation_enabled: bool = True,
) -> Dict[str, Any]:
    """
    Evaluate MVP2 closed-loop approval policy for a proposed action.

    Approval triggers are intentionally deterministic for the MVP:
      - auto remediation disabled
      - amount above configured threshold
      - bulk customer impact
      - low confidence decision
      - network remediation without rollback
    """
    reasons = []

    if not auto_remediation_enabled:
        reasons.append("auto remediation is disabled")
    if amount is not None and amount > threshold:
        reasons.append(f"amount ${amount:.2f} exceeds threshold ${threshold:.2f}")
    if bulk_customer_impact:
        reasons.append("bulk customer impact")
    if confidence is not None and confidence < 0.75:
        reasons.append(f"low confidence {confidence:.0%}")
    if network_remediation and not rollback_available:
        reasons.append("network remediation without rollback")

    requires_approval = bool(reasons)
    return {
        "action": action,
        "policy_decision": "approval_required" if requires_approval else "auto_remediation_allowed",
        "requires_human_approval": requires_approval,
        "risk_reason": "; ".join(reasons) if reasons else None,
    }


def auto_allow(action: str) -> Dict[str, Any]:
    """Return an explicit auto-allow decision for low-risk MVP2 actions."""
    return {
        "action": action,
        "policy_decision": "auto_remediation_allowed",
        "requires_human_approval": False,
        "risk_reason": None,
    }
