"""
L1 Simulation Component — MVP3

Provides controlled injection of billing anomaly scenarios for demo/testing.
Each simulation creates seed-level data (issues, usage events, PDU sessions)
that triggers the corresponding agentic flow when remediated.

Simulation types:
  - duplicate_charge       : inject duplicate usage event (P2 trigger)
  - zombie_pdu_session     : inject zombie PDU session (P3 trigger)
  - usage_delay            : inject missing mediation record (P1 trigger)
  - qos_mismatch           : inject QoS mismatch signal (P4 trigger)
  - sla_breach             : inject service outage event (P5 trigger)
  - partner_discrepancy    : inject partner settlement discrepancy (P7 trigger)
  - proactive_risk         : inject anomalous usage spike (P9 trigger)
"""
import datetime
import logging
import uuid
from typing import Dict, Any, Optional, List

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import (
    SimulationRun, Issue, UsageEvent, PDUSession, MediationRecord, PartnerSettlement,
)

logger = logging.getLogger(__name__)

# In-memory registry of active simulations (cleared on reset)
_active_simulations: Dict[str, Dict[str, Any]] = {}

SIMULATION_TYPES = [
    "duplicate_charge", "zombie_pdu_session", "usage_delay",
    "qos_mismatch", "sla_breach", "partner_discrepancy", "proactive_risk",
]

SIMULATION_USE_CASE_MAP = {
    "duplicate_charge": "P2",
    "zombie_pdu_session": "P3",
    "usage_delay": "P1",
    "qos_mismatch": "P4",
    "sla_breach": "P5",
    "partner_discrepancy": "P7",
    "proactive_risk": "P9",
}


async def inject_simulation(
    db: AsyncSession,
    *,
    simulation_type: str,
    customer_id: str = "CUST-100001",
    billing_account_id: str = "BA-100001",
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    Inject a billing anomaly scenario. Creates supporting data records.
    If dry_run=True, returns what would be created without writing to DB.
    """
    if simulation_type not in SIMULATION_TYPES:
        return {"error": f"Unknown simulation type: {simulation_type}. Valid: {SIMULATION_TYPES}"}

    sim_id = f"SIM-{simulation_type.upper()[:8]}-{str(uuid.uuid4())[:6].upper()}"
    use_case_id = SIMULATION_USE_CASE_MAP[simulation_type]
    issue_id = f"SIM-ISSUE-{sim_id}"
    now = datetime.datetime.utcnow()

    artifacts = []

    if simulation_type == "duplicate_charge":
        ue_id = f"SIM-UE-DUP-{sim_id}"
        artifacts = [
            {"type": "UsageEvent", "id": ue_id, "description": "Duplicate 2GB data session injected"},
            {"type": "Issue", "id": issue_id, "use_case": "P2", "description": "Simulated duplicate charge"},
        ]
        if not dry_run:
            ue = UsageEvent(
                id=ue_id, customer_id=customer_id,
                billing_account_id=billing_account_id,
                session_id=f"SIM-SESSION-{sim_id}",
                event_type="data", data_volume_bytes=2_000_000_000,
                start_time=now - datetime.timedelta(hours=2),
                end_time=now - datetime.timedelta(hours=1),
                charging_trigger="CHF",
                billing_period=now.strftime("%Y-%m"),
                payload={"charge_type": "duplicate", "simulation_id": sim_id},
                created_at=now,
            )
            issue = Issue(
                id=issue_id, use_case_id="P2",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Duplicate charge of 2GB data session injected by {sim_id}.",
                status="open",
            )
            db.add(ue)
            db.add(issue)

    elif simulation_type == "zombie_pdu_session":
        pdu_id = f"SIM-PDU-ZOMBIE-{sim_id}"
        artifacts = [
            {"type": "PDUSession", "id": pdu_id, "description": "Zombie PDU session injected"},
            {"type": "Issue", "id": issue_id, "use_case": "P3", "description": "Simulated zombie PDU session"},
        ]
        if not dry_run:
            pdu = PDUSession(
                id=pdu_id, customer_id=customer_id,
                billing_account_id=billing_account_id,
                session_id=f"SIM-PDU-SESSION-{sim_id}",
                upf_node="UPF-EAST-SIM", smf_node="SMF-EAST-SIM",
                start_time=now - datetime.timedelta(hours=8),
                end_time=None,  # zombie: no end time
                data_volume_gb=3.2, status="zombie",
                payload={"simulation_id": sim_id, "charge_type": "zombie_session"},
            )
            issue = Issue(
                id=issue_id, use_case_id="P3",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Zombie PDU session {pdu_id} injected — continuing to charge after disconnect.",
                status="open",
            )
            db.add(pdu)
            db.add(issue)

    elif simulation_type == "usage_delay":
        mr_id = f"SIM-MR-DELAY-{sim_id}"
        artifacts = [
            {"type": "MediationRecord", "id": mr_id, "description": "Missing/delayed mediation record"},
            {"type": "Issue", "id": issue_id, "use_case": "P1", "description": "Simulated usage delay"},
        ]
        if not dry_run:
            mr = MediationRecord(
                id=mr_id, billing_account_id=billing_account_id,
                status="raw",  # stuck in raw — not rated
                rating_attempt_count=0,
                billing_period=now.strftime("%Y-%m"),
                payload={"simulation_id": sim_id, "delay_hours": 24, "pipeline_stage": "CDR_COLLECTION"},
                created_at=now,
            )
            issue = Issue(
                id=issue_id, use_case_id="P1",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Usage delay: mediation record {mr_id} stuck in CDR_COLLECTION for 24h.",
                status="open",
            )
            db.add(mr)
            db.add(issue)

    elif simulation_type == "qos_mismatch":
        artifacts = [
            {"type": "Issue", "id": issue_id, "use_case": "P4", "description": "Simulated QoS mismatch"},
        ]
        if not dry_run:
            issue = Issue(
                id=issue_id, use_case_id="P4",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] QoS mismatch: premium 5G slice charged but 4G QoS delivered for 48h.",
                status="open",
            )
            db.add(issue)

    elif simulation_type == "sla_breach":
        artifacts = [
            {"type": "Issue", "id": issue_id, "use_case": "P5", "description": "Simulated SLA breach"},
        ]
        if not dry_run:
            issue = Issue(
                id=issue_id, use_case_id="P5",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Service degradation: 10h voice outage detected. SLA breach, compensation required.",
                status="open",
            )
            db.add(issue)

    elif simulation_type == "partner_discrepancy":
        artifacts = [
            {"type": "Issue", "id": issue_id, "use_case": "P7", "description": "Simulated partner discrepancy"},
        ]
        if not dry_run:
            issue = Issue(
                id=issue_id, use_case_id="P7",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Partner discrepancy: $2,800 gap between CSP and partner settlement records.",
                status="open",
            )
            db.add(issue)

    elif simulation_type == "proactive_risk":
        ue_id = f"SIM-UE-ANOMALY-{sim_id}"
        artifacts = [
            {"type": "UsageEvent", "id": ue_id, "description": "Anomalous usage spike injected"},
            {"type": "Issue", "id": issue_id, "use_case": "P9", "description": "Simulated proactive risk"},
        ]
        if not dry_run:
            ue = UsageEvent(
                id=ue_id, customer_id=customer_id,
                billing_account_id=billing_account_id,
                session_id=f"SIM-SPIKE-{sim_id}",
                event_type="data", data_volume_bytes=50_000_000_000,  # 50GB spike
                start_time=now - datetime.timedelta(hours=1),
                end_time=now,
                charging_trigger="CHF",
                billing_period=now.strftime("%Y-%m"),
                payload={"anomaly_flag": True, "simulation_id": sim_id, "spike_multiplier": 8.0},
                created_at=now,
            )
            issue = Issue(
                id=issue_id, use_case_id="P9",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Proactive risk: 50GB anomalous data spike detected (8× average).",
                status="open",
            )
            db.add(ue)
            db.add(issue)

    # Create SimulationRun record (mapped to existing SimulationRun ORM fields)
    sim_run = SimulationRun(
        id=sim_id,
        use_case_id=use_case_id,
        run_type=simulation_type,               # simulation_type stored in run_type
        is_dry_run=dry_run,
        status="completed" if not dry_run else "dry_run",
        result_summary=f"Simulation {simulation_type} for {billing_account_id}",
        payload={
            "artifacts": artifacts,
            "customer_id": customer_id,
            "billing_account_id": billing_account_id,
            "simulation_type": simulation_type,
        },
        created_at=now,
    )

    if not dry_run:
        db.add(sim_run)
        await db.commit()
        _active_simulations[sim_id] = {
            "simulation_type": simulation_type,
            "issue_id": issue_id,
            "use_case_id": use_case_id,
            "artifacts": artifacts,
            "created_at": now.isoformat(),
        }

    logger.info("L1 Simulation: %s injected — id=%s dry_run=%s", simulation_type, sim_id, dry_run)
    return {
        "simulation_id": sim_id,
        "simulation_type": simulation_type,
        "use_case_id": use_case_id,
        "issue_id": issue_id if not dry_run else None,
        "dry_run": dry_run,
        "artifacts_created": len(artifacts),
        "artifacts": artifacts,
        "status": "injected" if not dry_run else "dry_run_preview",
        "next_step": f"POST /api/v1/issues/{issue_id}/remediate to trigger the {use_case_id} flow." if not dry_run else None,
    }


async def get_simulation_status(sim_id: str) -> Dict[str, Any]:
    """Return the status of an active simulation."""
    if sim_id in _active_simulations:
        return {"simulation_id": sim_id, "status": "active", **_active_simulations[sim_id]}
    return {"simulation_id": sim_id, "status": "not_found_or_reset"}


async def reset_simulations(db: AsyncSession) -> Dict[str, Any]:
    """
    Reset all simulation-created records.
    Deletes Issues and UsageEvents created by simulations (identified by [SIMULATION] prefix).
    """
    from sqlalchemy import select, delete
    from app.models.models import Issue, UsageEvent, PDUSession, MediationRecord

    deleted_counts = {}

    # Delete simulation issues
    issues_result = await db.execute(
        select(Issue).where(Issue.description.like("[SIMULATION]%"))
    )
    sim_issues = issues_result.scalars().all()
    for i in sim_issues:
        await db.delete(i)
    deleted_counts["issues"] = len(sim_issues)

    # Delete simulation usage events (filter in Python to avoid JSON operator portability issues)
    ue_result = await db.execute(select(UsageEvent))
    all_ues = ue_result.scalars().all()
    sim_ues = [ue for ue in all_ues if ue.payload and "simulation_id" in ue.payload]
    for ue in sim_ues:
        await db.delete(ue)
    deleted_counts["usage_events"] = len(sim_ues)

    await db.commit()
    _active_simulations.clear()

    logger.info("L1 Simulation: reset complete — deleted %s", deleted_counts)
    return {"status": "reset", "deleted": deleted_counts}


def list_active_simulations() -> List[Dict[str, Any]]:
    """Return all simulations currently tracked in memory."""
    return [{"simulation_id": k, **v} for k, v in _active_simulations.items()]