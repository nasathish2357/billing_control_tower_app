"""
L4 Roaming / Exposure Component — MVP3

Owner layer: L4 Network / Resource / Charging Trigger Layer

Responsibilities:
  - Gather SEPP N32 interface CDR export evidence for roaming sessions.
  - Gather NEF API exposure logs for partner-facing events.
  - Retrieve CHF charging records for disputed roaming sessions.
  - Audit TAP file export completeness vs partner-reported count.

Allowed:
  - Read SEPP/NEF/CHF evidence from DB and mock sources.
  - Return evidence pack summaries for L1/L2 consumption.

Forbidden:
  - Must not apply billing credits or modify bills.
  - Must not create TroubleTickets or Approvals.
  - Must not communicate directly with L2 or L3 without going through L1.
"""
import logging
from typing import Any, Dict, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import PartnerSettlement, UsageEvent, MediationRecord, NetworkFunction

logger = logging.getLogger(__name__)


async def get_sepp_cdr_export_evidence(
    db: AsyncSession,
    *,
    partner_account_id: str,
    billing_period: str,
    issue_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Retrieve SEPP N32 CDR export evidence for a given partner and billing period.
    Confirms what CDR volume the CSP exported to the partner network.
    """
    # Pull the settlement record to compare CSP vs partner figures
    result = await db.execute(
        select(PartnerSettlement).where(
            PartnerSettlement.partner_account_id == partner_account_id,
            PartnerSettlement.billing_period == billing_period,
        ).limit(1)
    )
    settlement = result.scalar_one_or_none()

    if settlement:
        csp_amount = settlement.csp_record_amount
        partner_amount = settlement.partner_record_amount
        discrepancy = settlement.discrepancy_amount
        settlement_payload = settlement.payload or {}
        csp_cdr_count = settlement_payload.get("csp_cdr_count", "unknown")
        partner_cdr_count = settlement_payload.get("partner_cdr_count", "unknown")
        sepp_log_ref = settlement_payload.get("sepp_evidence", f"SEPP-LOG-{billing_period}-{partner_account_id}")
    else:
        csp_amount = 0.0
        partner_amount = 0.0
        discrepancy = 0.0
        csp_cdr_count = "unknown"
        partner_cdr_count = "unknown"
        sepp_log_ref = f"SEPP-LOG-{billing_period}-{partner_account_id}"

    # Pull related roaming usage events from DB
    ue_result = await db.execute(
        select(UsageEvent).where(
            UsageEvent.event_type.in_(["roaming_data", "roaming_voice"]),
            UsageEvent.billing_period == billing_period,
        ).limit(20)
    )
    roaming_events = ue_result.scalars().all()
    roaming_event_ids = [ue.id for ue in roaming_events]

    # Confirm SEPP NF status
    sepp_result = await db.execute(
        select(NetworkFunction).where(NetworkFunction.nf_type == "SEPP").limit(1)
    )
    sepp_nf = sepp_result.scalar_one_or_none()
    sepp_status = sepp_nf.status if sepp_nf else "unknown"
    sepp_name = sepp_nf.name if sepp_nf else "SEPP-ROAMING-01"

    summary = (
        f"L4 SEPP Evidence: CSP exported {csp_cdr_count} CDRs (${csp_amount:.2f}) "
        f"to partner {partner_account_id} for {billing_period} via {sepp_name} "
        f"(status: {sepp_status}). "
        f"Partner acknowledged {partner_cdr_count} CDRs (${partner_amount:.2f}). "
        f"Discrepancy: ${discrepancy:.2f}. SEPP log ref: {sepp_log_ref}."
    )
    logger.info("L4 Roaming: SEPP evidence gathered for %s %s — discrepancy $%.2f",
                partner_account_id, billing_period, discrepancy)

    return {
        "source": "L4_sepp_cdr_export",
        "partner_account_id": partner_account_id,
        "billing_period": billing_period,
        "sepp_node": sepp_name,
        "sepp_status": sepp_status,
        "sepp_log_ref": sepp_log_ref,
        "csp_cdr_count": csp_cdr_count,
        "partner_cdr_count": partner_cdr_count,
        "csp_record_amount_usd": csp_amount,
        "partner_record_amount_usd": partner_amount,
        "discrepancy_usd": discrepancy,
        "roaming_event_ids": roaming_event_ids,
        "csr_export_complete": True,
        "partner_ingestion_gap_confirmed": discrepancy > 0,
        "evidence_summary": summary,
    }


async def get_chf_roaming_charging_records(
    db: AsyncSession,
    *,
    billing_account_id: str,
    billing_period: str,
) -> Dict[str, Any]:
    """
    Retrieve CHF charging records for roaming sessions to confirm what was charged.
    Used to validate retail customer billing vs network charging triggers.
    """
    # Get roaming usage events for the account and period
    result = await db.execute(
        select(UsageEvent).where(
            UsageEvent.billing_account_id == billing_account_id,
            UsageEvent.billing_period == billing_period,
            UsageEvent.event_type.in_(["roaming_data", "roaming_voice"]),
        )
    )
    roaming_events = result.scalars().all()

    # Get related mediation records
    mr_result = await db.execute(
        select(MediationRecord).where(
            MediationRecord.billing_account_id == billing_account_id,
            MediationRecord.billing_period == billing_period,
        ).limit(10)
    )
    mediation_records = mr_result.scalars().all()

    chf_result = await db.execute(
        select(NetworkFunction).where(NetworkFunction.nf_type == "CHF").limit(1)
    )
    chf_nf = chf_result.scalar_one_or_none()
    chf_name = chf_nf.name if chf_nf else "CHF-CHARGING-01"

    total_roaming_volume_bytes = sum(ue.data_volume_bytes or 0 for ue in roaming_events)
    total_roaming_duration_s = sum(ue.duration_seconds or 0 for ue in roaming_events)
    roaming_cdr_ids = [
        (ue.payload or {}).get("cdr_id", ue.id) for ue in roaming_events
    ]

    summary = (
        f"L4 CHF Evidence: {len(roaming_events)} roaming usage events found for "
        f"{billing_account_id} in {billing_period} via {chf_name}. "
        f"Total roaming data: {total_roaming_volume_bytes / 1_073_741_824:.2f} GB, "
        f"Duration: {total_roaming_duration_s // 3600}h. "
        f"CDR IDs: {roaming_cdr_ids[:3]}{'...' if len(roaming_cdr_ids) > 3 else ''}."
    )
    logger.info("L4 CHF: %d roaming events for %s %s", len(roaming_events), billing_account_id, billing_period)

    return {
        "source": "L4_chf_roaming_records",
        "chf_node": chf_name,
        "billing_account_id": billing_account_id,
        "billing_period": billing_period,
        "roaming_event_count": len(roaming_events),
        "roaming_cdr_ids": roaming_cdr_ids,
        "total_volume_bytes": total_roaming_volume_bytes,
        "total_duration_seconds": total_roaming_duration_s,
        "mediation_record_count": len(mediation_records),
        "evidence_summary": summary,
    }


async def get_nef_exposure_evidence(
    *,
    partner_account_id: str,
    billing_period: str,
) -> Dict[str, Any]:
    """
    Mock NEF API exposure evidence — confirms partner API notification delivery status.
    In production this would query NEF event logs.
    """
    summary = (
        f"L4 NEF Evidence: API event notifications for partner {partner_account_id} "
        f"in {billing_period} confirmed delivered via NEF-EXPOSURE-01. "
        f"No notification delivery failures detected on N33 interface."
    )
    logger.info("L4 NEF: exposure evidence for partner %s %s", partner_account_id, billing_period)
    return {
        "source": "L4_nef_exposure",
        "partner_account_id": partner_account_id,
        "billing_period": billing_period,
        "nef_node": "NEF-EXPOSURE-01",
        "notification_delivery": "confirmed",
        "n33_failures": 0,
        "evidence_summary": summary,
    }
