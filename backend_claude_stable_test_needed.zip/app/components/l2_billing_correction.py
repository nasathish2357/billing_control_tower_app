"""
L2 Billing Correction Component — MVP3

Responsibilities:
  - Apply charge reversals for erroneous billing events.
  - Create compensation credits for verified overcharges.
  - Return structured correction evidence for graph state.

Bounded rules:
  - L2 only. Does not gather CDR/network evidence (L4).
  - Does not evaluate SLA breaches (L3).
  - Does not make policy decisions (L1).
"""
import datetime
import logging
import uuid
from typing import Dict, Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import CompensationDecision, EvidencePack

logger = logging.getLogger(__name__)


async def apply_charge_reversal(
    db: AsyncSession,
    *,
    issue_id: str,
    control_case_id: str,
    billing_account_id: str,
    reversal_amount: float,
    charge_description: str,
    reason: str,
    approval_id: Optional[str] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """
    Apply a charge reversal credit to a billing account.
    Used for any confirmed erroneous charge (duplicate, zombie session, QoS mismatch, etc.).
    """
    comp_id = f"COMP-REV-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    evp_id = f"EVP-L2-REV-{str(uuid.uuid4())[:6].upper()}"
    summary = (
        f"L2 Billing Correction: charge reversal ${reversal_amount:.2f} applied to "
        f"{billing_account_id}. Ref {comp_id}. Charge: {charge_description}."
    )

    comp = CompensationDecision(
        id=comp_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        billing_account_id=billing_account_id,
        compensation_type="reversal",
        amount=reversal_amount,
        reason=reason,
        status="applied",
        approval_id=approval_id,
        applied_at=datetime.datetime.utcnow(),
    )
    evp = EvidencePack(
        id=evp_id,
        control_case_id=control_case_id,
        source_layer="L2",
        summary=summary,
        payload={
            "comp_id": comp_id,
            "type": "reversal",
            "amount": reversal_amount,
            "charge_description": charge_description,
            "approval_id": approval_id,
        },
    )
    db.add(comp)
    db.add(evp)
    if commit:
        await db.commit()

    logger.info(
        "L2 Billing Correction: reversal %s applied — $%.2f for %s",
        comp_id, reversal_amount, billing_account_id,
    )
    return {
        "comp_id": comp_id,
        "evp_id": evp_id,
        "type": "reversal",
        "amount": reversal_amount,
        "status": "applied",
        "evidence_summary": summary,
    }


async def apply_compensation_credit(
    db: AsyncSession,
    *,
    issue_id: str,
    control_case_id: str,
    billing_account_id: str,
    credit_amount: float,
    compensation_type: str,
    reason: str,
    approval_id: Optional[str] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """
    Apply a compensation credit (SLA breach, service degradation, goodwill).
    """
    comp_id = f"COMP-CREDIT-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    evp_id = f"EVP-L2-CREDIT-{str(uuid.uuid4())[:6].upper()}"
    summary = (
        f"L2 Billing Correction: {compensation_type} credit ${credit_amount:.2f} applied to "
        f"{billing_account_id}. Ref {comp_id}."
    )

    comp = CompensationDecision(
        id=comp_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        billing_account_id=billing_account_id,
        compensation_type="credit",
        amount=credit_amount,
        reason=reason,
        status="applied",
        approval_id=approval_id,
        applied_at=datetime.datetime.utcnow(),
    )
    evp = EvidencePack(
        id=evp_id,
        control_case_id=control_case_id,
        source_layer="L2",
        summary=summary,
        payload={
            "comp_id": comp_id,
            "type": "credit",
            "compensation_type": compensation_type,
            "amount": credit_amount,
            "approval_id": approval_id,
        },
    )
    db.add(comp)
    db.add(evp)
    if commit:
        await db.commit()

    logger.info(
        "L2 Billing Correction: credit %s applied — $%.2f for %s (%s)",
        comp_id, credit_amount, billing_account_id, compensation_type,
    )
    return {
        "comp_id": comp_id,
        "evp_id": evp_id,
        "type": "credit",
        "amount": credit_amount,
        "status": "applied",
        "evidence_summary": summary,
    }


async def get_correction_history(
    db: AsyncSession,
    billing_account_id: str,
    limit: int = 10,
) -> Dict[str, Any]:
    """Return recent correction/credit history for a billing account."""
    from sqlalchemy import select
    result = await db.execute(
        select(CompensationDecision)
        .where(CompensationDecision.billing_account_id == billing_account_id)
        .order_by(CompensationDecision.applied_at.desc())
        .limit(limit)
    )
    corrections = result.scalars().all()
    total_applied = sum(c.amount for c in corrections if c.status == "applied")
    return {
        "billing_account_id": billing_account_id,
        "correction_count": len(corrections),
        "total_applied_amount": total_applied,
        "corrections": [
            {
                "id": c.id,
                "type": c.compensation_type,
                "amount": c.amount,
                "reason": c.reason,
                "status": c.status,
                "applied_at": c.applied_at.isoformat() if c.applied_at else None,
            }
            for c in corrections
        ],
    }