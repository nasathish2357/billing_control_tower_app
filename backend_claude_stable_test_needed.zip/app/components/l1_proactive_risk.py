"""
L1 Proactive Risk Scorer — MVP3

Responsibilities:
  - Assess proactive billing risk for an account based on usage patterns.
  - Return a compact risk score and signals for L1 policy evaluation.
  - Used by P9 (proactive monitoring) and the dashboard layer.

Design rules:
  - Read-only access to usage, mediation, bill, and PDU session data.
  - No writes to bills, tickets, or compensation records.
  - Returns deterministic risk scoring with explicit signals.
"""
import logging
from typing import Dict, Any, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import UsageEvent, MediationRecord, Bill, PDUSession

logger = logging.getLogger(__name__)


# Risk thresholds (configurable via settings in production)
_ANOMALY_USAGE_MULTIPLIER = 2.5    # usage 2.5× above 3-month avg triggers HIGH risk
_ZOMBIE_SESSION_RISK = "HIGH"
_DUPLICATE_CHARGE_RISK = "HIGH"
_MISSING_USAGE_RISK = "MEDIUM"
_MEDIATION_ERROR_RISK = "MEDIUM"


async def assess_billing_risk(
    db: AsyncSession,
    billing_account_id: str,
    billing_period: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Assess proactive billing risk for a billing account.

    Returns:
        risk_level: LOW | MEDIUM | HIGH | CRITICAL
        risk_score: 0–100
        signals: list of detected risk signals
        summary: human-readable risk assessment
    """
    signals: List[Dict[str, Any]] = []
    risk_points = 0

    # ── PDU Session Anomalies ─────────────────────────────────────────────────
    pdu_result = await db.execute(
        select(PDUSession).where(PDUSession.billing_account_id == billing_account_id)
    )
    pdu_sessions = pdu_result.scalars().all()

    zombie_sessions = [s for s in pdu_sessions if s.status == "zombie"]
    if zombie_sessions:
        risk_points += 30 * len(zombie_sessions)
        signals.append({
            "type": "zombie_pdu_session",
            "severity": "HIGH",
            "count": len(zombie_sessions),
            "session_ids": [s.id for s in zombie_sessions],
            "description": f"{len(zombie_sessions)} zombie PDU session(s) detected — accruing charges after disconnect.",
        })

    # ── Usage Anomalies ───────────────────────────────────────────────────────
    usage_result = await db.execute(
        select(UsageEvent).where(UsageEvent.billing_account_id == billing_account_id)
    )
    usage_events = usage_result.scalars().all()

    anomaly_events = [u for u in usage_events
                      if (u.payload or {}).get("anomaly_flag") or
                         (u.payload or {}).get("charge_type") == "zombie_session"]
    if anomaly_events:
        risk_points += 20 * len(anomaly_events)
        signals.append({
            "type": "usage_anomaly",
            "severity": "HIGH",
            "count": len(anomaly_events),
            "event_ids": [u.id for u in anomaly_events],
            "description": f"{len(anomaly_events)} anomalous usage event(s) flagged — potential over-billing risk.",
        })

    # Duplicate usage events
    duplicate_events = [u for u in usage_events
                        if (u.payload or {}).get("charge_type") == "duplicate"]
    if duplicate_events:
        risk_points += 25 * len(duplicate_events)
        signals.append({
            "type": "duplicate_usage",
            "severity": "HIGH",
            "count": len(duplicate_events),
            "event_ids": [u.id for u in duplicate_events],
            "description": f"{len(duplicate_events)} duplicate usage event(s) — customer may be double-charged.",
        })

    # ── Mediation Errors ──────────────────────────────────────────────────────
    med_result = await db.execute(
        select(MediationRecord).where(MediationRecord.billing_account_id == billing_account_id)
    )
    mediation_records = med_result.scalars().all()

    error_records = [r for r in mediation_records if r.status in ("error", "duplicate")]
    if error_records:
        risk_points += 15 * len(error_records)
        signals.append({
            "type": "mediation_error",
            "severity": "MEDIUM",
            "count": len(error_records),
            "record_ids": [r.id for r in error_records],
            "description": f"{len(error_records)} mediation record(s) in error/duplicate state.",
        })

    # ── Bill Status ───────────────────────────────────────────────────────────
    bill_result = await db.execute(
        select(Bill).where(Bill.billing_account_id == billing_account_id)
        .order_by(Bill.billing_period.desc())
        .limit(3)
    )
    recent_bills = bill_result.scalars().all()

    disputed_bills = [b for b in recent_bills if b.status == "Disputed"]
    if disputed_bills:
        risk_points += 10 * len(disputed_bills)
        signals.append({
            "type": "disputed_bill",
            "severity": "MEDIUM",
            "count": len(disputed_bills),
            "bill_ids": [b.id for b in disputed_bills],
            "description": f"{len(disputed_bills)} bill(s) in Disputed status in last 3 periods.",
        })

    # ── Risk Classification ───────────────────────────────────────────────────
    risk_score = min(100, risk_points)
    if risk_score >= 70:
        risk_level = "CRITICAL"
    elif risk_score >= 40:
        risk_level = "HIGH"
    elif risk_score >= 15:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    signal_count = len(signals)
    summary = (
        f"Proactive risk assessment for {billing_account_id}: {risk_level} "
        f"(score {risk_score}/100). "
        f"{signal_count} risk signal(s) detected. "
        f"{'Immediate review recommended.' if risk_level in ('HIGH', 'CRITICAL') else 'Monitor for changes.'}"
    )

    logger.info(
        "L1 Proactive Risk: %s — level=%s score=%d signals=%d",
        billing_account_id, risk_level, risk_score, signal_count,
    )
    return {
        "billing_account_id": billing_account_id,
        "risk_level": risk_level,
        "risk_score": risk_score,
        "signal_count": signal_count,
        "signals": signals,
        "evidence_summary": summary,
    }


async def get_high_risk_accounts(db: AsyncSession, threshold: int = 40) -> List[Dict[str, Any]]:
    """
    Scan all billing accounts and return those with risk scores above threshold.
    Used by P9 proactive monitoring and dashboard.
    """
    from app.models.models import BillingAccount
    ba_result = await db.execute(select(BillingAccount))
    accounts = ba_result.scalars().all()

    high_risk = []
    for ba in accounts:
        assessment = await assess_billing_risk(db, ba.id)
        if assessment["risk_score"] >= threshold:
            high_risk.append({
                "billing_account_id": ba.id,
                "customer_id": ba.customer_id,
                "risk_level": assessment["risk_level"],
                "risk_score": assessment["risk_score"],
                "signal_count": assessment["signal_count"],
            })

    high_risk.sort(key=lambda x: x["risk_score"], reverse=True)
    return high_risk