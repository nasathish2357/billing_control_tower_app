"""
L3 QoS / Slice Correlation Component — MVP2

Responsibilities:
  - Retrieve QoS performance metrics for a billing account.
  - Check slice configuration (NSSAI) vs entitlement.
  - Detect throughput degradation.
  - Return structured network evidence.
"""
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Mock QoS metrics per billing_account_id / slice_id
QOS_METRICS: Dict[str, Dict[str, Any]] = {
    "BA-100001": {
        "slice_id": "SLICE-PREMIUM-001",
        "active_nssai": "01-000002",          # Wrong NSSAI — mismatch with promised 01-000001
        "avg_throughput_mbps": 15.0,
        "peak_throughput_mbps": 22.0,
        "packet_loss_pct": 0.8,
        "latency_ms": 45,
        "measurement_period": "2026-04",
        "qci": 9,
        "nwdaf_confidence": 0.94,
    },
    "BA-100002": {
        "slice_id": None,
        "active_nssai": None,
        "avg_throughput_mbps": 18.5,
        "peak_throughput_mbps": 20.0,
        "packet_loss_pct": 0.2,
        "latency_ms": 30,
        "measurement_period": "2026-04",
        "qci": 9,
        "nwdaf_confidence": 0.91,
    },
    "BA-100003": {
        "slice_id": None,
        "active_nssai": None,
        "avg_throughput_mbps": 4.2,
        "peak_throughput_mbps": 5.0,
        "packet_loss_pct": 1.2,
        "latency_ms": 80,
        "measurement_period": "2026-04",
        "qci": 9,
        "nwdaf_confidence": 0.88,
    },
}


def get_qos_evidence(billing_account_id: str) -> Dict[str, Any]:
    """
    Retrieve QoS performance metrics for a billing account.
    Returns structured network evidence.
    """
    metrics = QOS_METRICS.get(billing_account_id, {
        "slice_id": None,
        "active_nssai": None,
        "avg_throughput_mbps": 0.0,
        "peak_throughput_mbps": 0.0,
        "packet_loss_pct": 0.0,
        "latency_ms": 0,
        "measurement_period": "unknown",
        "qci": 9,
        "nwdaf_confidence": 0.0,
    })

    logger.info(
        "L3 QoS: %s avg_mbps=%.1f nssai=%s",
        billing_account_id, metrics["avg_throughput_mbps"], metrics.get("active_nssai"),
    )
    return {
        "billing_account_id": billing_account_id,
        "source": "NWDAF",
        **metrics,
    }


def get_slice_performance(
    billing_account_id: str,
    slice_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Get slice-specific performance data.
    Returns a structured evidence dict with NSSAI, throughput, and QCI details.
    """
    qos = get_qos_evidence(billing_account_id)
    effective_slice = slice_id or qos.get("slice_id")

    return {
        "billing_account_id": billing_account_id,
        "slice_id": effective_slice,
        "active_nssai": qos["active_nssai"],
        "avg_throughput_mbps": qos["avg_throughput_mbps"],
        "peak_throughput_mbps": qos["peak_throughput_mbps"],
        "packet_loss_pct": qos["packet_loss_pct"],
        "latency_ms": qos["latency_ms"],
        "qci": qos["qci"],
        "nwdaf_confidence": qos["nwdaf_confidence"],
        "measurement_period": qos["measurement_period"],
        "evidence_summary": (
            f"Slice {effective_slice}: avg {qos['avg_throughput_mbps']} Mbps, "
            f"NSSAI {qos['active_nssai']}, packet loss {qos['packet_loss_pct']}%, "
            f"latency {qos['latency_ms']}ms (NWDAF confidence {qos['nwdaf_confidence']:.0%})."
        ),
    }
