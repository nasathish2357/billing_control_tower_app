"""
L3 Mediation Replay Component — MVP2

Responsibilities:
  - Create MediationJob records for backlog replay.
  - Execute mock mediation replay and return result evidence.
  - Support bill protection hold pending replay completion.
"""
import datetime
import logging
import uuid
from typing import Dict, Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import MediationJob

logger = logging.getLogger(__name__)

# Mock mediation backlog per billing_account_id
MEDIATION_BACKLOG: Dict[str, Dict[str, Any]] = {
    "BA-100001": {
        "delayed_events": 847,
        "delay_hours": 18,
        "pipeline_stage": "CDR_COLLECTION",
        "estimated_impact_usd": 38.50,
        "billing_period": "2026-04",
    },
    "BA-100002": {
        "delayed_events": 0,
        "delay_hours": 0,
        "pipeline_stage": "RATED",
        "estimated_impact_usd": 0.0,
        "billing_period": "2026-04",
    },
    "BA-100003": {
        "delayed_events": 23,
        "delay_hours": 4,
        "pipeline_stage": "MEDIATION_PROCESSING",
        "estimated_impact_usd": 5.20,
        "billing_period": "2026-04",
    },
}


async def get_mediation_backlog(
    billing_account_id: str,
) -> Dict[str, Any]:
    """Return mediation backlog evidence for a billing account."""
    backlog = MEDIATION_BACKLOG.get(billing_account_id, {
        "delayed_events": 0,
        "delay_hours": 0,
        "pipeline_stage": "UNKNOWN",
        "estimated_impact_usd": 0.0,
        "billing_period": "unknown",
    })
    logger.info(
        "L3 Mediation: backlog for %s: %d events delayed %.1fh",
        billing_account_id, backlog["delayed_events"], backlog["delay_hours"],
    )
    return {
        "billing_account_id": billing_account_id,
        **backlog,
        "evidence_summary": (
            f"{backlog['delayed_events']} usage events delayed "
            f"{backlog['delay_hours']}h in {backlog['pipeline_stage']}. "
            f"Estimated bill impact: ${backlog['estimated_impact_usd']:.2f}."
        ),
    }


async def create_mediation_replay_job(
    db: AsyncSession,
    *,
    issue_id: str,
    billing_account_id: str,
    events_count: int,
    control_case_id: Optional[str] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """
    Create a mediation replay job (mock execution).
    In production, this would trigger the actual mediation pipeline.
    """
    job_id = f"MJ-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    job = MediationJob(
        id=job_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        billing_account_id=billing_account_id,
        job_type="backlog_replay",
        status="completed",          # mock: instantly completes
        events_count=events_count,
        events_replayed=events_count,
        completed_at=datetime.datetime.utcnow(),
        payload={
            "replay_trigger": "usage_delay_remediation",
            "replay_completed_at": datetime.datetime.utcnow().isoformat(),
        },
    )
    db.add(job)
    if commit:
        await db.commit()

    logger.info(
        "L3 Mediation: replay job %s created — %d events replayed for %s",
        job_id, events_count, billing_account_id,
    )
    return {
        "job_id": job_id,
        "status": "completed",
        "events_replayed": events_count,
        "billing_account_id": billing_account_id,
        "evidence_summary": f"Mediation replay job {job_id}: {events_count} events successfully replayed.",
    }


def apply_bill_protection_hold(
    billing_account_id: str,
    billing_period: str,
    estimated_impact_usd: float,
) -> Dict[str, Any]:
    """
    Mock: apply a bill protection hold pending mediation replay.
    Prevents incorrect charges from appearing on final bill.
    """
    hold_ref = f"BILL-PROTECT-{billing_account_id}-{billing_period}"
    result = {
        "hold_reference": hold_ref,
        "billing_account_id": billing_account_id,
        "billing_period": billing_period,
        "protected_amount_usd": estimated_impact_usd,
        "status": "active",
        "protection_type": "pre_bill_usage_replay_pending",
        "evidence_summary": (
            f"Bill protection hold {hold_ref} applied for {billing_period}. "
            f"Up to ${estimated_impact_usd:.2f} protected pending mediation replay."
        ),
    }
    logger.info(
        "L3 Mediation: bill protection hold %s applied for %s %s",
        hold_ref, billing_account_id, billing_period,
    )
    return result
