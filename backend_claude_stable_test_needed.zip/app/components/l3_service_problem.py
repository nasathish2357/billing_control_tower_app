"""
L3 Service Problem Component — MVP2

Responsibilities:
  - Create / update ServiceProblem records.
  - Detect SLA breaches based on outage duration.
  - Return structured service evidence for graph state.
"""
import datetime
import logging
import uuid
from typing import Dict, Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import ServiceProblem
from app.components.l2_product_entitlement import get_entitlement

logger = logging.getLogger(__name__)


async def create_service_problem(
    db: AsyncSession,
    *,
    issue_id: str,
    customer_id: str,
    service_id: str,
    problem_type: str,
    description: str,
    severity: str = "medium",
    control_case_id: Optional[str] = None,
    affected_start: Optional[datetime.datetime] = None,
    affected_end: Optional[datetime.datetime] = None,
    payload: Optional[Dict[str, Any]] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """Create a new ServiceProblem record."""
    sp_id = f"SP-{issue_id}-{str(uuid.uuid4())[:6].upper()}"

    # Determine SLA breach
    sla_breach = False
    if affected_start and affected_end:
        duration_min = (affected_end - affected_start).total_seconds() / 60
        # For now use a hardcoded SLA threshold; ideally from entitlement
        sla_breach = duration_min > 60  # 60-minute SLA default

    sp = ServiceProblem(
        id=sp_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        customer_id=customer_id,
        service_id=service_id,
        problem_type=problem_type,
        severity=severity,
        status="open",
        sla_breach=sla_breach,
        affected_period_start=affected_start,
        affected_period_end=affected_end,
        description=description,
        payload=payload or {},
    )
    db.add(sp)
    if commit:
        await db.commit()

    logger.info("L3 Service Problem: created %s for issue %s (sla_breach=%s)", sp_id, issue_id, sla_breach)
    return {
        "service_problem_id": sp_id,
        "status": "open",
        "problem_type": problem_type,
        "sla_breach": sla_breach,
        "severity": severity,
        "service_id": service_id,
    }


def evaluate_sla_breach(
    billing_account_id: str,
    outage_duration_hours: float,
    service_type: str = "voice",
) -> Dict[str, Any]:
    """
    Evaluate SLA breach and compute compensation recommendation.
    Returns structured evidence with compensation amount.
    """
    entitlement = get_entitlement(billing_account_id)
    sla_max_minutes = entitlement.get("sla_max_outage_minutes", 60)
    outage_minutes = outage_duration_hours * 60
    sla_breach = outage_minutes > sla_max_minutes
    overage_minutes = max(0.0, outage_minutes - sla_max_minutes)

    # Compensation: $5 per hour beyond SLA threshold (simplified policy)
    compensation_amount = round((overage_minutes / 60) * 5.0, 2)

    result = {
        "billing_account_id": billing_account_id,
        "service_type": service_type,
        "plan_name": entitlement["plan_name"],
        "outage_duration_hours": outage_duration_hours,
        "outage_duration_minutes": round(outage_minutes, 1),
        "sla_max_minutes": sla_max_minutes,
        "sla_breach": sla_breach,
        "overage_minutes": round(overage_minutes, 1),
        "compensation_recommended": sla_breach,
        "compensation_amount": compensation_amount,
        "evidence_summary": (
            f"{service_type.capitalize()} service outage {outage_duration_hours:.1f}h. "
            f"SLA threshold: {sla_max_minutes}min. "
            f"Breach: {sla_breach}. Overage: {overage_minutes:.0f}min. "
            f"Recommended compensation: ${compensation_amount:.2f}."
        ),
    }
    logger.info(
        "L3 SLA evaluation: %s breach=%s compensation=$%.2f",
        billing_account_id, sla_breach, compensation_amount,
    )
    return result
