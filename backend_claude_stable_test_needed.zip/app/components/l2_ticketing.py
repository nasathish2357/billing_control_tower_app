"""
L2 Ticketing Component — MVP2

Responsibilities:
  - Open / update TroubleTicket records.
  - Check collections / dunning state for a billing account.
  - Return structured ticket data for graph state.
"""
import datetime
import logging
import uuid
from typing import Optional, Dict, Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import TroubleTicket, CollectionsHold

logger = logging.getLogger(__name__)


async def open_trouble_ticket(
    db: AsyncSession,
    *,
    issue_id: str,
    customer_id: str,
    billing_account_id: str,
    ticket_type: str,
    description: str,
    priority: str = "medium",
    control_case_id: Optional[str] = None,
    extra_payload: Optional[Dict[str, Any]] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """Open a new TroubleTicket and return its summary."""
    tt_id = f"TT-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    tt = TroubleTicket(
        id=tt_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        customer_id=customer_id,
        billing_account_id=billing_account_id,
        ticket_type=ticket_type,
        status="open",
        priority=priority,
        description=description,
        payload=extra_payload or {},
    )
    db.add(tt)
    if commit:
        await db.commit()

    logger.info("L2 Ticketing: opened ticket %s for issue %s", tt_id, issue_id)
    return {
        "ticket_id": tt_id,
        "status": "open",
        "ticket_type": ticket_type,
        "priority": priority,
        "billing_account_id": billing_account_id,
    }


async def check_collections_state(
    db: AsyncSession,
    billing_account_id: str,
) -> Dict[str, Any]:
    """
    Check active collections holds for a billing account.
    Returns a dict with hold status and amounts.
    """
    result = await db.execute(
        select(CollectionsHold)
        .where(
            CollectionsHold.billing_account_id == billing_account_id,
            CollectionsHold.status == "active",
        )
    )
    holds = result.scalars().all()

    if holds:
        total_disputed = sum(h.disputed_amount for h in holds)
        return {
            "has_active_hold": True,
            "hold_count": len(holds),
            "total_disputed_amount": total_disputed,
            "dunning_paused": any(h.dunning_paused for h in holds),
            "hold_ids": [h.id for h in holds],
        }
    return {
        "has_active_hold": False,
        "hold_count": 0,
        "total_disputed_amount": 0.0,
        "dunning_paused": False,
        "hold_ids": [],
    }


async def apply_collections_hold(
    db: AsyncSession,
    *,
    issue_id: str,
    billing_account_id: str,
    disputed_amount: float,
    undisputed_amount: float,
    hold_reason: str,
    control_case_id: Optional[str] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """Apply a collections hold for the disputed portion of a balance."""
    hold_id = f"HOLD-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    hold = CollectionsHold(
        id=hold_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        billing_account_id=billing_account_id,
        disputed_amount=disputed_amount,
        undisputed_amount=undisputed_amount,
        hold_reason=hold_reason,
        status="active",
        dunning_paused=True,
    )
    db.add(hold)
    if commit:
        await db.commit()

    logger.info(
        "L2 Ticketing: collections hold %s applied for %s — disputed=%.2f undisputed=%.2f",
        hold_id, billing_account_id, disputed_amount, undisputed_amount,
    )
    return {
        "hold_id": hold_id,
        "billing_account_id": billing_account_id,
        "disputed_amount": disputed_amount,
        "undisputed_amount": undisputed_amount,
        "dunning_paused": True,
        "status": "active",
    }
