"""
L2 Collections & Dunning Component — MVP2

Responsibilities:
  - Apply disputed balance holds.
  - Separate disputed from undisputed debt.
  - Pause dunning for disputed amount.
  - Release holds when dispute is resolved.
"""
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Mock dunning state per billing account
DUNNING_STATE: Dict[str, Dict[str, Any]] = {
    "BA-100001": {"stage": "none", "overdue_days": 0, "balance": 145.80},
    "BA-100002": {"stage": "first_notice", "overdue_days": 15, "balance": 320.50},
    "BA-100003": {"stage": "first_notice", "overdue_days": 12, "balance": 89.99},
}


def get_dunning_state(billing_account_id: str) -> Dict[str, Any]:
    """Return current dunning / collections state for an account."""
    state = DUNNING_STATE.get(billing_account_id, {
        "stage": "unknown",
        "overdue_days": 0,
        "balance": 0.0,
    })
    logger.info("L2 Collections: dunning state for %s: stage=%s", billing_account_id, state["stage"])
    return {
        "billing_account_id": billing_account_id,
        **state,
    }


def separate_disputed_balance(
    total_balance: float,
    disputed_amount: float,
) -> Dict[str, Any]:
    """
    Separate disputed from undisputed balance.
    Dunning continues only on undisputed portion.
    """
    undisputed = max(0.0, total_balance - disputed_amount)
    return {
        "total_balance": total_balance,
        "disputed_amount": disputed_amount,
        "undisputed_amount": round(undisputed, 2),
        "collections_action": "hold_disputed_continue_undisputed",
        "dunning_pause_scope": "disputed_portion_only",
    }


def evaluate_hold_policy(
    billing_account_id: str,
    disputed_amount: float,
    *,
    min_hold_amount: float = 5.0,
) -> Dict[str, Any]:
    """
    Evaluate whether a collections hold should be applied.
    Returns the policy decision.
    """
    state = get_dunning_state(billing_account_id)

    if disputed_amount < min_hold_amount:
        return {
            "hold_recommended": False,
            "reason": f"Disputed amount ${disputed_amount:.2f} below minimum threshold ${min_hold_amount:.2f}",
        }

    separation = separate_disputed_balance(state["balance"], disputed_amount)

    return {
        "hold_recommended": True,
        "billing_account_id": billing_account_id,
        "current_dunning_stage": state["stage"],
        "total_balance": state["balance"],
        "disputed_amount": disputed_amount,
        "undisputed_amount": separation["undisputed_amount"],
        "dunning_action": "pause_on_disputed_continue_on_undisputed",
        "evidence_summary": (
            f"Dunning stage: {state['stage']}. Balance: ${state['balance']:.2f}. "
            f"Disputed: ${disputed_amount:.2f} held. Undisputed: ${separation['undisputed_amount']:.2f} remains collectible."
        ),
    }
