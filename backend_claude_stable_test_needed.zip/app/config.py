import os
from functools import lru_cache
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    app_name: str = "Telecom Billing Dispute Agentic AI MVP"
    app_env: str = "local"
    app_debug: bool = True
    api_v1_prefix: str = "/api/v1"

    # Database
    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/billing_dispute_ai"
    langgraph_checkpoint_database_url: str = "postgresql://postgres:postgres@localhost:5432/billing_dispute_ai"

    # LLM Provider
    llm_provider: str = "vertexai_gemini"
    vertexai_project: str = ""
    vertexai_location: str = "us-central1"
    vertexai_model: str = "gemini-1.5-pro"
    vertexai_embedding_model: str = "text-embedding-004"
    google_application_credentials: str = ""

    # Vector Store
    vector_store_path: str = "data/vector_store/chroma"
    playbook_path: str = "data/playbooks"

    # Business Rules
    auto_remediation_enabled: bool = True
    human_approval_credit_threshold: float = 50.00

    # Logging / CORS / Chat
    log_level: str = "INFO"
    cors_allow_origins: str = "http://localhost:3000,http://localhost:5173"
    chat_streaming_enabled: bool = True

    # MVP2 Feature Flags
    kg_enabled: bool = True            # Enable NetworkX knowledge graph

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"

@lru_cache()
def get_settings() -> Settings:
    return Settings()
