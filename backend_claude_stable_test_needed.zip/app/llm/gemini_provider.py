"""
Google GenAI LLM and Embedding provider — langchain-google-genai 4.x.

Auth: Vertex AI backend via GOOGLE_GENAI_USE_VERTEXAI=true.
Credentials: GOOGLE_APPLICATION_CREDENTIALS (service account) or ADC.

NOTE: env vars are applied eagerly at module import so that the lru_cache
returns correctly-configured instances.
"""

import logging
import os
from functools import lru_cache

logger = logging.getLogger(__name__)

# ── Apply Vertex AI env vars at import time ────────────────────────────────
# This must happen BEFORE ChatGoogleGenerativeAI is imported/instantiated.
def _bootstrap_vertex_ai() -> None:
    """Read settings and stamp the process env so google-genai SDK uses Vertex AI."""
    from app.config import get_settings
    settings = get_settings()

    missing = []
    if not settings.vertexai_project:
        missing.append("VERTEXAI_PROJECT")
    if not settings.vertexai_model:
        missing.append("VERTEXAI_MODEL")
    if missing:
        raise EnvironmentError(
            f"Missing required configuration: {', '.join(missing)}. "
            "Please populate .env before starting."
        )

    # Tell google-genai SDK: use Vertex AI, not the Gemini Developer API
    os.environ.setdefault("GOOGLE_GENAI_USE_VERTEXAI", "true")
    os.environ.setdefault("GOOGLE_CLOUD_PROJECT", settings.vertexai_project)
    os.environ.setdefault("GOOGLE_CLOUD_LOCATION", settings.vertexai_location)

    # Apply service-account credentials file if provided
    creds = settings.google_application_credentials
    if creds:
        if os.path.exists(creds):
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = creds
            logger.info("Using service-account credentials: %s", creds)
        else:
            logger.warning(
                "GOOGLE_APPLICATION_CREDENTIALS='%s' not found — using ADC.",
                creds,
            )

    logger.info(
        "Vertex AI configured: project=%s location=%s model=%s",
        settings.vertexai_project, settings.vertexai_location, settings.vertexai_model,
    )


# Bootstrap immediately on import
_bootstrap_vertex_ai()

# Now safe to import — env vars are already set
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings


@lru_cache()
def get_llm(streaming: bool = False, temperature: float = 0.0) -> ChatGoogleGenerativeAI:
    from app.config import get_settings
    settings = get_settings()
    return ChatGoogleGenerativeAI(
        model=settings.vertexai_model,
        temperature=temperature,
        streaming=streaming,
    )


@lru_cache()
def get_embeddings() -> GoogleGenerativeAIEmbeddings:
    from app.config import get_settings
    settings = get_settings()
    embedding_model = settings.vertexai_embedding_model or "text-embedding-004"
    if not embedding_model.startswith("models/"):
        embedding_model = f"models/{embedding_model}"
    return GoogleGenerativeAIEmbeddings(model=embedding_model)
