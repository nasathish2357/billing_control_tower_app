"""
KG Builder — MVP3

Builds a NetworkX DiGraph as a derived read model from PostgreSQL.

Design rules (from master prompt):
  - PostgreSQL is the source of truth.
  - KG is a read-only derived model — no transactional writes.
  - KG is rebuilt from DB records on demand (cached 60s).
  - PostgreSQL evidence_packs / audit_traces hold large payloads.
  - KG stores only entity type, ID, and lightweight properties.

Relationships modelled (MVP2 baseline):
  Customer → BillingAccount → Bill
  Issue → ControlCase → EvidencePack
  Issue → ControlCase → AuditTrace
  TMFEvent → Issue
  TroubleTicket → ControlCase
  ServiceProblem → Issue
  Approval → ControlCase

Additional relationships (MVP3):
  Bill → BillLineItem (charge breakdown)
  BillingAccount → RatedUsage → MediationRecord → UsageEvent (CDR/usage chain)
  BillingAccount → PDUSession (session accounting)
  Customer → Device (SIM/handset)
  BillingAccount → Product → ProductOffering
  Customer → ServiceInventory → ProductOffering
  NetworkFunction (standalone nodes — 5G NF registry)
  PartnerAccount → PartnerSettlement → Issue
  BillingAccount → PaymentRecord
"""
import datetime
import logging
import time
import uuid
from typing import Optional

logger = logging.getLogger(__name__)

try:
    import networkx as nx
    _NX_AVAILABLE = True
except ImportError:
    _NX_AVAILABLE = False
    logger.warning("networkx not installed — KG builder will return empty graphs.")


# ── In-memory cache ───────────────────────────────────────────────────────────

_cached_graph = None
_cache_built_at: Optional[datetime.datetime] = None
_CACHE_TTL_SECONDS = 60


def _is_cache_valid() -> bool:
    if _cached_graph is None or _cache_built_at is None:
        return False
    age = (datetime.datetime.utcnow() - _cache_built_at).total_seconds()
    return age < _CACHE_TTL_SECONDS


async def build_graph(db) -> "nx.DiGraph":
    """
    Build a NetworkX DiGraph from the current PostgreSQL state.
    Returns cached graph if cache is still valid (< 60s old).
    """
    global _cached_graph, _cache_built_at

    if _is_cache_valid():
        logger.debug("KG: using cached graph (%d nodes)", _cached_graph.number_of_nodes())
        return _cached_graph

    if not _NX_AVAILABLE:
        return None

    from sqlalchemy import select
    from app.models.models import (
        Customer, BillingAccount, Bill, Issue, ControlCase,
        EvidencePack, AuditTrace, TMFEvent, TroubleTicket,
        ServiceProblem, Approval,
        # MVP3 entities
        BillLineItem, Product, ProductOffering,
        Device, PaymentRecord,
        UsageEvent, MediationRecord, RatedUsage, PDUSession,
        ServiceInventory, NetworkFunction,
        PartnerAccount, PartnerSettlement,
    )

    t0 = time.time()
    G = nx.DiGraph()

    # ── Customers ────────────────────────────────────────────────────────────
    result = await db.execute(select(Customer))
    for c in result.scalars():
        G.add_node(c.id, type="Customer", name=c.name, segment=c.segment,
                   customer_type=c.customer_type)

    # ── Billing Accounts ─────────────────────────────────────────────────────
    result = await db.execute(select(BillingAccount))
    for ba in result.scalars():
        G.add_node(ba.id, type="BillingAccount", status=ba.status,
                   account_type=ba.account_type, credit_limit=ba.credit_limit)
        if ba.customer_id in G:
            G.add_edge(ba.customer_id, ba.id, rel="HAS_BILLING_ACCOUNT")

    # ── Bills ────────────────────────────────────────────────────────────────
    result = await db.execute(select(Bill))
    for b in result.scalars():
        G.add_node(b.id, type="Bill", period=b.billing_period,
                   amount=b.amount_due, status=b.status)
        if b.billing_account_id in G:
            G.add_edge(b.billing_account_id, b.id, rel="HAS_BILL")

    # ── Issues ───────────────────────────────────────────────────────────────
    result = await db.execute(select(Issue))
    for iss in result.scalars():
        G.add_node(iss.id, type="Issue", use_case=iss.use_case_id, status=iss.status)
        if iss.billing_account_id in G:
            G.add_edge(iss.billing_account_id, iss.id, rel="HAS_ISSUE")

    # ── Control Cases ─────────────────────────────────────────────────────────
    result = await db.execute(select(ControlCase))
    for cc in result.scalars():
        G.add_node(cc.id, type="ControlCase", status=cc.status)
        if cc.issue_id in G:
            G.add_edge(cc.issue_id, cc.id, rel="HAS_CONTROL_CASE")

    # ── Evidence Packs ────────────────────────────────────────────────────────
    result = await db.execute(select(EvidencePack))
    for evp in result.scalars():
        G.add_node(evp.id, type="EvidencePack", layer=evp.source_layer)
        if evp.control_case_id in G:
            G.add_edge(evp.control_case_id, evp.id, rel="HAS_EVIDENCE")

    # ── Audit Traces ──────────────────────────────────────────────────────────
    result = await db.execute(select(AuditTrace))
    for at in result.scalars():
        G.add_node(at.id, type="AuditTrace", action_type=at.action_type)
        if at.control_case_id in G:
            G.add_edge(at.control_case_id, at.id, rel="HAS_AUDIT")

    # ── TMF Events ────────────────────────────────────────────────────────────
    result = await db.execute(select(TMFEvent))
    for ev in result.scalars():
        G.add_node(ev.id, type="TMFEvent", event_type=ev.event_type, status=ev.status)
        if ev.issue_id and ev.issue_id in G:
            G.add_edge(ev.id, ev.issue_id, rel="TRIGGERED_ISSUE")
        if ev.control_case_id and ev.control_case_id in G:
            G.add_edge(ev.id, ev.control_case_id, rel="CORRELATED_TO")

    # ── Trouble Tickets ────────────────────────────────────────────────────────
    result = await db.execute(select(TroubleTicket))
    for tt in result.scalars():
        G.add_node(tt.id, type="TroubleTicket", ticket_type=tt.ticket_type, status=tt.status)
        if tt.issue_id and tt.issue_id in G:
            G.add_edge(tt.id, tt.issue_id, rel="RELATED_TO_ISSUE")
        if tt.control_case_id and tt.control_case_id in G:
            G.add_edge(tt.id, tt.control_case_id, rel="RELATED_TO_CASE")

    # ── Service Problems ──────────────────────────────────────────────────────
    result = await db.execute(select(ServiceProblem))
    for sp in result.scalars():
        G.add_node(sp.id, type="ServiceProblem", problem_type=sp.problem_type,
                   sla_breach=sp.sla_breach)
        if sp.issue_id and sp.issue_id in G:
            G.add_edge(sp.id, sp.issue_id, rel="RELATES_TO_ISSUE")

    # ── Approvals ─────────────────────────────────────────────────────────────
    result = await db.execute(select(Approval))
    for ap in result.scalars():
        G.add_node(ap.id, type="Approval", action=ap.action, status=ap.status)
        if ap.control_case_id in G:
            G.add_edge(ap.control_case_id, ap.id, rel="REQUIRES_APPROVAL")

    # ═══════════════════════════════════════════════════════════════════════════
    # MVP3 Entity Types
    # ═══════════════════════════════════════════════════════════════════════════

    # ── Bill Line Items (charge breakdown) ────────────────────────────────────
    result = await db.execute(select(BillLineItem))
    for bli in result.scalars():
        G.add_node(bli.id, type="BillLineItem", charge_type=bli.charge_type,
                   amount=bli.amount, dispute_flag=bli.dispute_flag)
        if bli.bill_id in G:
            G.add_edge(bli.bill_id, bli.id, rel="HAS_LINE_ITEM")
        # Link to RatedUsage if available (added after RatedUsage nodes)

    # ── Products (catalog — standalone, linked to offerings) ─────────────────
    result = await db.execute(select(Product))
    for p in result.scalars():
        G.add_node(p.id, type="Product", name=p.name,
                   product_type=p.product_type, is_active=p.is_active)

    # ── Product Offerings ─────────────────────────────────────────────────────
    result = await db.execute(select(ProductOffering))
    for po in result.scalars():
        G.add_node(po.id, type="ProductOffering", name=po.name,
                   tier=po.tier, monthly_fee=po.monthly_fee)
        if po.product_id in G:
            G.add_edge(po.product_id, po.id, rel="HAS_OFFERING")

    # ── Devices ───────────────────────────────────────────────────────────────
    result = await db.execute(select(Device))
    for dev in result.scalars():
        G.add_node(dev.id, type="Device", model=dev.model,
                   manufacturer=dev.manufacturer, status=dev.status)
        if dev.customer_id in G:
            G.add_edge(dev.customer_id, dev.id, rel="HAS_DEVICE")

    # ── Payment Records ───────────────────────────────────────────────────────
    result = await db.execute(select(PaymentRecord))
    for pay in result.scalars():
        G.add_node(pay.id, type="PaymentRecord", amount=pay.amount,
                   method=pay.method, status=pay.status)
        if pay.billing_account_id in G:
            G.add_edge(pay.billing_account_id, pay.id, rel="HAS_PAYMENT")

    # ── Usage Events (CDR/xDR) ────────────────────────────────────────────────
    result = await db.execute(select(UsageEvent))
    for ue in result.scalars():
        G.add_node(ue.id, type="UsageEvent", event_type=ue.event_type,
                   charging_trigger=ue.charging_trigger, billing_period=ue.billing_period)
        if ue.billing_account_id in G:
            G.add_edge(ue.billing_account_id, ue.id, rel="HAS_USAGE_EVENT")

    # ── Mediation Records ─────────────────────────────────────────────────────
    result = await db.execute(select(MediationRecord))
    for mr in result.scalars():
        G.add_node(mr.id, type="MediationRecord", status=mr.status,
                   billing_period=mr.billing_period)
        if mr.usage_event_id and mr.usage_event_id in G:
            G.add_edge(mr.usage_event_id, mr.id, rel="MEDIATED_BY")
        elif mr.billing_account_id and mr.billing_account_id in G:
            # Fall back to linking via billing account if usage_event_id not set
            G.add_edge(mr.billing_account_id, mr.id, rel="HAS_MEDIATION_RECORD")

    # ── Rated Usage (rating engine output) ───────────────────────────────────
    result = await db.execute(select(RatedUsage))
    for ru in result.scalars():
        G.add_node(ru.id, type="RatedUsage", charge_type=ru.charge_type,
                   amount=ru.amount, billing_period=ru.billing_period)
        if ru.mediation_record_id and ru.mediation_record_id in G:
            G.add_edge(ru.mediation_record_id, ru.id, rel="RATED_FROM")
        if ru.bill_id and ru.bill_id in G:
            G.add_edge(ru.id, ru.bill_id, rel="RATED_INTO_BILL")
        if ru.billing_account_id in G:
            G.add_edge(ru.billing_account_id, ru.id, rel="HAS_RATED_USAGE")

    # Back-link BillLineItem → RatedUsage (second pass — both now in graph)
    result = await db.execute(select(BillLineItem))
    for bli in result.scalars():
        if bli.rated_usage_id and bli.rated_usage_id in G and bli.id in G:
            G.add_edge(bli.id, bli.rated_usage_id, rel="FROM_RATED_USAGE")

    # ── PDU Sessions ──────────────────────────────────────────────────────────
    result = await db.execute(select(PDUSession))
    for pdu in result.scalars():
        G.add_node(pdu.id, type="PDUSession", session_id=pdu.session_id,
                   status=pdu.status, data_volume_gb=pdu.data_volume_gb)
        if pdu.billing_account_id in G:
            G.add_edge(pdu.billing_account_id, pdu.id, rel="HAS_PDU_SESSION")

    # ── Service Inventory ─────────────────────────────────────────────────────
    result = await db.execute(select(ServiceInventory))
    for svc in result.scalars():
        G.add_node(svc.id, type="ServiceInventory", service_type=svc.service_type,
                   service_id=svc.service_id, status=svc.status)
        if svc.customer_id in G:
            G.add_edge(svc.customer_id, svc.id, rel="HAS_SERVICE")
        if svc.billing_account_id and svc.billing_account_id in G:
            G.add_edge(svc.billing_account_id, svc.id, rel="SERVICE_ON_ACCOUNT")
        if svc.product_offering_id and svc.product_offering_id in G:
            G.add_edge(svc.id, svc.product_offering_id, rel="DELIVERED_BY_OFFERING")

    # ── Network Functions ─────────────────────────────────────────────────────
    result = await db.execute(select(NetworkFunction))
    for nf in result.scalars():
        G.add_node(nf.id, type="NetworkFunction", nf_type=nf.nf_type,
                   name=nf.name, region=nf.region, status=nf.status)
        # NFs are standalone in KG — connected by cross-reference queries

    # ── Partner Accounts ──────────────────────────────────────────────────────
    result = await db.execute(select(PartnerAccount))
    for pa in result.scalars():
        G.add_node(pa.id, type="PartnerAccount", name=pa.name,
                   partner_type=pa.partner_type, status=pa.status)

    # ── Partner Settlements ───────────────────────────────────────────────────
    result = await db.execute(select(PartnerSettlement))
    for ps in result.scalars():
        G.add_node(ps.id, type="PartnerSettlement", billing_period=ps.billing_period,
                   discrepancy=ps.discrepancy_amount, status=ps.status)
        if ps.partner_account_id in G:
            G.add_edge(ps.partner_account_id, ps.id, rel="HAS_SETTLEMENT")
        if ps.issue_id and ps.issue_id in G:
            G.add_edge(ps.id, ps.issue_id, rel="LINKED_TO_ISSUE")
        if ps.control_case_id and ps.control_case_id in G:
            G.add_edge(ps.id, ps.control_case_id, rel="LINKED_TO_CASE")

    elapsed_ms = (time.time() - t0) * 1000
    logger.info(
        "KG built: %d nodes, %d edges in %.1fms",
        G.number_of_nodes(), G.number_of_edges(), elapsed_ms,
    )

    # ── Persist snapshot metadata ─────────────────────────────────────────────
    try:
        from app.models.models import KGSnapshot
        snap_id = f"KG-SNAP-{str(uuid.uuid4())[:8].upper()}"
        snap = KGSnapshot(
            id=snap_id,
            node_count=G.number_of_nodes(),
            edge_count=G.number_of_edges(),
            build_duration_ms=elapsed_ms,
            status="ready",
        )
        db.add(snap)
        await db.commit()
    except Exception as e:
        logger.warning("KG snapshot persist failed: %s", e)

    _cached_graph = G
    _cache_built_at = datetime.datetime.utcnow()
    return G


def invalidate_cache():
    """Force the next build_graph() call to rebuild from DB."""
    global _cached_graph, _cache_built_at
    _cached_graph = None
    _cache_built_at = None