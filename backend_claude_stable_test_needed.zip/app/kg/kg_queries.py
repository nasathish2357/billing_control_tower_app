"""
KG Queries — MVP3

Graph query functions over the NetworkX DiGraph built by kg_builder.
All queries operate on the derived read model — no writes to PostgreSQL.
"""
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


async def get_issue_relationships(db, issue_id: str) -> Dict[str, Any]:
    """
    Return all KG nodes and edges reachable from the given issue_id.
    Includes: billing account, customer, bills, control cases, evidence packs, events.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"issue_id": issue_id, "nodes": [], "edges": [], "error": "networkx not available"}

    if issue_id not in G:
        return {"issue_id": issue_id, "nodes": [], "edges": [], "warning": "issue not in graph"}

    nodes = []
    edges = []
    visited = {issue_id}

    # Outgoing (children)
    for successor in G.successors(issue_id):
        edge_data = G[issue_id][successor]
        edges.append({"from": issue_id, "to": successor, "rel": edge_data.get("rel")})
        if successor not in visited:
            visited.add(successor)
            nodes.append({"id": successor, **G.nodes[successor]})
            # One more hop for control case children
            for child in G.successors(successor):
                child_edge = G[successor][child]
                edges.append({"from": successor, "to": child, "rel": child_edge.get("rel")})
                if child not in visited:
                    visited.add(child)
                    nodes.append({"id": child, **G.nodes[child]})

    # Incoming (parents — e.g. events that triggered this issue)
    for predecessor in G.predecessors(issue_id):
        edge_data = G[predecessor][issue_id]
        edges.append({"from": predecessor, "to": issue_id, "rel": edge_data.get("rel")})
        if predecessor not in visited:
            visited.add(predecessor)
            nodes.append({"id": predecessor, **G.nodes[predecessor]})

    issue_node = {"id": issue_id, **G.nodes[issue_id]}

    return {
        "issue_id": issue_id,
        "issue": issue_node,
        "nodes": nodes,
        "edges": edges,
        "total_nodes": len(nodes) + 1,
        "total_edges": len(edges),
    }


async def get_customer_billing_context(db, customer_id: str) -> Dict[str, Any]:
    """
    Return full billing context for a customer from the KG.
    Traverses: Customer → BillingAccounts → Bills → Issues → ControlCases.
    Also includes devices, services, products in the customer subtree.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"customer_id": customer_id, "error": "networkx not available"}

    if customer_id not in G:
        return {"customer_id": customer_id, "warning": "customer not in graph"}

    def _collect_subtree(node_id: str, max_depth: int = 4) -> List[Dict[str, Any]]:
        collected = []
        for successor in G.successors(node_id):
            node_data = {"id": successor, **G.nodes[successor]}
            node_data["rel"] = G[node_id][successor].get("rel")
            if max_depth > 0:
                node_data["children"] = _collect_subtree(successor, max_depth - 1)
            collected.append(node_data)
        return collected

    customer_node = {"id": customer_id, **G.nodes[customer_id]}

    # Summarize key counts
    subtree = _collect_subtree(customer_id)
    billing_accounts = [n for n in subtree if n.get("type") == "BillingAccount"]
    devices = [n for n in subtree if n.get("type") == "Device"]
    services = [n for n in subtree if n.get("type") == "ServiceInventory"]

    return {
        "customer_id": customer_id,
        "customer": customer_node,
        "billing_account_count": len(billing_accounts),
        "device_count": len(devices),
        "service_count": len(services),
        "billing_tree": subtree,
    }


async def get_control_case_impact(db, control_case_id: str) -> Dict[str, Any]:
    """
    Return all entities reachable from a control case in the KG:
    ControlCase → EvidencePacks, AuditTraces, Approvals.
    Also traverse upstream: ControlCase ← Issue ← BillingAccount ← Customer.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"control_case_id": control_case_id, "error": "networkx not available"}

    if control_case_id not in G:
        return {"control_case_id": control_case_id, "warning": "control case not in graph"}

    try:
        import networkx as nx

        # Downstream: everything reachable from the control case
        downstream_ids = list(nx.descendants(G, control_case_id))
        downstream_nodes = [{"id": n, **G.nodes[n]} for n in downstream_ids]
        downstream_edges = [
            {"from": u, "to": v, "rel": G[u][v].get("rel")}
            for u, v in nx.edge_bfs(G, control_case_id)
        ]

        # Upstream: issue, billing account, customer
        upstream = []
        visited_up = {control_case_id}
        for pred in G.predecessors(control_case_id):   # Issue → ControlCase
            if pred not in visited_up:
                visited_up.add(pred)
                upstream.append({"id": pred, **G.nodes[pred], "rel": G[pred][control_case_id].get("rel")})
                for pred2 in G.predecessors(pred):     # BillingAccount → Issue
                    if pred2 not in visited_up:
                        visited_up.add(pred2)
                        upstream.append({"id": pred2, **G.nodes[pred2],
                                         "rel": G[pred2][pred].get("rel")})
                        for pred3 in G.predecessors(pred2):  # Customer → BillingAccount
                            if pred3 not in visited_up:
                                visited_up.add(pred3)
                                upstream.append({"id": pred3, **G.nodes[pred3],
                                                 "rel": G[pred3][pred2].get("rel")})

        # Bucket downstream nodes by type
        evidence_packs = [n for n in downstream_nodes if n.get("type") == "EvidencePack"]
        audit_traces = [n for n in downstream_nodes if n.get("type") == "AuditTrace"]
        approvals = [n for n in downstream_nodes if n.get("type") == "Approval"]

    except Exception as e:
        return {"control_case_id": control_case_id, "error": str(e)}

    return {
        "control_case_id": control_case_id,
        "control_case": {"id": control_case_id, **G.nodes[control_case_id]},
        "upstream_entities": upstream,
        "evidence_pack_count": len(evidence_packs),
        "audit_trace_count": len(audit_traces),
        "approval_count": len(approvals),
        "downstream_nodes": downstream_nodes,
        "downstream_edges": downstream_edges,
        "total_downstream": len(downstream_nodes),
    }


async def get_bill_to_usage_trace(db, bill_id: str) -> Dict[str, Any]:
    """
    Trace a bill back through the full usage chain:
    Bill → BillLineItem → RatedUsage → MediationRecord → UsageEvent (CDR)

    Enables cross-domain billing audit: confirm that each billed charge
    is traceable to a rated CDR from the mediation engine.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"bill_id": bill_id, "error": "networkx not available"}

    if bill_id not in G:
        return {"bill_id": bill_id, "warning": "bill not in graph"}

    chain: List[Dict[str, Any]] = []
    traced_ids = {bill_id}

    # Bill → BillLineItem
    for bli_id in G.successors(bill_id):
        if G.nodes[bli_id].get("type") != "BillLineItem":
            continue
        bli_node = {"id": bli_id, **G.nodes[bli_id], "rel": "HAS_LINE_ITEM", "children": []}
        traced_ids.add(bli_id)

        # BillLineItem → RatedUsage
        for ru_id in G.successors(bli_id):
            if G.nodes[ru_id].get("type") != "RatedUsage":
                continue
            ru_node = {"id": ru_id, **G.nodes[ru_id], "rel": "FROM_RATED_USAGE", "children": []}
            traced_ids.add(ru_id)

            # RatedUsage ← MediationRecord (inverted: MediationRecord → RatedUsage edge)
            for mr_id in G.predecessors(ru_id):
                if G.nodes[mr_id].get("type") != "MediationRecord":
                    continue
                mr_node = {"id": mr_id, **G.nodes[mr_id], "rel": "RATED_FROM", "children": []}
                traced_ids.add(mr_id)

                # MediationRecord ← UsageEvent (inverted: UsageEvent → MediationRecord)
                for ue_id in G.predecessors(mr_id):
                    if G.nodes[ue_id].get("type") != "UsageEvent":
                        continue
                    ue_node = {"id": ue_id, **G.nodes[ue_id], "rel": "MEDIATED_BY"}
                    traced_ids.add(ue_id)
                    mr_node["children"].append(ue_node)

                ru_node["children"].append(mr_node)

            bli_node["children"].append(ru_node)

        chain.append(bli_node)

    return {
        "bill_id": bill_id,
        "bill": {"id": bill_id, **G.nodes[bill_id]},
        "line_item_count": len(chain),
        "usage_chain": chain,
        "traced_entity_count": len(traced_ids),
    }


async def get_service_to_nf_trace(db, service_inventory_id: str) -> Dict[str, Any]:
    """
    Trace a service inventory entry to network functions delivering it.
    ServiceInventory → ProductOffering, plus correlated NetworkFunction nodes
    of the type that would deliver the service (e.g., UPF for data, CHF for charging).
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"service_inventory_id": service_inventory_id, "error": "networkx not available"}

    if service_inventory_id not in G:
        return {"service_inventory_id": service_inventory_id, "warning": "service not in graph"}

    svc_node = {"id": service_inventory_id, **G.nodes[service_inventory_id]}
    service_type = svc_node.get("service_type", "")

    # Map service types to relevant NF types
    SERVICE_TO_NF_TYPES = {
        "data": ["UPF", "SMF", "CHF"],
        "voice": ["AMF", "SMF", "CTF"],
        "premium_5g_slice": ["UPF", "SMF", "PCF", "NWDAF"],
        "roaming": ["UPF", "SMF", "SEPP", "CHF"],
        "iot": ["UPF", "NEF", "CHF"],
        "sms": ["SMF", "CTF"],
    }
    relevant_nf_types = SERVICE_TO_NF_TYPES.get(service_type, ["UPF", "SMF"])

    # Collect downstream nodes (ProductOffering)
    offering_nodes = []
    for succ in G.successors(service_inventory_id):
        if G.nodes[succ].get("type") == "ProductOffering":
            offering_nodes.append({"id": succ, **G.nodes[succ]})

    # Find all NetworkFunction nodes of relevant types
    nf_nodes = [
        {"id": n, **G.nodes[n]}
        for n, d in G.nodes(data=True)
        if d.get("type") == "NetworkFunction" and d.get("nf_type") in relevant_nf_types
    ]

    return {
        "service_inventory_id": service_inventory_id,
        "service": svc_node,
        "product_offerings": offering_nodes,
        "relevant_network_functions": nf_nodes,
        "relevant_nf_types": relevant_nf_types,
    }


async def find_impacted_entities(db, event_id: str) -> Dict[str, Any]:
    """
    From a TMFEvent node, find all downstream entities:
    Event → Issue → ControlCase → EvidencePack / AuditTrace.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"event_id": event_id, "error": "networkx not available"}

    if event_id not in G:
        return {"event_id": event_id, "warning": "event not in graph"}

    try:
        import networkx as nx
        reachable = list(nx.descendants(G, event_id))
        nodes = [{"id": n, **G.nodes[n]} for n in reachable]
        edges = [
            {"from": u, "to": v, "rel": G[u][v].get("rel")}
            for u, v in nx.edge_bfs(G, event_id)
        ]
    except Exception as e:
        return {"event_id": event_id, "error": str(e)}

    return {
        "event_id": event_id,
        "event": {"id": event_id, **G.nodes[event_id]},
        "impacted_nodes": nodes,
        "impacted_edges": edges,
        "total_impacted": len(nodes),
    }