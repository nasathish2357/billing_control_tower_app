"""KG package — NetworkX knowledge graph as derived read model from PostgreSQL."""
