"""
SQLAlchemy ORM models for Billing Control Tower MVP1 + MVP2.

Design principle: Large TMF-style payloads are stored in JSON/JSONB columns
on the database rows. Only compact references (IDs, summaries) are placed in
LangGraph state, keeping checkpointed state lightweight.
"""

import datetime
from typing import List, Optional
from sqlalchemy import String, ForeignKey, DateTime, Float, JSON, Text, Boolean, Integer, BigInteger
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class UseCase(Base):
    __tablename__ = "use_cases"

    id: Mapped[str] = mapped_column(String(10), primary_key=True)   # P1 … P10
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    priority: Mapped[str] = mapped_column(String(10))
    flow_type: Mapped[str] = mapped_column(String(30), default="simplified_deterministic")
    status: Mapped[str] = mapped_column(String(20), default="active")


class Customer(Base):
    __tablename__ = "customers"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # CUST-100001
    name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str] = mapped_column(String(200))
    segment: Mapped[str] = mapped_column(String(50))                 # Consumer, Enterprise, Wholesale
    phone: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    address: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    customer_type: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)  # B2C, B2B, B2B2X

    billing_accounts: Mapped[List["BillingAccount"]] = relationship(back_populates="customer")


class BillingAccount(Base):
    __tablename__ = "billing_accounts"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # BA-100001
    customer_id: Mapped[str] = mapped_column(ForeignKey("customers.id"))
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    status: Mapped[str] = mapped_column(String(30))
    account_type: Mapped[Optional[str]] = mapped_column(String(30), nullable=True)  # prepaid, postpaid, enterprise, wholesale
    credit_limit: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    customer: Mapped["Customer"] = relationship(back_populates="billing_accounts")
    bills: Mapped[List["Bill"]] = relationship(back_populates="billing_account")


class Bill(Base):
    __tablename__ = "bills"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # BILL-202604
    billing_account_id: Mapped[str] = mapped_column(ForeignKey("billing_accounts.id"))
    billing_period: Mapped[str] = mapped_column(String(20))         # 2026-04
    amount_due: Mapped[float] = mapped_column(Float)
    previous_amount: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    due_date: Mapped[datetime.datetime] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(30))                  # Paid, Disputed, Pending
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    billing_account: Mapped["BillingAccount"] = relationship(back_populates="bills")


class Issue(Base):
    __tablename__ = "issues"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # ISSUE-P2-001
    use_case_id: Mapped[str] = mapped_column(ForeignKey("use_cases.id"))
    customer_id: Mapped[str] = mapped_column(String(50))
    billing_account_id: Mapped[str] = mapped_column(String(50))
    bill_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="open")
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    use_case: Mapped["UseCase"] = relationship()
    control_cases: Mapped[List["ControlCase"]] = relationship(back_populates="issue")


class ControlCase(Base):
    __tablename__ = "control_cases"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # CC-P2-001
    issue_id: Mapped[str] = mapped_column(ForeignKey("issues.id"))
    status: Mapped[str] = mapped_column(String(30))
    thread_id: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    requires_human_approval: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)

    issue: Mapped["Issue"] = relationship(back_populates="control_cases")
    evidence_packs: Mapped[List["EvidencePack"]] = relationship(back_populates="control_case")
    audit_traces: Mapped[List["AuditTrace"]] = relationship(back_populates="control_case")
    approvals: Mapped[List["Approval"]] = relationship(back_populates="control_case")


class EvidencePack(Base):
    __tablename__ = "evidence_packs"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # EVP-P2-L3-001
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    source_layer: Mapped[str] = mapped_column(String(30))
    summary: Mapped[str] = mapped_column(Text)
    payload: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)

    control_case: Mapped["ControlCase"] = relationship(back_populates="evidence_packs")


class AuditTrace(Base):
    __tablename__ = "audit_traces"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # TRACE-P2-001
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    action_type: Mapped[str] = mapped_column(String(50))
    actor: Mapped[str] = mapped_column(String(50))
    summary: Mapped[str] = mapped_column(Text)
    details: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)

    control_case: Mapped["ControlCase"] = relationship(back_populates="audit_traces")


# ─────────────────────────────────────────────────────────────────────────────
# MVP2 Models
# ─────────────────────────────────────────────────────────────────────────────

class TMFEvent(Base):
    """TMF688-style event lifecycle table for event-driven correlation."""
    __tablename__ = "tmf_events"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # EVT-P1-001
    event_type: Mapped[str] = mapped_column(String(100))
    use_case_id: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    source_layer: Mapped[str] = mapped_column(String(10))                # L1, L2, L3, L4
    severity: Mapped[str] = mapped_column(String(20), default="medium")  # low, medium, high, critical
    status: Mapped[str] = mapped_column(String(20), default="new")       # new, correlated, resolved
    customer_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    description: Mapped[str] = mapped_column(Text)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    correlated_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


class Approval(Base):
    """Human approval record for high-risk agentic actions. Linked to LangGraph thread_id for resume."""
    __tablename__ = "approvals"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # APPR-P5-001
    thread_id: Mapped[str] = mapped_column(String(200))
    issue_id: Mapped[str] = mapped_column(String(50))
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    action: Mapped[str] = mapped_column(String(100))                     # e.g. "apply_compensation"
    risk_reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending")   # pending, approved, rejected
    approver_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    amount: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    decided_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)

    control_case: Mapped["ControlCase"] = relationship(back_populates="approvals")


class ServiceProblem(Base):
    """L3 OSS service problem lifecycle (TMF656-inspired)."""
    __tablename__ = "service_problems"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # SP-P5-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    customer_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    service_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    problem_type: Mapped[str] = mapped_column(String(100))               # service_degradation, outage, qos_breach
    severity: Mapped[str] = mapped_column(String(20), default="medium")
    status: Mapped[str] = mapped_column(String(20), default="open")      # open, investigating, resolved
    sla_breach: Mapped[bool] = mapped_column(Boolean, default=False)
    affected_period_start: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    affected_period_end: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    description: Mapped[str] = mapped_column(Text)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class TroubleTicket(Base):
    """L2 BSS trouble ticket (TMF621-inspired)."""
    __tablename__ = "trouble_tickets"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # TT-P6-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    customer_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    ticket_type: Mapped[str] = mapped_column(String(100))                # billing_dispute, service_complaint
    status: Mapped[str] = mapped_column(String(20), default="open")      # open, in_progress, resolved, closed
    priority: Mapped[str] = mapped_column(String(20), default="medium")
    description: Mapped[str] = mapped_column(Text)
    resolution: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class MediationJob(Base):
    """L3 mediation replay job tracking."""
    __tablename__ = "mediation_jobs"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # MJ-P1-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    job_type: Mapped[str] = mapped_column(String(50))                    # usage_replay, backlog_replay
    status: Mapped[str] = mapped_column(String(20), default="queued")    # queued, running, completed, failed
    events_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    events_replayed: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    completed_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class CollectionsHold(Base):
    """L2 collections hold record for disputed balances."""
    __tablename__ = "collections_holds"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # HOLD-P6-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[str] = mapped_column(String(50))
    disputed_amount: Mapped[float] = mapped_column(Float)
    undisputed_amount: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    hold_reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="active")    # active, released, expired
    dunning_paused: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    released_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class CompensationDecision(Base):
    """L2 compensation decision record for SLA breaches / service degradation."""
    __tablename__ = "compensation_decisions"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # COMP-P5-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[str] = mapped_column(String(50))
    compensation_type: Mapped[str] = mapped_column(String(50))           # credit, waiver, rebill, voucher
    amount: Mapped[float] = mapped_column(Float)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending")   # pending, approved, applied, rejected
    approval_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    applied_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


class KGSnapshot(Base):
    """Metadata for NetworkX knowledge graph snapshots (derived read model from PostgreSQL)."""
    __tablename__ = "kg_snapshots"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # KG-SNAP-001
    node_count: Mapped[int] = mapped_column(Integer, default=0)
    edge_count: Mapped[int] = mapped_column(Integer, default=0)
    build_duration_ms: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="ready")     # building, ready, stale
    built_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


# ─────────────────────────────────────────────────────────────────────────────
# MVP3 Models
# ─────────────────────────────────────────────────────────────────────────────

class Product(Base):
    """Product catalog entry (TMF620-inspired)."""
    __tablename__ = "products"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # PROD-001
    name: Mapped[str] = mapped_column(String(200))
    product_type: Mapped[str] = mapped_column(String(50))                # mobile_plan, add_on, vas, wholesale
    description: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    offerings: Mapped[List["ProductOffering"]] = relationship(back_populates="product")


class ProductOffering(Base):
    """Commercial product offering linked to a product (TMF637-inspired)."""
    __tablename__ = "product_offerings"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # PO-001
    product_id: Mapped[str] = mapped_column(ForeignKey("products.id"))
    name: Mapped[str] = mapped_column(String(200))
    tier: Mapped[str] = mapped_column(String(30))                        # basic, standard, premium, enterprise, wholesale
    monthly_fee: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    product: Mapped["Product"] = relationship(back_populates="offerings")


class BillLineItem(Base):
    """Individual bill line item (TMF678-inspired)."""
    __tablename__ = "bill_line_items"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # BLI-001
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id"))
    description: Mapped[str] = mapped_column(String(500))
    amount: Mapped[float] = mapped_column(Float)
    quantity: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    unit: Mapped[Optional[str]] = mapped_column(String(30), nullable=True)    # GB, minutes, units
    charge_type: Mapped[str] = mapped_column(String(30))                 # recurring, usage, one_time, tax, adjustment, roaming
    service_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    rated_usage_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    dispute_flag: Mapped[bool] = mapped_column(Boolean, default=False)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)


class Device(Base):
    """Customer device (SIM/handset) record."""
    __tablename__ = "devices"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # DEV-001
    customer_id: Mapped[str] = mapped_column(String(50))
    imei: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    model: Mapped[str] = mapped_column(String(100))
    manufacturer: Mapped[str] = mapped_column(String(100))
    os: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)


class PaymentRecord(Base):
    """Payment history for a billing account."""
    __tablename__ = "payment_records"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # PAY-001
    billing_account_id: Mapped[str] = mapped_column(String(50))
    amount: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    payment_date: Mapped[datetime.datetime] = mapped_column(DateTime)
    method: Mapped[str] = mapped_column(String(30))                      # credit_card, bank_transfer, direct_debit
    status: Mapped[str] = mapped_column(String(20), default="success")  # success, failed, pending
    reference: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)


class UsageEvent(Base):
    """Raw usage event (CDR/xDR) from the network layer."""
    __tablename__ = "usage_events"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # UE-001
    customer_id: Mapped[str] = mapped_column(String(50))
    billing_account_id: Mapped[str] = mapped_column(String(50))
    session_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    event_type: Mapped[str] = mapped_column(String(50))                  # data, voice, sms, roaming_data, roaming_voice
    data_volume_bytes: Mapped[Optional[int]] = mapped_column(BigInteger, nullable=True)
    duration_seconds: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    start_time: Mapped[datetime.datetime] = mapped_column(DateTime)
    end_time: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    network_element: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    charging_trigger: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # CHF, CTF, OCS
    billing_period: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


class MediationRecord(Base):
    """Mediation processing record for CDR/xDR through the mediation engine."""
    __tablename__ = "mediation_records"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # MR-001
    usage_event_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    cdr_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="rated")     # raw, processing, rated, error, duplicate
    rating_attempt_count: Mapped[int] = mapped_column(Integer, default=1)
    error_code: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_period: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


class RatedUsage(Base):
    """Rated usage output from the rating engine, linked to a bill."""
    __tablename__ = "rated_usage"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # RU-001
    mediation_record_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    bill_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[str] = mapped_column(String(50))
    amount: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    charge_type: Mapped[str] = mapped_column(String(30))                 # data, voice, sms, roaming, adjustment
    service_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_period: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    rated_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)


class PDUSession(Base):
    """5G PDU session record (from SMF/UPF)."""
    __tablename__ = "pdu_sessions"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # PDU-001
    customer_id: Mapped[str] = mapped_column(String(50))
    billing_account_id: Mapped[str] = mapped_column(String(50))
    session_id: Mapped[str] = mapped_column(String(100))
    upf_node: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    smf_node: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    start_time: Mapped[datetime.datetime] = mapped_column(DateTime)
    end_time: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    data_volume_gb: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(20), default="terminated")  # active, terminated, zombie
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)


class ServiceInventory(Base):
    """Customer service instance (TMF638-inspired)."""
    __tablename__ = "service_inventory"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # SVC-INV-001
    customer_id: Mapped[str] = mapped_column(String(50))
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    service_type: Mapped[str] = mapped_column(String(50))                # voice, data, sms, premium_5g_slice, roaming, iot
    service_id: Mapped[str] = mapped_column(String(100))                 # internal service ID
    status: Mapped[str] = mapped_column(String(20), default="active")   # active, suspended, terminated
    product_offering_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


class NetworkFunction(Base):
    """5G/4G network function instance (UPF, AMF, SMF, PCF, NWDAF, CHF, CTF, CGF, SEPP, NEF)."""
    __tablename__ = "network_functions"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # NF-UPF-EAST-01
    nf_type: Mapped[str] = mapped_column(String(20))                     # UPF, AMF, SMF, PCF, NWDAF, CTF, CHF, CGF, SEPP, NEF
    name: Mapped[str] = mapped_column(String(100))
    host: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    region: Mapped[str] = mapped_column(String(50))
    status: Mapped[str] = mapped_column(String(20), default="active")   # active, degraded, offline
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)


class PartnerAccount(Base):
    """Partner/MVNO/Wholesale account (P7 roaming and wholesale discrepancy)."""
    __tablename__ = "partner_accounts"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # PARTNER-001
    name: Mapped[str] = mapped_column(String(200))
    partner_type: Mapped[str] = mapped_column(String(30))                # MVNO, roaming, wholesale, interconnect
    country_code: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    plmn_id: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)  # e.g. 310-410
    settlement_currency: Mapped[str] = mapped_column(String(10), default="USD")
    status: Mapped[str] = mapped_column(String(20), default="active")
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    settlements: Mapped[List["PartnerSettlement"]] = relationship(back_populates="partner_account")


class PartnerSettlement(Base):
    """Partner/wholesale settlement record showing discrepancy between CSP and partner."""
    __tablename__ = "partner_settlements"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # PS-001
    partner_account_id: Mapped[str] = mapped_column(ForeignKey("partner_accounts.id"))
    billing_period: Mapped[str] = mapped_column(String(20))              # 2026-03
    csp_record_amount: Mapped[float] = mapped_column(Float)
    partner_record_amount: Mapped[float] = mapped_column(Float)
    discrepancy_amount: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    status: Mapped[str] = mapped_column(String(20), default="open")      # open, disputed, resolved, escalated
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)

    partner_account: Mapped["PartnerAccount"] = relationship(back_populates="settlements")


class SimulationRun(Base):
    """L1 simulation run record (Phase 6 — simulation component)."""
    __tablename__ = "simulation_runs"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # SIM-001
    use_case_id: Mapped[str] = mapped_column(String(10))
    run_type: Mapped[str] = mapped_column(String(20))                    # inject, dry_run, reset
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending, running, completed, failed
    is_dry_run: Mapped[bool] = mapped_column(Boolean, default=False)
    action_plan: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    result_summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    completed_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class Appointment(Base):
    """Customer appointment for callback, field visit, or video call (self-service)."""
    __tablename__ = "appointments"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # APPT-001
    customer_id: Mapped[str] = mapped_column(String(50))
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    appointment_type: Mapped[str] = mapped_column(String(30))            # callback, field_visit, video_call
    scheduled_at: Mapped[datetime.datetime] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(20), default="scheduled") # scheduled, completed, cancelled, no_show
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
