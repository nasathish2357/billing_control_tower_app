"""
MVP3 TMF Mock API

Mock implementations of key TMF Open APIs used by the Billing Control Tower.
These are self-contained stubs that return realistic data from the PostgreSQL seed.
They enable demo/testing without connecting to real BSS/OSS/network systems.

TMF specs implemented (simplified):
  TMF620 - Product Catalog Management
  TMF621 - Trouble Ticket Management
  TMF638 - Service Inventory Management
  TMF641 - Service Order Management (simplified — appointment stub)
  TMF656 - Service Problem Management
  TMF678 - Customer Bill Management
  TMF688 - Event Management (notification stubs)
  TMF700 - Audit Management (L1 audit trace proxy)

Routes:
  GET  /mock-tmf/product-catalog/product          — list products
  GET  /mock-tmf/product-catalog/product/{id}     — get product
  GET  /mock-tmf/product-catalog/productOffering   — list offerings
  GET  /mock-tmf/trouble-ticket                   — list trouble tickets
  GET  /mock-tmf/trouble-ticket/{id}              — get ticket
  PATCH /mock-tmf/trouble-ticket/{id}             — update ticket status
  GET  /mock-tmf/service-inventory/service        — list services
  GET  /mock-tmf/service-inventory/service/{id}   — get service
  GET  /mock-tmf/service-problem                  — list service problems
  GET  /mock-tmf/service-problem/{id}             — get service problem
  GET  /mock-tmf/customer-bill                    — list bills
  GET  /mock-tmf/customer-bill/{id}               — get bill
  GET  /mock-tmf/customer-bill/{id}/line-items    — get bill line items
  POST /mock-tmf/hub                              — register notification hub (stub)
  GET  /mock-tmf/event                            — list TMF events
  GET  /mock-tmf/audit-record                     — list audit traces (TMF700 proxy)
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import (
    Product, ProductOffering, TroubleTicket, ServiceInventory,
    ServiceProblem, Bill, BillLineItem, TMFEvent, AuditTrace,
)

logger = logging.getLogger(__name__)
router = APIRouter()


# ── TMF620 — Product Catalog ──────────────────────────────────────────────────

@router.get("/mock-tmf/product-catalog/product")
async def list_products(
    is_active: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
):
    """TMF620: List products from the product catalog."""
    q = select(Product)
    if is_active is not None:
        q = q.where(Product.is_active == is_active)
    result = await db.execute(q)
    products = result.scalars().all()
    return [_product_to_tmf(p) for p in products]


@router.get("/mock-tmf/product-catalog/product/{product_id}")
async def get_product(product_id: str, db: AsyncSession = Depends(get_db)):
    """TMF620: Get a specific product by ID."""
    result = await db.execute(select(Product).where(Product.id == product_id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail=f"Product {product_id} not found")
    return _product_to_tmf(p)


@router.get("/mock-tmf/product-catalog/productOffering")
async def list_product_offerings(
    tier: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """TMF620: List product offerings."""
    q = select(ProductOffering)
    if tier:
        q = q.where(ProductOffering.tier == tier)
    result = await db.execute(q)
    offerings = result.scalars().all()
    return [_offering_to_tmf(o) for o in offerings]


def _product_to_tmf(p: Product) -> dict:
    return {
        "id": p.id,
        "name": p.name,
        "type": p.product_type,
        "isActive": p.is_active,
        "@type": "Product",
        "@schemaLocation": "/mock-tmf/schemas/TMF620",
    }


def _offering_to_tmf(o: ProductOffering) -> dict:
    return {
        "id": o.id,
        "name": o.name,
        "tier": o.tier,
        "monthlyFee": {"amount": o.monthly_fee, "units": o.currency},
        "isActive": o.is_active,
        "@type": "ProductOffering",
        "@schemaLocation": "/mock-tmf/schemas/TMF620",
    }


# ── TMF621 — Trouble Ticket ───────────────────────────────────────────────────

@router.get("/mock-tmf/trouble-ticket")
async def list_trouble_tickets(
    status: Optional[str] = None,
    customer_id: Optional[str] = None,
    limit: int = Query(default=20, le=100),
    db: AsyncSession = Depends(get_db),
):
    """TMF621: List trouble tickets."""
    q = select(TroubleTicket).limit(limit)
    if status:
        q = q.where(TroubleTicket.status == status)
    if customer_id:
        q = q.where(TroubleTicket.customer_id == customer_id)
    result = await db.execute(q)
    tickets = result.scalars().all()
    return [_ticket_to_tmf(t) for t in tickets]


@router.get("/mock-tmf/trouble-ticket/{ticket_id}")
async def get_trouble_ticket(ticket_id: str, db: AsyncSession = Depends(get_db)):
    """TMF621: Get a specific trouble ticket."""
    result = await db.execute(select(TroubleTicket).where(TroubleTicket.id == ticket_id))
    t = result.scalar_one_or_none()
    if not t:
        raise HTTPException(status_code=404, detail=f"TroubleTicket {ticket_id} not found")
    return _ticket_to_tmf(t)


@router.patch("/mock-tmf/trouble-ticket/{ticket_id}")
async def update_trouble_ticket(
    ticket_id: str,
    status: str,
    db: AsyncSession = Depends(get_db),
):
    """TMF621: Update trouble ticket status."""
    result = await db.execute(select(TroubleTicket).where(TroubleTicket.id == ticket_id))
    t = result.scalar_one_or_none()
    if not t:
        raise HTTPException(status_code=404, detail=f"TroubleTicket {ticket_id} not found")
    valid_statuses = {"open", "in_progress", "resolved", "closed", "cancelled"}
    if status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Valid: {valid_statuses}")
    t.status = status
    await db.commit()
    return _ticket_to_tmf(t)


def _ticket_to_tmf(t: TroubleTicket) -> dict:
    return {
        "id": t.id,
        "type": t.ticket_type,
        "status": t.status,
        "priority": t.priority,
        "description": t.description,
        "relatedParty": [{"id": t.customer_id, "role": "Customer"}],
        "relatedEntity": [{"id": t.billing_account_id, "type": "BillingAccount"}],
        "@type": "TroubleTicket",
        "@schemaLocation": "/mock-tmf/schemas/TMF621",
    }


# ── TMF638 — Service Inventory ────────────────────────────────────────────────

@router.get("/mock-tmf/service-inventory/service")
async def list_services(
    customer_id: Optional[str] = None,
    service_type: Optional[str] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """TMF638: List service inventory."""
    q = select(ServiceInventory)
    if customer_id:
        q = q.where(ServiceInventory.customer_id == customer_id)
    if service_type:
        q = q.where(ServiceInventory.service_type == service_type)
    if status:
        q = q.where(ServiceInventory.status == status)
    result = await db.execute(q)
    services = result.scalars().all()
    return [_service_to_tmf(s) for s in services]


@router.get("/mock-tmf/service-inventory/service/{service_id}")
async def get_service(service_id: str, db: AsyncSession = Depends(get_db)):
    """TMF638: Get a specific service from inventory."""
    result = await db.execute(select(ServiceInventory).where(ServiceInventory.id == service_id))
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(status_code=404, detail=f"ServiceInventory {service_id} not found")
    return _service_to_tmf(s)


def _service_to_tmf(s: ServiceInventory) -> dict:
    return {
        "id": s.id,
        "serviceId": s.service_id,
        "serviceType": s.service_type,
        "status": s.status,
        "relatedParty": [{"id": s.customer_id, "role": "Customer"}],
        "billingAccount": {"id": s.billing_account_id} if s.billing_account_id else None,
        "productOffering": {"id": s.product_offering_id} if s.product_offering_id else None,
        "@type": "Service",
        "@schemaLocation": "/mock-tmf/schemas/TMF638",
    }


# ── TMF656 — Service Problem ──────────────────────────────────────────────────

@router.get("/mock-tmf/service-problem")
async def list_service_problems(
    status: Optional[str] = None,
    sla_breach: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
):
    """TMF656: List service problems."""
    q = select(ServiceProblem)
    if status:
        q = q.where(ServiceProblem.status == status)
    if sla_breach is not None:
        q = q.where(ServiceProblem.sla_breach == sla_breach)
    result = await db.execute(q)
    problems = result.scalars().all()
    return [_problem_to_tmf(p) for p in problems]


@router.get("/mock-tmf/service-problem/{problem_id}")
async def get_service_problem(problem_id: str, db: AsyncSession = Depends(get_db)):
    """TMF656: Get a specific service problem."""
    result = await db.execute(select(ServiceProblem).where(ServiceProblem.id == problem_id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail=f"ServiceProblem {problem_id} not found")
    return _problem_to_tmf(p)


def _problem_to_tmf(p: ServiceProblem) -> dict:
    return {
        "id": p.id,
        "problemType": p.problem_type,
        "status": p.status,
        "severity": p.severity,
        "slaBreach": p.sla_breach,
        "description": p.description,
        "affectedPeriodStart": p.affected_period_start.isoformat() if p.affected_period_start else None,
        "affectedPeriodEnd": p.affected_period_end.isoformat() if p.affected_period_end else None,
        "relatedIssue": {"id": p.issue_id} if p.issue_id else None,
        "@type": "ServiceProblem",
        "@schemaLocation": "/mock-tmf/schemas/TMF656",
    }


# ── TMF678 — Customer Bill ────────────────────────────────────────────────────

@router.get("/mock-tmf/customer-bill")
async def list_customer_bills(
    billing_account_id: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = Query(default=20, le=100),
    db: AsyncSession = Depends(get_db),
):
    """TMF678: List customer bills."""
    q = select(Bill).limit(limit)
    if billing_account_id:
        q = q.where(Bill.billing_account_id == billing_account_id)
    if status:
        q = q.where(Bill.status == status)
    result = await db.execute(q.order_by(Bill.billing_period.desc()))
    bills = result.scalars().all()
    return [_bill_to_tmf(b) for b in bills]


@router.get("/mock-tmf/customer-bill/{bill_id}")
async def get_customer_bill(bill_id: str, db: AsyncSession = Depends(get_db)):
    """TMF678: Get a specific customer bill."""
    result = await db.execute(select(Bill).where(Bill.id == bill_id))
    b = result.scalar_one_or_none()
    if not b:
        raise HTTPException(status_code=404, detail=f"Bill {bill_id} not found")
    return _bill_to_tmf(b)


@router.get("/mock-tmf/customer-bill/{bill_id}/line-items")
async def get_bill_line_items(bill_id: str, db: AsyncSession = Depends(get_db)):
    """TMF678: Get line items for a specific bill."""
    result = await db.execute(select(BillLineItem).where(BillLineItem.bill_id == bill_id))
    items = result.scalars().all()
    return {
        "billId": bill_id,
        "lineItems": [_line_item_to_tmf(i) for i in items],
        "count": len(items),
        "@type": "BillItemCollection",
    }


def _bill_to_tmf(b: Bill) -> dict:
    return {
        "id": b.id,
        "billingPeriod": b.billing_period,
        "amountDue": {"amount": b.amount_due, "units": "USD"},
        "previousAmount": {"amount": b.previous_amount, "units": "USD"} if b.previous_amount else None,
        "dueDate": b.due_date.isoformat() if b.due_date else None,
        "status": b.status,
        "billingAccount": {"id": b.billing_account_id},
        "@type": "CustomerBill",
        "@schemaLocation": "/mock-tmf/schemas/TMF678",
    }


def _line_item_to_tmf(i: BillLineItem) -> dict:
    return {
        "id": i.id,
        "description": i.description,
        "amount": {"amount": i.amount, "units": "USD"},
        "chargeType": i.charge_type,
        "quantity": i.quantity,
        "unit": i.unit,
        "disputeFlag": i.dispute_flag,
        "ratedUsageId": i.rated_usage_id,
        "@type": "BillItem",
    }


# ── TMF688 — Event Management ─────────────────────────────────────────────────

@router.get("/mock-tmf/event")
async def list_tmf_events(
    event_type: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = Query(default=20, le=100),
    db: AsyncSession = Depends(get_db),
):
    """TMF688: List TMF events."""
    q = select(TMFEvent).limit(limit).order_by(TMFEvent.created_at.desc())
    if event_type:
        q = q.where(TMFEvent.event_type == event_type)
    if status:
        q = q.where(TMFEvent.status == status)
    result = await db.execute(q)
    events = result.scalars().all()
    return [_event_to_tmf(e) for e in events]


@router.post("/mock-tmf/hub")
async def register_hub(callback_url: str, query: Optional[str] = None):
    """TMF688: Register a notification hub (stub — returns dummy hub ID)."""
    import uuid
    hub_id = str(uuid.uuid4())
    logger.info("TMF Hub registration stub: callback=%s query=%s hub_id=%s", callback_url, query, hub_id)
    return {
        "id": hub_id,
        "callback": callback_url,
        "query": query,
        "@type": "Hub",
        "note": "This is a mock hub — no actual notifications will be sent.",
    }


def _event_to_tmf(e: TMFEvent) -> dict:
    return {
        "id": e.id,
        "eventType": e.event_type,
        "status": e.status,
        "useCaseId": e.use_case_id,
        "relatedIssue": {"id": e.issue_id} if e.issue_id else None,
        "controlCase": {"id": e.control_case_id} if e.control_case_id else None,
        "createdAt": e.created_at.isoformat() if e.created_at else None,
        "@type": "Event",
        "@schemaLocation": "/mock-tmf/schemas/TMF688",
    }


# ── TMF700 Proxy — Audit Records ──────────────────────────────────────────────

@router.get("/mock-tmf/audit-record")
async def list_audit_records(
    control_case_id: Optional[str] = None,
    action_type: Optional[str] = None,
    limit: int = Query(default=20, le=100),
    db: AsyncSession = Depends(get_db),
):
    """TMF700 proxy: List audit traces as TMF audit records."""
    q = select(AuditTrace).limit(limit).order_by(AuditTrace.created_at.desc())
    if control_case_id:
        q = q.where(AuditTrace.control_case_id == control_case_id)
    if action_type:
        q = q.where(AuditTrace.action_type == action_type)
    result = await db.execute(q)
    traces = result.scalars().all()
    return [_audit_to_tmf(t) for t in traces]


def _audit_to_tmf(t: AuditTrace) -> dict:
    return {
        "id": t.id,
        "actionType": t.action_type,
        "actor": t.actor,
        "summary": t.summary,
        "controlCase": {"id": t.control_case_id},
        "details": t.details,
        "createdAt": t.created_at.isoformat() if t.created_at else None,
        "@type": "AuditRecord",
        "@schemaLocation": "/mock-tmf/schemas/TMF700",
    }