"""
MVP2 Approvals API

Routes:
  GET  /approvals/pending                    — list pending approvals
  GET  /approvals/{approval_id}              — get approval
  POST /approvals/{approval_id}/approve      — approve
  POST /approvals/{approval_id}/reject       — reject
  POST /issues/{issue_id}/remediate/resume   — resume graph after approval decision
"""
import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.agents.approval_manager import (
    get_pending_approvals, get_approval, decide_approval, resume_graph,
)
from app.api.v1.schemas import ApprovalOut

logger = logging.getLogger(__name__)
router = APIRouter()


class ApprovalActionBody(BaseModel):
    notes: Optional[str] = None
    approver_id: Optional[str] = None    # e.g. "USER-001" or employee ID
    approver_name: Optional[str] = None  # display name of the approver
    reason_code: Optional[str] = None    # e.g. "POLICY_EXCEPTION", "WITHIN_AUTHORITY"


@router.get("/approvals/pending", response_model=List[ApprovalOut])
async def list_pending_approvals(db: AsyncSession = Depends(get_db)):
    """List all pending human approvals."""
    return await get_pending_approvals(db)


@router.get("/approvals/{approval_id}", response_model=ApprovalOut)
async def get_approval_detail(approval_id: str, db: AsyncSession = Depends(get_db)):
    """Get a specific approval record."""
    approval = await get_approval(db, approval_id)
    if not approval:
        raise HTTPException(status_code=404, detail=f"Approval {approval_id} not found")
    return approval


@router.post("/approvals/{approval_id}/approve")
async def approve_action(
    approval_id: str,
    body: ApprovalActionBody = ApprovalActionBody(),
    db: AsyncSession = Depends(get_db),
):
    """Approve a pending high-risk action. Supports approver metadata and reason codes."""
    # Build enhanced notes string with approver metadata
    notes_parts = []
    if body.approver_id:
        notes_parts.append(f"approver_id={body.approver_id}")
    if body.approver_name:
        notes_parts.append(f"approver={body.approver_name}")
    if body.reason_code:
        notes_parts.append(f"reason={body.reason_code}")
    if body.notes:
        notes_parts.append(body.notes)
    full_notes = " | ".join(notes_parts) if notes_parts else None

    result = await decide_approval(db, approval_id, approved=True, notes=full_notes)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/approvals/{approval_id}/reject")
async def reject_action(
    approval_id: str,
    body: ApprovalActionBody = ApprovalActionBody(),
    db: AsyncSession = Depends(get_db),
):
    """Reject a pending high-risk action. Requires reason_code for audit trail."""
    notes_parts = []
    if body.approver_id:
        notes_parts.append(f"approver_id={body.approver_id}")
    if body.approver_name:
        notes_parts.append(f"approver={body.approver_name}")
    if body.reason_code:
        notes_parts.append(f"reason={body.reason_code}")
    if body.notes:
        notes_parts.append(body.notes)
    full_notes = " | ".join(notes_parts) if notes_parts else None

    result = await decide_approval(db, approval_id, approved=False, notes=full_notes)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/issues/{issue_id}/remediate/resume")
async def resume_remediation(issue_id: str, db: AsyncSession = Depends(get_db)):
    """
    Resume a checkpointed remediation graph for the given issue.
    Finds the most recent decided (approved/rejected) approval for this issue
    and resumes the graph from its thread_id.
    """
    from sqlalchemy import select
    from app.models.models import Approval
    from app.agents.checkpoint_setup import get_checkpointer

    # Find latest decided approval for this issue
    result = await db.execute(
        select(Approval)
        .where(Approval.issue_id == issue_id, Approval.status.in_(["approved", "rejected"]))
        .order_by(Approval.decided_at.desc())
        .limit(1)
    )
    approval = result.scalar_one_or_none()
    if not approval:
        raise HTTPException(
            status_code=404,
            detail=f"No decided approval found for issue {issue_id}. Approve or reject first.",
        )

    checkpointer = get_checkpointer()
    approved = approval.status == "approved"

    # Route to the correct graph based on use_case — derive from issue
    from app.models.models import Issue
    issue_result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = issue_result.scalar_one_or_none()
    if not issue:
        raise HTTPException(status_code=404, detail=f"Issue {issue_id} not found")

    use_case_id = issue.use_case_id
    _graph_map = {
        "P1": ("app.agents.p1_graph", "get_p1_graph"),
        "P4": ("app.agents.p4_graph", "get_p4_graph"),
        "P5": ("app.agents.p5_graph", "get_p5_graph"),
        "P6": ("app.agents.p6_graph", "get_p6_graph"),
        "P7": ("app.agents.p7_graph", "get_p7_graph"),
        "P9": ("app.agents.p9_graph", "get_p9_graph"),
        "P10": ("app.agents.p10_graph", "get_p10_graph"),
    }
    if use_case_id not in _graph_map:
        raise HTTPException(
            status_code=400,
            detail=f"Resume not supported for use case {use_case_id} (no approval interrupt).",
        )
    import importlib
    mod_path, fn_name = _graph_map[use_case_id]
    mod = importlib.import_module(mod_path)
    graph = getattr(mod, fn_name)(checkpointer)

    result = await resume_graph(approval.thread_id, approved, graph, checkpointer)
    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])
    return result
