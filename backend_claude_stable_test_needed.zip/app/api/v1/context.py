"""
MVP2 Context API

Routes:
  GET /customers/{customer_id}/billing-context
  GET /billing-accounts/{billing_account_id}/bill-comparison
  GET /control-cases/{control_case_id}/evidence
"""
import logging
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.db.database import get_db
from app.models.models import (
    Customer, BillingAccount, Bill, Issue, ControlCase, EvidencePack,
)
from app.api.v1.schemas import BillingContextOut, BillComparisonOut, EvidencePackOut

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/customers/{customer_id}/billing-context", response_model=BillingContextOut)
async def get_billing_context(customer_id: str, db: AsyncSession = Depends(get_db)):
    """
    Return full billing context for a customer:
    Customer → BillingAccounts → recent Bills → open Issues.
    """
    result = await db.execute(select(Customer).where(Customer.id == customer_id))
    customer = result.scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=404, detail=f"Customer {customer_id} not found")

    # Billing accounts
    ba_result = await db.execute(
        select(BillingAccount).where(BillingAccount.customer_id == customer_id)
    )
    billing_accounts = ba_result.scalars().all()
    ba_ids = [ba.id for ba in billing_accounts]

    # Bills (last 3 per account)
    bills = []
    if ba_ids:
        bill_result = await db.execute(
            select(Bill)
            .where(Bill.billing_account_id.in_(ba_ids))
            .order_by(Bill.billing_period.desc())
            .limit(9)
        )
        bills = bill_result.scalars().all()

    # Open issues
    issue_result = await db.execute(
        select(Issue)
        .where(Issue.customer_id == customer_id, Issue.status.in_(["open", "investigating"]))
    )
    issues = issue_result.scalars().all()

    return {
        "customer_id": customer_id,
        "customer_name": customer.name,
        "segment": customer.segment,
        "billing_accounts": [
            {"id": ba.id, "currency": ba.currency, "status": ba.status}
            for ba in billing_accounts
        ],
        "recent_bills": [
            {
                "id": b.id, "billing_account_id": b.billing_account_id,
                "billing_period": b.billing_period, "amount_due": b.amount_due,
                "status": b.status,
            }
            for b in bills
        ],
        "open_issues": [
            {"id": i.id, "use_case_id": i.use_case_id, "status": i.status, "description": i.description[:100]}
            for i in issues
        ],
    }


@router.get("/billing-accounts/{billing_account_id}/bill-comparison", response_model=BillComparisonOut)
async def bill_comparison(billing_account_id: str, db: AsyncSession = Depends(get_db)):
    """
    Compare the latest bill against the previous bill for a billing account.
    """
    result = await db.execute(
        select(Bill)
        .where(Bill.billing_account_id == billing_account_id)
        .order_by(Bill.billing_period.desc())
        .limit(2)
    )
    bills = result.scalars().all()

    if not bills:
        raise HTTPException(status_code=404, detail=f"No bills found for {billing_account_id}")

    current = bills[0]
    previous = bills[1] if len(bills) > 1 else None

    delta = None
    delta_pct = None
    if previous:
        delta = round(current.amount_due - previous.amount_due, 2)
        if previous.amount_due > 0:
            delta_pct = round((delta / previous.amount_due) * 100, 1)

    return {
        "billing_account_id": billing_account_id,
        "current_bill": {
            "id": current.id, "period": current.billing_period,
            "amount_due": current.amount_due, "status": current.status,
        },
        "previous_bill": {
            "id": previous.id, "period": previous.billing_period,
            "amount_due": previous.amount_due, "status": previous.status,
        } if previous else None,
        "delta_amount": delta,
        "delta_pct": delta_pct,
        "comparison_summary": (
            f"Current bill (${current.amount_due:.2f}) is "
            f"{'up' if (delta or 0) > 0 else 'down'} "
            f"${abs(delta or 0):.2f} ({delta_pct or 0:+.1f}%) "
            f"vs previous (${previous.amount_due:.2f})."
            if previous else f"Only one bill available for {billing_account_id}."
        ),
    }


@router.get("/control-cases/{control_case_id}/evidence", response_model=List[EvidencePackOut])
async def get_evidence(control_case_id: str, db: AsyncSession = Depends(get_db)):
    """Return all evidence packs for a control case."""
    cc_result = await db.execute(select(ControlCase).where(ControlCase.id == control_case_id))
    cc = cc_result.scalar_one_or_none()
    if not cc:
        raise HTTPException(status_code=404, detail=f"Control case {control_case_id} not found")

    result = await db.execute(
        select(EvidencePack)
        .where(EvidencePack.control_case_id == control_case_id)
        .order_by(EvidencePack.created_at)
    )
    return result.scalars().all()
