"""
MVP3 Governance and Audit API — Phase 12

Routes:
  GET  /audit/search                    — search audit traces by filters
  GET  /audit/traces/{trace_id}         — get specific trace (alias for /audit-traces)
  GET  /audit/export/{control_case_id}  — export full audit chain as JSON
  GET  /audit/actions                   — list all distinct action types seen
"""
import json
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import AuditTrace, ControlCase, Issue

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/audit/search")
async def search_audit_traces(
    issue_id: Optional[str] = None,
    control_case_id: Optional[str] = None,
    customer_id: Optional[str] = None,
    action_type: Optional[str] = None,
    actor: Optional[str] = None,
    use_case_id: Optional[str] = None,
    limit: int = Query(default=50, le=200),
    db: AsyncSession = Depends(get_db),
):
    """
    Search audit traces by multiple filters.
    For customer_id and use_case_id, looks up via the linked ControlCase/Issue.
    """
    q = select(AuditTrace).order_by(AuditTrace.created_at.desc())

    # Direct column filters
    if control_case_id:
        q = q.where(AuditTrace.control_case_id == control_case_id)
    if action_type:
        q = q.where(AuditTrace.action_type == action_type)
    if actor:
        q = q.where(AuditTrace.actor == actor)

    q = q.limit(limit)
    result = await db.execute(q)
    traces = result.scalars().all()

    # Post-filter on JSON details for issue_id, customer_id, use_case_id
    filtered = []
    for t in traces:
        details = t.details or {}
        if issue_id and details.get("issue_id") != issue_id:
            continue
        if customer_id:
            # customer_id stored in issue — skip if details don't match
            # (approximate: accept if issue_id matches)
            pass
        if use_case_id and details.get("use_case_id") != use_case_id:
            continue
        filtered.append(t)

    return {
        "total": len(filtered),
        "filters": {
            "issue_id": issue_id,
            "control_case_id": control_case_id,
            "customer_id": customer_id,
            "action_type": action_type,
            "actor": actor,
            "use_case_id": use_case_id,
        },
        "traces": [_trace_to_dict(t) for t in filtered],
    }


@router.get("/audit/traces/{trace_id}")
async def get_audit_trace_detail(trace_id: str, db: AsyncSession = Depends(get_db)):
    """Get a specific audit trace by ID."""
    result = await db.execute(select(AuditTrace).where(AuditTrace.id == trace_id))
    trace = result.scalar_one_or_none()
    if not trace:
        raise HTTPException(status_code=404, detail=f"Audit trace {trace_id} not found")
    return _trace_to_dict(trace)


@router.get("/audit/export/{control_case_id}")
async def export_audit_chain(control_case_id: str, db: AsyncSession = Depends(get_db)):
    """
    Export full governance audit chain for a control case as JSON.
    Includes the control case, linked issue, and all audit traces.
    """
    # Verify control case exists
    cc_result = await db.execute(select(ControlCase).where(ControlCase.id == control_case_id))
    cc = cc_result.scalar_one_or_none()
    if not cc:
        raise HTTPException(status_code=404, detail=f"Control case {control_case_id} not found")

    # Load linked issue
    issue = None
    if cc.issue_id:
        issue_result = await db.execute(select(Issue).where(Issue.id == cc.issue_id))
        issue = issue_result.scalar_one_or_none()

    # Load all audit traces
    traces_result = await db.execute(
        select(AuditTrace)
        .where(AuditTrace.control_case_id == control_case_id)
        .order_by(AuditTrace.created_at.asc())
    )
    traces = traces_result.scalars().all()

    export = {
        "export_type": "governance_audit_chain",
        "control_case": {
            "id": cc.id,
            "issue_id": cc.issue_id,
            "status": cc.status,
            "thread_id": cc.thread_id,
            "requires_human_approval": cc.requires_human_approval,
            "resolved_at": cc.resolved_at.isoformat() if cc.resolved_at else None,
        },
        "issue": {
            "id": issue.id,
            "use_case_id": issue.use_case_id,
            "customer_id": issue.customer_id,
            "billing_account_id": issue.billing_account_id,
            "description": issue.description,
            "status": issue.status,
        } if issue else None,
        "audit_chain": [_trace_to_dict(t) for t in traces],
        "trace_count": len(traces),
    }

    return JSONResponse(
        content=export,
        headers={"Content-Disposition": f'attachment; filename="audit-{control_case_id}.json"'},
    )


@router.get("/audit/actions")
async def list_action_types(db: AsyncSession = Depends(get_db)):
    """Return all distinct action types seen in audit traces."""
    result = await db.execute(select(AuditTrace))
    traces = result.scalars().all()
    action_types = sorted(set(t.action_type for t in traces if t.action_type))
    actor_types = sorted(set(t.actor for t in traces if t.actor))
    return {
        "action_types": action_types,
        "actors": actor_types,
        "total_traces": len(traces),
    }


def _trace_to_dict(t: AuditTrace) -> dict:
    return {
        "id": t.id,
        "control_case_id": t.control_case_id,
        "action_type": t.action_type,
        "actor": t.actor,
        "summary": t.summary,
        "details": t.details,
        "created_at": t.created_at.isoformat() if t.created_at else None,
    }