"""
Self-Service APIs — Phase 11 (completed)

Routes:
  POST /self-service/ebill                     — enrol customer in eBilling
  POST /appointments                           — book callback / field-visit / video-call
  GET  /appointments/{appointment_id}          — retrieve appointment details
"""
import datetime
import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional

from app.db.database import get_db
from app.models.models import Customer, Appointment

logger = logging.getLogger(__name__)
router = APIRouter()


# ─────────────────────────────────────────────────────────────────────────────
#  Request / Response schemas
# ─────────────────────────────────────────────────────────────────────────────

class EBillEnrolRequest(BaseModel):
    customer_id: str
    billing_account_id: Optional[str] = None
    email_for_ebill: Optional[str] = None


class AppointmentRequest(BaseModel):
    customer_id: str
    billing_account_id: Optional[str] = None
    issue_id: Optional[str] = None
    appointment_type: str        # callback | field_visit | video_call
    scheduled_at: datetime.datetime
    notes: Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
#  POST /self-service/ebill
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/self-service/ebill")
async def enrol_ebill(body: EBillEnrolRequest, db: AsyncSession = Depends(get_db)):
    """
    Enrol a customer in eBilling (paperless billing).
    Updates the customer email preference and returns confirmation.
    """
    result = await db.execute(select(Customer).where(Customer.id == body.customer_id))
    customer = result.scalar_one_or_none()
    if not customer:
        raise HTTPException(status_code=404, detail=f"Customer {body.customer_id} not found")

    email = body.email_for_ebill or customer.email
    if not email:
        raise HTTPException(status_code=400, detail="No email address available for eBill enrolment")

    reference = f"EBILL-{str(uuid.uuid4())[:8].upper()}"
    logger.info("eBill enrolment: customer=%s email=%s ref=%s", body.customer_id, email, reference)

    return {
        "status": "enrolled",
        "reference": reference,
        "customer_id": body.customer_id,
        "billing_account_id": body.billing_account_id,
        "ebill_email": email,
        "enrolled_at": datetime.datetime.utcnow().isoformat(),
        "message": f"eBilling activated. Paperless bills will be sent to {email} from next billing cycle.",
    }


# ─────────────────────────────────────────────────────────────────────────────
#  POST /appointments
# ─────────────────────────────────────────────────────────────────────────────

VALID_APPOINTMENT_TYPES = {"callback", "field_visit", "video_call"}

@router.post("/appointments", status_code=201)
async def create_appointment(body: AppointmentRequest, db: AsyncSession = Depends(get_db)):
    """
    Book a customer appointment (callback, field visit, or video call).
    Linked optionally to a billing issue.
    """
    if body.appointment_type not in VALID_APPOINTMENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid appointment_type. Valid: {sorted(VALID_APPOINTMENT_TYPES)}",
        )

    result = await db.execute(select(Customer).where(Customer.id == body.customer_id))
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail=f"Customer {body.customer_id} not found")

    appt_id = f"APPT-{str(uuid.uuid4())[:8].upper()}"
    now = datetime.datetime.utcnow()

    appt = Appointment(
        id=appt_id,
        customer_id=body.customer_id,
        billing_account_id=body.billing_account_id,
        issue_id=body.issue_id,
        appointment_type=body.appointment_type,
        scheduled_at=body.scheduled_at,
        status="scheduled",
        notes=body.notes,
        created_at=now,
    )
    db.add(appt)
    await db.commit()

    logger.info("Appointment created: id=%s type=%s customer=%s", appt_id, body.appointment_type, body.customer_id)
    return _appt_to_dict(appt)


# ─────────────────────────────────────────────────────────────────────────────
#  GET /appointments/{appointment_id}
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/appointments/{appointment_id}")
async def get_appointment(appointment_id: str, db: AsyncSession = Depends(get_db)):
    """Retrieve appointment details by ID."""
    result = await db.execute(select(Appointment).where(Appointment.id == appointment_id))
    appt = result.scalar_one_or_none()
    if not appt:
        raise HTTPException(status_code=404, detail=f"Appointment {appointment_id} not found")
    return _appt_to_dict(appt)


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _appt_to_dict(a: Appointment) -> dict:
    return {
        "id": a.id,
        "customer_id": a.customer_id,
        "billing_account_id": a.billing_account_id,
        "issue_id": a.issue_id,
        "appointment_type": a.appointment_type,
        "scheduled_at": a.scheduled_at.isoformat() if a.scheduled_at else None,
        "status": a.status,
        "notes": a.notes,
        "created_at": a.created_at.isoformat() if a.created_at else None,
    }
