"""
MVP3 Simulation API

Routes:
  GET   /simulation/types                          — list available simulation types
  POST  /simulation/inject                         — inject a billing anomaly scenario
  POST  /simulation/inject?dry_run=true            — preview what would be created
  GET   /simulation/status/{simulation_id}         — status of a specific simulation
  GET   /simulation/active                         — list all active simulations
  POST  /simulation/reset                          — reset all simulation data
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.components.l1_simulation import (
    inject_simulation, get_simulation_status, reset_simulations,
    list_active_simulations, SIMULATION_TYPES, SIMULATION_USE_CASE_MAP,
)

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/simulation/types")
async def list_simulation_types():
    """Return all available simulation types and their corresponding use cases."""
    return {
        "simulation_types": [
            {
                "type": t,
                "use_case_id": SIMULATION_USE_CASE_MAP[t],
                "description": _TYPE_DESCRIPTIONS.get(t, ""),
            }
            for t in SIMULATION_TYPES
        ]
    }


@router.post("/simulation/inject")
async def inject_scenario(
    simulation_type: str,
    customer_id: str = "CUST-100001",
    billing_account_id: str = "BA-100001",
    dry_run: bool = Query(default=False, description="Preview without writing to DB"),
    db: AsyncSession = Depends(get_db),
):
    """
    Inject a billing anomaly scenario into the system.
    Creates the necessary data artifacts (UsageEvent, PDUSession, Issue, etc.)
    and returns the issue_id to trigger remediation with.

    Set dry_run=true to preview what would be created without writing to DB.
    """
    result = await inject_simulation(
        db,
        simulation_type=simulation_type,
        customer_id=customer_id,
        billing_account_id=billing_account_id,
        dry_run=dry_run,
    )
    if "error" in result:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.get("/simulation/status/{simulation_id}")
async def get_status(simulation_id: str):
    """Return the status of an active simulation by ID."""
    return await get_simulation_status(simulation_id)


@router.get("/simulation/active")
async def list_active():
    """Return all simulations currently active in this session."""
    sims = list_active_simulations()
    return {
        "active_simulation_count": len(sims),
        "simulations": sims,
    }


@router.post("/simulation/reset")
async def reset_all(db: AsyncSession = Depends(get_db)):
    """
    Reset all simulation-created records.
    Removes Issues, UsageEvents, PDUSessions, and MediationRecords created by simulations.
    """
    result = await reset_simulations(db)
    return result


_TYPE_DESCRIPTIONS = {
    "duplicate_charge": "Injects a duplicate 2GB data usage event — triggers P2 Duplicate Charging flow.",
    "zombie_pdu_session": "Injects a zombie PDU session accruing charges after disconnect — triggers P3 flow.",
    "usage_delay": "Injects a mediation record stuck in CDR_COLLECTION — triggers P1 Missing Usage Feed flow.",
    "qos_mismatch": "Injects a QoS mismatch issue (premium 5G charged but 4G delivered) — triggers P4 flow.",
    "sla_breach": "Injects a service degradation / outage issue — triggers P5 SLA Compensation flow.",
    "partner_discrepancy": "Injects a partner/MVNO settlement discrepancy — triggers P7 Partner flow.",
    "proactive_risk": "Injects an anomalous 50GB usage spike — triggers P9 Proactive Risk Monitoring flow.",
}