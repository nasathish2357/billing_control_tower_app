"""
MVP3 Dashboard APIs

Routes:
  GET /dashboard/summary          — system-wide KPIs
  GET /dashboard/prebill-risks    — accounts with high pre-bill risk
  GET /dashboard/postbill-disputes — active billing disputes
  GET /dashboard/layer-health     — L1/L2/L3/L4 component health
  GET /dashboard/audit-summary    — recent audit trace summary
"""
import logging

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import (
    Issue, ControlCase, AuditTrace, Approval,
    Bill, BillingAccount, TroubleTicket, ServiceProblem,
    NetworkFunction,
)

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/dashboard/summary")
async def get_dashboard_summary(db: AsyncSession = Depends(get_db)):
    """
    Return system-wide KPIs for the Billing Control Tower dashboard.
    Includes issue counts, remediation rates, approval queue, and financial exposure.
    """
    # Issue counts by status
    issues_result = await db.execute(select(Issue))
    all_issues = issues_result.scalars().all()
    open_issues = [i for i in all_issues if i.status == "open"]
    remediated_issues = [i for i in all_issues if i.status == "remediated"]
    partial_issues = [i for i in all_issues if i.status == "partial_remediation"]

    # Issue counts by use case
    use_case_counts: dict = {}
    for i in all_issues:
        use_case_counts[i.use_case_id] = use_case_counts.get(i.use_case_id, 0) + 1

    # Control cases
    cc_result = await db.execute(select(ControlCase))
    all_cases = cc_result.scalars().all()
    active_cases = [c for c in all_cases if c.status not in ("closed", "resolved")]

    # Approval queue
    appr_result = await db.execute(
        select(Approval).where(Approval.status == "pending")
    )
    pending_approvals = appr_result.scalars().all()

    # Financial exposure (disputed bills)
    disputed_result = await db.execute(
        select(Bill).where(Bill.status == "Disputed")
    )
    disputed_bills = disputed_result.scalars().all()
    total_disputed_usd = sum(b.amount_due for b in disputed_bills)

    # Trouble tickets
    tt_result = await db.execute(
        select(TroubleTicket).where(TroubleTicket.status.in_(["open", "in_progress"]))
    )
    open_tickets = tt_result.scalars().all()

    remediation_rate = (
        round(len(remediated_issues) / len(all_issues) * 100, 1)
        if all_issues else 0.0
    )

    return {
        "issues": {
            "total": len(all_issues),
            "open": len(open_issues),
            "remediated": len(remediated_issues),
            "partial": len(partial_issues),
            "remediation_rate_pct": remediation_rate,
            "by_use_case": use_case_counts,
        },
        "control_cases": {
            "total": len(all_cases),
            "active": len(active_cases),
        },
        "approvals": {
            "pending": len(pending_approvals),
            "pending_ids": [a.id for a in pending_approvals],
        },
        "financial_exposure": {
            "disputed_bills": len(disputed_bills),
            "total_disputed_usd": round(total_disputed_usd, 2),
        },
        "tickets": {
            "open_count": len(open_tickets),
        },
    }


@router.get("/dashboard/prebill-risks")
async def get_prebill_risks(
    min_risk_score: int = Query(default=15, description="Minimum risk score (0-100)"),
    db: AsyncSession = Depends(get_db),
):
    """
    Return billing accounts with pre-bill risk signals above the threshold.
    Uses the L1 Proactive Risk Scorer.
    """
    try:
        from app.components.l1_proactive_risk import get_high_risk_accounts
        high_risk = await get_high_risk_accounts(db, threshold=min_risk_score)
        return {
            "prebill_risk_accounts": len(high_risk),
            "min_risk_score_filter": min_risk_score,
            "accounts": high_risk,
        }
    except Exception as e:
        logger.warning("Pre-bill risk scan failed: %s", e)
        return {"prebill_risk_accounts": 0, "accounts": [], "error": str(e)}


@router.get("/dashboard/postbill-disputes")
async def get_postbill_disputes(db: AsyncSession = Depends(get_db)):
    """
    Return active post-bill disputes with associated control case and customer info.
    """
    disputed_result = await db.execute(
        select(Bill).where(Bill.status == "Disputed")
    )
    disputed_bills = disputed_result.scalars().all()

    disputes = []
    for bill in disputed_bills:
        # Find associated issue
        issue_result = await db.execute(
            select(Issue).where(Issue.bill_id == bill.id).limit(1)
        )
        issue = issue_result.scalar_one_or_none()

        # Find control case
        cc = None
        if issue:
            cc_result = await db.execute(
                select(ControlCase).where(ControlCase.issue_id == issue.id).limit(1)
            )
            cc = cc_result.scalar_one_or_none()

        disputes.append({
            "bill_id": bill.id,
            "billing_period": bill.billing_period,
            "billing_account_id": bill.billing_account_id,
            "amount_due": bill.amount_due,
            "status": bill.status,
            "issue_id": issue.id if issue else None,
            "use_case_id": issue.use_case_id if issue else None,
            "control_case_id": cc.id if cc else None,
            "control_case_status": cc.status if cc else None,
        })

    total_exposure = sum(d["amount_due"] for d in disputes)
    return {
        "dispute_count": len(disputes),
        "total_exposure_usd": round(total_exposure, 2),
        "disputes": disputes,
    }


@router.get("/dashboard/layer-health")
async def get_layer_health(db: AsyncSession = Depends(get_db)):
    """
    Return health status for each owner layer (L1–L4) and key components.
    """
    # L4 Network Function health
    nf_result = await db.execute(select(NetworkFunction))
    nfs = nf_result.scalars().all()
    nf_health: dict = {}
    for nf in nfs:
        nf_type = nf.nf_type
        if nf_type not in nf_health:
            nf_health[nf_type] = {"active": 0, "degraded": 0, "offline": 0}
        status_key = nf.status if nf.status in nf_health[nf_type] else "offline"
        nf_health[nf_type][status_key] += 1

    all_nf_active = all(
        counts["degraded"] == 0 and counts["offline"] == 0
        for counts in nf_health.values()
    )

    # L3 Service Problem count
    sp_result = await db.execute(
        select(ServiceProblem).where(ServiceProblem.status.in_(["open", "investigating"]))
    )
    open_sps = sp_result.scalars().all()

    # L2 Trouble Ticket count
    tt_result = await db.execute(
        select(TroubleTicket).where(TroubleTicket.status.in_(["open", "in_progress"]))
    )
    open_tts = tt_result.scalars().all()

    # L1 Pending approvals
    appr_result = await db.execute(
        select(Approval).where(Approval.status == "pending")
    )
    pending_approvals = appr_result.scalars().all()

    return {
        "L1": {
            "status": "healthy",
            "pending_approvals": len(pending_approvals),
            "approval_ids": [a.id for a in pending_approvals],
        },
        "L2": {
            "status": "healthy" if len(open_tts) < 10 else "busy",
            "open_trouble_tickets": len(open_tts),
        },
        "L3": {
            "status": "healthy" if not any(s.sla_breach for s in open_sps) else "sla_breach_active",
            "open_service_problems": len(open_sps),
            "sla_breach_active": any(s.sla_breach for s in open_sps),
        },
        "L4": {
            "status": "healthy" if all_nf_active else "degraded",
            "network_functions": nf_health,
        },
    }


@router.get("/dashboard/audit-summary")
async def get_audit_summary(
    limit: int = Query(default=10, le=50),
    db: AsyncSession = Depends(get_db),
):
    """
    Return a summary of recent governance audit traces.
    """
    result = await db.execute(
        select(AuditTrace)
        .order_by(AuditTrace.created_at.desc())
        .limit(limit)
    )
    traces = result.scalars().all()

    # Count by action type
    action_type_counts: dict = {}
    for t in traces:
        action_type_counts[t.action_type] = action_type_counts.get(t.action_type, 0) + 1

    return {
        "recent_audit_count": len(traces),
        "by_action_type": action_type_counts,
        "recent_traces": [
            {
                "id": t.id,
                "action_type": t.action_type,
                "actor": t.actor,
                "summary": t.summary,
                "control_case_id": t.control_case_id,
                "created_at": t.created_at.isoformat() if t.created_at else None,
            }
            for t in traces
        ],
    }