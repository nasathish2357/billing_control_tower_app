"""
MVP3 KG API

Routes:
  GET  /kg/issue/{issue_id}/relationships          — KG relationships for an issue
  GET  /kg/customer/{customer_id}/billing-context  — full billing tree for a customer
  GET  /kg/control-case/{control_case_id}/impact   — impact map for a control case
  GET  /kg/trace/bill/{bill_id}                    — bill → usage → CDR trace chain
  GET  /kg/trace/service/{service_id}              — service → network function trace
  POST /kg/rebuild                                 — force KG cache rebuild
"""
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/kg/issue/{issue_id}/relationships")
async def get_issue_kg_relationships(issue_id: str, db: AsyncSession = Depends(get_db)):
    """
    Return knowledge graph relationships for an issue.
    Builds KG from PostgreSQL (cached 60s) and traverses from issue_id.
    """
    try:
        from app.kg.kg_queries import get_issue_relationships
        result = await get_issue_relationships(db, issue_id)
        if "error" in result:
            raise HTTPException(status_code=503, detail=result["error"])
        return result
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")


@router.get("/kg/customer/{customer_id}/billing-context")
async def get_customer_billing_context(customer_id: str, db: AsyncSession = Depends(get_db)):
    """
    Return full billing context for a customer from the KG.
    Traverses: Customer → BillingAccounts → Bills → Issues → ControlCases.
    Also includes devices, services, and products in the customer subtree.
    """
    try:
        from app.kg.kg_queries import get_customer_billing_context as _query
        result = await _query(db, customer_id)
        if "error" in result:
            raise HTTPException(status_code=503, detail=result["error"])
        if "warning" in result:
            raise HTTPException(status_code=404, detail=result["warning"])
        return result
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")


@router.get("/kg/control-case/{control_case_id}/impact")
async def get_control_case_impact(control_case_id: str, db: AsyncSession = Depends(get_db)):
    """
    Return impact map for a control case from the KG.
    Shows all downstream evidence packs, audit traces, approvals,
    and upstream issue / billing account / customer chain.
    """
    try:
        from app.kg.kg_queries import get_control_case_impact as _query
        result = await _query(db, control_case_id)
        if "error" in result:
            raise HTTPException(status_code=503, detail=result["error"])
        if "warning" in result:
            raise HTTPException(status_code=404, detail=result["warning"])
        return result
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")


@router.get("/kg/trace/bill/{bill_id}")
async def trace_bill_to_usage(bill_id: str, db: AsyncSession = Depends(get_db)):
    """
    Trace a bill through the full usage chain:
    Bill → BillLineItem → RatedUsage → MediationRecord → UsageEvent (CDR)

    Enables cross-domain billing audit: confirm each billed charge is
    traceable to a rated CDR from the mediation engine.
    """
    try:
        from app.kg.kg_queries import get_bill_to_usage_trace
        result = await get_bill_to_usage_trace(db, bill_id)
        if "error" in result:
            raise HTTPException(status_code=503, detail=result["error"])
        if "warning" in result:
            raise HTTPException(status_code=404, detail=result["warning"])
        return result
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")


@router.get("/kg/trace/service/{service_id}")
async def trace_service_to_nf(service_id: str, db: AsyncSession = Depends(get_db)):
    """
    Trace a service inventory entry to the network functions delivering it.
    ServiceInventory → ProductOffering + correlated NetworkFunction nodes
    (UPF, SMF, CHF, PCF, etc. depending on service_type).
    """
    try:
        from app.kg.kg_queries import get_service_to_nf_trace
        result = await get_service_to_nf_trace(db, service_id)
        if "error" in result:
            raise HTTPException(status_code=503, detail=result["error"])
        if "warning" in result:
            raise HTTPException(status_code=404, detail=result["warning"])
        return result
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")


@router.post("/kg/rebuild")
async def rebuild_kg(db: AsyncSession = Depends(get_db)):
    """
    Force a KG rebuild from PostgreSQL.
    Useful for development, testing, or after bulk data changes.
    The KG normally rebuilds automatically on each request (cached 60s).
    """
    try:
        from app.kg.kg_builder import build_graph, invalidate_cache
        invalidate_cache()
        G = await build_graph(db)
        if G is None:
            raise HTTPException(status_code=503, detail="networkx not installed — KG not available")

        # Count by entity type
        type_counts: dict = {}
        for _, data in G.nodes(data=True):
            t = data.get("type", "Unknown")
            type_counts[t] = type_counts.get(t, 0) + 1

        return {
            "status": "rebuilt",
            "node_count": G.number_of_nodes(),
            "edge_count": G.number_of_edges(),
            "entity_types": type_counts,
        }
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")