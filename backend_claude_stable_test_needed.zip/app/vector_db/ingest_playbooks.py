"""
Playbook ingestion script — run once to populate ChromaDB.

Run:  python -m app.vector_db.ingest_playbooks
"""

import sys
import asyncio
import os
import glob
# Windows fix: psycopg3 async requires SelectorEventLoop
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import logging

from app.vector_db.vector_store import add_playbooks
from app.config import get_settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Fallback basic playbooks for MVP1 use cases that might not have markdown files yet
FALLBACK_PLAYBOOKS = [
    {
        "id": "PB-P2-001",
        "text": (
            "Playbook: Duplicate Charging Resolution (P2)\n"
            "1. Retrieve the billing account and identify the duplicate charge line item.\n"
            "2. Obtain mediation evidence from L3 confirming the double processing event.\n"
            "3. Obtain rating evidence from L4 showing two rating triggers for a single session.\n"
            "4. Issue a credit adjustment via L2 for the duplicate amount.\n"
            "5. Update the control case and create an audit trace.\n"
            "Outcome: Credit applied, bill corrected, customer notified."
        ),
        "metadata": {"use_case": "P2", "layer": "L1-L4", "action": "credit"},
    },
    {
        "id": "PB-P3-001",
        "text": (
            "Playbook: Zombie PDU Session Resolution (P3)\n"
            "1. Identify the session ID and the time range of anomalous charging.\n"
            "2. Request L4 network evidence to confirm the session was not legitimately active.\n"
            "3. Execute L4 mock session cleanup/termination for the zombie session ID.\n"
            "4. Calculate the erroneous charge amount and apply a billing correction via L2.\n"
            "5. Create audit trace with L4 session evidence and L2 correction record.\n"
            "Outcome: Session cleaned, billing corrected."
        ),
        "metadata": {"use_case": "P3", "layer": "L4", "action": "session_cleanup+credit"},
    },
    {
        "id": "PB-P8-001",
        "text": (
            "Playbook: Bill Explanation (P8)\n"
            "1. Load the current bill and all line items for the billing account.\n"
            "2. Load the previous 3 months of bills for comparison.\n"
            "3. Identify line items that changed significantly month-over-month.\n"
            "4. Use Gemini to generate a plain-language explanation of each change.\n"
            "5. If no discrepancy is found, return the explanation without escalation.\n"
            "6. If a discrepancy is detected, escalate to the remediation flow.\n"
            "Outcome: Customer receives a clear, plain-language bill explanation."
        ),
        "metadata": {"use_case": "P8", "layer": "L2", "action": "explanation"},
    },
]


async def main():
    settings = get_settings()
    playbooks_dir = settings.playbook_path
    
    texts = []
    metadatas = []
    ids = []
    
    use_cases_loaded_from_disk = set()

    # Try loading markdown playbooks from disk
    if os.path.exists(playbooks_dir):
        logger.info(f"Scanning for markdown playbooks in {playbooks_dir}")
        for filepath in glob.glob(os.path.join(playbooks_dir, "*.md")):
            filename = os.path.basename(filepath)
            
            use_case = "UNKNOWN"
            if "p1" in filename.lower(): use_case = "P1"
            elif "p4" in filename.lower(): use_case = "P4"
            elif "p5" in filename.lower(): use_case = "P5"
            elif "p6" in filename.lower(): use_case = "P6"
            elif "p9" in filename.lower(): use_case = "P9"
            
            use_cases_loaded_from_disk.add(use_case)
            
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
                
            pb_id = f"PB-{use_case}-001"
            logger.info(f"Loaded playbook: {filename} ({pb_id})")
            
            texts.append(content)
            metadatas.append({"use_case": use_case, "source": filename})
            ids.append(pb_id)

    # Add fallbacks for use cases we didn't find markdown files for
    for pb in FALLBACK_PLAYBOOKS:
        uc = pb["metadata"]["use_case"]
        if uc not in use_cases_loaded_from_disk:
            logger.info(f"Using fallback playbook for {uc}")
            texts.append(pb["text"])
            metadatas.append(pb["metadata"])
            ids.append(pb["id"])

    if not texts:
        logger.warning("No playbooks found to ingest!")
        return

    logger.info(f"Ingesting {len(texts)} playbooks into ChromaDB...")
    await add_playbooks(texts, metadatas, ids)
    logger.info("Playbook ingestion complete.")


if __name__ == "__main__":
    asyncio.run(main())
