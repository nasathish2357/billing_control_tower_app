"""
ChromaDB vector store backed by Vertex AI embeddings.

Design:
  - Persistent, file-mounted client (not in-memory).
  - Embedding is done via VertexAIEmbeddings; the raw vectors are passed to Chroma.
  - Exposes async-compatible wrappers (sync Chroma calls wrapped in threadpool).
"""

import asyncio
import logging
import os
from functools import lru_cache
from typing import List, Dict, Optional

import chromadb
from chromadb import Documents, EmbeddingFunction, Embeddings

from app.config import get_settings
from app.llm.gemini_provider import get_embeddings

logger = logging.getLogger(__name__)
COLLECTION_NAME = "billing_playbooks"


class VertexAIEmbeddingFunction(EmbeddingFunction):
    """Adapter so ChromaDB can call VertexAIEmbeddings."""

    def __call__(self, input: Documents) -> Embeddings:  # type: ignore
        embeddings_model = get_embeddings()
        return embeddings_model.embed_documents(list(input))


@lru_cache()
def _get_chroma_client() -> chromadb.PersistentClient:
    settings = get_settings()
    path = settings.vector_store_path
    os.makedirs(path, exist_ok=True)
    return chromadb.PersistentClient(path=path)


def get_collection():
    client = _get_chroma_client()
    return client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=VertexAIEmbeddingFunction(),
        metadata={"hnsw:space": "cosine"},
    )


async def add_playbooks(texts: List[str], metadatas: List[dict], ids: List[str]) -> None:
    """Ingest playbook documents into ChromaDB (runs in threadpool)."""
    def _add():
        collection = get_collection()
        collection.add(documents=texts, metadatas=metadatas, ids=ids)

    await asyncio.get_event_loop().run_in_executor(None, _add)
    logger.info("Ingested %d playbook documents into ChromaDB.", len(texts))


async def similarity_search(query: str, n_results: int = 3) -> List[Dict]:
    """Return top-n matching playbook chunks."""
    def _search():
        collection = get_collection()
        results = collection.query(query_texts=[query], n_results=n_results)
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        return [{"document": d, "metadata": m} for d, m in zip(docs, metas)]

    return await asyncio.get_event_loop().run_in_executor(None, _search)
