# Billing Control Tower — MVP1 Backend

Telecom Billing Dispute Agentic AI backend powered by FastAPI, LangGraph, Google Vertex AI Gemini, PostgreSQL, and ChromaDB.

## Quick Start

### Prerequisites
- Python 3.12+ (`.venv` already set up)
- PostgreSQL 15+ running locally
- Google Vertex AI credentials (service account JSON)

### 1. Configure Environment
```bash
cp .env.example .env
# Edit .env and fill in:
#   VERTEXAI_PROJECT, VERTEXAI_LOCATION, VERTEXAI_MODEL
#   GOOGLE_APPLICATION_CREDENTIALS (path to your service account JSON)
#   DATABASE_URL (PostgreSQL connection string)
```

### 2. Create the Database
```sql
CREATE DATABASE billing_dispute_ai;
```

### 3. Seed the Database (creates tables + seed data)
```bash
.venv\Scripts\python.exe -m app.db.seed
```

### 4. Ingest Playbooks into ChromaDB (requires Vertex AI credentials)
```bash
.venv\Scripts\python.exe -m app.vector_db.ingest_playbooks
```

### 5. Start the Server
```bash
.venv\Scripts\uvicorn.exe app.main:app --reload
```

API available at: http://localhost:8000  
Interactive docs: http://localhost:8000/docs

---

## API Reference

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/health` | Health check |
| GET | `/api/v1/use-cases` | List all 10 use cases |
| GET | `/api/v1/issues` | List all 10 seeded issues |
| GET | `/api/v1/issues/{id}` | Get single issue |
| POST | `/api/v1/issues/{id}/remediate` | Trigger remediation (LangGraph for P2/P3, deterministic for others) |
| POST | `/api/v1/chat/stream` | Streaming bill explanation (SSE) — P8 |
| POST | `/api/v1/chat` | Non-streaming chat (for tests) |
| GET | `/api/v1/audit-traces/{id}` | Retrieve audit trace |
| GET | `/api/v1/control-cases/{id}` | Retrieve control case |

## Use Cases

| ID | Name | Flow Type |
|----|------|-----------|
| P1 | Missing/Delayed Usage Feed | Deterministic |
| **P2** | **Duplicate Charging** | **LangGraph (Full)** |
| **P3** | **Zombie PDU Session** | **LangGraph (Full)** |
| P4 | QoS/Slice Entitlement Mismatch | Deterministic |
| P5 | Service Degradation Compensation | Deterministic |
| P6 | Collections Hold | Deterministic |
| P7 | Partner Charge Discrepancy | Deterministic |
| **P8** | **Bill Explanation (Chat)** | **LangGraph + SSE** |
| P9 | Proactive Anomaly Discovery | Deterministic |
| P10 | End-to-End Governed Dispute | Deterministic |

## Architecture

```
FastAPI (async)
  ├── /api/v1/issues/{id}/remediate
  │     ├── P2/P3 → LangGraph RemediationGraph
  │     │     ├── L1 Master Orchestration (load, policy, audit)
  │     │     ├── L2 BSS Service (bills, adjustments)
  │     │     ├── L3 OSS Service (mediation evidence)
  │     │     └── L4 Network Service (session evidence, cleanup)
  │     └── P1,P4-P7,P9-P10 → DeterministicFlow
  └── /api/v1/chat/stream
        └── LangGraph ChatGraph (P8)
              ├── Intent classification (Gemini)
              ├── Bill data loading (L2 BSS)
              ├── RAG playbook retrieval (ChromaDB)
              └── Explanation generation (Gemini) → SSE stream

Vector Store: ChromaDB (file-mounted, Vertex AI embeddings)
LLM: Google Vertex AI Gemini 1.5 Pro
DB: PostgreSQL (async SQLAlchemy + psycopg3)
```

## Docker

```bash
docker build -t billing-control-tower-mvp1 .
docker run -p 8000:8000 \
  --env-file .env \
  -v /path/to/service-account.json:/app/secrets/vertex-ai-service-account.json:ro \
  -v /path/to/chroma_data:/app/data/vector_store/chroma \
  billing-control-tower-mvp1
```
