"""
Infrastructure connectivity checker — run before E2E tests.
Checks: PostgreSQL, seed data, Vertex AI LLM, Vertex AI Embeddings, ChromaDB.
"""

import sys
import asyncio

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


def section(title):
    print(f"\n[{title}]")


def result(label, ok, detail=""):
    icon = "PASS" if ok else "FAIL"
    print(f"  Status : {icon}")
    if detail:
        print(f"  Detail : {detail[:200]}")


async def main():
    print("=" * 70)
    print("  INFRASTRUCTURE CONNECTIVITY CHECKS")
    print("=" * 70)

    all_ok = True

    # ── 1. PostgreSQL ────────────────────────────────────────────────────
    section("1. PostgreSQL Connectivity")
    try:
        from sqlalchemy import text
        from app.db.database import AsyncSessionFactory
        async with AsyncSessionFactory() as db:
            r = await db.execute(text("SELECT version()"))
            version = r.scalar()
        result("postgres", True, version[:80])
    except Exception as e:
        result("postgres", False, str(e))
        all_ok = False

    # ── 2. Seed data counts ──────────────────────────────────────────────
    section("2. Seed Data Row Counts")
    try:
        from sqlalchemy import text
        from app.db.database import AsyncSessionFactory
        expected = {"use_cases": 10, "issues": 10, "customers": 3, "bills": 2}
        async with AsyncSessionFactory() as db:
            for table, exp in expected.items():
                r = await db.execute(text(f"SELECT COUNT(*) FROM {table}"))
                n = r.scalar()
                ok = n >= exp
                all_ok = all_ok and ok
                icon = "PASS" if ok else "FAIL"
                print(f"  [{icon}] {table}: {n} rows (expected >= {exp})")
    except Exception as e:
        result("seed", False, str(e))
        all_ok = False

    # ── 3. Vertex AI LLM ────────────────────────────────────────────────
    section("3. Vertex AI LLM (Gemini) Call")
    try:
        from langchain_core.messages import HumanMessage
        from app.llm.gemini_provider import get_llm
        llm = get_llm()
        response = await llm.ainvoke([HumanMessage(content='Say exactly the word: OK')])
        reply = response.content.strip()[:100]
        ok = len(reply) > 0
        all_ok = all_ok and ok
        result("llm", ok, f"Gemini replied: '{reply}'")
    except Exception as e:
        result("llm", False, str(e))
        all_ok = False

    # ── 4. Vertex AI Embeddings ──────────────────────────────────────────
    section("4. Vertex AI Embeddings")
    try:
        from app.llm.gemini_provider import get_embeddings
        embeddings = get_embeddings()
        vecs = embeddings.embed_documents(["telecom billing dispute"])
        ok = len(vecs) > 0 and len(vecs[0]) > 0
        all_ok = all_ok and ok
        result("embeddings", ok, f"Vector dimensions: {len(vecs[0])}")
    except Exception as e:
        result("embeddings", False, str(e))
        all_ok = False

    # ── 5. ChromaDB ──────────────────────────────────────────────────────
    section("5. ChromaDB Vector Store")
    try:
        from app.vector_db.vector_store import get_collection
        col = get_collection()
        n = col.count()
        ok = True
        all_ok = all_ok and ok
        result("chromadb", ok, f"{n} documents in '{col.name}' collection")
    except Exception as e:
        result("chromadb", False, str(e))
        all_ok = False

    print()
    print("=" * 70)
    print(f"  RESULT: {'ALL CHECKS PASSED' if all_ok else 'SOME CHECKS FAILED'}")
    print("=" * 70)
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
