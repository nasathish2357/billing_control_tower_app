"""
MVP1 E2E agentic flow test — run AFTER check_infra.py passes.
Tests all 9 API endpoints including P2/P3 LangGraph flows and P8 SSE chat.
"""

import sys
import asyncio
import json
import urllib.request
import urllib.error

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

BASE = "http://localhost:8000/api/v1"


def get(path):
    try:
        with urllib.request.urlopen(BASE + path, timeout=20) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}
    except Exception as e:
        return None, str(e)


def post(path, data=None):
    try:
        body = json.dumps(data or {}).encode()
        req = urllib.request.Request(
            BASE + path, data=body,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}
    except Exception as e:
        return None, str(e)


results = []


def check(name, passed, detail=""):
    results.append((name, passed, str(detail)[:110]))


print()
print("=" * 72)
print("  MVP1 AGENTIC E2E TESTS")
print("=" * 72)

# ── Health ───────────────────────────────────────────────────────────────
s, d = get("/health")
check("GET /health", s == 200, d)

# ── Use Cases ────────────────────────────────────────────────────────────
s, d = get("/use-cases")
check("GET /use-cases returns 10", s == 200 and len(d) == 10, f"{len(d) if isinstance(d,list) else d} use cases")
if isinstance(d, list):
    ids = [u["id"] for u in d]
    all_present = all(f"P{i}" in ids for i in range(1, 11))
    check("All P1-P10 use cases present", all_present, str(ids))

# ── Issues ───────────────────────────────────────────────────────────────
s, d = get("/issues")
check("GET /issues returns 10", s == 200 and len(d) == 10, f"{len(d) if isinstance(d,list) else d} issues")

s, d = get("/issues/ISSUE-P2-001")
check("GET /issues/ISSUE-P2-001", s == 200, d.get("use_case_id") if isinstance(d, dict) else d)

s, d = get("/issues/ISSUE-FAKE-999")
check("GET /issues/ISSUE-FAKE-999 -> 404", s == 404, s)

# ── Deterministic flows ──────────────────────────────────────────────────
for p in ["P1", "P4", "P5", "P6", "P7", "P9", "P10"]:
    s, d = post(f"/issues/ISSUE-{p}-001/remediate")
    ok = s == 200 and isinstance(d, dict) and d.get("status") == "remediated"
    detail = d.get("summary", d.get("action", ""))[:80] if isinstance(d, dict) else str(d)[:80]
    check(f"POST remediate {p} (deterministic)", ok, detail)

# ── Audit trace retrieval ────────────────────────────────────────────────
s, d = post("/issues/ISSUE-P6-001/remediate")
audit_id = d.get("audit_trace_id") if isinstance(d, dict) else None
if audit_id:
    s, ad = get(f"/audit-traces/{audit_id}")
    check("GET /audit-traces/{id}", s == 200 and ad.get("id") == audit_id, ad.get("action_type") if isinstance(ad, dict) else ad)
else:
    check("GET /audit-traces/{id}", False, f"No audit_trace_id: {d}")

# ── Control case retrieval ───────────────────────────────────────────────
s, d = post("/issues/ISSUE-P7-001/remediate")
cc_id = d.get("control_case_id") if isinstance(d, dict) else None
if cc_id:
    s, cd = get(f"/control-cases/{cc_id}")
    check("GET /control-cases/{id}", s == 200 and cd.get("id") == cc_id, cd.get("status") if isinstance(cd, dict) else cd)
else:
    check("GET /control-cases/{id}", False, f"No control_case_id: {d}")

# ── P8 Chat non-streaming ────────────────────────────────────────────────
s, d = post("/chat", {
    "conversation_id": "E2E-INFRA-001",
    "message": "Why is my bill higher this month?",
    "customer_id": "CUST-100001",
    "billing_account_id": "BA-100001",
})
fr = d.get("final_response", "") if isinstance(d, dict) else ""
ok = s == 200 and bool(fr) and fr != "Unable to generate explanation."
check("POST /chat P8 (non-streaming, LLM-backed)", ok, fr[:100])

# ── Print results ────────────────────────────────────────────────────────
print()
pass_count = 0
for name, passed, detail in results:
    icon = "PASS" if passed else "FAIL"
    if passed:
        pass_count += 1
    print(f"  [{icon}] {name}")
    print(f"         {detail}")

print()
print("=" * 72)
print(f"  Score: {pass_count}/{len(results)} passed")
print("=" * 72)
sys.exit(0 if pass_count == len(results) else 1)
