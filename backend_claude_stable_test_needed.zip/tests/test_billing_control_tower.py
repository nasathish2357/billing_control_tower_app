"""
Billing Control Tower — Master Test Suite (MVP3 ground truth).

Covers all acceptance criteria across the full backend:
  - Core: health, use-cases, issues
  - Remediation flows: P1, P5 (interrupt + resume), P6, P7, P9, P10
  - Chat: P8 bill explanation, intent classification
  - Events: TMF event list, simulate
  - Approvals: pending list, approve/reject
  - Context: customer billing context
  - KG: rebuild, issue relationships, customer billing-context, bill trace, not-found
  - Simulation: types, dry-run, active list, invalid type
  - TMF Mock APIs: all 11 resource types
  - Dashboard: all 5 routes
  - Audit: search, action-type filter, action list

Run:  pytest tests/test_billing_control_tower.py -v
"""
import sys
import asyncio
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

# Windows: psycopg3 async requires SelectorEventLoop
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from app.main import app


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest_asyncio.fixture
async def client():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c


# ─────────────────────────────────────────────────────────────────────────────
#  Health
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_health(client):
    response = await client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["mvp"] == "3"


# ─────────────────────────────────────────────────────────────────────────────
#  Use Cases
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_use_cases(client):
    """All 10 use cases exist and every one is full_graph."""
    response = await client.get("/api/v1/use-cases")
    assert response.status_code == 200
    use_cases = response.json()
    assert len(use_cases) == 10
    flow_types = {uc["id"]: uc["flow_type"] for uc in use_cases}
    for p in ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10"]:
        assert p in flow_types, f"{p} not found in use cases"
        assert flow_types[p] == "full_graph", f"{p} expected full_graph, got {flow_types[p]}"


# ─────────────────────────────────────────────────────────────────────────────
#  Issues
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_issues_list(client):
    """All 10 issues (P1–P10) are seeded."""
    response = await client.get("/api/v1/issues")
    assert response.status_code == 200
    issues = response.json()
    assert len(issues) >= 10
    use_case_ids = {i["use_case_id"] for i in issues}
    for uc in ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10"]:
        assert uc in use_case_ids, f"Issue for {uc} not found"


@pytest.mark.anyio
async def test_get_issue_by_id(client):
    response = await client.get("/api/v1/issues/ISSUE-P2-001")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == "ISSUE-P2-001"
    assert data["use_case_id"] == "P2"


@pytest.mark.anyio
async def test_get_issue_not_found(client):
    response = await client.get("/api/v1/issues/ISSUE-DOES-NOT-EXIST")
    assert response.status_code == 404


# ─────────────────────────────────────────────────────────────────────────────
#  Remediation Flows
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_remediate_p1(client):
    response = await client.post("/api/v1/issues/ISSUE-P1-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P1"
    assert data["status"] in ("remediated", "pending_approval")


@pytest.mark.anyio
async def test_remediate_p5_interrupt(client):
    """P5 always interrupts for human approval (compensation > $50 threshold)."""
    response = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P5"
    assert data["status"] == "pending_approval"
    assert "approval_id" in data
    assert "thread_id" in data


@pytest.mark.anyio
async def test_remediate_p5_resume_after_approval(client):
    """Full P5 interrupt → approve → resume cycle."""
    # 1. Trigger
    res1 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert res1.status_code == 200
    assert res1.json()["status"] == "pending_approval"
    approval_id = res1.json()["approval_id"]

    # 2. Approve
    res2 = await client.post(
        f"/api/v1/approvals/{approval_id}/approve",
        json={"notes": "Approved by automated test.", "approver_id": "TEST-USER-001", "reason_code": "WITHIN_AUTHORITY"},
    )
    assert res2.status_code == 200
    assert res2.json()["status"] == "approved"

    # 3. Resume
    res3 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/resume")
    assert res3.status_code == 200
    data3 = res3.json()
    assert data3["final_state"]["is_remediated"] is True
    assert "audit_trace_id" in data3["final_state"]


@pytest.mark.anyio
async def test_remediate_p6(client):
    response = await client.post("/api/v1/issues/ISSUE-P6-001/remediate")
    assert response.status_code == 200
    assert response.json()["use_case_id"] == "P6"
    assert response.json()["status"] in ("remediated", "pending_approval")


@pytest.mark.anyio
async def test_remediate_p7(client):
    """P7 is full_graph — returns remediated or pending_approval."""
    response = await client.post("/api/v1/issues/ISSUE-P7-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P7"
    assert data["status"] in ("remediated", "awaiting_approval", "pending_approval")


@pytest.mark.anyio
async def test_remediate_p9(client):
    response = await client.post("/api/v1/issues/ISSUE-P9-001/remediate")
    assert response.status_code == 200
    assert response.json()["use_case_id"] == "P9"


@pytest.mark.anyio
async def test_remediate_p10(client):
    """P10 enterprise correction ($320) always exceeds $50 threshold → pending_approval."""
    response = await client.post("/api/v1/issues/ISSUE-P10-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P10"
    assert data["status"] in ("remediated", "awaiting_approval", "pending_approval")


# ─────────────────────────────────────────────────────────────────────────────
#  Chat (P8)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_chat_bill_explanation(client):
    """P8 non-streaming bill explanation — LLM fallback ensures non-empty response."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P8-001",
        "message": "Why is my bill higher this month?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]


@pytest.mark.anyio
async def test_chat_issue_analysis_intent(client):
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-INTENT-001",
        "message": "Can you analyze the usage delay issue for my account?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert len(data["final_response"]) > 0


# ─────────────────────────────────────────────────────────────────────────────
#  Events
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_get_events(client):
    response = await client.get("/api/v1/events")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_simulate_event(client):
    response = await client.post("/api/v1/events/simulate/P5")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P5"
    assert "event_id" in data
    assert data["status"] == "new"
    assert "correlation" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Approvals
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_list_pending_approvals(client):
    response = await client.get("/api/v1/approvals/pending")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_approve_nonexistent_returns_400(client):
    response = await client.post(
        "/api/v1/approvals/APPR-INVALID-99999999/approve",
        json={"notes": "test", "approver_id": "USER-001", "reason_code": "WITHIN_AUTHORITY"},
    )
    assert response.status_code == 400


# ─────────────────────────────────────────────────────────────────────────────
#  Context
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_customer_billing_context(client):
    response = await client.get("/api/v1/customers/CUST-100001/billing-context")
    assert response.status_code == 200
    data = response.json()
    assert data["customer_id"] == "CUST-100001"
    assert "billing_accounts" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Knowledge Graph
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_kg_rebuild(client):
    response = await client.post("/api/v1/kg/rebuild")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "rebuilt"
    assert data["node_count"] > 0
    assert data["edge_count"] > 0
    assert "entity_types" in data
    for expected in ("Customer", "BillingAccount", "Bill", "Issue",
                     "NetworkFunction", "PDUSession", "UsageEvent", "PartnerAccount"):
        assert expected in data["entity_types"], f"{expected} missing from KG entity_types"


@pytest.mark.anyio
async def test_kg_issue_relationships_p2(client):
    response = await client.get("/api/v1/kg/issue/ISSUE-P2-001/relationships")
    assert response.status_code == 200
    data = response.json()
    assert data["issue_id"] == "ISSUE-P2-001"
    assert "issue" in data
    assert isinstance(data["nodes"], list)
    assert isinstance(data["edges"], list)


@pytest.mark.anyio
async def test_kg_issue_relationships_p5(client):
    response = await client.get("/api/v1/kg/issue/ISSUE-P5-001/relationships")
    assert response.status_code == 200
    data = response.json()
    assert "nodes" in data
    assert isinstance(data["nodes"], list)


@pytest.mark.anyio
async def test_kg_customer_billing_context(client):
    response = await client.get("/api/v1/kg/customer/CUST-100001/billing-context")
    assert response.status_code == 200
    data = response.json()
    assert data["customer_id"] == "CUST-100001"
    assert "customer" in data
    assert "billing_tree" in data
    assert isinstance(data["billing_account_count"], int)


@pytest.mark.anyio
async def test_kg_bill_to_usage_trace(client):
    response = await client.get("/api/v1/kg/trace/bill/BILL-202604")
    assert response.status_code == 200
    data = response.json()
    assert data["bill_id"] == "BILL-202604"
    assert "usage_chain" in data
    assert isinstance(data["line_item_count"], int)


@pytest.mark.anyio
async def test_kg_customer_not_found(client):
    response = await client.get("/api/v1/kg/customer/CUST-DOES-NOT-EXIST/billing-context")
    assert response.status_code in (404, 200)


# ─────────────────────────────────────────────────────────────────────────────
#  Simulation
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_simulation_types(client):
    response = await client.get("/api/v1/simulation/types")
    assert response.status_code == 200
    data = response.json()
    assert "simulation_types" in data
    types = [t["type"] for t in data["simulation_types"]]
    for expected in ("duplicate_charge", "zombie_pdu_session", "usage_delay",
                     "qos_mismatch", "sla_breach", "partner_discrepancy", "proactive_risk"):
        assert expected in types
    assert len(types) == 7


@pytest.mark.anyio
async def test_simulation_dry_run(client):
    response = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "duplicate_charge", "customer_id": "CUST-100001",
                "billing_account_id": "BA-100001", "dry_run": "true"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["dry_run"] is True
    assert data["simulation_type"] == "duplicate_charge"
    assert data["use_case_id"] == "P2"
    assert data["issue_id"] is None
    assert data["artifacts_created"] > 0


@pytest.mark.anyio
async def test_simulation_active_list(client):
    response = await client.get("/api/v1/simulation/active")
    assert response.status_code == 200
    data = response.json()
    assert "active_simulation_count" in data
    assert "simulations" in data


@pytest.mark.anyio
async def test_simulation_invalid_type_returns_400(client):
    response = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "not_a_real_type"},
    )
    assert response.status_code == 400


# ─────────────────────────────────────────────────────────────────────────────
#  TMF Mock APIs
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_tmf_product_catalog(client):
    response = await client.get("/api/v1/mock-tmf/product-catalog/product")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_product_offerings(client):
    response = await client.get("/api/v1/mock-tmf/product-catalog/productOffering")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_trouble_tickets(client):
    response = await client.get("/api/v1/mock-tmf/trouble-ticket")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_service_inventory(client):
    response = await client.get("/api/v1/mock-tmf/service-inventory/service")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_customer_bills(client):
    response = await client.get("/api/v1/mock-tmf/customer-bill")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_bill_line_items(client):
    response = await client.get("/api/v1/mock-tmf/customer-bill/BILL-202604/line-items")
    assert response.status_code == 200
    data = response.json()
    assert "lineItems" in data
    assert isinstance(data["lineItems"], list)
    assert len(data["lineItems"]) > 0


@pytest.mark.anyio
async def test_tmf_events(client):
    response = await client.get("/api/v1/mock-tmf/event")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_service_problem(client):
    response = await client.get("/api/v1/mock-tmf/service-problem")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_audit_records(client):
    response = await client.get("/api/v1/mock-tmf/audit-record")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


@pytest.mark.anyio
async def test_tmf_hub_registration(client):
    response = await client.post(
        "/api/v1/mock-tmf/hub",
        params={"callback_url": "https://test.example.com/notify"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "id" in data
    assert data["callback"] == "https://test.example.com/notify"


@pytest.mark.anyio
async def test_tmf_trouble_ticket_patch(client):
    """PATCH trouble-ticket status update (status is a query param)."""
    response = await client.patch(
        "/api/v1/mock-tmf/trouble-ticket/TT-P5-001",
        params={"status": "in_progress"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "in_progress"


# ─────────────────────────────────────────────────────────────────────────────
#  Dashboard
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_dashboard_summary(client):
    response = await client.get("/api/v1/dashboard/summary")
    assert response.status_code == 200
    data = response.json()
    assert "issues" in data
    assert "control_cases" in data
    assert "approvals" in data
    assert "financial_exposure" in data
    assert data["issues"]["total"] >= 10


@pytest.mark.anyio
async def test_dashboard_prebill_risks(client):
    response = await client.get("/api/v1/dashboard/prebill-risks")
    assert response.status_code == 200
    data = response.json()
    assert "prebill_risk_accounts" in data
    assert "accounts" in data


@pytest.mark.anyio
async def test_dashboard_postbill_disputes(client):
    response = await client.get("/api/v1/dashboard/postbill-disputes")
    assert response.status_code == 200
    data = response.json()
    assert "dispute_count" in data
    assert "disputes" in data


@pytest.mark.anyio
async def test_dashboard_layer_health(client):
    response = await client.get("/api/v1/dashboard/layer-health")
    assert response.status_code == 200
    data = response.json()
    for layer in ("L1", "L2", "L3", "L4"):
        assert layer in data
        assert "status" in data[layer]


@pytest.mark.anyio
async def test_dashboard_audit_summary(client):
    response = await client.get("/api/v1/dashboard/audit-summary")
    assert response.status_code == 200
    data = response.json()
    assert "recent_audit_count" in data
    assert "recent_traces" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Audit
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_audit_search_no_filters(client):
    response = await client.get("/api/v1/audit/search")
    assert response.status_code == 200
    data = response.json()
    assert "traces" in data
    assert "total" in data


@pytest.mark.anyio
async def test_audit_search_by_action_type(client):
    response = await client.get("/api/v1/audit/search", params={"action_type": "event_correlation"})
    assert response.status_code == 200
    data = response.json()
    for trace in data["traces"]:
        assert trace["action_type"] == "event_correlation"


@pytest.mark.anyio
async def test_audit_action_types(client):
    response = await client.get("/api/v1/audit/actions")
    assert response.status_code == 200
    data = response.json()
    assert "action_types" in data
    assert "total_traces" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Self-Service — eBill and Appointments
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_ebill_enrolment(client):
    """Enrol a known customer in eBilling."""
    response = await client.post("/api/v1/self-service/ebill", json={
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "email_for_ebill": "alice@example.com",
    })
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "enrolled"
    assert data["customer_id"] == "CUST-100001"
    assert "reference" in data
    assert "ebill_email" in data


@pytest.mark.anyio
async def test_ebill_enrolment_customer_not_found(client):
    response = await client.post("/api/v1/self-service/ebill", json={
        "customer_id": "CUST-DOES-NOT-EXIST",
    })
    assert response.status_code == 404


@pytest.mark.anyio
async def test_create_appointment_callback(client):
    """Book a callback appointment linked to a billing issue."""
    response = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P2-001",
        "appointment_type": "callback",
        "scheduled_at": "2026-05-10T14:00:00",
        "notes": "Customer wants to discuss duplicate charge",
    })
    assert response.status_code == 201
    data = response.json()
    assert data["appointment_type"] == "callback"
    assert data["status"] == "scheduled"
    assert data["customer_id"] == "CUST-100001"
    assert "id" in data
    return data["id"]


@pytest.mark.anyio
async def test_get_appointment(client):
    """Create then retrieve an appointment."""
    # Create
    create_resp = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100003",
        "appointment_type": "video_call",
        "scheduled_at": "2026-05-12T10:30:00",
        "notes": "SLA compensation discussion",
    })
    assert create_resp.status_code == 201
    appt_id = create_resp.json()["id"]

    # Retrieve
    get_resp = await client.get(f"/api/v1/appointments/{appt_id}")
    assert get_resp.status_code == 200
    data = get_resp.json()
    assert data["id"] == appt_id
    assert data["appointment_type"] == "video_call"
    assert data["customer_id"] == "CUST-100003"


@pytest.mark.anyio
async def test_appointment_invalid_type(client):
    response = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100001",
        "appointment_type": "telepathy",
        "scheduled_at": "2026-05-15T09:00:00",
    })
    assert response.status_code == 400


@pytest.mark.anyio
async def test_appointment_not_found(client):
    response = await client.get("/api/v1/appointments/APPT-DOES-NOT-EXIST")
    assert response.status_code == 404


# ─────────────────────────────────────────────────────────────────────────────
#  RAG Playbook Coverage
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_chat_proactive_risk_summary(client):
    """P9 proactive_risk_summary intent — fetches live risk before LLM response."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P9-RISK",
        "message": "What is the billing risk on my account right now?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]


@pytest.mark.anyio
async def test_chat_partner_charge_explanation(client):
    """partner_charge_explanation intent."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P7-PARTNER",
        "message": "Why are there wholesale partner charges on my account?",
        "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]


@pytest.mark.anyio
async def test_chat_governed_case_summary(client):
    """governed_case_summary intent."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P10-GOV",
        "message": "Can you summarise the status of my dispute case?",
        "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]
