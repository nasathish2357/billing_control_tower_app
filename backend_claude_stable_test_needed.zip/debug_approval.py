import asyncio
from httpx import AsyncClient, ASGITransport
from app.main import app
import json

async def run():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        res1 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
        data1 = res1.json()
        print("RES1:", json.dumps(data1, indent=2))
        approval_id = data1.get("approval_id")

        if approval_id:
            res2 = await client.post(f"/api/v1/approvals/{approval_id}/approve", json={"notes": "Approved by test."})
            print("RES2:", json.dumps(res2.json(), indent=2))

            res3 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/resume")
            print("RES3:", json.dumps(res3.json(), indent=2))

asyncio.run(run())
