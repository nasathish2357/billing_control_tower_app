"""
Windows-compatible entry point.

Uvicorn's ProactorEventLoop interferes with psycopg3 async on Windows.
The only reliable fix is to run uvicorn inside asyncio.run() with an
explicit SelectorEventLoop factory.

Usage:
    .venv\\Scripts\\python.exe run.py
"""

import sys
import asyncio
import selectors

# Force SelectorEventLoop globally before anything else runs
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import uvicorn


async def main():
    config = uvicorn.Config(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        log_level="info",
        loop="none",      # tell uvicorn NOT to install its own loop
    )
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    if sys.platform == "win32":
        # Use SelectorEventLoop explicitly as loop_factory
        asyncio.run(
            main(),
            # loop_factory is only available in Python 3.12+
        )
    else:
        asyncio.run(main())
