"""
Approval flows — HITL interrupt, old /approvals/{id}/approve, and new
inline POST /issues/{id}/approve.

P5 is the canonical approval use case (£75 compensation).
P1, P7, P10 are also gated but P5 is the simplest to test deterministically.
"""


# ── old approval endpoint — listing ──────────────────────────────────────────

async def test_list_pending_approvals(client):
    r = await client.get("/api/v1/approvals/pending")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_approve_nonexistent_returns_400(client):
    r = await client.post(
        "/api/v1/approvals/APPR-INVALID-XXXXXXXX/approve",
        json={"notes": "test", "approver_id": "TEST-001", "reason_code": "WITHIN_AUTHORITY"},
    )
    assert r.status_code == 400


# ── P5 full interrupt → approve → resume via legacy endpoint ─────────────────

async def test_p5_interrupt_and_legacy_resume(client):
    """P5: trigger → pauses → approve via /approvals/{id}/approve → resume."""
    # 1. Trigger remediation (must pause for approval)
    r1 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert r1.status_code == 200
    d1 = r1.json()
    assert d1["status"] in ("pending_approval", "remediated"), d1

    if d1["status"] != "pending_approval":
        # Policy auto-approved — skip approval cycle
        return

    approval_id = d1["approval_id"]
    assert approval_id

    # 2. Approve
    r2 = await client.post(
        f"/api/v1/approvals/{approval_id}/approve",
        json={"notes": "Approved by test.", "approver_id": "TEST-001", "reason_code": "WITHIN_AUTHORITY"},
    )
    assert r2.status_code == 200
    assert r2.json()["status"] == "approved"

    # 3. Resume graph
    r3 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/resume")
    assert r3.status_code == 200
    d3 = r3.json()
    assert d3.get("final_state", {}).get("is_remediated") is True
    assert d3.get("final_state", {}).get("audit_trace_id")


async def test_p5_interrupt_and_legacy_reject(client):
    """P5: trigger → reject → issue stays in closed/pending state without audit."""
    r1 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert r1.status_code == 200
    d1 = r1.json()

    if d1["status"] != "pending_approval":
        return

    approval_id = d1["approval_id"]
    r2 = await client.post(
        f"/api/v1/approvals/{approval_id}/reject",
        json={"notes": "Insufficient evidence.", "approver_id": "TEST-001", "reason_code": "ESCALATION_NEEDED"},
    )
    assert r2.status_code == 200
    assert r2.json()["status"] == "rejected"


# ── new inline POST /issues/{id}/approve ─────────────────────────────────────

async def test_inline_approve_unknown_issue(client):
    """Inline approve on a non-existent issue returns 404."""
    r = await client.post("/api/v1/issues/ISSUE-DOES-NOT-EXIST/approve", json={
        "approval_id": "APPR-FAKE-001",
        "decision": "approved",
        "reason": "",
    })
    assert r.status_code == 404


async def test_inline_approve_unknown_approval(client):
    """Inline approve with a non-existent approval_id returns 404."""
    r = await client.post("/api/v1/issues/ISSUE-P5-001/approve", json={
        "approval_id": "APPR-DOES-NOT-EXIST",
        "decision": "approved",
        "reason": "",
    })
    assert r.status_code == 404


async def test_inline_approve_p5_full_cycle(client):
    """
    Full cycle: stream P5 → get awaiting_approval event → inline approve →
    graph resumes → returns audit_trace_id.
    """
    import json as _json

    # 1. Stream remediation (blocking collect)
    r1 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/stream")
    assert r1.status_code == 200

    events = []
    for frame in r1.text.split("\n\n"):
        frame = frame.strip()
        if not frame:
            continue
        etype, dstr = None, None
        for line in frame.split("\n"):
            if line.startswith("event:"):
                etype = line[6:].strip()
            elif line.startswith("data:"):
                dstr = line[5:].strip()
        if etype and dstr:
            try:
                events.append((etype, _json.loads(dstr)))
            except _json.JSONDecodeError:
                pass

    etypes = [e for e, _ in events]

    if "awaiting_approval" not in etypes:
        # Policy auto-approved or P5 resolved without approval — acceptable
        assert "summary" in etypes, f"Neither awaiting_approval nor summary: {etypes}"
        return

    approval_data = next(d for e, d in events if e == "awaiting_approval")
    approval_id = approval_data.get("approval_id")
    assert approval_id, f"awaiting_approval missing approval_id: {approval_data}"

    # 2. Inline approve
    r2 = await client.post(f"/api/v1/issues/ISSUE-P5-001/approve", json={
        "approval_id": approval_id,
        "decision": "approved",
        "reason": "Approved by inline test.",
    })
    assert r2.status_code == 200
    d2 = r2.json()
    assert d2["decision"] == "approved"


async def test_inline_reject_p7(client):
    """P7: stream → reject if approval paused → check decision returned."""
    import json as _json

    r1 = await client.post("/api/v1/issues/ISSUE-P7-001/remediate/stream")
    assert r1.status_code == 200

    approval_id = None
    for frame in r1.text.split("\n\n"):
        frame = frame.strip()
        if not frame:
            continue
        etype, dstr = None, None
        for line in frame.split("\n"):
            if line.startswith("event:"):
                etype = line[6:].strip()
            elif line.startswith("data:"):
                dstr = line[5:].strip()
        if etype == "awaiting_approval" and dstr:
            try:
                approval_id = _json.loads(dstr).get("approval_id")
            except _json.JSONDecodeError:
                pass

    if not approval_id:
        return  # P7 auto-approved — skip

    r2 = await client.post(f"/api/v1/issues/ISSUE-P7-001/approve", json={
        "approval_id": approval_id,
        "decision": "rejected",
        "reason": "Insufficient partner evidence.",
    })
    assert r2.status_code == 200
    assert r2.json()["decision"] == "rejected"
