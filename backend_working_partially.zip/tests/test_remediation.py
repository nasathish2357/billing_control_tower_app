"""
Remediation blocking endpoint — all 10 use cases.

POST /api/v1/issues/{id}/remediate  (non-streaming, blocking)
"""
import pytest


# ── helpers ───────────────────────────────────────────────────────────────────

async def _remediate(client, issue_id: str, expected_uc: str) -> dict:
    r = await client.post(f"/api/v1/issues/{issue_id}/remediate")
    assert r.status_code == 200, f"{issue_id}: {r.text}"
    d = r.json()
    assert d["use_case_id"] == expected_uc
    return d


# ── auto-remediation (no approval gate) ──────────────────────────────────────

async def test_remediate_p2_duplicate_charge(client):
    """P2: duplicate CTF triggers → mediation dedup → credit. Auto path."""
    d = await _remediate(client, "ISSUE-P2-001", "P2")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p3_zombie_session(client):
    """P3: zombie PDU session → force-terminate → credit. Auto path."""
    d = await _remediate(client, "ISSUE-P3-001", "P3")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p6_collections_hold(client):
    """P6: disputed invoice → collections hold + dunning pause. L2-only."""
    d = await _remediate(client, "ISSUE-P6-001", "P6")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p8_bill_explanation(client):
    """P8: confusing bill → L2 bill insight only. Auto path."""
    d = await _remediate(client, "ISSUE-P8-001", "P8")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p9_proactive_risk(client):
    """P9: pre-bill CHF duplicate detection → suppress + L3 mediation. Auto path."""
    d = await _remediate(client, "ISSUE-P9-001", "P9")
    assert d["status"] in ("remediated", "pending_approval")


# ── approval-gated use cases ──────────────────────────────────────────────────

async def test_remediate_p1_usage_delay(client):
    """P1: mediation backlog → rebill gate (approval required)."""
    d = await _remediate(client, "ISSUE-P1-001", "P1")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p4_qos_mismatch(client):
    """P4: QoS/NSSAI mismatch → surcharge removal (approval required)."""
    d = await _remediate(client, "ISSUE-P4-001", "P4")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p5_sla_breach_pauses(client):
    """P5: compensation £75 > £50 threshold → always pauses for approval."""
    d = await _remediate(client, "ISSUE-P5-001", "P5")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p7_partner_discrepancy(client):
    """P7: roaming partner variance → retail credit + recovery case."""
    d = await _remediate(client, "ISSUE-P7-001", "P7")
    assert d["status"] in ("remediated", "pending_approval")


async def test_remediate_p10_governed_multisite(client):
    """P10: £7800 multi-site enterprise dispute → all 4 layers + approval."""
    d = await _remediate(client, "ISSUE-P10-001", "P10")
    assert d["status"] in ("remediated", "pending_approval")


# ── error paths ───────────────────────────────────────────────────────────────

async def test_remediate_unknown_issue(client):
    r = await client.post("/api/v1/issues/ISSUE-DOES-NOT-EXIST/remediate")
    assert r.status_code == 404
