"""
Shared pytest fixtures for Billing Control Tower tests.

All test modules import `client` from here via pytest's conftest auto-discovery.

asyncio_mode = auto (set in pytest.ini) — no @pytest.mark.asyncio needed.
"""
import asyncio
import sys

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

# Windows: psycopg3 async requires SelectorEventLoop
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# Per-test LLM timeout — Gemini 2.5 Flash can be slow under load
TEST_TIMEOUT = 180


@pytest_asyncio.fixture
async def client():
    """
    ASGI test client with a MemorySaver checkpointer injected.

    httpx ASGITransport does NOT call the ASGI lifespan, so setup_checkpointer()
    is never invoked and the graph's checkpointer stays None by default.
    We inject MemorySaver directly so interrupt()/Command(resume=...) work
    for P1/P5/P7/P10 approval flows without needing a real Postgres connection.
    """
    from langgraph.checkpoint.memory import MemorySaver
    import app.agents.checkpoint_setup as _cs
    from app.agents.graph_builder import reset_agentic_graph
    from app.main import app

    _cs._checkpointer = MemorySaver()
    reset_agentic_graph()

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        timeout=TEST_TIMEOUT,
    ) as c:
        yield c

    reset_agentic_graph()
    _cs._checkpointer = None


@pytest_asyncio.fixture
async def client_no_checkpointer():
    """
    Test client without a checkpointer — for use cases that don't need
    interrupt/resume (P2, P3, P6, P8, P9).  Faster startup.
    """
    from app.agents.graph_builder import reset_agentic_graph
    from app.main import app

    reset_agentic_graph()

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        timeout=TEST_TIMEOUT,
    ) as c:
        yield c

    reset_agentic_graph()
