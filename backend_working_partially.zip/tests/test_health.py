"""Health, use-cases list, and issues CRUD."""


async def test_health(client):
    r = await client.get("/api/v1/health")
    assert r.status_code == 200
    d = r.json()
    assert d["status"] == "ok"
    assert d["mvp"] == "3"


async def test_use_cases_all_ten_full_graph(client):
    r = await client.get("/api/v1/use-cases")
    assert r.status_code == 200
    ucs = r.json()
    assert len(ucs) == 10
    ft = {u["id"]: u["flow_type"] for u in ucs}
    for p in [f"P{i}" for i in range(1, 11)]:
        assert p in ft, f"{p} missing"
        assert ft[p] == "full_graph", f"{p} not full_graph"


async def test_issues_list_all_ten(client):
    r = await client.get("/api/v1/issues")
    assert r.status_code == 200
    issues = r.json()
    assert len(issues) >= 10
    ids = {i["use_case_id"] for i in issues}
    for p in [f"P{i}" for i in range(1, 11)]:
        assert p in ids, f"Issue for {p} not found"


async def test_get_issue_by_id(client):
    r = await client.get("/api/v1/issues/ISSUE-P2-001")
    assert r.status_code == 200
    d = r.json()
    assert d["id"] == "ISSUE-P2-001"
    assert d["use_case_id"] == "P2"


async def test_get_issue_not_found(client):
    r = await client.get("/api/v1/issues/ISSUE-DOES-NOT-EXIST")
    assert r.status_code == 404
