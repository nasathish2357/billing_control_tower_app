"""Simulation injection, dry-run, active listing, invalid type."""


async def test_simulation_types_all_seven(client):
    r = await client.get("/api/v1/simulation/types")
    assert r.status_code == 200
    d = r.json()
    assert "simulation_types" in d
    types = [t["type"] for t in d["simulation_types"]]
    for expected in ("duplicate_charge", "zombie_pdu_session", "usage_delay",
                     "qos_mismatch", "sla_breach", "partner_discrepancy", "proactive_risk"):
        assert expected in types, f"Missing simulation type: {expected}"
    assert len(types) == 7


async def test_simulation_dry_run_duplicate_charge(client):
    r = await client.post(
        "/api/v1/simulation/inject",
        params={
            "simulation_type": "duplicate_charge",
            "customer_id": "CUST-100001",
            "billing_account_id": "BA-100001",
            "dry_run": "true",
        },
    )
    assert r.status_code == 200
    d = r.json()
    assert d["dry_run"] is True
    assert d["simulation_type"] == "duplicate_charge"
    assert d["use_case_id"] == "P2"
    assert d["issue_id"] is None
    assert d["artifacts_created"] > 0


async def test_simulation_dry_run_zombie_session(client):
    r = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "zombie_pdu_session", "dry_run": "true"},
    )
    assert r.status_code == 200
    d = r.json()
    assert d["use_case_id"] == "P3"
    assert d["dry_run"] is True


async def test_simulation_dry_run_sla_breach(client):
    r = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "sla_breach", "dry_run": "true"},
    )
    assert r.status_code == 200
    assert r.json()["use_case_id"] == "P5"


async def test_simulation_dry_run_partner_discrepancy(client):
    r = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "partner_discrepancy", "dry_run": "true"},
    )
    assert r.status_code == 200
    assert r.json()["use_case_id"] == "P7"


async def test_simulation_active_list(client):
    r = await client.get("/api/v1/simulation/active")
    assert r.status_code == 200
    d = r.json()
    assert "active_simulation_count" in d
    assert "simulations" in d


async def test_simulation_invalid_type_returns_400(client):
    r = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "not_a_real_type"},
    )
    assert r.status_code == 400
