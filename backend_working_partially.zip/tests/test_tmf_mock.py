"""Mock TMF API endpoints — all 11 resource types."""


async def test_product_catalog(client):
    r = await client.get("/api/v1/mock-tmf/product-catalog/product")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_product_offerings(client):
    r = await client.get("/api/v1/mock-tmf/product-catalog/productOffering")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_trouble_tickets(client):
    r = await client.get("/api/v1/mock-tmf/trouble-ticket")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_service_inventory(client):
    r = await client.get("/api/v1/mock-tmf/service-inventory/service")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_customer_bills(client):
    r = await client.get("/api/v1/mock-tmf/customer-bill")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_bill_line_items(client):
    r = await client.get("/api/v1/mock-tmf/customer-bill/BILL-202604/line-items")
    assert r.status_code == 200
    d = r.json()
    assert "lineItems" in d
    assert isinstance(d["lineItems"], list)
    assert len(d["lineItems"]) > 0


async def test_tmf_events_list(client):
    r = await client.get("/api/v1/mock-tmf/event")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_service_problem_list(client):
    r = await client.get("/api/v1/mock-tmf/service-problem")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_audit_records(client):
    r = await client.get("/api/v1/mock-tmf/audit-record")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_hub_registration(client):
    r = await client.post(
        "/api/v1/mock-tmf/hub",
        params={"callback_url": "https://test.example.com/notify"},
    )
    assert r.status_code == 200
    d = r.json()
    assert "id" in d
    assert d["callback"] == "https://test.example.com/notify"


async def test_trouble_ticket_patch_status(client):
    r = await client.patch(
        "/api/v1/mock-tmf/trouble-ticket/TT-P5-001",
        params={"status": "in_progress"},
    )
    assert r.status_code == 200
    assert r.json()["status"] == "in_progress"
