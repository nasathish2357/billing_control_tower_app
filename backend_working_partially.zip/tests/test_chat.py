"""Chat endpoints — bill explanation, intent coverage, SSE streaming."""


async def test_chat_bill_explanation(client):
    r = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P8-001",
        "message": "Why is my bill higher this month?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert r.status_code == 200
    d = r.json()
    assert d.get("final_response"), "No final_response"


async def test_chat_issue_analysis_intent(client):
    r = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-INTENT-001",
        "message": "Analyse the usage delay issue on my account",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert r.status_code == 200
    assert r.json().get("final_response")


async def test_chat_proactive_risk_summary(client):
    r = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P9-RISK",
        "message": "What is the billing risk on my account right now?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert r.status_code == 200
    assert r.json().get("final_response")


async def test_chat_partner_charge_explanation(client):
    r = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P7-PARTNER",
        "message": "Why are there wholesale partner charges on my account?",
        "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002",
    })
    assert r.status_code == 200
    assert r.json().get("final_response")


async def test_chat_governed_case_summary(client):
    r = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P10-GOV",
        "message": "Summarise my dispute case status",
        "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002",
    })
    assert r.status_code == 200
    assert r.json().get("final_response")


async def test_chat_stream_has_conversation_started_and_final(client):
    """SSE chat stream must include conversation_started and final events."""
    import json as _json

    r = await client.post("/api/v1/chat/stream", json={
        "conversation_id": "TEST-STREAM-SSE-001",
        "message": "Explain my bill",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert r.status_code == 200
    assert "text/event-stream" in r.headers.get("content-type", "")

    etypes = []
    final_data = {}
    for frame in r.text.split("\n\n"):
        frame = frame.strip()
        if not frame:
            continue
        etype, dstr = None, None
        for line in frame.split("\n"):
            if line.startswith("event:"):
                etype = line[6:].strip()
            elif line.startswith("data:"):
                dstr = line[5:].strip()
        if etype and dstr:
            etypes.append(etype)
            if etype == "final":
                try:
                    final_data = _json.loads(dstr)
                except _json.JSONDecodeError:
                    pass

    assert "conversation_started" in etypes, f"Missing conversation_started. Got: {etypes}"
    assert "final" in etypes, f"Missing final. Got: {etypes}"
    assert final_data.get("final_response"), "final event missing final_response"
