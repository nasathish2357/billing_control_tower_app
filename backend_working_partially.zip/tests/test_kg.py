"""Knowledge Graph — rebuild, issue relationships, customer context, bill trace."""


async def test_kg_rebuild(client):
    r = await client.post("/api/v1/kg/rebuild")
    assert r.status_code == 200
    d = r.json()
    assert d["status"] == "rebuilt"
    assert d["node_count"] > 0
    assert d["edge_count"] > 0
    assert "entity_types" in d
    for expected in ("Customer", "BillingAccount", "Bill", "Issue",
                     "NetworkFunction", "PDUSession", "UsageEvent", "PartnerAccount"):
        assert expected in d["entity_types"], f"{expected} missing from KG entity_types"


async def test_kg_issue_relationships_p2(client):
    r = await client.get("/api/v1/kg/issue/ISSUE-P2-001/relationships")
    assert r.status_code == 200
    d = r.json()
    assert d["issue_id"] == "ISSUE-P2-001"
    assert "issue" in d
    assert isinstance(d["nodes"], list)
    assert isinstance(d["edges"], list)


async def test_kg_issue_relationships_p5(client):
    r = await client.get("/api/v1/kg/issue/ISSUE-P5-001/relationships")
    assert r.status_code == 200
    d = r.json()
    assert "nodes" in d


async def test_kg_customer_billing_context(client):
    r = await client.get("/api/v1/kg/customer/CUST-100001/billing-context")
    assert r.status_code == 200
    d = r.json()
    assert d["customer_id"] == "CUST-100001"
    assert "customer" in d
    assert "billing_tree" in d
    assert isinstance(d["billing_account_count"], int)


async def test_kg_bill_to_usage_trace(client):
    r = await client.get("/api/v1/kg/trace/bill/BILL-202604")
    assert r.status_code == 200
    d = r.json()
    assert d["bill_id"] == "BILL-202604"
    assert "usage_chain" in d
    assert isinstance(d["line_item_count"], int)


async def test_kg_customer_not_found_graceful(client):
    r = await client.get("/api/v1/kg/customer/CUST-DOES-NOT-EXIST/billing-context")
    assert r.status_code in (404, 200)
