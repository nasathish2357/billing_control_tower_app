"""Audit trace search, action-type filter, action list."""


async def test_audit_search_no_filters(client):
    r = await client.get("/api/v1/audit/search")
    assert r.status_code == 200
    d = r.json()
    assert "traces" in d
    assert "total" in d


async def test_audit_search_by_action_type(client):
    r = await client.get("/api/v1/audit/search", params={"action_type": "event_correlation"})
    assert r.status_code == 200
    d = r.json()
    for trace in d["traces"]:
        assert trace["action_type"] == "event_correlation"


async def test_audit_action_types_list(client):
    r = await client.get("/api/v1/audit/actions")
    assert r.status_code == 200
    d = r.json()
    assert "action_types" in d
    assert "total_traces" in d
