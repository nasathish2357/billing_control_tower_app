"""Dashboard endpoints — summary, KPIs, risks, disputes, layer health, audit."""


async def test_dashboard_summary(client):
    r = await client.get("/api/v1/dashboard/summary")
    assert r.status_code == 200
    d = r.json()
    assert "issues" in d
    assert "control_cases" in d
    assert "approvals" in d
    assert "financial_exposure" in d
    assert d["issues"]["total"] >= 10


async def test_dashboard_prebill_risks(client):
    r = await client.get("/api/v1/dashboard/prebill-risks")
    assert r.status_code == 200
    d = r.json()
    assert "prebill_risk_accounts" in d
    assert "accounts" in d


async def test_dashboard_postbill_disputes(client):
    r = await client.get("/api/v1/dashboard/postbill-disputes")
    assert r.status_code == 200
    d = r.json()
    assert "dispute_count" in d
    assert "disputes" in d


async def test_dashboard_layer_health(client):
    r = await client.get("/api/v1/dashboard/layer-health")
    assert r.status_code == 200
    d = r.json()
    for layer in ("L1", "L2", "L3", "L4"):
        assert layer in d, f"{layer} missing from layer-health"
        assert "status" in d[layer]


async def test_dashboard_audit_summary(client):
    r = await client.get("/api/v1/dashboard/audit-summary")
    assert r.status_code == 200
    d = r.json()
    assert "recent_audit_count" in d
    assert "recent_traces" in d
