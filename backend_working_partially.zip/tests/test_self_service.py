"""Self-service — eBill enrolment, appointments, customer context."""


async def test_customer_billing_context(client):
    r = await client.get("/api/v1/customers/CUST-100001/billing-context")
    assert r.status_code == 200
    d = r.json()
    assert d["customer_id"] == "CUST-100001"
    assert "billing_accounts" in d


async def test_ebill_enrolment(client):
    r = await client.post("/api/v1/self-service/ebill", json={
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "email_for_ebill": "alice@example.com",
    })
    assert r.status_code == 200
    d = r.json()
    assert d["status"] == "enrolled"
    assert d["customer_id"] == "CUST-100001"
    assert "reference" in d
    assert "ebill_email" in d


async def test_ebill_enrolment_unknown_customer(client):
    r = await client.post("/api/v1/self-service/ebill", json={
        "customer_id": "CUST-DOES-NOT-EXIST",
    })
    assert r.status_code == 404


async def test_create_appointment_callback(client):
    r = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P2-001",
        "appointment_type": "callback",
        "scheduled_at": "2026-05-10T14:00:00",
        "notes": "Discuss duplicate charge",
    })
    assert r.status_code == 201
    d = r.json()
    assert d["appointment_type"] == "callback"
    assert d["status"] == "scheduled"
    assert "id" in d


async def test_get_appointment_roundtrip(client):
    r1 = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100003",
        "appointment_type": "video_call",
        "scheduled_at": "2026-05-12T10:30:00",
        "notes": "SLA compensation discussion",
    })
    assert r1.status_code == 201
    appt_id = r1.json()["id"]

    r2 = await client.get(f"/api/v1/appointments/{appt_id}")
    assert r2.status_code == 200
    d = r2.json()
    assert d["id"] == appt_id
    assert d["appointment_type"] == "video_call"


async def test_appointment_invalid_type(client):
    r = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100001",
        "appointment_type": "telepathy",
        "scheduled_at": "2026-05-15T09:00:00",
    })
    assert r.status_code == 400


async def test_appointment_not_found(client):
    r = await client.get("/api/v1/appointments/APPT-DOES-NOT-EXIST")
    assert r.status_code == 404
