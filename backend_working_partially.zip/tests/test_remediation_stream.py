"""
SSE streaming remediation endpoint.

POST /api/v1/issues/{id}/remediate/stream  → text/event-stream

Verifies that the 8-type SSE contract is honoured:
  step_start, agent_thought, tool_call, tool_result, step_complete,
  awaiting_approval, summary, error
"""
import json


# ── helpers ───────────────────────────────────────────────────────────────────

def _parse_sse(body: str) -> list[tuple[str, dict]]:
    """Parse raw SSE body into [(event_type, data_dict), ...]."""
    events = []
    for frame in body.split("\n\n"):
        frame = frame.strip()
        if not frame:
            continue
        etype, dstr = None, None
        for line in frame.split("\n"):
            if line.startswith("event:"):
                etype = line[6:].strip()
            elif line.startswith("data:"):
                dstr = line[5:].strip()
        if etype and dstr:
            try:
                events.append((etype, json.loads(dstr)))
            except json.JSONDecodeError:
                events.append((etype, {"raw": dstr}))
    return events


# ── P2 — auto path (no approval gate) ────────────────────────────────────────

async def test_stream_p2_returns_sse(client):
    """P2 stream returns text/event-stream with at least one step_start."""
    r = await client.post("/api/v1/issues/ISSUE-P2-001/remediate/stream")
    assert r.status_code == 200
    assert "text/event-stream" in r.headers.get("content-type", "")


async def test_stream_p2_has_step_start(client):
    r = await client.post("/api/v1/issues/ISSUE-P2-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    etypes = [e for e, _ in events]
    assert "step_start" in etypes, f"step_start missing. Got: {etypes}"


async def test_stream_p2_has_summary_or_error(client):
    """Stream must end with either summary or error — never just cut off."""
    r = await client.post("/api/v1/issues/ISSUE-P2-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    etypes = [e for e, _ in events]
    assert "summary" in etypes or "error" in etypes, f"No terminal event. Got: {etypes}"


async def test_stream_p2_step_start_has_layer(client):
    """Every step_start must carry layer, agent, action fields."""
    r = await client.post("/api/v1/issues/ISSUE-P2-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    starts = [(e, d) for e, d in events if e == "step_start"]
    assert starts, "No step_start events"
    for _, d in starts:
        assert d.get("layer") in ("L1", "L2", "L3", "L4"), f"Bad layer: {d}"
        assert d.get("agent"), f"Missing agent: {d}"
        assert d.get("step_id"), f"Missing step_id: {d}"


async def test_stream_p2_tool_calls_have_tool_key(client):
    """tool_call events must include tool_key (vector/kg/event/cmdb/policy/audit/tmf/tool)."""
    r = await client.post("/api/v1/issues/ISSUE-P2-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    tool_events = [(e, d) for e, d in events if e == "tool_call"]
    for _, d in tool_events:
        assert d.get("tool_key"), f"tool_call missing tool_key: {d}"
        assert d.get("tool"), f"tool_call missing tool name: {d}"


async def test_stream_p2_l1_monitoring_fires_first(client):
    """L1 Monitoring Agent must be the first step_start event."""
    r = await client.post("/api/v1/issues/ISSUE-P2-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    starts = [d for e, d in events if e == "step_start"]
    if starts:
        assert starts[0]["layer"] == "L1", f"First step not L1: {starts[0]}"


async def test_stream_p2_summary_has_resolution(client):
    """summary event must include a resolution field."""
    r = await client.post("/api/v1/issues/ISSUE-P2-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    summaries = [d for e, d in events if e == "summary"]
    if summaries:
        assert "resolution" in summaries[0], f"summary missing resolution: {summaries[0]}"


# ── P5 — approval-gated path ──────────────────────────────────────────────────

async def test_stream_p5_emits_awaiting_approval(client):
    """P5 (£75 compensation) must pause with awaiting_approval SSE event."""
    r = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    etypes = [e for e, _ in events]
    # Either awaiting_approval (correct) or summary (if policy auto-approved)
    assert "awaiting_approval" in etypes or "summary" in etypes, (
        f"No terminal event for P5. Got: {etypes}"
    )


async def test_stream_p5_awaiting_approval_has_why(client):
    """awaiting_approval payload must carry why, proposed_action, financial_impact."""
    r = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    approval_events = [d for e, d in events if e == "awaiting_approval"]
    for d in approval_events:
        assert d.get("why"), f"awaiting_approval missing why: {d}"
        assert d.get("proposed_action") is not None, f"missing proposed_action: {d}"
        assert "financial_impact" in d, f"missing financial_impact: {d}"


# ── P6 — L2-only path ─────────────────────────────────────────────────────────

async def test_stream_p6_no_l4_steps(client):
    """P6 (collections hold) is L2-only — no L4 steps expected."""
    r = await client.post("/api/v1/issues/ISSUE-P6-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    l4_starts = [d for e, d in events if e == "step_start" and d.get("layer") == "L4"]
    assert not l4_starts, f"Unexpected L4 steps in P6: {l4_starts}"


# ── P10 — all layers ──────────────────────────────────────────────────────────

async def test_stream_p10_hits_all_layers(client):
    """P10 governed multi-domain must touch L1, L2, L3, L4."""
    r = await client.post("/api/v1/issues/ISSUE-P10-001/remediate/stream")
    assert r.status_code == 200
    events = _parse_sse(r.text)
    layers_seen = {d["layer"] for e, d in events if e == "step_start"}
    # At minimum L1 and L2 must fire; L3/L4 depend on policy/evidence
    assert "L1" in layers_seen, f"L1 missing in P10: {layers_seen}"
    assert "L2" in layers_seen, f"L2 missing in P10: {layers_seen}"


# ── error path ────────────────────────────────────────────────────────────────

async def test_stream_unknown_issue(client):
    r = await client.post("/api/v1/issues/ISSUE-DOES-NOT-EXIST/remediate/stream")
    assert r.status_code == 404
