"""TMF event listing and per-use-case simulation."""


async def test_get_events_returns_list(client):
    r = await client.get("/api/v1/events")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


async def test_simulate_event_p1(client):
    r = await client.post("/api/v1/events/simulate/P1")
    assert r.status_code == 200
    d = r.json()
    assert d["use_case_id"] == "P1"
    assert "event_id" in d
    assert d["status"] == "new"


async def test_simulate_event_p2(client):
    r = await client.post("/api/v1/events/simulate/P2")
    assert r.status_code == 200
    d = r.json()
    assert d["use_case_id"] == "P2"


async def test_simulate_event_p5(client):
    r = await client.post("/api/v1/events/simulate/P5")
    assert r.status_code == 200
    d = r.json()
    assert d["use_case_id"] == "P5"
    assert "correlation" in d


async def test_simulate_event_invalid_use_case(client):
    r = await client.post("/api/v1/events/simulate/P99")
    assert r.status_code in (200, 400, 404)
