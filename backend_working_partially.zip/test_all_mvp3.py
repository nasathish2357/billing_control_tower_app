import sys
import asyncio
import json
import urllib.request
import urllib.error
import time

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

BASE = "http://localhost:8000/api/v1"

def get(path):
    try:
        with urllib.request.urlopen(BASE + path, timeout=60) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}
    except Exception as e:
        return None, str(e)

def post(path, data=None):
    try:
        body = json.dumps(data or {}).encode()
        req = urllib.request.Request(
            BASE + path, data=body,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        # 10 minutes timeout to allow for LLM execution
        with urllib.request.urlopen(req, timeout=600) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}
    except Exception as e:
        return None, str(e)

results = []

def check(name, passed, detail=""):
    results.append((name, passed, str(detail)[:150]))
    icon = "PASS" if passed else "FAIL"
    print(f"[{icon}] {name}")
    if detail:
        print(f"         {str(detail)[:150]}")

print("=" * 72)
print("  MVP3 COMPREHENSIVE E2E TESTS (ALL APIS & USE CASES)")
print("=" * 72)

# ── 1. Dashboard APIs (Initial State) ────────────────────────────────────
print("\n--- Testing Dashboard APIs ---")
s, d = get("/dashboard/summary")
check("GET /dashboard/summary", s == 200, "Dashboard summary retrieved")

s, d = get("/dashboard/prebill-risks")
check("GET /dashboard/prebill-risks", s == 200, "Pre-bill risks retrieved")

s, d = get("/dashboard/postbill-disputes")
check("GET /dashboard/postbill-disputes", s == 200, "Post-bill disputes retrieved")

s, d = get("/dashboard/layer-health")
check("GET /dashboard/layer-health", s == 200, "Layer health retrieved")

s, d = get("/dashboard/audit-summary")
check("GET /dashboard/audit-summary", s == 200, "Audit summary retrieved")


# ── 2. Mock TMF APIs ─────────────────────────────────────────────────────
print("\n--- Testing Mock TMF APIs ---")
s, d = get("/mock-tmf/customer-bill?billing_account_id=BA-100001")
check("GET /mock-tmf/customer-bill", s == 200, "Customer bills retrieved")
if s == 200 and isinstance(d, list) and len(d) > 0:
    bill_id = d[0]["id"]
    s2, d2 = get(f"/mock-tmf/customer-bill/{bill_id}/line-items")
    check("GET /mock-tmf/customer-bill/{id}/line-items", s2 == 200, "Line items retrieved")


# ── 3. Simulation & Remediation (P1-P10) ─────────────────────────────────
print("\n--- Testing 10 Agentic Use Cases ---")

s, types_res = get("/simulation/types")
check("GET /simulation/types", s == 200, "Simulation types retrieved")

# The available simulations and their corresponding use cases:
# P1: usage_delay
# P2: duplicate_charge
# P3: zombie_pdu_session
# P4: qos_mismatch
# P5: sla_breach
# P7: partner_discrepancy
# P9: proactive_risk
# Note: P6, P8, P10 might not have explicit simulation types mapped in the list, but we can test what is available, or test hardcoded issues.

# Let's get the list of issues first
s, issues = get("/issues")
check("GET /issues", s == 200, f"Retrieved {len(issues) if isinstance(issues, list) else 0} issues")

if isinstance(issues, list):
    for use_case_id in ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P9", "P10"]:
        # Find the issue
        issue = next((i for i in issues if i["use_case_id"] == use_case_id), None)
        if not issue:
            check(f"Remediate {use_case_id}", False, "Issue not found")
            continue
        
        issue_id = issue["id"]
        print(f"\n>> Starting {use_case_id} ({issue_id}) remediation... This will take time.")
        s, r = post(f"/issues/{issue_id}/remediate")
        
        if s == 200 and r.get("status") == "pending_approval":
            print(f"   {use_case_id} paused for approval. Approving...")
            approval_id = r.get("approval_id")
            s2, a2 = post(f"/approvals/{approval_id}/approve", {"notes": "E2E Test Auto Approve"})
            check(f"Approve {use_case_id}", s2 == 200, "Approval processed")
            
            print(f"   Resuming {use_case_id}...")
            s3, r3 = post(f"/issues/{issue_id}/remediate/resume")
            check(f"Remediate {use_case_id} (Resumed)", s3 == 200 and r3.get("status") == "remediated", str(r3.get("summary")))
        else:
            check(f"Remediate {use_case_id}", s == 200 and r.get("status") == "remediated", str(r.get("summary")))


# ── 4. Chat API (P8) ─────────────────────────────────────────────────────
print("\n--- Testing Chat API (P8) ---")
s, d = post("/chat", {
    "conversation_id": "E2E-INFRA-001",
    "message": "Why is my bill higher this month? Please explain.",
    "customer_id": "CUST-100001",
    "billing_account_id": "BA-100001",
})
check("POST /chat (P8 Confusing Invoice)", s == 200, d.get("final_response") if isinstance(d, dict) else d)

# ── 5. Dashboard APIs (Final State) ────────────────────────────────────
print("\n--- Testing Dashboard APIs (Post-Remediation) ---")
s, d = get("/dashboard/summary")
check("GET /dashboard/summary (Final)", s == 200, f"Remediated: {d.get('issues', {}).get('remediated')}")


print("\n" + "=" * 72)
pass_count = sum(1 for _, p, _ in results if p)
print(f"  Score: {pass_count}/{len(results)} passed")
print("=" * 72)
sys.exit(0 if pass_count == len(results) else 1)
