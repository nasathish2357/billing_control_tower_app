"""
L4 Network / Resource / Charging Trigger Orchestration Graph — 5 sub-agents.

Agents:
  Network Orchestration (entry router, read-side evidence coordinator)
  Charging NF Correlation — CHF/CTF/OCS charging trigger evidence
  Core Session            — SMF/UPF/AMF PDU session state and evidence
  Resource RCA            — network function RCA, root cause identification
  Remediation Orchestrator — executes network-side fixes (NF config, session purge, policy push)

All agents must call retrieve_playbook + query_knowledge_graph before any action.
Remediation Orchestrator is the executor; Network Orchestration is the read coordinator.
"""
import logging
from typing import Literal

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory

logger = logging.getLogger(__name__)

_L4_PLAN: dict = {
    "P1":  ["charging_nf_correlation"],
    "P2":  ["charging_nf_correlation", "core_session"],
    "P3":  ["core_session", "resource_rca", "remediation_orchestrator"],
    "P4":  ["charging_nf_correlation"],
    "P5":  ["charging_nf_correlation"],   # RAN performance evidence
    "P6":  [],                             # L4 not involved
    "P7":  ["charging_nf_correlation"],   # SEPP/roaming evidence
    "P8":  [],                             # L4 not involved
    "P9":  ["charging_nf_correlation"],   # CHF duplicate detection
    "P10": ["network_entry", "charging_nf_correlation", "core_session", "resource_rca"],
}

L4Agents = Literal[
    "l4_network_entry", "l4_charging_nf_correlation", "l4_core_session",
    "l4_resource_rca", "l4_remediation_orchestrator", "l4_done",
]

_AGENT_NODE_MAP = {
    "network_entry":            "l4_network_entry",
    "charging_nf_correlation":  "l4_charging_nf_correlation",
    "core_session":             "l4_core_session",
    "resource_rca":             "l4_resource_rca",
    "remediation_orchestrator": "l4_remediation_orchestrator",
}


async def l4_network_orchestration_entry(state: AgentState) -> Command[L4Agents]:
    """L4 Network Orchestration entry — routes to appropriate sub-agents per use-case plan."""
    use_case_id = state.get("use_case_id", "P2")
    messages = state.get("messages", [])
    visited_agents = _visited_l4_agents(messages)

    plan = _L4_PLAN.get(use_case_id, ["charging_nf_correlation"])
    if not plan:
        return Command(
            goto="l4_done",
            update={"messages": [AIMessage(content=f"L4 Network Orchestration: No L4 action required for {use_case_id}.")]},
        )

    next_key = _next_in_plan(plan, visited_agents)
    if next_key is None:
        return Command(
            goto="l4_done",
            update={"messages": [AIMessage(content="L4 Network Orchestration: All L4 operations complete.")]},
        )

    next_node = _AGENT_NODE_MAP.get(next_key, "l4_network_entry")
    logger.info("[L4 Network Orchestration] use_case=%s → %s", use_case_id, next_node)
    return Command(
        goto=next_node,
        update={
            "next_agent": next_node,
            "messages": [AIMessage(content=f"L4 Network Orchestration routing to {next_node} for {use_case_id}.")],
        },
    )


async def l4_done(state: AgentState) -> dict:
    logger.info("[L4 Network Orchestration] done")
    return {"messages": [AIMessage(content="L4 Network domain operations complete. Returning to L1 Master.")]}


def _visited_l4_agents(messages: list) -> set:
    visited = set()
    for agent_key in _AGENT_NODE_MAP.values():
        for msg in messages:
            if agent_key in str(getattr(msg, "content", "")):
                short = agent_key.replace("l4_", "")
                visited.add(short)
    return visited


def _next_in_plan(plan: list, visited: set):
    for step in plan:
        if step not in visited:
            return step
    return None


# ── System prompts ────────────────────────────────────────────────────────────

_L4_MANDATE = """
MANDATORY REASONING PROTOCOL:
1. FIRST call retrieve_playbook with a query describing the network/charging issue.
2. THEN call query_knowledge_graph and/or query_cmdb to ground NF and session relationships.
3. Justify your findings before any remediation action.
4. Call append_audit after each action.
"""

NETWORK_ENTRY_PROMPT = """You are the L4 Network Orchestration Agent (read-side coordinator). You gather
high-level network context (NF inventory, session state, charging trigger overview) to help L1 Master
plan the L4 investigation. You do NOT execute remediation — that is the Remediation Orchestrator.
""" + _L4_MANDATE + """
Tools: query_cmdb, tmf_get_performance, tmf_get_pdu_session, retrieve_playbook, query_knowledge_graph."""

CHARGING_NF_PROMPT = """You are the L4 Charging NF Correlation Agent. You retrieve CHF/CTF/OCS charging
trigger records to confirm whether duplicate triggers, missing triggers, or incorrect triggers caused
the billing issue. You own charging event evidence from the network layer.
""" + _L4_MANDATE + """
Tools: get_rating_evidence_tool, get_sepp_cdr_evidence_tool, get_chf_roaming_records_tool,
query_cmdb, retrieve_playbook, query_knowledge_graph.
Output: charging trigger record(s), session_id, trigger_count, NF identity, verdict."""

CORE_SESSION_PROMPT = """You are the L4 Core Session Agent. You retrieve PDU session records from SMF/UPF
to determine session lifecycle — active, terminated, or zombie. Identify stale sessions and usage
accrued after intended termination.
""" + _L4_MANDATE + """
Tools: get_session_evidence_tool, tmf_get_pdu_session, query_cmdb,
retrieve_playbook, query_knowledge_graph.
Output: session status, data_volume_gb, start_time, end_time, zombie=true/false."""

RESOURCE_RCA_PROMPT = """You are the L4 Resource RCA Agent. You identify the root cause of network-layer
billing issues — NF configuration errors, capacity constraints, CHF bug, SMF state machine failure,
PCF policy misalignment, or SEPP CDR gap.
""" + _L4_MANDATE + """
Tools: query_cmdb, tmf_get_performance, get_rating_evidence_tool,
retrieve_playbook, query_knowledge_graph.
Output: root_cause, affected_nf, remediation_recommendation."""

REMEDIATION_ORCHESTRATOR_PROMPT = """You are the L4 Remediation Orchestrator Agent. You execute
network-side fixes: force-terminate zombie PDU sessions, push NF configuration corrections,
update slice/policy bindings, or trigger CDR replay from the network layer. You are the executor.
""" + _L4_MANDATE + """
Tools: cleanup_zombie_session_tool, query_cmdb, tmf_emit_event,
retrieve_playbook, query_knowledge_graph, append_audit.
Output: remediation_action_taken, session_id/nf_id, confirmation, rollback_available=true/false."""


def build_l4_network_orchestration_graph(factory: AgentFactory, checkpointer=None):
    """Build the L4 Network orchestration StateGraph with all 5 sub-agents."""
    from app.agents.tools import L4_TOOLS, SHARED_TOOLS, TMF_TOOLS

    all_l4_tools = L4_TOOLS + SHARED_TOOLS + TMF_TOOLS

    network_entry_node = factory.create_agent(all_l4_tools, NETWORK_ENTRY_PROMPT, name="l4_network_entry")
    charging_nf_node = factory.create_agent(all_l4_tools, CHARGING_NF_PROMPT, name="l4_charging_nf_correlation")
    core_session_node = factory.create_agent(all_l4_tools, CORE_SESSION_PROMPT, name="l4_core_session")
    resource_rca_node = factory.create_agent(all_l4_tools, RESOURCE_RCA_PROMPT, name="l4_resource_rca")
    remediation_orch_node = factory.create_agent(all_l4_tools, REMEDIATION_ORCHESTRATOR_PROMPT, name="l4_remediation_orchestrator")

    builder = StateGraph(AgentState)
    builder.add_node("l4_network_orchestration_entry", l4_network_orchestration_entry)
    builder.add_node("l4_network_entry", network_entry_node)
    builder.add_node("l4_charging_nf_correlation", charging_nf_node)
    builder.add_node("l4_core_session", core_session_node)
    builder.add_node("l4_resource_rca", resource_rca_node)
    builder.add_node("l4_remediation_orchestrator", remediation_orch_node)
    builder.add_node("l4_done", l4_done)

    builder.add_edge(START, "l4_network_orchestration_entry")
    for agent_node in [
        "l4_network_entry", "l4_charging_nf_correlation", "l4_core_session",
        "l4_resource_rca", "l4_remediation_orchestrator",
    ]:
        builder.add_edge(agent_node, "l4_network_orchestration_entry")
    builder.add_edge("l4_done", END)

    return builder.compile(checkpointer=checkpointer)
