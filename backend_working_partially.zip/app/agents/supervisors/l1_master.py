"""
L1 Master Agent (= Closed-Loop Control Agent).

Responsibilities:
- Plan evidence collection across L2/L3/L4 using playbook + KG.
- Dispatch to domain orchestrators (l2_bss_orchestration, l3_oss_orchestration, l4_network_orchestration).
- Reason over returned evidence to decide remediation path.
- Validate fix after remediation domain acts.
- Close the issue and route to L1 Audit when complete.

Default domain plan is kept as a fallback; L1 Master can reason to override it based on
playbook + KG findings.
"""
import json
import logging
from typing import Any, Dict, Literal

from langchain_core.messages import AIMessage
from langgraph.types import Command

from app.agents.agent_state import AgentState

logger = logging.getLogger(__name__)

# Default domain plan — L1 Master uses this as starting point but can override via playbook/KG reasoning.
USE_CASE_DOMAIN_PLAN: Dict[str, list] = {
    "P1":  ["l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"],
    "P2":  ["l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"],
    "P3":  ["l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"],
    "P4":  ["l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"],
    "P5":  ["l3_oss_orchestration", "l2_bss_orchestration"],
    "P6":  ["l2_bss_orchestration"],
    "P7":  ["l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"],
    "P8":  ["l2_bss_orchestration"],
    "P9":  ["l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"],
    "P10": ["l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"],
}

APPROVAL_USE_CASES = {"P1", "P4", "P5", "P7", "P10"}


async def l1_master_node(state: AgentState) -> Command:
    """
    L1 Master Agent node — central intelligence for orchestration, analysis, validation, and closure.

    Routing logic:
    1. If not yet dispatched to domain orchestrators → use playbook/KG to plan, dispatch to next unvisited.
    2. If all domain orchestrators visited and not yet remediated → analyze and decide.
    3. If policy says approval_required and not resolved → route to l1_human_approval.
    4. If remediated and no audit yet → route to l1_audit.
    5. If audit done → END.
    """
    from app.agents.tools.shared_tools import retrieve_playbook, query_knowledge_graph, evaluate_policy

    use_case_id = state.get("use_case_id", "P2")
    issue_id = state.get("issue_id", "")
    policy = state.get("policy_decision")
    approval_status = state.get("approval_status")
    audit_trace_id = state.get("audit_trace_id")
    is_remediated = state.get("is_remediated", False)
    evidence_summary = state.get("evidence_summary", "")
    visited = set(state.get("visited_supervisors") or [])

    logger.info(
        "[L1 Master] use_case=%s issue=%s policy=%s approval=%s remediated=%s visited=%s",
        use_case_id, issue_id, policy, approval_status, is_remediated, visited,
    )

    # ── Step 1: Audit done → END ──────────────────────────────────────────────
    if audit_trace_id:
        return Command(goto="__end__")

    # ── Step 2: Remediated → route to audit ──────────────────────────────────
    if is_remediated and not audit_trace_id:
        return Command(goto="l1_audit")

    # ── Step 3: Approval required and pending → route to HITL ────────────────
    if policy == "approval_required" and approval_status not in ("approved", "rejected"):
        return Command(goto="l1_human_approval")

    # ── Step 4: Approval rejected → close without full remediation ────────────
    if approval_status == "rejected":
        return Command(
            goto="l1_audit",
            update={
                "is_remediated": True,
                "evidence_summary": evidence_summary + "\nApproval rejected — case closed without financial action.",
            },
        )

    # ── Step 5: Determine next domain orchestrator ────────────────────────────
    plan = USE_CASE_DOMAIN_PLAN.get(use_case_id, ["l2_bss_orchestration"])

    # Use playbook + KG to potentially refine the plan (agentic override)
    plan = await _refine_plan_with_reasoning(use_case_id, issue_id, plan, evidence_summary, state)

    next_orchestrator = _next_in_plan(plan, visited)

    if next_orchestrator is None:
        # All domain orchestrators visited — analyze and decide
        return await _analyze_and_decide(state, use_case_id, issue_id, policy, evidence_summary)

    # ── Step 6: Check if policy evaluation needed before financial action ─────
    if (
        next_orchestrator == "l2_bss_orchestration"
        and use_case_id in APPROVAL_USE_CASES
        and policy is None
    ):
        # Evaluate policy before BSS financial action
        try:
            amount = _estimate_amount(use_case_id)
            policy_result = await evaluate_policy.ainvoke({
                "action": f"remediate_{use_case_id.lower()}",
                "context": evidence_summary[:300],
                "amount": amount,
            })
            policy_data = json.loads(policy_result)
            policy_decision = policy_data.get("decision", "auto_remediation_allowed")
            requires_approval = policy_data.get("requires_approval", False)

            updates: Dict[str, Any] = {
                "policy_decision": policy_decision,
                "requires_human_approval": requires_approval,
                "messages": [AIMessage(content=f"L1 Master: Policy evaluated — {policy_decision}")],
            }

            if requires_approval:
                appr_id = await _create_approval_record(state, use_case_id, policy_data)
                updates["approval_id"] = appr_id
                updates["approval_status"] = "pending"
                return Command(goto="l1_human_approval", update=updates)

            return Command(
                goto=next_orchestrator,
                update={
                    **updates,
                    "visited_supervisors": visited | {next_orchestrator},
                    "next_agent": next_orchestrator,
                    "messages": [AIMessage(content=f"L1 Master: Policy approved auto-remediation. Dispatching to {next_orchestrator}.")],
                },
            )
        except Exception as exc:
            logger.warning("[L1 Master] policy evaluation failed: %s", exc)

    # ── Step 7: Dispatch to next orchestrator ─────────────────────────────────
    logger.info("[L1 Master] dispatching to %s", next_orchestrator)
    return Command(
        goto=next_orchestrator,
        update={
            "next_agent": next_orchestrator,
            "visited_supervisors": visited | {next_orchestrator},
            "messages": [AIMessage(content=f"L1 Master dispatching to {next_orchestrator} for {use_case_id} evidence collection.")],
        },
    )


async def _refine_plan_with_reasoning(
    use_case_id: str, issue_id: str, default_plan: list, evidence: str, state: AgentState
) -> list:
    """
    Query playbook and KG; if reasoning suggests skipping a layer, remove it from plan.
    Returns the refined (or unchanged) domain plan.
    """
    try:
        from app.agents.tools.shared_tools import retrieve_playbook, query_knowledge_graph
        import json

        # Only refine if we have some evidence already (not first dispatch)
        if not evidence or len(evidence) < 50:
            return default_plan

        playbook_result = await retrieve_playbook.ainvoke({
            "query": f"{use_case_id} domain layer selection evidence {evidence[:200]}"
        })
        playbook_data = json.loads(playbook_result)
        playbook_text = " ".join(playbook_data.get("playbooks", []))

        # Simple heuristic refinement: P6 is L2-only per playbook
        if use_case_id == "P6":
            return ["l2_bss_orchestration"]
        if use_case_id == "P8":
            return ["l2_bss_orchestration"]

        # For others, keep default — L1 Master could extend this with full LLM call
        return default_plan
    except Exception:
        return default_plan


async def _analyze_and_decide(
    state: AgentState, use_case_id: str, issue_id: str, policy: str, evidence: str
) -> Command:
    """
    After all domain evidence is collected, analyze and mark as remediated.
    """
    logger.info("[L1 Master] all domains visited, analyzing evidence for %s", use_case_id)

    final_summary = (
        f"L1 Master analysis complete for {use_case_id}/{issue_id}. "
        f"Evidence gathered from all planned domain layers. "
        f"Evidence: {evidence[-500:] if evidence else 'none'}"
    )

    return Command(
        goto="l1_master",
        update={
            "is_remediated": True,
            "final_response_summary": final_summary,
            "messages": [AIMessage(content=final_summary)],
        },
    )


async def _create_approval_record(state: AgentState, use_case_id: str, policy_data: dict) -> str:
    """Create an Approval DB record and return its ID."""
    try:
        from app.agents.approval_manager import create_approval
        from app.db.database import AsyncSessionFactory

        amount = _estimate_amount(use_case_id)
        evidence_summary = state.get("evidence_summary", "")

        async with AsyncSessionFactory() as db:
            appr = await create_approval(
                db,
                thread_id=state.get("thread_id", ""),
                issue_id=state.get("issue_id", ""),
                control_case_id=state.get("control_case_id", ""),
                action=f"remediate_{use_case_id.lower()}",
                risk_reason=policy_data.get("risk_reason", "Policy threshold exceeded."),
                amount=amount,
            )
        return appr["approval_id"]
    except Exception as exc:
        logger.warning("[L1 Master] approval record creation failed: %s", exc)
        return f"APPR-{use_case_id}-FALLBACK"


def _next_in_plan(plan: list, visited: set):
    for step in plan:
        if step not in visited:
            return step
    return None


def _estimate_amount(use_case_id: str) -> float:
    defaults = {
        "P1": 38.50, "P2": 12.50, "P3": 12.00, "P4": 29.99,
        "P5": 75.00, "P6": 12.50, "P7": 89.99, "P10": 320.00,
    }
    return defaults.get(use_case_id, 50.0)
