"""
L2 BSS Domain Orchestration Graph — 7 sub-agents.

Agents:
  BSS Orchestration (entry router)
  Bill Insight        — TMF678 bill analysis, line item review
  Usage Integrity     — usage-to-bill reconciliation, duplicate detection
  Backoffice Adjustment — credits, charge reversals, bill protection holds
  Collections & Dunning — hold, dunning pause, balance separation
  Partner Settlement  — wholesale discrepancy filing, settlement records
  Ticketing           — trouble ticket open/update/close

Each sub-agent is a LLM ReAct node created by AgentFactory.
All agents must call retrieve_playbook + query_knowledge_graph before any DB mutation.
"""
import logging
from typing import Literal

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory

logger = logging.getLogger(__name__)

# ── Per-use-case agent routing plan ──────────────────────────────────────────
_L2_PLAN: dict = {
    "P1":  ["bill_insight", "usage_integrity", "backoffice_adjustment"],
    "P2":  ["bill_insight", "backoffice_adjustment"],
    "P3":  ["usage_integrity", "backoffice_adjustment"],
    "P4":  ["bss_entry", "backoffice_adjustment"],          # bss_entry reads entitlement
    "P5":  ["ticketing", "backoffice_adjustment"],
    "P6":  ["ticketing", "collections_dunning"],
    "P7":  ["partner_settlement", "bill_insight", "backoffice_adjustment"],
    "P8":  ["bill_insight", "usage_integrity"],
    "P9":  ["bill_insight", "backoffice_adjustment"],
    "P10": ["ticketing", "bill_insight", "backoffice_adjustment", "collections_dunning"],
}

L2Agents = Literal[
    "l2_bss_entry", "l2_bill_insight", "l2_usage_integrity",
    "l2_backoffice_adjustment", "l2_collections_dunning",
    "l2_partner_settlement", "l2_ticketing", "l2_done",
]

_AGENT_NODE_MAP = {
    "bss_entry":           "l2_bss_entry",
    "bill_insight":        "l2_bill_insight",
    "usage_integrity":     "l2_usage_integrity",
    "backoffice_adjustment": "l2_backoffice_adjustment",
    "collections_dunning": "l2_collections_dunning",
    "partner_settlement":  "l2_partner_settlement",
    "ticketing":           "l2_ticketing",
}


async def l2_bss_orchestration_entry(state: AgentState) -> Command[L2Agents]:
    """L2 BSS Orchestration entry — routes to the appropriate sub-agents per use-case plan."""
    use_case_id = state.get("use_case_id", "P2")
    messages = state.get("messages", [])
    visited_agents = _visited_l2_agents(messages)

    plan = _L2_PLAN.get(use_case_id, ["bill_insight", "backoffice_adjustment"])
    next_key = _next_in_plan(plan, visited_agents)

    if next_key is None:
        return Command(
            goto="l2_done",
            update={"messages": [AIMessage(content="L2 BSS Orchestration: All L2 operations complete.")]},
        )

    next_node = _AGENT_NODE_MAP.get(next_key, "l2_bss_entry")
    logger.info("[L2 BSS Orchestration] use_case=%s → %s", use_case_id, next_node)
    return Command(
        goto=next_node,
        update={
            "next_agent": next_node,
            "messages": [AIMessage(content=f"L2 BSS Orchestration routing to {next_node} for {use_case_id}.")],
        },
    )


async def l2_done(state: AgentState) -> dict:
    logger.info("[L2 BSS Orchestration] done")
    return {"messages": [AIMessage(content="L2 BSS domain operations complete. Returning to L1 Master.")]}


def _visited_l2_agents(messages: list) -> set:
    visited = set()
    for agent_key in _AGENT_NODE_MAP.values():
        for msg in messages:
            if agent_key in str(getattr(msg, "content", "")):
                short = agent_key.replace("l2_", "")
                visited.add(short)
    return visited


def _next_in_plan(plan: list, visited: set):
    for step in plan:
        if step not in visited and step not in {n.replace("l2_", "") for n in visited}:
            return step
    return None


# ── System prompts ────────────────────────────────────────────────────────────

_L2_MANDATE = """
MANDATORY REASONING PROTOCOL:
1. FIRST call retrieve_playbook with a query describing the current billing issue.
2. THEN call query_knowledge_graph with the issue_id to ground customer-account-bill relationships.
3. Use the playbook and KG findings to justify your decision before executing any tool that modifies data.
4. Call append_audit after every data-mutating action.
"""

BSS_ENTRY_PROMPT = """You are the L2 BSS Orchestration Agent. You retrieve customer and billing account context
to help L1 Master plan evidence collection. You do NOT apply credits or adjustments.
""" + _L2_MANDATE + """
Tools: tmf_get_customer_context, tmf_get_customer_bill, tmf_get_service_inventory, retrieve_playbook, query_knowledge_graph."""

BILL_INSIGHT_PROMPT = """You are the L2 Bill Insight Agent. You analyse bill line items to identify disputed charges,
duplicate entries, or opaque charge patterns. You do NOT apply credits.
""" + _L2_MANDATE + """
Tools: tmf_get_customer_bill, tmf_get_bill_lines, tmf_get_product_usage, retrieve_playbook, query_knowledge_graph.
Output: a concise summary of which line items are disputed and why."""

USAGE_INTEGRITY_PROMPT = """You are the L2 Usage Integrity Agent. You reconcile usage events to bill line items
to detect over-billing, zombie session charges, or missing usage.
""" + _L2_MANDATE + """
Tools: tmf_get_product_usage, tmf_get_bill_lines, get_previous_bills_tool, retrieve_playbook, query_knowledge_graph.
Output: confirm whether usage is correctly reflected in billing, with specific CDR or usage event IDs."""

BACKOFFICE_ADJUSTMENT_PROMPT = """You are the L2 Backoffice Adjustment Agent. You apply billing credits,
charge reversals, bill protection holds, surcharge removals, and compensation payments.
Only act AFTER playbook confirms the adjustment type and policy approves the amount.
""" + _L2_MANDATE + """
Tools: apply_billing_adjustment, apply_compensation_credit, apply_surcharge_removal_tool,
apply_bill_protection_hold_tool, retrieve_playbook, query_knowledge_graph, append_audit.
Output: adjustment_id, amount, reason, and confirmation."""

COLLECTIONS_DUNNING_PROMPT = """You are the L2 Collections & Dunning Agent. You manage dunning state,
apply collections holds on disputed balances, and ensure undisputed amounts remain collectible.
""" + _L2_MANDATE + """
Tools: apply_collections_hold_tool, place_collections_hold_tool, get_customer_context_tool,
retrieve_playbook, query_knowledge_graph, append_audit.
Output: hold_id, disputed_amount, undisputed_amount, dunning_state."""

PARTNER_SETTLEMENT_PROMPT = """You are the L2 Partner Settlement Agent. You retrieve wholesale settlement records,
calculate discrepancy amounts, and file partner recovery cases for roaming or MVNO charge mismatches.
""" + _L2_MANDATE + """
Tools: get_customer_context_tool, apply_billing_adjustment, retrieve_playbook, query_knowledge_graph, append_audit.
Output: settlement discrepancy details, recovery case reference, retail correction applied."""

TICKETING_PROMPT = """You are the L2 Ticketing Agent. You open, update, and close billing dispute tickets
and service complaint tickets. Link tickets to the issue_id and customer.
""" + _L2_MANDATE + """
Tools: open_trouble_ticket_tool, tmf_create_trouble_ticket, tmf_get_trouble_ticket,
retrieve_playbook, query_knowledge_graph, append_audit.
Output: ticket_id, ticket_type, priority, status."""


def build_l2_bss_orchestration_graph(factory: AgentFactory, checkpointer=None):
    """Build the L2 BSS orchestration StateGraph with all 7 sub-agents."""
    from app.agents.tools import L2_TOOLS, SHARED_TOOLS, TMF_TOOLS

    all_l2_tools = L2_TOOLS + SHARED_TOOLS + TMF_TOOLS

    bss_entry_node = factory.create_agent(all_l2_tools, BSS_ENTRY_PROMPT, name="l2_bss_entry")
    bill_insight_node = factory.create_agent(all_l2_tools, BILL_INSIGHT_PROMPT, name="l2_bill_insight")
    usage_integrity_node = factory.create_agent(all_l2_tools, USAGE_INTEGRITY_PROMPT, name="l2_usage_integrity")
    backoffice_adj_node = factory.create_agent(all_l2_tools, BACKOFFICE_ADJUSTMENT_PROMPT, name="l2_backoffice_adjustment")
    collections_node = factory.create_agent(all_l2_tools, COLLECTIONS_DUNNING_PROMPT, name="l2_collections_dunning")
    partner_node = factory.create_agent(all_l2_tools, PARTNER_SETTLEMENT_PROMPT, name="l2_partner_settlement")
    ticketing_node = factory.create_agent(all_l2_tools, TICKETING_PROMPT, name="l2_ticketing")

    builder = StateGraph(AgentState)
    builder.add_node("l2_bss_orchestration_entry", l2_bss_orchestration_entry)
    builder.add_node("l2_bss_entry", bss_entry_node)
    builder.add_node("l2_bill_insight", bill_insight_node)
    builder.add_node("l2_usage_integrity", usage_integrity_node)
    builder.add_node("l2_backoffice_adjustment", backoffice_adj_node)
    builder.add_node("l2_collections_dunning", collections_node)
    builder.add_node("l2_partner_settlement", partner_node)
    builder.add_node("l2_ticketing", ticketing_node)
    builder.add_node("l2_done", l2_done)

    builder.add_edge(START, "l2_bss_orchestration_entry")
    for agent_node in [
        "l2_bss_entry", "l2_bill_insight", "l2_usage_integrity",
        "l2_backoffice_adjustment", "l2_collections_dunning",
        "l2_partner_settlement", "l2_ticketing",
    ]:
        builder.add_edge(agent_node, "l2_bss_orchestration_entry")
    builder.add_edge("l2_done", END)

    return builder.compile(checkpointer=checkpointer)
