"""
L3 OSS Domain Orchestration Graph — 5 sub-agents.

Agents:
  OSS Orchestration (entry router)
  Service Problem     — TMF656 service problem lifecycle
  Mediation Replay    — CDR replay, duplicate suppression, backlog clearance
  QoS/Slice Correlation — 5QI/NSSAI performance vs. entitlement comparison
  Service Topology    — dynamic CMDB+KG topology stitching for cross-domain RCA

All agents must call retrieve_playbook + query_knowledge_graph before any action.
"""
import logging
from typing import Literal

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory

logger = logging.getLogger(__name__)

_L3_PLAN: dict = {
    "P1":  ["mediation_replay", "oss_entry"],
    "P2":  ["mediation_replay"],
    "P3":  ["service_problem"],
    "P4":  ["qos_slice_correlation", "service_topology"],
    "P5":  ["service_problem", "oss_entry"],
    "P6":  [],                                      # L3 not involved for P6
    "P7":  ["mediation_replay"],
    "P8":  ["service_topology"],
    "P9":  ["mediation_replay", "oss_entry"],
    "P10": ["service_problem", "mediation_replay", "service_topology"],
}

L3Agents = Literal[
    "l3_oss_entry", "l3_service_problem", "l3_mediation_replay",
    "l3_qos_slice_correlation", "l3_service_topology", "l3_done",
]

_AGENT_NODE_MAP = {
    "oss_entry":           "l3_oss_entry",
    "service_problem":     "l3_service_problem",
    "mediation_replay":    "l3_mediation_replay",
    "qos_slice_correlation": "l3_qos_slice_correlation",
    "service_topology":    "l3_service_topology",
}


async def l3_oss_orchestration_entry(state: AgentState) -> Command[L3Agents]:
    """L3 OSS Orchestration entry — routes to appropriate sub-agents per use-case plan."""
    use_case_id = state.get("use_case_id", "P2")
    messages = state.get("messages", [])
    visited_agents = _visited_l3_agents(messages)

    plan = _L3_PLAN.get(use_case_id, ["mediation_replay"])
    if not plan:
        return Command(
            goto="l3_done",
            update={"messages": [AIMessage(content=f"L3 OSS Orchestration: No L3 action required for {use_case_id}.")]},
        )

    next_key = _next_in_plan(plan, visited_agents)
    if next_key is None:
        return Command(
            goto="l3_done",
            update={"messages": [AIMessage(content="L3 OSS Orchestration: All L3 operations complete.")]},
        )

    next_node = _AGENT_NODE_MAP.get(next_key, "l3_oss_entry")
    logger.info("[L3 OSS Orchestration] use_case=%s → %s", use_case_id, next_node)
    return Command(
        goto=next_node,
        update={
            "next_agent": next_node,
            "messages": [AIMessage(content=f"L3 OSS Orchestration routing to {next_node} for {use_case_id}.")],
        },
    )


async def l3_done(state: AgentState) -> dict:
    logger.info("[L3 OSS Orchestration] done")
    return {"messages": [AIMessage(content="L3 OSS domain operations complete. Returning to L1 Master.")]}


def _visited_l3_agents(messages: list) -> set:
    visited = set()
    for agent_key in _AGENT_NODE_MAP.values():
        for msg in messages:
            if agent_key in str(getattr(msg, "content", "")):
                short = agent_key.replace("l3_", "")
                visited.add(short)
    return visited


def _next_in_plan(plan: list, visited: set):
    for step in plan:
        if step not in visited:
            return step
    return None


# ── System prompts ────────────────────────────────────────────────────────────

_L3_MANDATE = """
MANDATORY REASONING PROTOCOL:
1. FIRST call retrieve_playbook with a query describing the service/mediation/QoS issue.
2. THEN call query_knowledge_graph to ground the service-network-customer topology.
3. Use playbook and KG findings to justify your action before any data mutation.
4. Call append_audit after each data-mutating action.
"""

OSS_ENTRY_PROMPT = """You are the L3 OSS Orchestration Agent. You assess the service assurance context
to determine which L3 sub-agents are needed and retrieve OSS-layer evidence for L1 Master.
""" + _L3_MANDATE + """
Tools: tmf_get_service_problem, tmf_get_service_inventory, tmf_get_performance,
retrieve_playbook, query_knowledge_graph."""

SERVICE_PROBLEM_PROMPT = """You are the L3 Service Problem Agent. You create and manage TMF656 service problem
records for SLA breaches, QoS degradation, and session issues. Assess breach duration and scope.
""" + _L3_MANDATE + """
Tools: create_service_problem_tool, tmf_create_service_problem, tmf_get_service_problem,
evaluate_sla_breach_tool, retrieve_playbook, query_knowledge_graph, append_audit.
Output: service_problem_id, problem_type, sla_breach=true/false, affected_period."""

MEDIATION_REPLAY_PROMPT = """You are the L3 Mediation Replay Agent. You identify delayed or duplicate CDR
batches and trigger mediation replay or duplicate suppression. Own CDR replay lifecycle.
""" + _L3_MANDATE + """
Tools: get_mediation_evidence_tool, create_mediation_replay_tool, get_mediation_backlog_tool,
retrieve_playbook, query_knowledge_graph, append_audit.
Output: mediation_job_id, events_replayed, duplicate_suppressed=true/false, confirmation."""

QOS_SLICE_PROMPT = """You are the L3 QoS/Slice Correlation Agent. You compare committed QoS/NSSAI
entitlements (from PCF/policy) against delivered RAN/transport performance metrics.
""" + _L3_MANDATE + """
Tools: get_qos_evidence_tool, get_slice_performance_tool, evaluate_sla_breach_tool,
tmf_get_performance, retrieve_playbook, query_knowledge_graph.
Output: 5QI delivered vs. committed, NSSAI match=true/false, SLA breach period."""

SERVICE_TOPOLOGY_PROMPT = """You are the L3 Service Topology Agent. You dynamically stitch a service
topology from CMDB, live session state, slice configuration, and KG relationships to support RCA.
""" + _L3_MANDATE + """
Tools: query_cmdb, query_knowledge_graph, tmf_get_service_inventory, tmf_get_performance,
retrieve_playbook, append_audit.
Output: topology map (customer → service → slice/cell → NF → CHF path), ownership per node."""


def build_l3_oss_orchestration_graph(factory: AgentFactory, checkpointer=None):
    """Build the L3 OSS orchestration StateGraph with all 5 sub-agents."""
    from app.agents.tools import L3_TOOLS, SHARED_TOOLS, TMF_TOOLS

    all_l3_tools = L3_TOOLS + SHARED_TOOLS + TMF_TOOLS

    oss_entry_node = factory.create_agent(all_l3_tools, OSS_ENTRY_PROMPT, name="l3_oss_entry")
    service_problem_node = factory.create_agent(all_l3_tools, SERVICE_PROBLEM_PROMPT, name="l3_service_problem")
    mediation_replay_node = factory.create_agent(all_l3_tools, MEDIATION_REPLAY_PROMPT, name="l3_mediation_replay")
    qos_slice_node = factory.create_agent(all_l3_tools, QOS_SLICE_PROMPT, name="l3_qos_slice_correlation")
    topology_node = factory.create_agent(all_l3_tools, SERVICE_TOPOLOGY_PROMPT, name="l3_service_topology")

    builder = StateGraph(AgentState)
    builder.add_node("l3_oss_orchestration_entry", l3_oss_orchestration_entry)
    builder.add_node("l3_oss_entry", oss_entry_node)
    builder.add_node("l3_service_problem", service_problem_node)
    builder.add_node("l3_mediation_replay", mediation_replay_node)
    builder.add_node("l3_qos_slice_correlation", qos_slice_node)
    builder.add_node("l3_service_topology", topology_node)
    builder.add_node("l3_done", l3_done)

    builder.add_edge(START, "l3_oss_orchestration_entry")
    for agent_node in [
        "l3_oss_entry", "l3_service_problem", "l3_mediation_replay",
        "l3_qos_slice_correlation", "l3_service_topology",
    ]:
        builder.add_edge(agent_node, "l3_oss_orchestration_entry")
    builder.add_edge("l3_done", END)

    return builder.compile(checkpointer=checkpointer)
