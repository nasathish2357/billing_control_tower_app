"""
L1 Monitoring Agent — event correlation, playbook-driven issue creation.

Responsibilities:
- Query TMFEvent DB for new/uncorrelated events filtered by use_case_id.
- Retrieve correlation playbook to discover cross-layer grouping rules.
- Query KG to ground customer-account-event relationships.
- Transition matched event pairs/triplets to 'correlated' state.
- Create or confirm the Issue record with a correlation_key.

This agent runs FIRST in every remediation graph invocation.
"""
import datetime
import json
import logging
import uuid

from langchain_core.messages import AIMessage
from langgraph.types import Command

from app.agents.agent_state import AgentState

logger = logging.getLogger(__name__)


async def l1_monitoring_node(state: AgentState) -> Command:
    """
    L1 Monitoring Agent node.

    1. Uses query_event_db to find uncorrelated events for this use_case_id.
    2. Uses retrieve_playbook to find the correlation rule for this use case.
    3. Uses query_knowledge_graph to ground entity relationships.
    4. Uses update_event_state to mark matched events as 'correlated'.
    5. Updates Issue with correlation_key.
    6. Passes correlation findings to L1 Master via state.
    """
    from app.agents.tools.shared_tools import (
        retrieve_playbook, query_knowledge_graph,
        query_event_db, update_event_state,
    )
    from app.db.database import AsyncSessionFactory
    from app.models.models import Issue, TMFEvent
    from sqlalchemy import select

    use_case_id = state.get("use_case_id", "")
    issue_id = state.get("issue_id", "")
    customer_id = state.get("customer_id", "")
    billing_account_id = state.get("billing_account_id", "")

    logger.info("[L1 Monitoring] use_case=%s issue=%s", use_case_id, issue_id)

    findings = []
    correlation_key = None

    try:
        # Step 1: Query event DB for this use case
        events_result = await query_event_db.ainvoke({
            "use_case_id": use_case_id,
            "status": "new",
            "customer_id": customer_id,
        })
        events_data = json.loads(events_result)
        findings.append(f"Event DB: {events_data.get('total', 0)} new events, layers={events_data.get('layers_present', [])}, cross_layer={events_data.get('cross_layer', False)}")

        # Step 2: Retrieve correlation playbook
        playbook_result = await retrieve_playbook.ainvoke({
            "query": f"{use_case_id} event correlation cross-layer billing dispute telecom",
        })
        playbook_data = json.loads(playbook_result)
        playbook_text = " | ".join(playbook_data.get("playbooks", []))
        findings.append(f"Playbook: {playbook_text[:300]}")

        # Step 3: Query KG for entity grounding
        kg_result = await query_knowledge_graph.ainvoke({"issue_id": issue_id})
        kg_data = json.loads(kg_result)
        findings.append(f"KG: {kg_data.get('summary', 'no summary')}")

        # Step 4: Correlate events — generate shared correlation key
        events = events_data.get("events", [])
        if events:
            # Check if Issue already has a correlation_key; if not, create one
            async with AsyncSessionFactory() as db:
                issue_result = await db.execute(select(Issue).where(Issue.id == issue_id))
                issue = issue_result.scalar_one_or_none()
                if issue:
                    correlation_key = issue.correlation_key or f"CORR-{use_case_id}-{str(uuid.uuid4())[:8].upper()}"
                    if not issue.correlation_key:
                        issue.correlation_key = correlation_key
                        await db.commit()

            # Mark events as correlated
            correlated_count = 0
            for event in events[:10]:  # cap at 10 per run
                try:
                    await update_event_state.ainvoke({
                        "event_id": event["id"],
                        "new_status": "correlated",
                        "notes": f"Correlated by L1 Monitoring for {use_case_id}. Playbook match: {playbook_text[:100]}",
                    })
                    correlated_count += 1
                except Exception as e:
                    logger.warning("[L1 Monitoring] event state update failed for %s: %s", event["id"], e)

            findings.append(f"Correlated {correlated_count} events with key={correlation_key}")

    except Exception as exc:
        logger.error("[L1 Monitoring] error: %s", exc)
        findings.append(f"Monitoring error: {exc}")

    monitoring_summary = "; ".join(findings)
    logger.info("[L1 Monitoring] %s", monitoring_summary)

    return Command(
        goto="l1_master",
        update={
            "evidence_summary": monitoring_summary,
            "playbook_summary": findings[1] if len(findings) > 1 else None,
            "kg_context": findings[2] if len(findings) > 2 else None,
            "messages": [AIMessage(content=f"L1 Monitoring Agent: {monitoring_summary}")],
        },
    )
