"""
L1 Audit & Compliance Agent — immutable audit trace writer and compliance verifier.

Responsibilities:
- Verify that each domain layer's state transitions have matching playbook + KG + audit calls.
- Write an immutable AuditTrace record covering the full remediation lifecycle.
- Mark ControlCase as resolved and Issue as remediated.
- Append a structured final summary to state.
"""
import datetime
import logging

from langchain_core.messages import AIMessage
from langgraph.types import Command

from app.agents.agent_state import AgentState

logger = logging.getLogger(__name__)


async def l1_audit_node(state: AgentState) -> Command:
    """
    L1 Audit & Compliance Agent node.

    1. Verifies evidence packs exist for each visited domain layer.
    2. Writes immutable AuditTrace record.
    3. Marks Issue.status = 'remediated' and ControlCase.status = 'resolved'.
    4. Builds structured final summary (Findings, Resolution, Next Steps, Architecture Rule, Final State).
    5. Routes to __end__.
    """
    import datetime as dt
    from sqlalchemy import select
    from app.agents.tools.l1_tools import write_governance_audit
    from app.models.models import Issue, ControlCase, EvidencePack
    from app.db.database import AsyncSessionFactory

    use_case_id = state.get("use_case_id", "")
    issue_id = state.get("issue_id", "")
    control_case_id = state.get("control_case_id", "")
    approval_status = state.get("approval_status")

    # Guard: if control_case_id is missing, look it up by issue_id so the FK write succeeds
    if not control_case_id and issue_id:
        from app.models.models import ControlCase as _CC
        try:
            async with AsyncSessionFactory() as _db:
                _cc_r = await _db.execute(
                    select(_CC)
                    .where(_CC.issue_id == issue_id, _CC.resolved_at.is_(None))
                    .order_by(_CC.created_at.desc())
                    .limit(1)
                )
                _cc = _cc_r.scalar_one_or_none()
                if _cc:
                    control_case_id = _cc.id
                    logger.warning("[L1 Audit] control_case_id missing in state, resolved to %s via issue_id", control_case_id)
        except Exception as _e:
            logger.warning("[L1 Audit] could not resolve control_case_id for issue %s: %s", issue_id, _e)
    evidence_pack_ids = state.get("evidence_pack_ids", [])
    evidence_summary = state.get("evidence_summary", "")
    policy_decision = state.get("policy_decision", "")

    logger.info("[L1 Audit] use_case=%s issue=%s cc=%s", use_case_id, issue_id, control_case_id)

    async with AsyncSessionFactory() as db:
        # Update Issue status
        issue_result = await db.execute(select(Issue).where(Issue.id == issue_id))
        issue = issue_result.scalar_one_or_none()
        if issue:
            issue.status = "remediated" if approval_status != "rejected" else "closed"
            issue.updated_at = dt.datetime.utcnow()

        # Update ControlCase status
        cc_result = await db.execute(select(ControlCase).where(ControlCase.id == control_case_id))
        cc = cc_result.scalar_one_or_none()
        if cc:
            cc.status = "resolved"
            cc.resolved_at = dt.datetime.utcnow()

        # Count evidence packs per layer
        evp_result = await db.execute(
            select(EvidencePack).where(EvidencePack.control_case_id == control_case_id)
        )
        evps = evp_result.scalars().all()
        layers_with_evidence = list({evp.source_layer for evp in evps})

        # Write immutable AuditTrace
        trace_id = await write_governance_audit(
            db,
            control_case_id=control_case_id,
            action_type="agentic_remediation_complete",
            actor="L1 Audit & Compliance Agent",
            summary=(
                f"Full agentic remediation cycle complete for {use_case_id} / {issue_id}. "
                f"Layers with evidence: {layers_with_evidence}. "
                f"Policy: {policy_decision}. Approval: {approval_status}. "
                f"Evidence packs: {len(evps)}. {evidence_summary[-200:]}"
            ),
            issue_id=issue_id,
            use_case_id=use_case_id,
            evidence_pack_ids=evidence_pack_ids,
            approval_id=state.get("approval_id"),
            decision=policy_decision,
            actions_taken=state.get("planned_action_ids", []),
            commit=True,
        )

    # Build structured final summary
    summary = _build_summary(use_case_id, issue_id, evidence_summary, approval_status, layers_with_evidence, trace_id)

    logger.info("[L1 Audit] audit_trace_id=%s summary built", trace_id)
    return Command(
        goto="__end__",
        update={
            "audit_trace_id": trace_id,
            "final_response_summary": summary["resolution"],
            "messages": [AIMessage(content=f"L1 Audit & Compliance Agent: {summary['resolution']}")],
        },
    )


def _build_summary(
    use_case_id: str, issue_id: str, evidence: str,
    approval_status: str, layers: list, trace_id: str
) -> dict:
    findings_map = {
        "P1": "Mediation backlog delayed usage records past billing cycle. Late-rated events identified.",
        "P2": "Duplicate SMF CTF trigger caused same session to be rated twice in the charging engine.",
        "P3": "PDU session not released by SMF/UPF. CHF continued generating usage ticks on a zombie session.",
        "P4": "PCF policy mapping error caused standard-tier 5QI delivery despite premium slice subscription.",
        "P5": "Sustained RAN degradation confirmed across multiple days. SLA breach period documented.",
        "P6": "Full invoice entered dunning while partial dispute was active. Billing/AR sync gap.",
        "P7": "Roaming partner CDR feed diverged from home operator mediation output. Settlement mismatch confirmed.",
        "P8": "Bill charges are technically correct. Complexity arises from family plan proration and bundle adjustments.",
        "P9": "Duplicate interim CHF updates detected pre-bill for subscriber cohort. Suppressed before customer impact.",
        "P10": "Multi-site enterprise incident — QoS/service/billing evidence collected across all affected sites.",
    }
    resolution_map = {
        "P1": "Controlled rebill triggered for delayed usage period. Bill protection hold applied.",
        "P2": "Duplicate CDR suppressed at mediation layer. Credit applied for the duplicate charge.",
        "P3": "Zombie session force-terminated at SMF. Credit issued for post-release data charges.",
        "P4": "Premium surcharge removed for the affected period. Enterprise billing account credited.",
        "P5": "Commercial compensation credit applied per SLA breach assessment.",
        "P6": "Collections hold applied on disputed amount. Undisputed balance remains collectible.",
        "P7": "Retail credit applied to customer. Partner discrepancy recovery case filed with wholesale team.",
        "P8": "Bill explanation provided to customer with plain-language charge breakdown.",
        "P9": "Duplicate charges suppressed pre-bill. Subscriber cohort bills will be clean.",
        "P10": "Credits applied per site. Collections holds placed. Enterprise dispute case formally closed.",
    }
    next_steps_map = {
        "P1": "Monitor next billing cycle. Verify mediation guard prevents future late-rating.",
        "P2": "Enable duplicate suppression guard for this mediation path. Monitor for recurrence.",
        "P3": "Review SMF/UPF session release procedures. Enable zombie detection alerting.",
        "P4": "Fix PCF policy mapping for this customer profile. Validate slice delivery going forward.",
        "P5": "Investigate RAN capacity / congestion root cause. Schedule permanent fix with network ops.",
        "P6": "Improve billing-AR integration to auto-synchronize dispute status before dunning runs.",
        "P7": "Escalate mediation variance to partner. Review SEPP CDR reconciliation controls.",
        "P8": "Consider bill simplification initiative for family plans. Improve digital self-serve bill view.",
        "P9": "Root cause the CHF interim update duplication. Deploy monitoring alert for this pattern.",
        "P10": "Establish permanent enterprise dispute workflow. Governance process now documented in AuditTrace.",
    }

    approved = approval_status != "rejected"
    return {
        "findings": findings_map.get(use_case_id, f"Evidence collected for {use_case_id}. See EvidencePacks."),
        "resolution": (resolution_map.get(use_case_id, "Remediation applied.") if approved
                       else "Approval rejected — case closed without financial action. Issue logged for manual review."),
        "next_steps": next_steps_map.get(use_case_id, "Monitor and verify fix."),
        "architecture_rule": "Write-local, read-shared, orchestrate-through-owner.",
        "final_state": f"EventDB: correlated/in-progress → closed. AuditDB: {trace_id}. Layers: {layers}.",
        "audit_trace_id": trace_id,
    }
