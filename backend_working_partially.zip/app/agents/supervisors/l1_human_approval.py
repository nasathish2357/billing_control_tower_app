"""
L1 Human Approval Agent — HITL gate for governed remediation actions.

Uses LangGraph interrupt() to pause the graph and wait for human decision.
The interrupt payload includes full context: why the approval is needed,
evidence references, proposed action, and financial impact.

Resume path: POST /issues/{id}/approve with {decision: "approved"|"rejected", reason?}
→ Command(resume={decision, reason}) → graph continues.
"""
import datetime
import logging

from langchain_core.messages import AIMessage
from langgraph.types import Command, interrupt

from app.agents.agent_state import AgentState

logger = logging.getLogger(__name__)


async def l1_human_approval_node(state: AgentState) -> Command:
    """
    L1 Human Approval Agent node.

    Pauses execution via interrupt() with a detailed approval payload.
    On resume, routes back to L1 Master with the decision in state.
    """
    use_case_id = state.get("use_case_id", "")
    issue_id = state.get("issue_id", "")
    approval_id = state.get("approval_id", "")
    evidence_summary = state.get("evidence_summary", "")
    approval_status = state.get("approval_status")

    logger.info("[L1 Human Approval] use_case=%s issue=%s approval=%s status=%s",
                use_case_id, issue_id, approval_id, approval_status)

    # If already decided (resume path), route back to L1 Master
    if approval_status in ("approved", "rejected"):
        logger.info("[L1 Human Approval] already decided: %s", approval_status)
        return Command(goto="l1_master")

    # Build human-readable approval context
    why = _build_why(use_case_id, evidence_summary)
    proposed_action = _proposed_action(use_case_id)
    financial_impact = _financial_impact(use_case_id)
    evidence_refs = state.get("evidence_pack_ids", [])

    # Update Approval record with rich context for FE display
    await _enrich_approval_record(
        approval_id=approval_id,
        why=why,
        proposed_action=proposed_action,
        financial_impact=financial_impact,
        evidence_refs=evidence_refs,
    )

    # Interrupt graph — FE will receive awaiting_approval SSE event
    logger.info("[L1 Human Approval] pausing for human decision, approval_id=%s", approval_id)
    human_input = interrupt({
        "type": "human_approval",
        "approval_id": approval_id,
        "issue_id": issue_id,
        "use_case_id": use_case_id,
        "why": why,
        "proposed_action": proposed_action,
        "financial_impact": financial_impact,
        "evidence_refs": evidence_refs,
    })

    # Resume path: human_input = {"decision": "approved"|"rejected", "reason": "..."}
    decision = "rejected"
    rejection_reason = ""
    if isinstance(human_input, dict):
        decision = human_input.get("decision", "rejected")
        rejection_reason = human_input.get("reason", "")

    # Persist decision to Approval record
    await _record_decision(approval_id, decision, rejection_reason)

    logger.info("[L1 Human Approval] decision=%s reason=%s", decision, rejection_reason)
    return Command(
        goto="l1_master",
        update={
            "approval_status": decision,
            "messages": [AIMessage(content=f"L1 Human Approval: decision={decision}. {rejection_reason}")],
        },
    )


def _build_why(use_case_id: str, evidence_summary: str) -> str:
    reasons = {
        "P1": "Rebilling a customer carries risk of customer-facing impact and revenue leakage. Human oversight required before triggering a controlled rebill cycle.",
        "P4": "Removing a premium surcharge for an enterprise B2B customer has significant financial and contractual implications. SLA evidence must be reviewed.",
        "P5": "Commercial compensation for service degradation is a discretionary financial decision requiring manager sign-off before crediting the customer account.",
        "P7": "Dual-track action: retail credit to the customer AND partner dispute filing. The combined financial exposure and partner relationship impact require approval.",
        "P10": "Governed multi-domain enterprise dispute involves £7,800+ across multiple sites. Cross-team coordination and executive sign-off required before any credit.",
    }
    base_reason = reasons.get(use_case_id, f"High-risk financial action for {use_case_id} requires human oversight.")
    if evidence_summary:
        base_reason += f" Evidence summary: {evidence_summary[-300:]}"
    return base_reason


def _proposed_action(use_case_id: str) -> str:
    actions = {
        "P1": "Trigger a controlled rebill for the delayed usage period. Apply bill protection hold until rebill completes.",
        "P4": "Remove the premium 5G slice surcharge for the affected period. Issue credit note to enterprise billing account.",
        "P5": "Apply commercial compensation credit to customer account for sustained service degradation during the affected period.",
        "P7": "Apply retail credit to customer for disputed roaming charges AND file a partner discrepancy recovery case with the wholesale settlement team.",
        "P10": "Apply credit adjustments per affected site, issue formal credit notes, and place collections holds where applicable across all enterprise billing accounts.",
    }
    return actions.get(use_case_id, f"Execute approved remediation action for {use_case_id}.")


def _financial_impact(use_case_id: str) -> float:
    impacts = {
        "P1": 38.50, "P4": 29.99, "P5": 75.00, "P7": 3200.00, "P10": 7800.00,
    }
    return impacts.get(use_case_id, 50.0)


async def _enrich_approval_record(
    approval_id: str, why: str, proposed_action: str, financial_impact: float, evidence_refs: list
) -> None:
    """Update the Approval record with FE-displayable context."""
    if not approval_id:
        return
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import Approval

        async with AsyncSessionFactory() as db:
            result = await db.execute(select(Approval).where(Approval.id == approval_id))
            appr = result.scalar_one_or_none()
            if appr:
                appr.why = why
                appr.proposed_action = proposed_action
                appr.financial_impact = financial_impact
                appr.evidence_refs = evidence_refs
                await db.commit()
    except Exception as exc:
        logger.warning("[L1 Human Approval] enrich failed: %s", exc)


async def _record_decision(approval_id: str, decision: str, reason: str) -> None:
    """Persist the human decision to the Approval record."""
    if not approval_id:
        return
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import Approval

        async with AsyncSessionFactory() as db:
            result = await db.execute(select(Approval).where(Approval.id == approval_id))
            appr = result.scalar_one_or_none()
            if appr:
                appr.status = decision
                appr.decided_at = datetime.datetime.utcnow()
                if decision == "rejected":
                    appr.rejection_reason = reason
                else:
                    appr.approver_notes = reason
                await db.commit()
    except Exception as exc:
        logger.warning("[L1 Human Approval] decision record failed: %s", exc)
