"""
Hierarchical Multi-Agent Graph Builder — Billing Control Tower (MVP4).

Architecture:
  START
  └─ l1_monitoring          (L1 Monitoring Agent — event correlation)
     └─ l1_master           (L1 Master / Closed-Loop Control — central intelligence)
        ├─ l4_network_orchestration  (L4 subgraph — NF/session/charging evidence)
        ├─ l3_oss_orchestration      (L3 subgraph — OSS/mediation/QoS)
        ├─ l2_bss_orchestration      (L2 subgraph — BSS/billing/tickets)
        ├─ l1_human_approval         (HITL gate — interrupt/resume)
        └─ l1_audit                  (L1 Audit & Compliance — immutable trace)
           └─ END

Domain orchestration subgraphs return plain dicts (via their internal l*_done nodes).
Explicit edges route them back to l1_master for re-evaluation.
l1_master, l1_monitoring, l1_human_approval, l1_audit all use Command for routing.
"""
import logging

from langgraph.graph import END, START, StateGraph

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory

logger = logging.getLogger(__name__)


def build_agentic_graph(checkpointer=None):
    """
    Build and compile the full hierarchical multi-agent graph.

    Returns:
        Compiled LangGraph StateGraph.
    """
    from app.llm.gemini_provider import get_llm
    from app.agents.supervisors.l1_monitoring import l1_monitoring_node
    from app.agents.supervisors.l1_master import l1_master_node
    from app.agents.supervisors.l1_human_approval import l1_human_approval_node
    from app.agents.supervisors.l1_audit import l1_audit_node
    from app.agents.supervisors.l2_bss_orchestration import build_l2_bss_orchestration_graph
    from app.agents.supervisors.l3_oss_orchestration import build_l3_oss_orchestration_graph
    from app.agents.supervisors.l4_network_orchestration import build_l4_network_orchestration_graph

    llm = get_llm()
    factory = AgentFactory(llm)

    # ── Build domain orchestration subgraphs ─────────────────────────────────
    # checkpointer=True → subgraphs inherit the master graph's checkpointer.
    # Required for interrupt/resume to work correctly across subgraph boundaries.
    l2_graph = build_l2_bss_orchestration_graph(factory, checkpointer=True)
    l3_graph = build_l3_oss_orchestration_graph(factory, checkpointer=True)
    l4_graph = build_l4_network_orchestration_graph(factory, checkpointer=True)

    # ── Assemble master StateGraph ────────────────────────────────────────────
    builder = StateGraph(AgentState)

    # L1 layer nodes
    builder.add_node("l1_monitoring", l1_monitoring_node)
    builder.add_node("l1_master", l1_master_node)
    builder.add_node("l1_human_approval", l1_human_approval_node)
    builder.add_node("l1_audit", l1_audit_node)

    # Domain orchestration subgraphs as nodes
    builder.add_node("l4_network_orchestration", l4_graph)
    builder.add_node("l3_oss_orchestration", l3_graph)
    builder.add_node("l2_bss_orchestration", l2_graph)

    # ── Entry point ───────────────────────────────────────────────────────────
    builder.add_edge(START, "l1_monitoring")
    # l1_monitoring returns Command(goto="l1_master") — no additional edge needed

    # ── Domain subgraph returns ───────────────────────────────────────────────
    # Domain subgraphs return plain state dicts (their internal *_done nodes
    # return dict, not Command). Explicit edges route back to l1_master for
    # re-evaluation after each domain layer completes.
    builder.add_edge("l4_network_orchestration", "l1_master")
    builder.add_edge("l3_oss_orchestration", "l1_master")
    builder.add_edge("l2_bss_orchestration", "l1_master")

    # l1_human_approval, l1_audit → use Command internally for routing
    # l1_master → uses Command to dispatch to domains / approval / audit / __end__

    compiled = builder.compile(checkpointer=checkpointer)
    logger.info(
        "build_agentic_graph: compiled 7-node master graph with checkpointer=%r",
        type(checkpointer).__name__ if checkpointer else None,
    )
    return compiled


# ── Singleton with lazy init ──────────────────────────────────────────────────

_agentic_graph = None


def get_agentic_graph(checkpointer=None):
    """Return the compiled hierarchical agentic graph (lazy singleton)."""
    global _agentic_graph
    if _agentic_graph is None:
        _agentic_graph = build_agentic_graph(checkpointer)
        logger.info("✅ Agentic graph compiled (L1→L2/L3/L4 orchestration subgraphs).")
    return _agentic_graph


def reset_agentic_graph():
    """Reset the singleton — call when checkpointer changes."""
    global _agentic_graph
    _agentic_graph = None
