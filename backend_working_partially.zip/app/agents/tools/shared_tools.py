"""
Shared tools available to all agent layers (L1, L2, L3, L4).

These tools are cross-layer concerns:
  - Vector DB playbook retrieval
  - Knowledge Graph queries
  - Governance audit writing   (logic in l1_tools.write_governance_audit)
  - Billing risk assessment    (logic in l1_tools.assess_billing_risk)
"""
import json
import logging
from typing import Optional

from langchain_core.tools import tool

logger = logging.getLogger(__name__)


@tool
async def retrieve_playbook(query: str, n_results: int = 2) -> str:
    """
    Search the ChromaDB vector store for relevant remediation playbooks.

    Args:
        query: Natural language query describing the billing issue.
        n_results: Number of playbook chunks to retrieve (default 2).

    Returns:
        JSON string with matching playbook documents and metadata.
    """
    try:
        from app.vector_db.vector_store import similarity_search
        results = await similarity_search(query, n_results=n_results)
        if results:
            return json.dumps({"playbooks": [r["document"] for r in results]})
        return json.dumps({"playbooks": ["Standard remediation: gather evidence from L2/L3/L4, apply credit if confirmed."]})
    except Exception as exc:
        logger.warning("retrieve_playbook failed: %s", exc)
        return json.dumps({"playbooks": ["No playbook found — apply standard remediation protocol."]})


@tool
async def query_knowledge_graph(issue_id: str) -> str:
    """
    Query the NetworkX Knowledge Graph for entities and relationships
    reachable from the given issue_id.

    Args:
        issue_id: The issue ID to query KG relationships for.

    Returns:
        JSON string with nodes, edges, and relationship counts.
    """
    try:
        from app.kg.kg_queries import get_issue_relationships
        from app.db.database import AsyncSessionFactory
        async with AsyncSessionFactory() as db:
            result = await get_issue_relationships(db, issue_id)
        return json.dumps({
            "issue_id": result["issue_id"],
            "total_nodes": result.get("total_nodes", 0),
            "total_edges": result.get("total_edges", 0),
            "summary": f"KG: {result.get('total_nodes', 0)} nodes, {result.get('total_edges', 0)} edges reachable.",
        })
    except Exception as exc:
        logger.warning("query_knowledge_graph failed: %s", exc)
        return json.dumps({"summary": "KG: query failed — proceeding with direct evidence.", "error": str(exc)})


@tool
async def write_audit_trace(
    control_case_id: str,
    action_type: str,
    actor: str,
    summary: str,
    issue_id: Optional[str] = None,
    use_case_id: Optional[str] = None,
    evidence_pack_ids: Optional[str] = None,
    approval_id: Optional[str] = None,
    policy_decision: Optional[str] = None,
    actions_taken: Optional[str] = None,
) -> str:
    """
    Write a governance audit trace for a completed remediation action.

    Args:
        control_case_id: The control case this trace belongs to.
        action_type: Type of action (e.g. agentic_remediation, event_correlation).
        actor: The agent or component that performed the action.
        summary: Human-readable summary of what was done.
        issue_id: Associated issue ID (optional).
        use_case_id: Use case label P1-P10 (optional).
        evidence_pack_ids: JSON-encoded list of evidence pack IDs (optional).
        approval_id: Approval record ID if human approval was involved (optional).
        policy_decision: The policy decision taken (optional).
        actions_taken: JSON-encoded list of action IDs taken (optional).

    Returns:
        JSON string with the created audit_trace_id.
    """
    from app.agents.tools.l1_tools import write_governance_audit
    from app.db.database import AsyncSessionFactory

    evp_ids = json.loads(evidence_pack_ids) if evidence_pack_ids else []
    act_taken = json.loads(actions_taken) if actions_taken else []

    async with AsyncSessionFactory() as db:
        trace_id = await write_governance_audit(
            db,
            control_case_id=control_case_id,
            action_type=action_type,
            actor=actor,
            summary=summary,
            issue_id=issue_id,
            use_case_id=use_case_id,
            evidence_pack_ids=evp_ids,
            approval_id=approval_id,
            decision=policy_decision,
            actions_taken=act_taken,
        )
    return json.dumps({"audit_trace_id": trace_id})


@tool
async def query_event_db(
    use_case_id: str = "",
    status: str = "",
    source_layer: str = "",
    customer_id: str = "",
    correlation_key: str = "",
    limit: int = 20,
) -> str:
    """
    Query the TMFEvent database for events matching given filters.

    Args:
        use_case_id: Filter by use case (e.g. P2). Empty = any.
        status: Filter by status (new, correlated, in_progress, resolved, closed). Empty = any.
        source_layer: Filter by source layer (L2, L3, L4). Empty = any.
        customer_id: Filter by customer ID. Empty = any.
        correlation_key: Filter by shared correlation key across layers. Empty = any.
        limit: Maximum results to return (default 20).

    Returns:
        JSON with list of matching TMFEvents and a cross-layer summary.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import TMFEvent

        async with AsyncSessionFactory() as db:
            query = select(TMFEvent).order_by(TMFEvent.created_at.desc()).limit(limit)
            if use_case_id:
                query = query.where(TMFEvent.use_case_id == use_case_id)
            if status:
                query = query.where(TMFEvent.status == status)
            if source_layer:
                query = query.where(TMFEvent.source_layer == source_layer)
            if customer_id:
                query = query.where(TMFEvent.customer_id == customer_id)
            if correlation_key:
                query = query.where(TMFEvent.correlation_key == correlation_key)

            result = await db.execute(query)
            events = result.scalars().all()

            layers_present = list({e.source_layer for e in events})
            return json.dumps({
                "total": len(events),
                "layers_present": layers_present,
                "cross_layer": len(layers_present) > 1,
                "events": [
                    {
                        "id": e.id,
                        "event_type": e.event_type,
                        "source_layer": e.source_layer,
                        "status": e.status,
                        "severity": e.severity,
                        "customer_id": e.customer_id,
                        "correlation_key": e.correlation_key,
                        "description": e.description,
                        "created_at": e.created_at.isoformat() if e.created_at else None,
                    }
                    for e in events
                ],
            })
    except Exception as exc:
        logger.warning("query_event_db failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def update_event_state(event_id: str, new_status: str, notes: str = "") -> str:
    """
    Transition a TMFEvent to a new state after reasoning confirms it.

    Valid transitions: new → correlated → in_progress → resolved → closed.

    Args:
        event_id: The TMFEvent ID to update.
        new_status: Target status (correlated, in_progress, resolved, closed).
        notes: Optional reasoning note to store in payload.

    Returns:
        JSON confirming the state transition.
    """
    try:
        import datetime
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import TMFEvent

        async with AsyncSessionFactory() as db:
            result = await db.execute(select(TMFEvent).where(TMFEvent.id == event_id))
            event = result.scalar_one_or_none()
            if not event:
                return json.dumps({"error": f"TMFEvent {event_id} not found"})

            previous_status = event.status
            event.status = new_status
            if new_status == "correlated":
                event.correlated_at = datetime.datetime.utcnow()
            if notes:
                payload = dict(event.payload or {})
                payload["state_change_notes"] = notes
                event.payload = payload

            await db.commit()
            return json.dumps({
                "event_id": event_id,
                "previous_status": previous_status,
                "new_status": new_status,
            })
    except Exception as exc:
        logger.warning("update_event_state failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def query_cmdb(resource_id: str) -> str:
    """
    Query the CMDB (Configuration Management DB) for a network function or resource.

    Args:
        resource_id: NetworkFunction ID (e.g. NF-UPF-EAST-01) or nf_type (UPF, SMF, CHF).

    Returns:
        JSON with NF type, name, region, status, and host.
    """
    try:
        from sqlalchemy import select, or_
        from app.db.database import AsyncSessionFactory
        from app.models.models import NetworkFunction

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(NetworkFunction).where(
                    or_(NetworkFunction.id == resource_id, NetworkFunction.nf_type == resource_id)
                ).limit(5)
            )
            nfs = result.scalars().all()
            if not nfs:
                return json.dumps({"message": f"No network function found for {resource_id}"})
            return json.dumps({
                "query": resource_id,
                "network_functions": [
                    {
                        "id": nf.id,
                        "nf_type": nf.nf_type,
                        "name": nf.name,
                        "region": nf.region,
                        "status": nf.status,
                        "host": nf.host,
                    }
                    for nf in nfs
                ],
            })
    except Exception as exc:
        logger.warning("query_cmdb failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def evaluate_policy(action: str, context: str, amount: float = 0.0) -> str:
    """
    Evaluate a proposed remediation action against CSP policy guardrails.

    Args:
        action: The action to evaluate (e.g. apply_credit, apply_compensation, purge_session).
        context: Description of the situation (why this action is needed).
        amount: Financial amount involved (default 0.0).

    Returns:
        JSON with decision (auto_approved, requires_approval, denied), risk_reason, and threshold info.
    """
    try:
        from app.agents.tools.l1_tools import decide_action_policy
        from app.config import get_settings

        settings = get_settings()
        result = decide_action_policy(
            action=action,
            amount=amount,
            threshold=settings.human_approval_credit_threshold,
            bulk_customer_impact=("cohort" in context.lower() or "enterprise" in context.lower() or "multi-site" in context.lower()),
            auto_remediation_enabled=settings.auto_remediation_enabled,
        )
        return json.dumps({
            "action": action,
            "amount": amount,
            "decision": result["policy_decision"],
            "requires_approval": result["requires_human_approval"],
            "risk_reason": result.get("risk_reason", ""),
            "threshold": settings.human_approval_credit_threshold,
        })
    except Exception as exc:
        logger.warning("evaluate_policy failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def append_audit(
    control_case_id: str,
    actor: str,
    action: str,
    summary: str,
    evidence_refs: str = "[]",
    decision: str = "",
) -> str:
    """
    Append an immutable audit trace entry for a remediation action.

    Args:
        control_case_id: The control case this entry belongs to.
        actor: Agent or human that performed the action (e.g. "L3 Mediation Replay Agent").
        action: Action type (e.g. mediation_replay, cdr_suppression, collections_hold).
        summary: Human-readable summary of what was done and why.
        evidence_refs: JSON-encoded list of evidence pack IDs (default "[]").
        decision: Policy decision if relevant (auto_approved, requires_approval, rejected).

    Returns:
        JSON with the created audit_trace_id.
    """
    try:
        from app.agents.tools.l1_tools import write_governance_audit
        from app.db.database import AsyncSessionFactory

        evp_ids = json.loads(evidence_refs) if evidence_refs else []

        async with AsyncSessionFactory() as db:
            trace_id = await write_governance_audit(
                db,
                control_case_id=control_case_id,
                action_type=action,
                actor=actor,
                summary=summary,
                evidence_pack_ids=evp_ids,
                decision=decision or None,
                commit=True,
            )
        return json.dumps({"audit_trace_id": trace_id})
    except Exception as exc:
        logger.warning("append_audit failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def assess_billing_risk_tool(billing_account_id: str) -> str:
    """
    Run a proactive billing risk assessment for a billing account.
    Returns risk level, score (0-100), and detected risk signals.

    Args:
        billing_account_id: The billing account to assess.

    Returns:
        JSON string with risk_level, risk_score, signal_count, signals list, and summary.
    """
    from app.agents.tools.l1_tools import assess_billing_risk
    from app.db.database import AsyncSessionFactory

    async with AsyncSessionFactory() as db:
        result = await assess_billing_risk(db, billing_account_id)

    return json.dumps({
        "billing_account_id": result["billing_account_id"],
        "risk_level": result["risk_level"],
        "risk_score": result["risk_score"],
        "signal_count": result["signal_count"],
        "evidence_summary": result["evidence_summary"],
        "signals": [
            {"type": s["type"], "severity": s["severity"], "description": s["description"]}
            for s in result.get("signals", [])
        ],
    })
