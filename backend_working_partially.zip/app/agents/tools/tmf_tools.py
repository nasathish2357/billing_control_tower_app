"""
TMF API Tools — thin wrappers over PostgreSQL models providing TMForum-aligned
context retrieval for all agent layers.

APIs wrapped:
  TMF678 CustomerBill   — get_bill, get_bill_lines
  TMF635 ProductUsage   — get_product_usage
  TMF621 TroubleTicket  — get_trouble_ticket, create_trouble_ticket
  TMF656 ServiceProblem — get_service_problem, create_service_problem
  TMF638 ServiceInventory — get_service_inventory
  TMF628 Performance    — get_performance (NetworkFunction status proxy)
  TMF702 ResourceActivation — get_pdu_session
  TMF688 Event          — emit_event, get_events
"""
import datetime
import json
import logging
import uuid

from langchain_core.tools import tool

logger = logging.getLogger(__name__)


@tool
async def tmf_get_customer_bill(billing_account_id: str) -> str:
    """
    TMF678 — Retrieve latest bill for a billing account.

    Args:
        billing_account_id: The billing account ID (e.g. BA-100001).

    Returns:
        JSON with bill id, amount_due, billing_period, status, line_item_count.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import Bill, BillLineItem

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(Bill).where(Bill.billing_account_id == billing_account_id)
                .order_by(Bill.due_date.desc()).limit(3)
            )
            bills = result.scalars().all()
            if not bills:
                return json.dumps({"error": f"No bills found for {billing_account_id}"})

            latest = bills[0]
            line_result = await db.execute(
                select(BillLineItem).where(BillLineItem.bill_id == latest.id)
            )
            lines = line_result.scalars().all()

            return json.dumps({
                "bill_id": latest.id,
                "billing_account_id": billing_account_id,
                "billing_period": latest.billing_period,
                "amount_due": latest.amount_due,
                "status": latest.status,
                "line_item_count": len(lines),
                "disputed_line_count": sum(1 for l in lines if l.dispute_flag),
                "previous_bills": [{"id": b.id, "period": b.billing_period, "amount": b.amount_due} for b in bills[1:]],
            })
    except Exception as exc:
        logger.warning("tmf_get_customer_bill failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_bill_lines(bill_id: str) -> str:
    """
    TMF678 — Retrieve all line items for a bill.

    Args:
        bill_id: The bill ID (e.g. BILL-202604).

    Returns:
        JSON with list of line items: description, amount, charge_type, dispute_flag.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import BillLineItem

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(BillLineItem).where(BillLineItem.bill_id == bill_id)
            )
            lines = result.scalars().all()
            return json.dumps({
                "bill_id": bill_id,
                "line_items": [
                    {
                        "id": l.id,
                        "description": l.description,
                        "amount": l.amount,
                        "charge_type": l.charge_type,
                        "dispute_flag": l.dispute_flag,
                        "service_id": l.service_id,
                    }
                    for l in lines
                ],
            })
    except Exception as exc:
        logger.warning("tmf_get_bill_lines failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_product_usage(billing_account_id: str, limit: int = 10) -> str:
    """
    TMF635 — Retrieve recent usage events for a billing account.

    Args:
        billing_account_id: The billing account ID.
        limit: Maximum usage events to return (default 10).

    Returns:
        JSON with list of usage events: event_type, data_volume_bytes, start_time, charging_trigger.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import UsageEvent

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(UsageEvent).where(UsageEvent.billing_account_id == billing_account_id)
                .order_by(UsageEvent.start_time.desc()).limit(limit)
            )
            events = result.scalars().all()
            return json.dumps({
                "billing_account_id": billing_account_id,
                "usage_events": [
                    {
                        "id": e.id,
                        "event_type": e.event_type,
                        "session_id": e.session_id,
                        "data_volume_bytes": e.data_volume_bytes,
                        "duration_seconds": e.duration_seconds,
                        "start_time": e.start_time.isoformat() if e.start_time else None,
                        "end_time": e.end_time.isoformat() if e.end_time else None,
                        "charging_trigger": e.charging_trigger,
                        "network_element": e.network_element,
                    }
                    for e in events
                ],
            })
    except Exception as exc:
        logger.warning("tmf_get_product_usage failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_trouble_ticket(issue_id: str) -> str:
    """
    TMF621 — Retrieve trouble ticket linked to an issue.

    Args:
        issue_id: The issue ID (e.g. ISSUE-P5-001).

    Returns:
        JSON with ticket id, status, priority, description, resolution.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import TroubleTicket

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(TroubleTicket).where(TroubleTicket.issue_id == issue_id)
                .order_by(TroubleTicket.created_at.desc()).limit(1)
            )
            ticket = result.scalar_one_or_none()
            if not ticket:
                return json.dumps({"message": f"No ticket found for issue {issue_id}"})
            return json.dumps({
                "id": ticket.id,
                "ticket_type": ticket.ticket_type,
                "status": ticket.status,
                "priority": ticket.priority,
                "description": ticket.description,
                "resolution": ticket.resolution,
                "customer_id": ticket.customer_id,
            })
    except Exception as exc:
        logger.warning("tmf_get_trouble_ticket failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_create_trouble_ticket(
    issue_id: str,
    customer_id: str,
    billing_account_id: str,
    ticket_type: str,
    priority: str,
    description: str,
) -> str:
    """
    TMF621 — Create a new trouble ticket for a billing dispute or service complaint.

    Args:
        issue_id: Associated issue ID.
        customer_id: Customer ID.
        billing_account_id: Billing account ID.
        ticket_type: Type of ticket (billing_dispute, service_complaint, partner_dispute).
        priority: Ticket priority (low, medium, high, critical).
        description: Detailed description of the issue.

    Returns:
        JSON with the created ticket_id.
    """
    try:
        from app.db.database import AsyncSessionFactory
        from app.models.models import TroubleTicket

        ticket_id = f"TT-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
        async with AsyncSessionFactory() as db:
            ticket = TroubleTicket(
                id=ticket_id,
                issue_id=issue_id,
                customer_id=customer_id,
                billing_account_id=billing_account_id,
                ticket_type=ticket_type,
                priority=priority,
                description=description,
                status="open",
            )
            db.add(ticket)
            await db.commit()
        return json.dumps({"ticket_id": ticket_id, "status": "open"})
    except Exception as exc:
        logger.warning("tmf_create_trouble_ticket failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_service_problem(issue_id: str) -> str:
    """
    TMF656 — Retrieve service problem linked to an issue.

    Args:
        issue_id: The issue ID.

    Returns:
        JSON with service problem details: problem_type, severity, sla_breach, affected_period.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import ServiceProblem

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(ServiceProblem).where(ServiceProblem.issue_id == issue_id)
                .order_by(ServiceProblem.created_at.desc()).limit(1)
            )
            sp = result.scalar_one_or_none()
            if not sp:
                return json.dumps({"message": f"No service problem found for issue {issue_id}"})
            return json.dumps({
                "id": sp.id,
                "problem_type": sp.problem_type,
                "severity": sp.severity,
                "status": sp.status,
                "sla_breach": sp.sla_breach,
                "affected_period_start": sp.affected_period_start.isoformat() if sp.affected_period_start else None,
                "affected_period_end": sp.affected_period_end.isoformat() if sp.affected_period_end else None,
                "description": sp.description,
                "service_id": sp.service_id,
            })
    except Exception as exc:
        logger.warning("tmf_get_service_problem failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_create_service_problem(
    issue_id: str,
    customer_id: str,
    service_id: str,
    problem_type: str,
    severity: str,
    sla_breach: bool,
    description: str,
) -> str:
    """
    TMF656 — Create a service problem record.

    Args:
        issue_id: Associated issue ID.
        customer_id: Customer ID.
        service_id: Service affected (e.g. SVC-INV-001).
        problem_type: Type (service_degradation, outage, qos_breach, zombie_session).
        severity: Severity (low, medium, high, critical).
        sla_breach: Whether SLA is breached.
        description: Problem description.

    Returns:
        JSON with the created service_problem_id.
    """
    try:
        from app.db.database import AsyncSessionFactory
        from app.models.models import ServiceProblem

        sp_id = f"SP-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
        async with AsyncSessionFactory() as db:
            sp = ServiceProblem(
                id=sp_id,
                issue_id=issue_id,
                customer_id=customer_id,
                service_id=service_id,
                problem_type=problem_type,
                severity=severity,
                sla_breach=sla_breach,
                description=description,
                status="open",
            )
            db.add(sp)
            await db.commit()
        return json.dumps({"service_problem_id": sp_id, "status": "open"})
    except Exception as exc:
        logger.warning("tmf_create_service_problem failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_service_inventory(customer_id: str) -> str:
    """
    TMF638 — Retrieve service inventory (active services) for a customer.

    Args:
        customer_id: The customer ID.

    Returns:
        JSON with list of services: service_type, service_id, status, product_offering_id.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import ServiceInventory

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(ServiceInventory).where(ServiceInventory.customer_id == customer_id)
            )
            services = result.scalars().all()
            return json.dumps({
                "customer_id": customer_id,
                "services": [
                    {
                        "id": s.id,
                        "service_type": s.service_type,
                        "service_id": s.service_id,
                        "status": s.status,
                        "product_offering_id": s.product_offering_id,
                    }
                    for s in services
                ],
            })
    except Exception as exc:
        logger.warning("tmf_get_service_inventory failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_performance(customer_id: str) -> str:
    """
    TMF628 — Retrieve network performance context for a customer (via NetworkFunction status).

    Args:
        customer_id: Customer ID (used to find serving network functions via ServiceInventory).

    Returns:
        JSON with network function statuses relevant to the customer.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import NetworkFunction

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(NetworkFunction).where(NetworkFunction.status.in_(["degraded", "active"])).limit(10)
            )
            nfs = result.scalars().all()
            return json.dumps({
                "customer_id": customer_id,
                "network_functions": [
                    {
                        "id": nf.id,
                        "nf_type": nf.nf_type,
                        "name": nf.name,
                        "region": nf.region,
                        "status": nf.status,
                    }
                    for nf in nfs
                ],
            })
    except Exception as exc:
        logger.warning("tmf_get_performance failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_pdu_session(billing_account_id: str) -> str:
    """
    TMF702 — Retrieve PDU session records for a billing account (network resource activation).

    Args:
        billing_account_id: Billing account ID.

    Returns:
        JSON with PDU sessions: session_id, status (active/terminated/zombie), data_volume_gb.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import PDUSession

        async with AsyncSessionFactory() as db:
            result = await db.execute(
                select(PDUSession).where(PDUSession.billing_account_id == billing_account_id)
                .order_by(PDUSession.start_time.desc()).limit(10)
            )
            sessions = result.scalars().all()
            return json.dumps({
                "billing_account_id": billing_account_id,
                "pdu_sessions": [
                    {
                        "id": s.id,
                        "session_id": s.session_id,
                        "status": s.status,
                        "data_volume_gb": s.data_volume_gb,
                        "upf_node": s.upf_node,
                        "smf_node": s.smf_node,
                        "start_time": s.start_time.isoformat() if s.start_time else None,
                        "end_time": s.end_time.isoformat() if s.end_time else None,
                    }
                    for s in sessions
                ],
                "zombie_count": sum(1 for s in sessions if s.status == "zombie"),
            })
    except Exception as exc:
        logger.warning("tmf_get_pdu_session failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_emit_event(
    event_type: str,
    source_layer: str,
    use_case_id: str,
    customer_id: str,
    billing_account_id: str,
    severity: str,
    description: str,
    correlation_key: str = "",
) -> str:
    """
    TMF688 — Emit a new TMFEvent to the event database.

    Args:
        event_type: Type of event (e.g. SMF_CTF_TRIGGER, MEDIATION_BACKLOG).
        source_layer: Layer emitting the event (L2, L3, L4).
        use_case_id: Associated use case (P1–P10).
        customer_id: Customer ID.
        billing_account_id: Billing account ID.
        severity: Event severity (low, medium, high, critical).
        description: Human-readable description of the event.
        correlation_key: Optional shared UUID to group cross-layer events.

    Returns:
        JSON with the created event_id.
    """
    try:
        from app.db.database import AsyncSessionFactory
        from app.models.models import TMFEvent

        event_id = f"EVT-{use_case_id}-{str(uuid.uuid4())[:8].upper()}"
        async with AsyncSessionFactory() as db:
            evt = TMFEvent(
                id=event_id,
                event_type=event_type,
                source_layer=source_layer,
                use_case_id=use_case_id,
                customer_id=customer_id,
                billing_account_id=billing_account_id,
                severity=severity,
                description=description,
                correlation_key=correlation_key or None,
                status="new",
            )
            db.add(evt)
            await db.commit()
        return json.dumps({"event_id": event_id, "status": "new", "correlation_key": correlation_key})
    except Exception as exc:
        logger.warning("tmf_emit_event failed: %s", exc)
        return json.dumps({"error": str(exc)})


@tool
async def tmf_get_customer_context(customer_id: str) -> str:
    """
    Retrieve full customer context: customer profile, billing accounts, and active services.

    Args:
        customer_id: Customer ID (e.g. CUST-100001).

    Returns:
        JSON with customer name, segment, billing accounts, and service count.
    """
    try:
        from sqlalchemy import select
        from app.db.database import AsyncSessionFactory
        from app.models.models import Customer, BillingAccount, ServiceInventory

        async with AsyncSessionFactory() as db:
            cust_result = await db.execute(select(Customer).where(Customer.id == customer_id))
            customer = cust_result.scalar_one_or_none()
            if not customer:
                return json.dumps({"error": f"Customer {customer_id} not found"})

            ba_result = await db.execute(
                select(BillingAccount).where(BillingAccount.customer_id == customer_id)
            )
            accounts = ba_result.scalars().all()

            svc_result = await db.execute(
                select(ServiceInventory).where(ServiceInventory.customer_id == customer_id)
            )
            services = svc_result.scalars().all()

            return json.dumps({
                "customer_id": customer.id,
                "name": customer.name,
                "email": customer.email,
                "segment": customer.segment,
                "customer_type": customer.customer_type,
                "phone": customer.phone,
                "address": customer.address,
                "billing_accounts": [
                    {"id": a.id, "currency": a.currency, "status": a.status, "account_type": a.account_type}
                    for a in accounts
                ],
                "active_services": [
                    {"service_type": s.service_type, "service_id": s.service_id, "status": s.status}
                    for s in services if s.status == "active"
                ],
            })
    except Exception as exc:
        logger.warning("tmf_get_customer_context failed: %s", exc)
        return json.dumps({"error": str(exc)})


# ── Exported tool list ────────────────────────────────────────────────────────

TMF_TOOLS = [
    tmf_get_customer_bill,
    tmf_get_bill_lines,
    tmf_get_product_usage,
    tmf_get_trouble_ticket,
    tmf_create_trouble_ticket,
    tmf_get_service_problem,
    tmf_create_service_problem,
    tmf_get_service_inventory,
    tmf_get_performance,
    tmf_get_pdu_session,
    tmf_emit_event,
    tmf_get_customer_context,
]
