"""Prompts package — all agent prompts now live inline in their supervisor modules."""
