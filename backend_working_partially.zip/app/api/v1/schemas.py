from pydantic import BaseModel
from typing import List, Optional, Any
from datetime import datetime


class UseCaseOut(BaseModel):
    id: str
    name: str
    description: str
    priority: str
    flow_type: str
    status: str

    class Config:
        from_attributes = True


class IssueOut(BaseModel):
    id: str
    use_case_id: str
    customer_id: str
    billing_account_id: str
    bill_id: Optional[str] = None
    description: str
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class ControlCaseOut(BaseModel):
    id: str
    issue_id: str
    status: str
    thread_id: Optional[str] = None
    requires_human_approval: bool
    created_at: datetime
    resolved_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class AuditTraceOut(BaseModel):
    id: str
    control_case_id: str
    action_type: str
    actor: str
    summary: str
    details: Optional[dict] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ChatRequest(BaseModel):
    conversation_id: str
    message: str
    customer_id: Optional[str] = None
    billing_account_id: Optional[str] = None
    context: Optional[dict] = None


class RemediateRequest(BaseModel):
    """Optional body — issue_id is taken from the path parameter."""
    pass


# ─────────────────────────────────────────────────────────────────────────────
# MVP2 Schemas
# ─────────────────────────────────────────────────────────────────────────────

class TMFEventOut(BaseModel):
    id: str
    event_type: str
    use_case_id: Optional[str] = None
    source_layer: str
    severity: str
    status: str
    customer_id: Optional[str] = None
    billing_account_id: Optional[str] = None
    issue_id: Optional[str] = None
    control_case_id: Optional[str] = None
    description: str
    created_at: datetime

    class Config:
        from_attributes = True


class TMFEventCreate(BaseModel):
    event_type: str
    use_case_id: Optional[str] = None
    source_layer: str
    severity: Optional[str] = "medium"
    customer_id: Optional[str] = None
    billing_account_id: Optional[str] = None
    issue_id: Optional[str] = None
    description: str
    payload: Optional[dict] = None


class ApprovalOut(BaseModel):
    id: str
    thread_id: str
    issue_id: str
    control_case_id: str
    action: str
    risk_reason: str
    status: str
    approver_notes: Optional[str] = None
    amount: Optional[float] = None
    created_at: datetime
    decided_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class EvidencePackOut(BaseModel):
    id: str
    control_case_id: str
    source_layer: str
    summary: str
    created_at: datetime

    class Config:
        from_attributes = True


class BillingContextOut(BaseModel):
    customer_id: str
    customer_name: str
    segment: str
    billing_accounts: List[dict]
    recent_bills: List[dict]
    open_issues: List[dict]


class BillComparisonOut(BaseModel):
    billing_account_id: str
    current_bill: dict
    previous_bill: Optional[dict] = None
    delta_amount: Optional[float] = None
    delta_pct: Optional[float] = None
    comparison_summary: str
