"""
API Endpoints — Billing Control Tower (Agentic Architecture).

Routes:
  GET  /health
  GET  /use-cases
  GET  /issues
  GET  /issues/{issue_id}
  POST /issues/{issue_id}/remediate   ← routes through hierarchical agentic graph
  POST /chat/stream
  POST /chat
  GET  /audit-traces/{audit_trace_id}
  GET  /control-cases/{control_case_id}

Remediation now runs through the hierarchical multi-agent graph:
  L1 Supervisor → L2/L3/L4 Supervisors → Domain Sub-agents
All use cases P1-P10 are handled by the same agentic backbone.
P8 (chat/bill explanation) continues to use the SSE streaming generator.
"""

import logging
import uuid
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import UseCase, Issue, ControlCase, AuditTrace
from app.api.v1.schemas import (
    UseCaseOut, IssueOut, ControlCaseOut, AuditTraceOut,
    ChatRequest, RemediateRequest,
)
from app.agents.chat_graph import chat_stream_generator

logger = logging.getLogger(__name__)
router = APIRouter()

# All use cases handled by agentic graph (P8 uses SSE streaming path)
AGENTIC_USE_CASES = {"P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10"}
APPROVAL_USE_CASES = {"P1", "P5", "P7", "P10"}  # may trigger human interrupt


# ─────────────────────────────────────────────
#  Health
# ─────────────────────────────────────────────

@router.get("/health")
async def health():
    return {"status": "ok", "service": "Billing Control Tower", "mvp": "3"}


# ─────────────────────────────────────────────
#  Use Cases — returns all 10
# ─────────────────────────────────────────────

@router.get("/use-cases", response_model=List[UseCaseOut])
async def list_use_cases(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(UseCase).order_by(UseCase.priority))
    return result.scalars().all()


# ─────────────────────────────────────────────
#  Issues — returns all 10
# ─────────────────────────────────────────────

@router.get("/issues", response_model=List[IssueOut])
async def list_issues(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Issue).order_by(Issue.id))
    return result.scalars().all()


@router.get("/issues/{issue_id}", response_model=IssueOut)
async def get_issue(issue_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise HTTPException(status_code=404, detail=f"Issue {issue_id} not found")
    return issue


# ─────────────────────────────────────────────
#  Remediation
# ─────────────────────────────────────────────

@router.post("/issues/{issue_id}/remediate")
async def remediate_issue(issue_id: str, db: AsyncSession = Depends(get_db)):
    """
    Trigger agentic remediation for an issue via the hierarchical multi-agent graph.

    All use cases P1-P10 route through the L1 Supervisor → domain supervisors → sub-agents.
    P8 (bill explanation) is handled via POST /api/v1/chat/stream.

    Returns:
      - status: remediated | pending_approval
      - approval_id + thread_id if human interrupt triggered
      - audit_trace_id, evidence_pack_ids, final summary on completion
    """
    # Verify issue exists
    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise HTTPException(status_code=404, detail=f"Issue {issue_id} not found")

    use_case_id = issue.use_case_id

    if use_case_id not in AGENTIC_USE_CASES:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown use case {use_case_id}. Supported: {sorted(AGENTIC_USE_CASES)}.",
        )

    # ── Create ControlCase and thread ─────────────────────────────────────────
    from app.models.models import ControlCase as CC
    cc_id = f"CC-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    thread_id = f"THREAD-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    cc = CC(id=cc_id, issue_id=issue_id, status="investigating", thread_id=thread_id)
    db.add(cc)
    await db.commit()

    # ── Build initial AgentState ──────────────────────────────────────────────
    from app.agents.agent_state import AgentState
    from langchain_core.messages import HumanMessage

    initial_state: AgentState = {
        "messages": [HumanMessage(content=f"Remediate {use_case_id} issue: {issue_id}")],
        "use_case_id": use_case_id,
        "issue_id": issue_id,
        "control_case_id": cc_id,
        "thread_id": thread_id,
        "customer_id": issue.customer_id,
        "billing_account_id": issue.billing_account_id,
        "bill_id": issue.bill_id,
        "evidence_pack_ids": [],
        "evidence_summary": "",
        "playbook_summary": None,
        "kg_context": None,
        "policy_decision": None,
        "requires_human_approval": False,
        "approval_id": None,
        "approval_status": None,
        "planned_action_ids": [],
        "final_response_summary": None,
        "audit_trace_id": None,
        "is_remediated": False,
        "previous_bill_ids": [],
        "escalation_required": False,
        "visited_supervisors": set(),
        "error": None,
    }

    # ── Run hierarchical agentic graph ────────────────────────────────────────
    from app.agents.checkpoint_setup import get_checkpointer
    from app.agents.graph_builder import get_agentic_graph, reset_agentic_graph

    checkpointer = get_checkpointer()

    # Rebuild graph with fresh checkpointer if needed
    if checkpointer is not None:
        reset_agentic_graph()
    graph = get_agentic_graph(checkpointer)

    # Recursion limits sized to business logic — NOT arbitrary:
    #
    # Master graph (recursion_limit=50):
    #   Worst case = P10 governed multi-domain dispute with HITL:
    #     L1 → L2_graph → L1 → L3_graph → L1 → L4_graph → L1
    #     → HITL_interrupt → resume → L1 → L1_audit_agent → L1 → END
    #   = ~25 master-level steps. 50 = 2× buffer for subgraph transitions.
    #
    # Sub-agents (recursion_limit=8, set in factory.py):
    #   Each agent needs at most 4-5 tool calls (gather + decide).
    #   8 = 60% safety buffer. Prevents infinite loops on bad LLM responses.
    config = {
        "configurable": {"thread_id": thread_id},
        "recursion_limit": 50,
    }


    try:
        final_state = await graph.ainvoke(initial_state, config=config)
    except Exception as exc:
        from langgraph.errors import GraphRecursionError
        if isinstance(exc, GraphRecursionError):
            logger.error("Graph recursion limit exceeded for %s: %s", issue_id, exc)
            raise HTTPException(
                status_code=500,
                detail=f"Agentic graph exceeded recursion limit — possible loop detected for {issue_id}.",
            )
        logger.exception("Agentic graph failed for %s: %s", issue_id, exc)
        raise HTTPException(status_code=500, detail=f"Agentic graph error: {exc}")


    # ── Check for human approval interrupt ────────────────────────────────────
    if (
        final_state.get("requires_human_approval")
        or final_state.get("approval_status") == "pending"
        or (final_state.get("approval_id") and not final_state.get("audit_trace_id"))
    ):
        return {
            "issue_id": issue_id,
            "use_case_id": use_case_id,
            "control_case_id": cc_id,
            "status": "pending_approval",
            "approval_id": final_state.get("approval_id"),
            "thread_id": thread_id,
            "message": (
                "Human approval required. "
                "Use POST /api/v1/approvals/{approval_id}/approve to proceed."
            ),
        }

    return {
        "issue_id": issue_id,
        "use_case_id": use_case_id,
        "control_case_id": cc_id,
        "audit_trace_id": final_state.get("audit_trace_id"),
        "evidence_pack_ids": final_state.get("evidence_pack_ids", []),
        "policy_decision": final_state.get("policy_decision"),
        "is_remediated": final_state.get("is_remediated", False),
        "summary": final_state.get("final_response_summary"),
        "status": "remediated",
    }


# ─────────────────────────────────────────────
#  Simulation — per-issue trigger
# ─────────────────────────────────────────────

_UC_TO_SIM_TYPE = {
    "P1": "usage_delay",
    "P2": "duplicate_charge",
    "P3": "zombie_pdu_session",
    "P4": "qos_mismatch",
    "P5": "sla_breach",
    "P7": "partner_discrepancy",
    "P9": "proactive_risk",
}


@router.post("/issues/{issue_id}/simulate")
async def simulate_issue(issue_id: str, db: AsyncSession = Depends(get_db)):
    """
    Trigger the simulation scenario for a seeded issue.

    Maps the issue's use_case_id to a simulation_type and injects the
    appropriate billing anomaly artifacts (UsageEvents, PDUSessions, etc.).
    P6/P8/P10 have no simulation artefact injection — they return a no-op.
    """
    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise HTTPException(status_code=404, detail=f"Issue {issue_id} not found")

    use_case_id = issue.use_case_id
    sim_type = _UC_TO_SIM_TYPE.get(use_case_id)

    if not sim_type:
        return {
            "issue_id": issue_id,
            "use_case_id": use_case_id,
            "status": "no_simulation",
            "message": f"{use_case_id} has no simulation artefact injection — issue is pre-seeded.",
        }

    from app.agents.tools.l1_tools import inject_simulation
    sim_result = await inject_simulation(
        db,
        simulation_type=sim_type,
        customer_id=issue.customer_id or "CUST-100001",
        billing_account_id=issue.billing_account_id or "BA-100001",
        dry_run=False,
    )

    if isinstance(sim_result, dict) and sim_result.get("error"):
        raise HTTPException(status_code=422, detail=sim_result["error"])

    return {
        "issue_id": issue_id,
        "use_case_id": use_case_id,
        "simulation_type": sim_type,
        "status": "simulated",
        "artifacts": sim_result.get("artifacts", []) if isinstance(sim_result, dict) else [],
    }


# ─────────────────────────────────────────────
#  Remediation — SSE streaming
# ─────────────────────────────────────────────

@router.post("/issues/{issue_id}/remediate/stream")
async def remediate_issue_stream(issue_id: str, db: AsyncSession = Depends(get_db)):
    """
    Stream agentic remediation for an issue via LangGraph astream_events.

    Returns text/event-stream with 8 event types:
      step_start, agent_thought, tool_call, tool_result, step_complete,
      awaiting_approval, summary, error
    """
    from app.api.v1.stream import remediation_stream_generator

    result = await db.execute(select(Issue).where(Issue.id == issue_id))
    issue = result.scalar_one_or_none()
    if not issue:
        raise HTTPException(status_code=404, detail=f"Issue {issue_id} not found")

    use_case_id = issue.use_case_id

    # Create ControlCase and thread
    from app.models.models import ControlCase as CC
    cc_id = f"CC-{issue_id}-{str(uuid.uuid4())[:8].upper()}"
    thread_id = f"THREAD-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    cc = CC(id=cc_id, issue_id=issue_id, status="investigating", thread_id=thread_id)
    db.add(cc)
    await db.commit()

    from app.agents.agent_state import AgentState
    from langchain_core.messages import HumanMessage

    initial_state: AgentState = {
        "messages": [HumanMessage(content=f"Remediate {use_case_id} issue: {issue_id}")],
        "use_case_id": use_case_id,
        "issue_id": issue_id,
        "control_case_id": cc_id,
        "thread_id": thread_id,
        "customer_id": issue.customer_id,
        "billing_account_id": issue.billing_account_id,
        "bill_id": issue.bill_id,
        "evidence_pack_ids": [],
        "evidence_summary": "",
        "playbook_summary": None,
        "kg_context": None,
        "policy_decision": None,
        "requires_human_approval": False,
        "approval_id": None,
        "approval_status": None,
        "planned_action_ids": [],
        "final_response_summary": None,
        "audit_trace_id": None,
        "is_remediated": False,
        "previous_bill_ids": [],
        "escalation_required": False,
        "visited_supervisors": set(),
        "error": None,
    }

    from app.agents.checkpoint_setup import get_checkpointer
    from app.agents.graph_builder import get_agentic_graph, reset_agentic_graph

    checkpointer = get_checkpointer()
    if checkpointer is not None:
        reset_agentic_graph()
    graph = get_agentic_graph(checkpointer)

    config = {
        "configurable": {"thread_id": thread_id},
        "recursion_limit": 60,
    }

    async def _gen():
        async for chunk in remediation_stream_generator(issue_id, initial_state, graph, config):
            yield chunk

    return StreamingResponse(
        _gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "X-Thread-Id": thread_id,
            "X-Control-Case-Id": cc_id,
        },
    )


# ─────────────────────────────────────────────
#  Inline Approval — resume graph after HITL
# ─────────────────────────────────────────────

class ApproveRequest(BaseModel):
    approval_id: str
    decision: str          # "approved" | "rejected"
    reason: str = ""


@router.post("/issues/{issue_id}/approve")
async def approve_issue(
    issue_id: str,
    body: ApproveRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Resume a checkpointed graph after human approval or rejection.

    Injects Command(resume={decision, reason}) into the graph.
    The graph continues from the interrupt point in l1_human_approval_node.
    """
    from app.models.models import Approval, ControlCase as CC

    # Validate approval record
    appr_result = await db.execute(
        select(Approval).where(Approval.id == body.approval_id)
    )
    appr = appr_result.scalar_one_or_none()
    if not appr:
        raise HTTPException(status_code=404, detail=f"Approval {body.approval_id} not found")

    # Find thread_id via ControlCase — must be the active (not-yet-resolved) one.
    # order_by created_at desc so we get the latest CC; filter out already-resolved cases
    # to avoid picking up a completed thread_id from an earlier test run.
    cc_result = await db.execute(
        select(CC)
        .where(CC.issue_id == issue_id, CC.resolved_at.is_(None))
        .order_by(CC.created_at.desc())
        .limit(1)
    )
    cc = cc_result.scalar_one_or_none()
    if not cc:
        # fallback: any CC for this issue (resolved ones included)
        cc_result2 = await db.execute(
            select(CC).where(CC.issue_id == issue_id).order_by(CC.created_at.desc()).limit(1)
        )
        cc = cc_result2.scalar_one_or_none()
    if not cc:
        raise HTTPException(status_code=404, detail=f"No control case found for issue {issue_id}")

    thread_id = cc.thread_id
    decision = body.decision  # "approved" or "rejected"
    reason = body.reason

    from app.agents.checkpoint_setup import get_checkpointer
    from app.agents.graph_builder import get_agentic_graph
    from langgraph.types import Command

    checkpointer = get_checkpointer()
    graph = get_agentic_graph(checkpointer)
    config = {"configurable": {"thread_id": thread_id}, "recursion_limit": 60}

    try:
        resume_state = await graph.ainvoke(
            Command(resume={"decision": decision, "reason": reason}),
            config=config,
        )
    except Exception as exc:
        logger.exception("[approve] graph resume failed for issue=%s: %s", issue_id, exc)
        raise HTTPException(status_code=500, detail=f"Graph resume error: {exc}")

    return {
        "issue_id": issue_id,
        "approval_id": body.approval_id,
        "decision": decision,
        "audit_trace_id": resume_state.get("audit_trace_id") if isinstance(resume_state, dict) else None,
        "status": "resumed",
    }


# ─────────────────────────────────────────────
#  Chat — streaming (primary) and non-streaming
# ─────────────────────────────────────────────

@router.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    """
    Primary demo endpoint. Returns SSE stream per the MVP1 chat contract.
    Events: conversation_started, intent_detected, tool_started, tool_completed,
            evidence_loaded, token, audit_written, final, error
    """
    return StreamingResponse(
        chat_stream_generator(request.model_dump()),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/chat")
async def chat_simple(request: ChatRequest):
    """
    Non-streaming variant — collects all SSE chunks and returns the final_response.
    Useful for automated tests.
    """
    import json

    final_response = None
    audit_trace_id = None
    buffer = ""

    async for chunk in chat_stream_generator(request.model_dump()):
        buffer += chunk
        # Process complete SSE frames (each ends with \n\n)
        while "\n\n" in buffer:
            frame, buffer = buffer.split("\n\n", 1)
            event_type = None
            data_str = None
            for line in frame.split("\n"):
                if line.startswith("event:"):
                    event_type = line[len("event:"):].strip()
                elif line.startswith("data:"):
                    data_str = line[len("data:"):].strip()
            if event_type == "final" and data_str:
                try:
                    payload = json.loads(data_str)
                    final_response = payload.get("final_response")
                    audit_trace_id = payload.get("audit_trace_id")
                except json.JSONDecodeError:
                    pass

    return {
        "conversation_id": request.conversation_id,
        "final_response": final_response or "Unable to generate explanation.",
        "audit_trace_id": audit_trace_id,
    }



# ─────────────────────────────────────────────
#  Audit Traces
# ─────────────────────────────────────────────

@router.get("/audit-traces/{audit_trace_id}", response_model=AuditTraceOut)
async def get_audit_trace(audit_trace_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(AuditTrace).where(AuditTrace.id == audit_trace_id))
    trace = result.scalar_one_or_none()
    if not trace:
        raise HTTPException(status_code=404, detail=f"Audit trace {audit_trace_id} not found")
    return trace


# ─────────────────────────────────────────────
#  Control Cases
# ─────────────────────────────────────────────

@router.get("/control-cases/{control_case_id}", response_model=ControlCaseOut)
async def get_control_case(control_case_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ControlCase).where(ControlCase.id == control_case_id))
    cc = result.scalar_one_or_none()
    if not cc:
        raise HTTPException(status_code=404, detail=f"Control case {control_case_id} not found")
    return cc
