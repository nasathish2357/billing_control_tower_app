"""
SSE Streaming — LangGraph astream_events(v2) → Frontend SSE contract.

Frontend event types:
  step_start       — agent node begins (time, agent, layer, action)
  agent_thought    — streaming LLM token delta
  tool_call        — tool invocation started (tool, tool_key, input_summary)
  tool_result      — tool invocation completed (tool, output_summary, duration_ms)
  step_complete    — agent node finished (outcome, evidence_refs)
  awaiting_approval — graph interrupted for HITL (why, proposed_action, financial_impact, approval_id)
  summary          — terminal structured summary (findings, resolution, next_steps, ...)
  error            — exception payload

Layer mapping  : L1 blue · L2 green · L3 purple · L4 orange
Tool key map   : retrieve_playbook→vector  query_knowledge_graph→kg
                 query_event_db/update_event_state→event  query_cmdb→cmdb
                 evaluate_policy→policy  append_audit→audit  tmf_*→tmf
"""
import datetime
import json
import logging
import time
from typing import AsyncGenerator

logger = logging.getLogger(__name__)

# ── Label / layer / action maps ───────────────────────────────────────────────

_LAYER_MAP = {
    "l1_monitoring":           "L1",
    "l1_master":               "L1",
    "l1_human_approval":       "L1",
    "l1_audit":                "L1",
    "l4_network_orchestration":       "L4",
    "l4_network_orchestration_entry": "L4",
    "l4_network_entry":               "L4",
    "l4_charging_nf_correlation":     "L4",
    "l4_core_session":                "L4",
    "l4_resource_rca":                "L4",
    "l4_remediation_orchestrator":    "L4",
    "l4_done":                        "L4",
    "l3_oss_orchestration":           "L3",
    "l3_oss_orchestration_entry":     "L3",
    "l3_oss_entry":                   "L3",
    "l3_service_problem":             "L3",
    "l3_mediation_replay":            "L3",
    "l3_qos_slice_correlation":       "L3",
    "l3_service_topology":            "L3",
    "l3_done":                        "L3",
    "l2_bss_orchestration":           "L2",
    "l2_bss_orchestration_entry":     "L2",
    "l2_bss_entry":                   "L2",
    "l2_bill_insight":                "L2",
    "l2_usage_integrity":             "L2",
    "l2_backoffice_adjustment":       "L2",
    "l2_collections_dunning":         "L2",
    "l2_partner_settlement":          "L2",
    "l2_ticketing":                   "L2",
    "l2_done":                        "L2",
}

_LABEL_MAP = {
    "l1_monitoring":                  "L1 Monitoring Agent",
    "l1_master":                      "L1 Master Agent",
    "l1_human_approval":              "L1 Human Approval Agent",
    "l1_audit":                       "L1 Audit & Compliance Agent",
    "l4_network_orchestration":       "L4 Network Orchestration",
    "l4_network_orchestration_entry": "L4 Network Orchestration Agent",
    "l4_network_entry":               "L4 Network Entry Agent",
    "l4_charging_nf_correlation":     "L4 Charging NF Correlation Agent",
    "l4_core_session":                "L4 Core Session Agent",
    "l4_resource_rca":                "L4 Resource RCA Agent",
    "l4_remediation_orchestrator":    "L4 Remediation Orchestrator Agent",
    "l3_oss_orchestration":           "L3 OSS Orchestration",
    "l3_oss_orchestration_entry":     "L3 OSS Orchestration Agent",
    "l3_oss_entry":                   "L3 OSS Entry Agent",
    "l3_service_problem":             "L3 Service Problem Agent",
    "l3_mediation_replay":            "L3 Mediation Replay Agent",
    "l3_qos_slice_correlation":       "L3 QoS/Slice Correlation Agent",
    "l3_service_topology":            "L3 Service Topology Agent",
    "l2_bss_orchestration":           "L2 BSS Orchestration",
    "l2_bss_orchestration_entry":     "L2 BSS Orchestration Agent",
    "l2_bss_entry":                   "L2 BSS Entry Agent",
    "l2_bill_insight":                "L2 Bill Insight Agent",
    "l2_usage_integrity":             "L2 Usage Integrity Agent",
    "l2_backoffice_adjustment":       "L2 Backoffice Adjustment Agent",
    "l2_collections_dunning":         "L2 Collections & Dunning Agent",
    "l2_partner_settlement":          "L2 Partner Settlement Agent",
    "l2_ticketing":                   "L2 Ticketing Agent",
}

_ACTION_MAP = {
    "l1_monitoring":               "Event correlation",
    "l1_master":                   "Orchestration & planning",
    "l1_human_approval":           "Awaiting human decision",
    "l1_audit":                    "Audit & compliance write",
    "l4_network_orchestration":    "Network layer coordination",
    "l4_network_entry":            "Network context gathering",
    "l4_charging_nf_correlation":  "Charging trigger correlation",
    "l4_core_session":             "PDU session analysis",
    "l4_resource_rca":             "Root cause analysis",
    "l4_remediation_orchestrator": "Network remediation",
    "l3_oss_orchestration":        "OSS layer coordination",
    "l3_oss_entry":                "OSS context gathering",
    "l3_service_problem":          "Service problem management",
    "l3_mediation_replay":         "Mediation replay",
    "l3_qos_slice_correlation":    "QoS/slice correlation",
    "l3_service_topology":         "Service topology stitching",
    "l2_bss_orchestration":        "BSS layer coordination",
    "l2_bss_entry":                "BSS context gathering",
    "l2_bill_insight":             "Bill analysis",
    "l2_usage_integrity":          "Usage reconciliation",
    "l2_backoffice_adjustment":    "Billing adjustment",
    "l2_collections_dunning":      "Collections & dunning",
    "l2_partner_settlement":       "Partner settlement",
    "l2_ticketing":                "Trouble ticket management",
}

_TOOL_KEY_MAP = {
    "retrieve_playbook":     "vector",
    "query_knowledge_graph": "kg",
    "query_event_db":        "event",
    "update_event_state":    "event",
    "query_cmdb":            "cmdb",
    "evaluate_policy":       "policy",
    "append_audit":          "audit",
    "write_audit_trace":     "audit",
}

# Nodes that are purely routing (entry/done) — skip step_start for them
_SKIP_NODES = {"l4_done", "l3_done", "l2_done",
               "l4_network_orchestration_entry",
               "l3_oss_orchestration_entry",
               "l2_bss_orchestration_entry"}

# Nodes that are subgraph wrappers — skip outer wrapper, inner nodes fire separately
_SUBGRAPH_WRAPPERS = {"l4_network_orchestration", "l3_oss_orchestration", "l2_bss_orchestration"}


def _tool_key(name: str) -> str:
    if name in _TOOL_KEY_MAP:
        return _TOOL_KEY_MAP[name]
    if name.startswith("tmf_"):
        return "tmf"
    return "tool"


def _sse(event_type: str, payload: dict) -> str:
    return f"event: {event_type}\ndata: {json.dumps(payload)}\n\n"


def _now() -> str:
    return datetime.datetime.utcnow().isoformat() + "Z"


def _is_agent_node(name: str) -> bool:
    return name in _LAYER_MAP and name not in _SKIP_NODES


async def remediation_stream_generator(
    issue_id: str,
    initial_state: dict,
    graph,
    config: dict,
) -> AsyncGenerator[str, None]:
    """
    Async generator that streams SSE events for agentic remediation.

    Drives graph.astream_events(initial_state, version="v2", config=config)
    and translates LangGraph events to the 8-type SSE frontend contract.
    """
    step_counter = 0
    # step_id per active node name
    step_id_map: dict[str, str] = {}
    # tool call start times for duration_ms
    tool_start_times: dict[str, float] = {}
    # track which nodes we've already started (avoid subgraph duplicate starts)
    started_nodes: set[str] = set()

    try:
        async for event in graph.astream_events(
            initial_state, version="v2", config=config
        ):
            etype = event.get("event", "")
            name = event.get("name", "")
            data = event.get("data", {})
            metadata = event.get("metadata", {})

            # Resolve actual node name from metadata (handles subgraph nesting)
            node_name = metadata.get("langgraph_node") or name

            # ── step_start: agent chain starts ────────────────────────────────
            if etype == "on_chain_start" and _is_agent_node(node_name):
                if node_name not in started_nodes:
                    started_nodes.add(node_name)
                    step_counter += 1
                    sid = f"step_{step_counter}"
                    step_id_map[node_name] = sid
                    yield _sse("step_start", {
                        "step_id": sid,
                        "time": _now(),
                        "agent": _LABEL_MAP.get(node_name, node_name),
                        "layer": _LAYER_MAP.get(node_name, "L1"),
                        "action": _ACTION_MAP.get(node_name, "Processing"),
                        "node": node_name,
                    })

            # ── agent_thought: streaming LLM token ────────────────────────────
            elif etype == "on_chat_model_stream":
                chunk = data.get("chunk") or {}
                content = getattr(chunk, "content", None) or (
                    chunk.get("content") if isinstance(chunk, dict) else None
                ) or ""
                if content and node_name in step_id_map:
                    yield _sse("agent_thought", {
                        "step_id": step_id_map[node_name],
                        "delta": str(content),
                    })

            # ── tool_call: tool starts ────────────────────────────────────────
            elif etype == "on_tool_start":
                tool_run_id = event.get("run_id", name)
                tool_start_times[tool_run_id] = time.monotonic()
                sid = step_id_map.get(node_name) or (
                    step_id_map.get(list(step_id_map.keys())[-1])
                    if step_id_map else "step_0"
                )
                inp = data.get("input") or {}
                yield _sse("tool_call", {
                    "step_id": sid,
                    "tool": name,
                    "tool_key": _tool_key(name),
                    "input_summary": str(inp)[:200],
                })

            # ── tool_result: tool ends ────────────────────────────────────────
            elif etype == "on_tool_end":
                tool_run_id = event.get("run_id", name)
                elapsed = tool_start_times.pop(tool_run_id, None)
                duration_ms = int((time.monotonic() - elapsed) * 1000) if elapsed else None
                sid = step_id_map.get(node_name) or (
                    step_id_map.get(list(step_id_map.keys())[-1])
                    if step_id_map else "step_0"
                )
                output = data.get("output") or ""
                yield _sse("tool_result", {
                    "step_id": sid,
                    "tool": name,
                    "tool_key": _tool_key(name),
                    "output_summary": str(output)[:300],
                    "duration_ms": duration_ms,
                })

            # ── step_complete: agent chain ends ───────────────────────────────
            elif etype == "on_chain_end" and node_name in step_id_map:
                sid = step_id_map.pop(node_name, None)
                started_nodes.discard(node_name)
                if sid:
                    output = data.get("output") or {}
                    outcome = _extract_outcome(output, node_name)
                    yield _sse("step_complete", {
                        "step_id": sid,
                        "node": node_name,
                        "outcome": outcome,
                    })

    except Exception as exc:
        logger.exception("[stream] astream_events error for issue=%s: %s", issue_id, exc)
        yield _sse("error", {"message": str(exc), "issue_id": issue_id})
        return

    # ── Post-stream: check for interrupt (HITL approval pause) ───────────────
    try:
        snapshot = await graph.aget_state(config)
        if snapshot and snapshot.tasks:
            for task in snapshot.tasks:
                interrupts = getattr(task, "interrupts", ()) or ()
                if interrupts:
                    payload = interrupts[0].value if interrupts else {}
                    if isinstance(payload, dict) and payload.get("type") == "human_approval":
                        yield _sse("awaiting_approval", {
                            "step_id": f"approval_{payload.get('approval_id', 'pending')}",
                            "approval_id": payload.get("approval_id", ""),
                            "issue_id": payload.get("issue_id", issue_id),
                            "why": payload.get("why", "Human approval required."),
                            "proposed_action": payload.get("proposed_action", ""),
                            "financial_impact": payload.get("financial_impact", 0),
                            "evidence_refs": payload.get("evidence_refs", []),
                        })
                        return

        # ── Normal completion: emit summary ───────────────────────────────────
        final_values = snapshot.values if snapshot else {}
        summary_payload = _build_summary_payload(final_values)
        yield _sse("summary", summary_payload)

    except Exception as exc:
        logger.warning("[stream] post-stream state check failed: %s", exc)
        yield _sse("summary", {"findings": "", "resolution": "Remediation complete.", "next_steps": ""})


def _extract_outcome(output: dict | object, node_name: str) -> str:
    if isinstance(output, dict):
        msgs = output.get("messages", [])
        if msgs:
            last = msgs[-1]
            content = getattr(last, "content", None) or (
                last.get("content") if isinstance(last, dict) else None
            )
            if content:
                return str(content)[:300]
        summary = output.get("final_response_summary") or output.get("evidence_summary")
        if summary:
            return str(summary)[:300]
    return f"{_LABEL_MAP.get(node_name, node_name)} completed."


def _build_summary_payload(state: dict) -> dict:
    return {
        "findings":          state.get("evidence_summary", "")[:500],
        "resolution":        state.get("final_response_summary", "Remediation complete."),
        "next_steps":        "",
        "architecture_rule": "Write-local, read-shared, orchestrate-through-owner.",
        "final_state":       f"audit_trace={state.get('audit_trace_id')} is_remediated={state.get('is_remediated')}",
        "audit_trace_id":    state.get("audit_trace_id"),
    }
