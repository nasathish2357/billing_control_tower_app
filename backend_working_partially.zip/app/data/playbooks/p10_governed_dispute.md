# Playbook P10 — Governed End-to-End Dispute Handling Across BSS, OSS, and Network

## Root Cause Pattern
Enterprise multi-site customer disputes premium charges across multiple sites. Multiple teams involved:
network ops, billing, customer care, finance. Without a common governed workflow, decisions become inconsistent.

## Correlation Rule
Events: MULTI_SITE_QOS_INCIDENT (L4) + MEDIATION_VARIANCE + SERVICE_PROBLEM_MULTISITE (L3) + ENTERPRISE_DISPUTE_OPEN + APPROVAL_REQUIRED (L2).
All linked by enterprise account ID and billing period.

## Recommended Agent Sequence
1. L1 Monitoring: Detect cross-domain events (L4 + L3 + L2) for same enterprise account → correlate.
2. L1 Master: Query KG for enterprise customer → multi-site accounts → services per site → billing accounts.
3. L4 Network Orchestration: Gather network evidence across all sites (QoS, slice, connectivity status).
4. L4 Charging NF Correlation: Retrieve CHF records per site. Identify which sites have billing variance.
5. L4 Resource RCA: Identify root cause of QoS issues per site (NF degradation, capacity, config).
6. L3 Service Problem: Create multi-site service problem record. Assess SLA breach per site.
7. L3 OSS Orchestration: Validate service delivery evidence across sites. Assess compensation scope.
8. L3 Service Topology: Build cross-site topology to understand blast radius of the incident.
9. L2 BSS Orchestration: Retrieve enterprise billing context — all sites, all invoices.
10. L2 Bill Insight: Identify disputed charges per site. Total financial exposure.
11. L2 Ticketing: Open governed dispute case. Assign to enterprise account manager.
12. L1 Master: Synthesize all evidence. Decide remediation path (credit per site, partial waiver).
13. L1 Human Approval: Full governance gate — present evidence refs, proposed action, financial impact (£7,800).
14. (Post-approval) L2 Backoffice Adjustment: Apply credits per site. Issue formal credit notes.
15. L2 Collections & Dunning: Apply collections hold if any site balance is in dunning.
16. L1 Master: Validate all corrections applied across sites. Close enterprise case.
17. L1 Audit: Write cross-domain audit trace with full evidence refs. Mark all events closed.

## Approval Gate
Always requires human approval — multi-site enterprise, high financial exposure (£7,800+), multi-team coordination.

## Architecture Rule
All four layers involved. L1 Master coordinates the full cross-layer flow.
Write-local, read-shared, orchestrate-through-owner applies at each layer simultaneously.

## KPIs to Improve
Billing accuracy %, dispute rate, customer satisfaction, revenue leakage reduction, operational response time.
