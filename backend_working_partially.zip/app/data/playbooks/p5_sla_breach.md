# Playbook P5 — Service Degradation Requiring Commercial Compensation

## Root Cause Pattern
Customer experiences persistent service degradation (latency spikes, packet loss) over multiple days.
Bill may be technically correct but customer deserves commercial compensation for degraded service.

## Correlation Rule
Events: RAN_LATENCY_SPIKE (L4, multi-day pattern) + SERVICE_PROBLEM_DEGRADATION (L3) + TICKET_OPEN_COMPENSATION_REQ (L2).

## Recommended Agent Sequence
1. L1 Monitoring: Detect sustained RAN_LATENCY_SPIKE events (multi-day) + service degradation signal → correlate.
2. L1 Master: Query KG for customer → service → serving cell/NF → performance history.
3. L3 Service Problem: Create/retrieve service problem record. Confirm SLA breach duration and scope.
4. L3 OSS Orchestration: Validate degradation period using performance analytics. Confirm it affected this customer.
5. L2 Ticketing: Open service complaint ticket linked to the issue. Record degradation evidence.
6. L2 BSS Orchestration: Look up customer contract — check compensation clause and eligible amount.
7. L1 Human Approval: Surface approval request with full evidence — duration, impact, proposed credit amount, financial exposure.
8. (Post-approval) L2 Backoffice Adjustment: Apply compensation credit to the billing account.
9. L1 Master: Validate credit applied. Confirm ticket resolved. Close service problem.
10. L1 Audit: Write immutable trace. Mark events closed.

## Approval Gate
Commercial compensation always requires human approval — subjective judgment + financial risk.
Approval block must include: degradation period, affected area, proposed compensation amount, SLA clause reference.

## Architecture Rule
L3 owns service problem and performance evidence. L2 owns ticket, compensation, and credit. L4 provides RAN degradation signals.

## KPIs to Improve
Reduction in credits & adjustments, SLA breach rate, churn rate, first call resolution %.
