# Playbook P8 — Confusing Invoice with Technically Valid but Opaque Charges

## Root Cause Pattern
Customer cannot understand their bill — multiple prorated items, bundle adjustments, device repayments,
and shared-data allocations that are individually valid but opaque in aggregate.

## Correlation Rule
Event: BILL_OPACITY_SIGNAL (L2) — high line-item count with multiple charge types on same bill.
No network-level fault. This is a bill-clarity / customer-experience case.

## Recommended Agent Sequence
1. L1 Monitoring: Detect BILL_OPACITY_SIGNAL (high line-item count, complex bundle) → create issue.
2. L1 Master: Query KG for customer → billing account → bill → all line items → product offerings.
3. L2 Bill Insight: Retrieve all bill line items. Group by charge_type. Identify which items are most confusing.
4. L2 Usage Integrity: Map usage events to line items. Confirm all charges have valid CDR backing.
5. L3 Service Topology: Build topology of customer services (family plan, shared data, add-ons) for context.
6. L2 BSS Orchestration: Generate plain-language explanation of each charge group.
7. Chat Agent: Provide natural-language bill explanation to the customer via the unified chat interface.
8. L1 Audit: Write trace. Mark events closed (no financial adjustment needed).

## Approval Gate
No approval required — read-only investigation and explanation only.

## Architecture Rule
No network remediation. L2 owns bill context. L3 Service Topology provides service graph for explanation.

## KPIs to Improve
Reduction in bill explanation calls, dispute rate per invoice, digital self-care usage %.
