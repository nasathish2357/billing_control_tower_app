# Playbook P6 — Collections Hold Required During Billing Dispute

## Root Cause Pattern
Customer disputes a portion of their invoice, but the accounts receivable process is not synchronized
with the dispute status — full amount progresses into dunning/collections.

## Correlation Rule
Events: DISPUTE_RAISED (L2) + DUNNING_NOTICE_QUEUED (L2) sharing billing_account_id.
Cross-check: disputed amount vs. undisputed balance. Separate them before collections acts.

## Recommended Agent Sequence
1. L1 Monitoring: Detect DISPUTE_RAISED + DUNNING_NOTICE_QUEUED for same account → correlate.
2. L1 Master: Query KG for customer → billing account → disputed bill → dispute record.
3. L2 Ticketing: Open billing dispute ticket. Record disputed amount (£28) vs. total (£96).
4. L2 Collections & Dunning: Check current dunning state. If full amount is in dunning, pause it.
5. L2 BSS Orchestration: Retrieve bill details. Confirm disputed vs. undisputed split.
6. L2 Collections & Dunning: Apply collections hold on the disputed portion (£28). Allow undisputed balance (£68) to proceed.
7. L1 Master: Validate hold applied. Confirm undisputed amount still collectible. Close.
8. L1 Audit: Write audit trace. Mark events closed.

## Approval Gate
No human approval required — hold is a protective, reversible action. Automated within policy.

## Architecture Rule
L2 owns all BSS actions. No L3/L4 involvement for P6. Write-local, read-shared.

## KPIs to Improve
Reduction in wrongful dunning cases, dispute handling cycle time, collections accuracy %.
