# Playbook P1 — Missing or Delayed Usage Feed into Billing

## Root Cause Pattern
Mediation backlog or delayed ingestion path causes usage records to miss the billing cycle window.
Typical triggers: high-traffic period near bill close, mediation system overload, SMF/UPF probe delays.

## Correlation Rule
Events to correlate: MEDIATION_BACKLOG (L3) + BILL_GENERATED_INCOMPLETE (L2) sharing the same billing_account_id within the same billing period.

## Recommended Agent Sequence
1. L1 Monitoring: Correlate MEDIATION_BACKLOG + BILL_GENERATED_INCOMPLETE events → mark correlated/in_progress.
2. L1 Master: Query KG for customer-account-service-mediation chain. Determine which usage batch is missing.
3. L4 Charging NF Correlation: Identify which CHF/CTF records exist vs. expected for the session window.
4. L3 Mediation Replay: Trigger mediation replay job for the delayed batch. Confirm records reach billing.
5. L3 OSS Orchestration: Verify replay completion and billing system acceptance.
6. L2 Usage Integrity: Confirm rated usage appears correctly on the billing account.
7. L2 Bill Insight: Assess impact on current bill (underbilling detected?).
8. L2 Backoffice Adjustment: Apply bill protection hold; schedule controlled rebill if usage is confirmed late.
9. L1 Master: Validate fix — confirm usage now rated and bill accurate. If rebill needed, flag for approval.
10. L1 Audit: Write immutable audit trace. Close events.

## Approval Gate
Rebilling a customer requires human approval (risk of customer-facing impact).

## Architecture Rule
Write-local, read-shared, orchestrate-through-owner.
L3 owns mediation replay. L2 owns billing adjustment. L4 owns usage trigger evidence.

## KPIs to Improve
Reduction in revenue leakage %, first bill accuracy %, rebill volume.
