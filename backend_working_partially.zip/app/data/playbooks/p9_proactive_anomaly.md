# Playbook P9 — Internal Anomaly Discovered by Monitoring Before Customer Impact

## Root Cause Pattern
Monitoring dashboard detects unusual pattern (e.g. duplicate interim charging updates) affecting a subscriber cohort
BEFORE bills are generated. Operator can suppress the anomaly and prevent customer-facing impact.

## Correlation Rule
Events: CHF_DUPLICATE_INTERIM_UPDATES (L4, cohort-wide) + MEDIATION_ANOMALY (L3) + PRE_BILL_SUPPRESS_CANDIDATE (L2).
Time window: pre-bill-close. No customer complaint yet.

## Recommended Agent Sequence
1. L1 Monitoring: Detect CHF_DUPLICATE_INTERIM_UPDATES affecting cohort → correlate with mediation anomaly.
2. L1 Master: Query KG for cohort → affected accounts → billing period → mediation batch.
3. L4 Charging NF Correlation: Identify which CHF is generating duplicate interim updates. Confirm cohort scope.
4. L3 Mediation Replay: Identify affected CDR batch. Activate duplicate suppression guard.
5. L3 OSS Orchestration: Validate suppression completed. Confirm clean mediation output for the cohort.
6. L2 Bill Insight: Verify pre-bill state — confirm duplicate charges NOT present on in-flight bills.
7. L2 Backoffice Adjustment: If any charges already rated (partial batch), apply pre-bill hold and correction.
8. L1 Master: Validate — confirm cohort bills will be clean. Close pre-emptively.
9. L1 Audit: Write proactive-remediation audit trace. Mark events closed.

## Approval Gate
No human approval required — proactive suppression is protective and reversible.

## Architecture Rule
L4 owns CHF anomaly detection. L3 owns mediation suppression. L2 owns pre-bill protection.
Pre-bill action taken before customer sees impact — highest-value use case for autonomous agentic systems.

## KPIs to Improve
Reduction in customer-impacting incidents, anomaly detection lead time, pre-bill correction rate, dispute avoidance %.
