# Playbook P2 — Duplicate Charging / Duplicate Usage Rating

## Root Cause Pattern
Same usage event rated twice due to mediation replay without duplicate suppression, or duplicate SMF CTF triggers for the same data session.
Customer sees two near-identical charge entries for the same service window.

## Correlation Rule
Events to correlate: SMF_CTF_TRIGGER×2 (L4, same session_id) + MEDIATION_REPLAY (L3) + RATED_USAGE_DUPLICATE (L2).
All share billing_account_id and session_id within a 30-minute window.

## Recommended Agent Sequence
1. L1 Monitoring: Detect paired SMF_CTF_TRIGGER events (L4) + RATED_USAGE_DUPLICATE (L2) with same session → correlate.
2. L1 Master: Query KG for customer → billing account → usage event chain. Identify duplicate CDR pair.
3. L4 Charging NF Correlation: Confirm duplicate CHF/CTF trigger records. Identify originating NF.
4. L4 Core Session: Retrieve session record — confirm it was a single session (one start, one end).
5. L3 Mediation Replay: Identify which mediation export caused duplication. Confirm duplicate suppression gap.
6. L1 Master: Analyze — is the duplicate in rating or in mediation export? Decide suppression vs. CDR reversal.
7. L3 Mediation Replay: Suppress/reverse the duplicate CDR. Confirm idempotent replay guard is now active.
8. L2 Bill Insight: Retrieve bill lines — identify duplicate charge entry.
9. L2 Backoffice Adjustment: Apply credit for the duplicate charge. Reference CDR ID in adjustment.
10. L1 Master: Validate — confirm only one charge entry remains, credit applied. Close.
11. L1 Audit: Append audit trace. Mark events closed.

## Approval Gate
No human approval required for auto-suppression if amount < threshold. Credit applied automatically.

## Architecture Rule
Write-local, read-shared, orchestrate-through-owner.
L4 owns CHF/CTF evidence. L3 owns mediation suppression. L2 owns credit/adjustment.

## KPIs to Improve
Dispute rate per 1,000 invoices, duplicate charge incident rate, credit note value reduction.
