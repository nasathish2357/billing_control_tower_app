# Playbook P7 — Partner or Wholesale Charge Discrepancy

## Root Cause Pattern
Roaming or partner-network charges differ between what the visited network records and what the home
operator rates. Customer faces a higher roaming charge than expected. Retail and wholesale teams must act independently.

## Correlation Rule
Events: ROAMING_PARTNER_USAGE_HIGH (L4) + MEDIATION_PARTNER_VARIANCE (L3) + RETAIL_BILL_DISPUTE + PARTNER_SETTLEMENT_DELTA (L2).

## Recommended Agent Sequence
1. L1 Monitoring: Detect ROAMING_PARTNER_USAGE_HIGH + RETAIL_BILL_DISPUTE → correlate cross-layer.
2. L1 Master: Query KG for customer → roaming session → partner account → settlement record.
3. L4 Charging NF Correlation: Retrieve SEPP/CHF roaming CDR evidence from visited network feed.
4. L3 Mediation Replay: Compare home operator mediation output vs. partner CDR feed. Identify variance source.
5. L2 Partner Settlement: Retrieve settlement record. Calculate discrepancy amount.
6. L2 Bill Insight: Retrieve retail bill — identify which line items reflect the disputed roaming charge.
7. L1 Master: Decide retail path (customer credit) and wholesale path (partner recovery) separately.
8. L1 Human Approval: Seek approval for combined retail credit + partner dispute filing (financial exposure).
9. (Post-approval) L2 Backoffice Adjustment: Apply retail credit to customer. Reference partner case.
10. L2 Partner Settlement: File partner discrepancy recovery case. Update settlement status.
11. L1 Master: Validate retail fix applied. Partner case filed. Close customer-facing issue.
12. L1 Audit: Write full trace. Mark events closed.

## Approval Gate
Retail credit + wholesale recovery requires human approval (dual-track financial action, £3,200 exposure).

## Architecture Rule
L4 owns roaming CDR/SEPP evidence. L3 owns mediation variance. L2 owns retail billing and partner settlement.
Retail path (customer) and wholesale path (partner) are coordinated by L1 Master but executed independently.

## KPIs to Improve
Roaming dispute rate, settlement accuracy %, wholesale leakage %, partner dispute resolution cycle time.
