# Playbook P3 — Zombie PDU Session Causing Unfair Data Charging

## Root Cause Pattern
PDU session not properly released by SMF/UPF after customer ends usage. CHF continues receiving usage ticks.
Customer sees ongoing data charges after device is idle — "zombie" session.

## Correlation Rule
Events to correlate: PDU_SESSION_NOT_RELEASED (L4) + CHF_USAGE_TICK_POST_RELEASE (L4) + RATED_USAGE_OVERRUN (L2).
Identify via session_id where end_time is null or stale, with usage events timestamped after expected session end.

## Recommended Agent Sequence
1. L1 Monitoring: Detect PDU_SESSION_NOT_RELEASED + CHF_USAGE_TICK_POST_RELEASE events → correlate.
2. L1 Master: Query KG for customer → PDU session → CHF records → billing account chain.
3. L4 Core Session: Retrieve PDU session record. Confirm status=zombie. Check SMF/UPF state mismatch.
4. L4 Resource RCA: Identify root cause — SMF release failure, UPF state stale, or CHF trigger not stopped.
5. L4 Remediation Orchestrator: Purge/force-terminate the zombie session at SMF level. Confirm session closed.
6. L3 Service Problem: Create service problem record for zombie session event. Link to customer.
7. L2 Usage Integrity: Calculate overcharged data volume (from session end intent to actual close time).
8. L2 Backoffice Adjustment: Apply credit for zombie session charges. Reference session_id and volume.
9. L1 Master: Validate — confirm session purged, usage overage credited, no new ticks. Close.
10. L1 Audit: Write audit trace. Mark events closed.

## Approval Gate
No human approval required if session is confirmed zombie and credit amount < threshold.

## Architecture Rule
L4 owns session lifecycle and remediation. L3 owns problem lifecycle. L2 owns billing correction.

## KPIs to Improve
Dispute resolution time, data usage accuracy %, credit adjustment value, customer trust/NPS.
