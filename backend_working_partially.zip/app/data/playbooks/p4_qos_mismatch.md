# Playbook P4 — QoS or Slice Entitlement Mismatch with Premium Charging

## Root Cause Pattern
Customer charged for premium 5G slice (e.g. 5QI 80 / enterprise NSSAI) but policy mapping is incorrect
or RAN delivered standard-tier performance. Premium charge without premium delivery.

## Correlation Rule
Events: RAN_QOS_DEGRADED (L4) + POLICY_5QI_MISMATCH (L4) + QOS_SLICE_VARIANCE (L3) + PREMIUM_BILL_LINE (L2).
Correlate via service_id (slice identifier) and billing_account_id.

## Recommended Agent Sequence
1. L1 Monitoring: Detect RAN_QOS_DEGRADED + POLICY_5QI_MISMATCH events → correlate with PREMIUM_BILL_LINE.
2. L1 Master: Query KG for customer → product offering (premium tier) → service inventory → slice/NSSAI → billing.
3. L4 Charging NF Correlation: Retrieve CHF records confirming premium charge trigger for the period.
4. L3 QoS/Slice Correlation: Compare committed SLA (latency/throughput/5QI) vs. delivered performance data.
5. L3 Service Topology: Build dynamic topology — PCF → SMF → RAN → slice → customer path to identify where policy diverged.
6. L2 BSS Orchestration: Retrieve product entitlement from catalogue. Confirm premium tier subscription is valid.
7. L2 Backoffice Adjustment: Remove premium surcharge for the period where QoS was not delivered.
8. L1 Master: Determine if misalignment is ongoing (policy fix needed) or one-time. Validate adjustment.
9. L1 Human Approval: Seek approval before applying the surcharge removal (enterprise B2B, high value).
10. L1 Audit: Write audit trace. Close.

## Approval Gate
Enterprise customers require human approval before surcharge removal (financial + SLA exposure).

## Architecture Rule
L3 owns QoS evidence and service topology. L4 owns charging trigger evidence. L2 owns entitlement + surcharge removal.

## KPIs to Improve
SLA compliance %, premium service dispute rate, latency/throughput compliance, B2B churn reduction.
