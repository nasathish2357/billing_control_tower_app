"""
Master seed — Billing Control Tower (MVP3 ground truth).

Creates all tables and populates the complete reference dataset in a single run.
This is the single source of truth; seed_mvp2.py and seed_mvp3.py are retired.

Run:  python -m app.db.seed
"""

import sys
import asyncio

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import datetime
import logging

from sqlalchemy import text

from app.db.database import engine, Base, AsyncSessionFactory
from app.models.models import (
    UseCase, Customer, BillingAccount, Bill, Issue,
    TMFEvent, TroubleTicket, ServiceProblem,
    Product, ProductOffering, BillLineItem,
    Device, PaymentRecord,
    UsageEvent, MediationRecord, RatedUsage, PDUSession,
    ServiceInventory, NetworkFunction,
    PartnerAccount, PartnerSettlement,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_d = datetime.datetime

# ── DDL patches — idempotent, safe to run against any existing schema ─────────
# Required when upgrading an older DB that predates the current model columns.
# On a fresh DB, create_all handles everything; these become no-ops.
DDL_PATCHES = [
    # ── customers ─────────────────────────────────────────────────────────────
    "ALTER TABLE customers ADD COLUMN IF NOT EXISTS phone VARCHAR(50)",
    "ALTER TABLE customers ADD COLUMN IF NOT EXISTS address JSON",
    "ALTER TABLE customers ADD COLUMN IF NOT EXISTS customer_type VARCHAR(20)",
    # ── billing_accounts ──────────────────────────────────────────────────────
    "ALTER TABLE billing_accounts ADD COLUMN IF NOT EXISTS account_type VARCHAR(30)",
    "ALTER TABLE billing_accounts ADD COLUMN IF NOT EXISTS credit_limit FLOAT",
    # ── use_cases ─────────────────────────────────────────────────────────────
    "ALTER TABLE use_cases ALTER COLUMN flow_type TYPE VARCHAR(30)",
    # ── issues — correlation and simulation plan (MVP4) ───────────────────────
    "ALTER TABLE issues ADD COLUMN IF NOT EXISTS correlation_key VARCHAR(100)",
    "ALTER TABLE issues ADD COLUMN IF NOT EXISTS simulation_plan JSON",
    # ── evidence_packs — LLM reasoning + tool call trace (MVP4) ──────────────
    "ALTER TABLE evidence_packs ADD COLUMN IF NOT EXISTS thought TEXT",
    "ALTER TABLE evidence_packs ADD COLUMN IF NOT EXISTS tool_calls JSON",
    "ALTER TABLE evidence_packs ADD COLUMN IF NOT EXISTS agent_name VARCHAR(100)",
    # ── approvals — HITL enrichment fields (MVP4) ─────────────────────────────
    "ALTER TABLE approvals ADD COLUMN IF NOT EXISTS why TEXT",
    "ALTER TABLE approvals ADD COLUMN IF NOT EXISTS evidence_refs JSON",
    "ALTER TABLE approvals ADD COLUMN IF NOT EXISTS proposed_action TEXT",
    "ALTER TABLE approvals ADD COLUMN IF NOT EXISTS financial_impact FLOAT",
    "ALTER TABLE approvals ADD COLUMN IF NOT EXISTS rejection_reason TEXT",
    "ALTER TABLE approvals ADD COLUMN IF NOT EXISTS decided_at TIMESTAMP",
    # ── usage_events ──────────────────────────────────────────────────────────
    "ALTER TABLE usage_events ALTER COLUMN data_volume_bytes TYPE BIGINT",
    # ── tmf_events — correlation key (MVP4) ──────────────────────────────────
    "ALTER TABLE tmf_events ADD COLUMN IF NOT EXISTS correlation_key VARCHAR(100)",
    "ALTER TABLE tmf_events ADD COLUMN IF NOT EXISTS correlated_at TIMESTAMP",
]

# ─────────────────────────────────────────────────────────────────────────────
#  Use Cases
# ─────────────────────────────────────────────────────────────────────────────

USE_CASES = [
    {"id": "P1",  "priority": "P1",  "flow_type": "full_graph", "status": "active",
     "name": "Missing or Delayed Usage Feed into Billing",
     "description": "Usage records are delayed or missing in the billing engine, leading to potential under-billing or late bill dispatch."},
    {"id": "P2",  "priority": "P2",  "flow_type": "full_graph", "status": "active",
     "name": "Duplicate Charging / Duplicate Usage Rating",
     "description": "Customer is charged twice for the same usage event due to a mediation or rating engine fault."},
    {"id": "P3",  "priority": "P3",  "flow_type": "full_graph", "status": "active",
     "name": "Zombie PDU Session Causing Unfair Data Charging",
     "description": "A ghost/zombie PDU session persists in the network after the customer disconnected, continuing to accrue data charges."},
    {"id": "P4",  "priority": "P4",  "flow_type": "full_graph", "status": "active",
     "name": "QoS or Slice Entitlement Mismatch with Premium Charging",
     "description": "Customer is charged for premium 5G slice/QoS tier but the network did not deliver promised performance."},
    {"id": "P5",  "priority": "P5",  "flow_type": "full_graph", "status": "active",
     "name": "Service Degradation Requiring Commercial Compensation",
     "description": "SLA breach or prolonged service degradation requires automatic or manual commercial compensation."},
    {"id": "P6",  "priority": "P6",  "flow_type": "full_graph", "status": "active",
     "name": "Collections Hold Required During Billing Dispute",
     "description": "While a dispute is active, the disputed amount must be placed on hold to prevent unjust collections proceedings."},
    {"id": "P7",  "priority": "P7",  "flow_type": "full_graph", "status": "active",
     "name": "Partner or Wholesale Charge Discrepancy",
     "description": "Mismatch between the CSP's internal billing and a partner/MVNO wholesale settlement record."},
    {"id": "P8",  "priority": "P8",  "flow_type": "full_graph", "status": "active",
     "name": "Confusing Invoice with Technically Valid but Opaque Charges",
     "description": "Customer cannot understand a bill with legitimate but complex charges; AI generates a plain-language explanation."},
    {"id": "P9",  "priority": "P9",  "flow_type": "full_graph", "status": "active",
     "name": "Internal Anomaly Discovered by Monitoring Before Customer Impact",
     "description": "Proactive internal detection of a billing risk or anomaly before it appears on a customer bill."},
    {"id": "P10", "priority": "P10", "flow_type": "full_graph", "status": "active",
     "name": "Governed End-to-End Dispute Handling Across BSS, OSS, and Network",
     "description": "Complex dispute requiring coordinated resolution across billing (BSS), service assurance (OSS), and network teams."},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Customers (10 total — B2C majority, 2 B2B enterprise, 1 B2B2X MVNO)
# ─────────────────────────────────────────────────────────────────────────────

CUSTOMERS = [
    {"id": "CUST-100001", "name": "Alice Nguyen",           "email": "alice@example.com",
     "segment": "Consumer",   "phone": "+1-555-0101", "customer_type": "B2C",
     "address": {"street": "12 Elm Street",         "city": "San Francisco", "state": "CA", "country": "US", "zip": "94102"}},
    {"id": "CUST-100002", "name": "Broadcom Enterprises",   "email": "billing@broadcom.example.com",
     "segment": "Enterprise", "phone": "+1-555-0102", "customer_type": "B2B",
     "address": {"street": "200 Corporate Park",    "city": "Houston",       "state": "TX", "country": "US", "zip": "77001"}},
    {"id": "CUST-100003", "name": "Marco Rossi",            "email": "marco@example.com",
     "segment": "Consumer",   "phone": "+1-555-0103", "customer_type": "B2C",
     "address": {"street": "56 Rosewood Drive",     "city": "Boston",        "state": "MA", "country": "US", "zip": "02101"}},
    {"id": "CUST-100004", "name": "Sarah Mitchell",         "email": "sarah.mitchell@example.com",
     "segment": "Consumer",   "phone": "+1-555-0104", "customer_type": "B2C",
     "address": {"street": "45 Maple Ave",          "city": "Austin",        "state": "TX", "country": "US", "zip": "78701"}},
    {"id": "CUST-100005", "name": "TechCorp Ltd.",          "email": "billing@techcorp.example.com",
     "segment": "Enterprise", "phone": "+1-555-0105", "customer_type": "B2B",
     "address": {"street": "100 Innovation Drive",  "city": "San Jose",      "state": "CA", "country": "US", "zip": "95110"}},
    {"id": "CUST-100006", "name": "Diego Fernandez",        "email": "diego.fernandez@example.com",
     "segment": "Consumer",   "phone": "+1-555-0106", "customer_type": "B2C",
     "address": {"street": "78 Ocean Blvd",         "city": "Miami",         "state": "FL", "country": "US", "zip": "33101"}},
    {"id": "CUST-100007", "name": "Priya Sharma",           "email": "priya.sharma@example.com",
     "segment": "Consumer",   "phone": "+1-555-0107", "customer_type": "B2C",
     "address": {"street": "222 Cherry Lane",       "city": "Seattle",       "state": "WA", "country": "US", "zip": "98101"}},
    {"id": "CUST-100008", "name": "Global Telecom MVNO",    "email": "wholesale@globaltelecom.example.com",
     "segment": "Wholesale",  "phone": "+1-555-0108", "customer_type": "B2B2X",
     "address": {"street": "500 Wholesale Plaza",   "city": "New York",      "state": "NY", "country": "US", "zip": "10001"}},
    {"id": "CUST-100009", "name": "James O'Connor",         "email": "james.oconnor@example.com",
     "segment": "Consumer",   "phone": "+1-555-0109", "customer_type": "B2C",
     "address": {"street": "9 Highland Road",       "city": "Chicago",       "state": "IL", "country": "US", "zip": "60601"}},
    {"id": "CUST-100010", "name": "Nova Retail Group",      "email": "finance@novaretail.example.com",
     "segment": "Enterprise", "phone": "+1-555-0110", "customer_type": "B2B",
     "address": {"street": "333 Commerce Street",   "city": "Dallas",        "state": "TX", "country": "US", "zip": "75201"}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Billing Accounts (12 total)
# ─────────────────────────────────────────────────────────────────────────────

BILLING_ACCOUNTS = [
    {"id": "BA-100001",  "customer_id": "CUST-100001", "status": "Active", "account_type": "postpaid",   "credit_limit": 1000.0},
    {"id": "BA-100002",  "customer_id": "CUST-100002", "status": "Active", "account_type": "enterprise", "credit_limit": 75000.0},
    {"id": "BA-100003",  "customer_id": "CUST-100003", "status": "Active", "account_type": "postpaid",   "credit_limit": 500.0},
    {"id": "BA-100004",  "customer_id": "CUST-100004", "status": "Active", "account_type": "postpaid",   "credit_limit": 500.0},
    {"id": "BA-100005",  "customer_id": "CUST-100005", "status": "Active", "account_type": "enterprise", "credit_limit": 50000.0},
    {"id": "BA-100005B", "customer_id": "CUST-100005", "status": "Active", "account_type": "enterprise", "credit_limit": 25000.0},
    {"id": "BA-100006",  "customer_id": "CUST-100006", "status": "Active", "account_type": "postpaid",   "credit_limit": 300.0},
    {"id": "BA-100007",  "customer_id": "CUST-100007", "status": "Active", "account_type": "prepaid",    "credit_limit": 0.0},
    {"id": "BA-100008",  "customer_id": "CUST-100008", "status": "Active", "account_type": "wholesale",  "credit_limit": 200000.0},
    {"id": "BA-100009",  "customer_id": "CUST-100009", "status": "Active", "account_type": "postpaid",   "credit_limit": 500.0},
    {"id": "BA-100010",  "customer_id": "CUST-100010", "status": "Active", "account_type": "enterprise", "credit_limit": 30000.0},
    {"id": "BA-100010B", "customer_id": "CUST-100010", "status": "Active", "account_type": "enterprise", "credit_limit": 10000.0},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Bills (23 total — 5 months Nov 2025 – Apr 2026, multiple accounts)
# ─────────────────────────────────────────────────────────────────────────────

BILLS = [
    # ── Alice Nguyen (BA-100001) ──────────────────────────────────────────────
    {"id": "BILL-202502", "billing_account_id": "BA-100001", "billing_period": "2025-11",
     "amount_due": 88.00,  "previous_amount": 85.00,  "due_date": _d(2025, 12, 15), "status": "Paid",
     "payload": {"line_items": [{"description": "Monthly plan", "amount": 65.00}, {"description": "Taxes & surcharges", "amount": 7.50}, {"description": "Misc usage", "amount": 15.50}], "payments": [{"amount": 88.00, "date": "2025-12-10"}]}},
    {"id": "BILL-202503", "billing_account_id": "BA-100001", "billing_period": "2025-12",
     "amount_due": 91.00,  "previous_amount": 88.00,  "due_date": _d(2026, 1,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Monthly plan", "amount": 65.00}, {"description": "International SMS", "amount": 18.50}, {"description": "Taxes & surcharges", "amount": 7.50}], "payments": [{"amount": 91.00, "date": "2026-01-12"}]}},
    {"id": "BILL-202504", "billing_account_id": "BA-100001", "billing_period": "2026-01",
     "amount_due": 90.00,  "previous_amount": 91.00,  "due_date": _d(2026, 2,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Monthly plan", "amount": 65.00}, {"description": "Data overage", "amount": 17.50}, {"description": "Taxes & surcharges", "amount": 7.50}], "payments": [{"amount": 90.00, "date": "2026-02-10"}]}},
    {"id": "BILL-202505", "billing_account_id": "BA-100001", "billing_period": "2026-02",
     "amount_due": 92.50,  "previous_amount": 90.00,  "due_date": _d(2026, 3,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Monthly plan", "amount": 65.00}, {"description": "Premium 5G slice add-on", "amount": 25.00}, {"description": "Taxes & surcharges", "amount": 7.50}], "payments": [{"amount": 92.50, "date": "2026-03-08"}]}},
    {"id": "BILL-202603", "billing_account_id": "BA-100001", "billing_period": "2026-03",
     "amount_due": 95.00,  "previous_amount": 90.00,  "due_date": _d(2026, 4,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Monthly plan", "amount": 65.00}, {"description": "Miscellaneous usage", "amount": 22.50}, {"description": "Taxes & surcharges", "amount": 7.50}], "payments": [{"amount": 95.00, "date": "2026-04-10"}]}},
    {"id": "BILL-202604", "billing_account_id": "BA-100001", "billing_period": "2026-04",
     "amount_due": 142.50, "previous_amount": 95.00,  "due_date": _d(2026, 5,  15), "status": "Disputed",
     "payload": {"line_items": [{"description": "Monthly plan", "amount": 65.00}, {"description": "International data roaming", "amount": 32.50}, {"description": "Premium 5G slice add-on", "amount": 25.00}, {"description": "Duplicate data session charge", "amount": 12.50, "dispute_flag": True}, {"description": "Taxes & surcharges", "amount": 7.50}], "payments": []}},

    # ── Broadcom Enterprises (BA-100002) ──────────────────────────────────────
    {"id": "BILL-202506", "billing_account_id": "BA-100002", "billing_period": "2025-11",
     "amount_due": 4250.00, "previous_amount": 4100.00, "due_date": _d(2025, 12, 15), "status": "Paid",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane", "amount": 2500.00}, {"description": "5G Ultra Slice (20 lines)", "amount": 1000.00}, {"description": "International roaming (5 lines)", "amount": 500.00}, {"description": "Taxes & surcharges", "amount": 250.00}], "payments": [{"amount": 4250.00, "date": "2025-12-12"}]}},
    {"id": "BILL-202507", "billing_account_id": "BA-100002", "billing_period": "2025-12",
     "amount_due": 4380.00, "previous_amount": 4250.00, "due_date": _d(2026, 1,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane", "amount": 2500.00}, {"description": "5G Ultra Slice (20 lines)", "amount": 1000.00}, {"description": "International roaming (7 lines)", "amount": 630.00}, {"description": "Taxes & surcharges", "amount": 250.00}], "payments": [{"amount": 4380.00, "date": "2026-01-10"}]}},
    {"id": "BILL-202508", "billing_account_id": "BA-100002", "billing_period": "2026-01",
     "amount_due": 4200.00, "previous_amount": 4380.00, "due_date": _d(2026, 2,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane", "amount": 2500.00}, {"description": "5G Ultra Slice (20 lines)", "amount": 1000.00}, {"description": "IoT Connectivity (50 devices)", "amount": 450.00}, {"description": "Taxes & surcharges", "amount": 250.00}], "payments": [{"amount": 4200.00, "date": "2026-02-08"}]}},
    {"id": "BILL-202509", "billing_account_id": "BA-100002", "billing_period": "2026-02",
     "amount_due": 4350.00, "previous_amount": 4200.00, "due_date": _d(2026, 3,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane", "amount": 2500.00}, {"description": "5G Ultra Slice (20 lines)", "amount": 1000.00}, {"description": "International roaming (6 lines)", "amount": 600.00}, {"description": "Taxes & surcharges", "amount": 250.00}], "payments": [{"amount": 4350.00, "date": "2026-03-05"}]}},
    {"id": "BILL-202510", "billing_account_id": "BA-100002", "billing_period": "2026-03",
     "amount_due": 4420.00, "previous_amount": 4350.00, "due_date": _d(2026, 4,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane", "amount": 2500.00}, {"description": "5G Ultra Slice (20 lines)", "amount": 1000.00}, {"description": "International roaming (8 lines)", "amount": 670.00}, {"description": "Taxes & surcharges", "amount": 250.00}], "payments": [{"amount": 4420.00, "date": "2026-04-08"}]}},
    {"id": "BILL-202511", "billing_account_id": "BA-100002", "billing_period": "2026-04",
     "amount_due": 7620.00, "previous_amount": 4420.00, "due_date": _d(2026, 5,  15), "status": "Disputed",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane", "amount": 2500.00}, {"description": "5G Ultra Slice (20 lines)", "amount": 1000.00}, {"description": "Partner/MVNO wholesale charges", "amount": 3870.00, "dispute_flag": True}, {"description": "Taxes & surcharges", "amount": 250.00}], "payments": []}},

    # ── Marco Rossi (BA-100003) ───────────────────────────────────────────────
    {"id": "BILL-202512", "billing_account_id": "BA-100003", "billing_period": "2025-11",
     "amount_due": 75.00,  "previous_amount": 70.00,  "due_date": _d(2025, 12, 15), "status": "Paid",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "Taxes & surcharges", "amount": 10.00}], "payments": [{"amount": 75.00, "date": "2025-12-12"}]}},
    {"id": "BILL-202513", "billing_account_id": "BA-100003", "billing_period": "2026-01",
     "amount_due": 78.00,  "previous_amount": 75.00,  "due_date": _d(2026, 2,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "Data add-on 5 GB", "amount": 5.00}, {"description": "Taxes & surcharges", "amount": 8.00}], "payments": [{"amount": 78.00, "date": "2026-02-12"}]}},
    {"id": "BILL-202514", "billing_account_id": "BA-100003", "billing_period": "2026-02",
     "amount_due": 82.00,  "previous_amount": 78.00,  "due_date": _d(2026, 3,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "International roaming add-on", "amount": 15.00}, {"description": "Taxes & surcharges", "amount": 7.00}], "payments": [{"amount": 82.00, "date": "2026-03-10"}]}},
    {"id": "BILL-202515", "billing_account_id": "BA-100003", "billing_period": "2026-03",
     "amount_due": 89.00,  "previous_amount": 82.00,  "due_date": _d(2026, 4,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "International roaming add-on", "amount": 15.00}, {"description": "Miscellaneous", "amount": 9.00}], "payments": [{"amount": 89.00, "date": "2026-04-08"}]}},
    {"id": "BILL-202516", "billing_account_id": "BA-100003", "billing_period": "2026-04",
     "amount_due": 149.00, "previous_amount": 89.00,  "due_date": _d(2026, 5,  15), "status": "Pending",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "International roaming add-on", "amount": 15.00}, {"description": "SLA compensation credit", "amount": -30.00}, {"description": "Taxes & surcharges", "amount": 9.00}, {"description": "Voice overcharge (disputed)", "amount": 90.00, "dispute_flag": True}], "payments": []}},

    # ── New customers ─────────────────────────────────────────────────────────
    {"id": "BILL-202520", "billing_account_id": "BA-100004", "billing_period": "2026-03",
     "amount_due": 72.00,  "previous_amount": 68.00,  "due_date": _d(2026, 4,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "Taxes & surcharges", "amount": 7.00}], "payments": [{"amount": 72.00, "date": "2026-04-10"}]}},
    {"id": "BILL-202521", "billing_account_id": "BA-100004", "billing_period": "2026-04",
     "amount_due": 95.00,  "previous_amount": 72.00,  "due_date": _d(2026, 5,  15), "status": "Pending",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "International roaming add-on", "amount": 15.00}, {"description": "Data overage", "amount": 8.00}, {"description": "Taxes & surcharges", "amount": 7.00}], "payments": []}},
    {"id": "BILL-202525", "billing_account_id": "BA-100005", "billing_period": "2026-03",
     "amount_due": 8500.00, "previous_amount": 8200.00, "due_date": _d(2026, 4,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane (50 lines)", "amount": 5000.00}, {"description": "5G Ultra Slice Enterprise", "amount": 2500.00}, {"description": "Taxes & surcharges", "amount": 1000.00}], "payments": [{"amount": 8500.00, "date": "2026-04-05"}]}},
    {"id": "BILL-202526", "billing_account_id": "BA-100005", "billing_period": "2026-04",
     "amount_due": 8750.00, "previous_amount": 8500.00, "due_date": _d(2026, 5,  15), "status": "Pending",
     "payload": {"line_items": [{"description": "Enterprise Priority Lane (50 lines)", "amount": 5000.00}, {"description": "5G Ultra Slice Enterprise", "amount": 2500.00}, {"description": "IoT Connectivity (100 devices)", "amount": 500.00}, {"description": "Taxes & surcharges", "amount": 750.00}], "payments": []}},
    {"id": "BILL-202530", "billing_account_id": "BA-100009", "billing_period": "2026-03",
     "amount_due": 68.00,  "previous_amount": 65.00,  "due_date": _d(2026, 4,  15), "status": "Paid",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "Taxes & surcharges", "amount": 7.00}], "payments": [{"amount": 68.00, "date": "2026-04-12"}]}},
    {"id": "BILL-202531", "billing_account_id": "BA-100009", "billing_period": "2026-04",
     "amount_due": 110.00, "previous_amount": 68.00,  "due_date": _d(2026, 5,  15), "status": "Pending",
     "payload": {"line_items": [{"description": "Standard 5G Plan", "amount": 65.00}, {"description": "International roaming", "amount": 32.00}, {"description": "Premium voicemail", "amount": 6.00}, {"description": "Taxes & surcharges", "amount": 7.00}], "payments": []}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Issues (P1 – P10, one per use case)
# ─────────────────────────────────────────────────────────────────────────────

ISSUES = [
    {"id": "ISSUE-P1-001",  "use_case_id": "P1",  "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "bill_id": None,
     "description": "Enterprise customer reports that March usage events are missing from the April bill run.", "status": "open"},
    {"id": "ISSUE-P2-001",  "use_case_id": "P2",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
     "description": "Customer Alice Nguyen is charged twice for a 2 GB data session on April 15th — duplicate charge of $12.50.", "status": "open"},
    {"id": "ISSUE-P3-001",  "use_case_id": "P3",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
     "description": "Zombie PDU session detected: Session ID PDU-4491 continued charging for 6 hours after customer device was switched off.", "status": "open"},
    {"id": "ISSUE-P4-001",  "use_case_id": "P4",  "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "bill_id": None,
     "description": "Enterprise customer charged for premium 5G Ultra slice but network delivered standard 4G QoS for 72 hours.", "status": "open"},
    {"id": "ISSUE-P5-001",  "use_case_id": "P5",  "customer_id": "CUST-100003", "billing_account_id": "BA-100003", "bill_id": None,
     "description": "Customer Marco Rossi experienced voice call drops for 8 hours on April 20th. SLA breach detected, compensation required.", "status": "open"},
    {"id": "ISSUE-P6-001",  "use_case_id": "P6",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
     "description": "Active billing dispute requires collections hold on disputed $12.50 balance to prevent dunning.", "status": "open"},
    {"id": "ISSUE-P7-001",  "use_case_id": "P7",  "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "bill_id": None,
     "description": "Wholesale partner MVNO-X settlement record shows $3,200 discrepancy vs CSP internal record for March.", "status": "open"},
    {"id": "ISSUE-P8-001",  "use_case_id": "P8",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "bill_id": "BILL-202604",
     "description": "Customer cannot understand why April bill is $47.50 higher than March. Requests plain-language explanation.", "status": "open"},
    {"id": "ISSUE-P9-001",  "use_case_id": "P9",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "bill_id": None,
     "description": "Proactive monitoring detected abnormal data usage spike pattern on account BA-100001 likely to cause billing complaint.", "status": "open"},
    {"id": "ISSUE-P10-001", "use_case_id": "P10", "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "bill_id": None,
     "description": "Complex dispute spanning BSS charge correction, OSS service problem closure, and network session audit for Enterprise account.", "status": "open"},
]

# ─────────────────────────────────────────────────────────────────────────────
#  TMF Events
# ─────────────────────────────────────────────────────────────────────────────

TMF_EVENTS = [
    {"id": "EVT-P1-001", "event_type": "SuspectedUsageDelayEvent",    "use_case_id": "P1", "source_layer": "L4", "severity": "high",     "status": "new", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "issue_id": "ISSUE-P1-001",
     "description": "847 usage events delayed in mediation pipeline. Bill-run exposure risk for BA-100001.",
     "payload": {"mediation_backlog_count": 847, "delay_hours": 18, "affected_billing_period": "2026-04", "pipeline_stage": "CDR_COLLECTION"}},
    {"id": "EVT-P2-001", "event_type": "DuplicateChargingEvent",      "use_case_id": "P2", "source_layer": "L3", "severity": "high",     "status": "new", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "issue_id": "ISSUE-P2-001",
     "description": "Duplicate data session charge detected for BA-100001 — 25.60 USD double-rated.",
     "payload": {"duplicate_session_id": "SESSION-DUP-20260415", "duplicate_amount": 25.60, "original_cdr_id": "CDR-20260415-001", "duplicate_cdr_id": "CDR-20260415-002"}},
    {"id": "EVT-P3-001", "event_type": "ZombieSessionSuspectedEvent", "use_case_id": "P3", "source_layer": "L4", "severity": "critical", "status": "new", "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "issue_id": "ISSUE-P3-001",
     "description": "PDU session SESSION-ZOMBIE-001 active for 72+ hours without network activity.",
     "payload": {"session_id": "SESSION-ZOMBIE-001", "duration_hours": 72, "data_charged_gb": 15.4, "actual_usage_gb": 0.0, "upf_node": "UPF-EAST-07"}},
    {"id": "EVT-P4-001", "event_type": "QoSMismatchEvent",            "use_case_id": "P4", "source_layer": "L4", "severity": "medium",   "status": "new", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "issue_id": "ISSUE-P4-001",
     "description": "QoS delivered 15 Mbps vs promised 100 Mbps for premium slice. Premium surcharge applied incorrectly.",
     "payload": {"promised_throughput_mbps": 100, "delivered_throughput_mbps": 15, "slice_id": "SLICE-PREMIUM-001", "nssai": "01-000001", "surcharge_amount": 25.00}},
    {"id": "EVT-P5-001", "event_type": "ServiceDegradationEvent",     "use_case_id": "P5", "source_layer": "L3", "severity": "high",     "status": "new", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "issue_id": "ISSUE-P5-001",
     "description": "8-hour voice service outage April 20 2026. SLA threshold exceeded (60 min). Compensation required.",
     "payload": {"outage_start": "2026-04-20T02:00:00Z", "outage_end": "2026-04-20T10:00:00Z", "duration_hours": 8, "sla_threshold_minutes": 60, "service_type": "voice", "compensation_eligibility": True}},
    {"id": "EVT-P6-001", "event_type": "CollectionsRiskEvent",        "use_case_id": "P6", "source_layer": "L2", "severity": "medium",   "status": "new", "customer_id": "CUST-100003", "billing_account_id": "BA-100003", "issue_id": "ISSUE-P6-001",
     "description": "Customer raised invoice dispute. Collections risk — dunning should be paused.",
     "payload": {"disputed_amount": 12.50, "total_balance": 89.99, "undisputed_amount": 77.49, "dunning_stage": "first_notice"}},
    {"id": "EVT-P9-001", "event_type": "BillingRiskDetectedEvent",    "use_case_id": "P9", "source_layer": "L1", "severity": "high",     "status": "new", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "issue_id": "ISSUE-P9-001",
     "description": "Internal monitoring detected data spike 3x normal usage on BA-100001. Pre-bill anomaly. No customer impact yet.",
     "payload": {"baseline_daily_gb": 2.1, "current_daily_gb": 6.8, "spike_factor": 3.2, "detection_source": "NWDAF", "pre_bill_exposure_usd": 48.00}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Trouble Tickets
# ─────────────────────────────────────────────────────────────────────────────

TROUBLE_TICKETS = [
    {"id": "TT-P6-001", "issue_id": "ISSUE-P6-001", "customer_id": "CUST-100003", "billing_account_id": "BA-100003",
     "ticket_type": "billing_dispute", "status": "open", "priority": "medium",
     "description": "Customer disputes charge of $12.50 on April 2026 bill. Requests collections hold.",
     "payload": {"channel": "web_portal", "reference_charge": "LINE-ITEM-009"}},
    {"id": "TT-P5-001", "issue_id": "ISSUE-P5-001", "customer_id": "CUST-100001", "billing_account_id": "BA-100001",
     "ticket_type": "service_complaint", "status": "open", "priority": "high",
     "description": "Voice service outage on April 20 2026 (8 hours). Customer requesting compensation.",
     "payload": {"channel": "call_center", "affected_service": "voice"}},
    {"id": "TT-P7-001", "issue_id": "ISSUE-P7-001", "customer_id": "CUST-100002", "billing_account_id": "BA-100002",
     "ticket_type": "billing_dispute", "status": "open", "priority": "high",
     "description": "Broadcom Enterprises disputes $3,200 discrepancy in MVNO-X wholesale settlement for March 2026.",
     "payload": {"channel": "account_manager", "partner_id": "PARTNER-001", "settlement_id": "PS-MVNOX-202603", "csp_amount": 5120.00, "partner_amount": 1920.00, "discrepancy": 3200.00}},
    {"id": "TT-P10-001", "issue_id": "ISSUE-P10-001", "customer_id": "CUST-100002", "billing_account_id": "BA-100002",
     "ticket_type": "billing_dispute", "status": "open", "priority": "critical",
     "description": "Complex cross-domain dispute: BSS billing correction, OSS service problem closure, and network session audit all required for Enterprise account BA-100002.",
     "payload": {"channel": "escalation_desk", "domains_involved": ["BSS", "OSS", "Network"], "estimated_impact_usd": 7800.00, "sla_breach": True, "cross_domain_ref": "XDOM-2026-0001"}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Service Problems
# ─────────────────────────────────────────────────────────────────────────────

SERVICE_PROBLEMS = [
    {"id": "SP-P5-001", "issue_id": "ISSUE-P5-001", "customer_id": "CUST-100001", "service_id": "SVC-VOICE-100001",
     "problem_type": "service_degradation", "severity": "high", "status": "open", "sla_breach": True,
     "affected_period_start": _d(2026, 4, 20, 2, 0, 0), "affected_period_end": _d(2026, 4, 20, 10, 0, 0),
     "description": "Complete voice service interruption for 8 hours. SLA max allowable: 60 minutes. Breach confirmed.",
     "payload": {"service_type": "voice", "root_cause": "core_node_failure", "affected_nodes": ["AMF-NORTH-01", "SMF-NORTH-01"], "sla_doc_ref": "SLA-ENTERPRISE-2025-001"}},
    {"id": "SP-P4-001", "issue_id": "ISSUE-P4-001", "customer_id": "CUST-100001", "service_id": "SVC-DATA-PREMIUM-100001",
     "problem_type": "qos_breach", "severity": "medium", "status": "open", "sla_breach": True,
     "affected_period_start": _d(2026, 4, 1, 0, 0, 0), "affected_period_end": _d(2026, 4, 30, 23, 59, 59),
     "description": "QoS entitlement mismatch: premium slice promised 100 Mbps, delivered 15 Mbps for entire April period.",
     "payload": {"slice_id": "SLICE-PREMIUM-001", "promised_qos": "100Mbps_eMBB", "delivered_qos": "15Mbps_shared", "nssai_configured": "01-000001", "nssai_active": "01-000002"}},
    {"id": "SP-P7-001", "issue_id": "ISSUE-P7-001", "customer_id": "CUST-100002", "service_id": "SVC-WHOLESALE-100008",
     "problem_type": "partner_cdr_gap", "severity": "high", "status": "open", "sla_breach": False,
     "affected_period_start": _d(2026, 3, 1, 0, 0, 0), "affected_period_end": _d(2026, 3, 31, 23, 59, 59),
     "description": "MVNO-X CDR ingestion gap: 802 roaming CDRs not received by partner mediation engine for March 2026.",
     "payload": {"partner_id": "PARTNER-001", "missing_cdr_count": 802, "sepp_export_status": "complete", "partner_ingestion_status": "incomplete", "evidence_ref": "SEPP-LOG-2026-03-MVNOX"}},
    {"id": "SP-P10-001", "issue_id": "ISSUE-P10-001", "customer_id": "CUST-100002", "service_id": "SVC-ENT-100002",
     "problem_type": "multi_domain_outage", "severity": "critical", "status": "open", "sla_breach": True,
     "affected_period_start": _d(2026, 4, 20, 2, 0, 0), "affected_period_end": _d(2026, 4, 20, 18, 0, 0),
     "description": "16-hour multi-domain degradation affecting Broadcom Enterprise: billing charge errors, voice service drop, and UPF session leak occurring simultaneously.",
     "payload": {"bss_impact": "incorrect_charges_applied", "oss_impact": "voice_service_degradation", "network_impact": "upf_session_leak", "domains_affected": ["BSS", "OSS", "Network"], "sla_ref": "SLA-ENTERPRISE-2025-001"}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Products and Offerings
# ─────────────────────────────────────────────────────────────────────────────

PRODUCTS = [
    {"id": "PROD-001", "name": "Standard 5G Plan",            "product_type": "mobile_plan", "description": "Standard 5G postpaid plan with 30 GB data, unlimited voice and SMS.",          "payload": {"data_allowance_gb": 30, "voice": "unlimited", "sms": "unlimited", "speed_mbps": 300}},
    {"id": "PROD-002", "name": "Premium 5G Ultra Plan",        "product_type": "mobile_plan", "description": "Premium 5G plan with dedicated slice, 100 GB data, guaranteed 500 Mbps.",     "payload": {"data_allowance_gb": 100, "voice": "unlimited", "sms": "unlimited", "speed_mbps": 500, "slice": "dedicated"}},
    {"id": "PROD-003", "name": "International Roaming Add-On", "product_type": "add_on",      "description": "International roaming data and voice in 50+ countries.",                       "payload": {"countries": 50, "data_allowance_gb": 5, "voice_minutes": 300}},
    {"id": "PROD-004", "name": "Premium 5G Slice Add-On",      "product_type": "add_on",      "description": "Enterprise-grade 5G network slice with guaranteed QoS.",                       "payload": {"slice_type": "eMBB", "guaranteed_mbps": 100, "nssai": "01-000001"}},
    {"id": "PROD-005", "name": "Enterprise Priority Lane",      "product_type": "mobile_plan", "description": "Enterprise bulk plan with dedicated account management and SLA.",              "payload": {"min_lines": 10, "sla_uptime_pct": 99.9, "dedicated_am": True}},
    {"id": "PROD-006", "name": "Basic 4G Plan",                "product_type": "mobile_plan", "description": "Basic postpaid 4G plan with 10 GB data.",                                     "payload": {"data_allowance_gb": 10, "voice": "500min", "sms": "unlimited", "speed_mbps": 50}},
    {"id": "PROD-007", "name": "IoT Connectivity",             "product_type": "vas",         "description": "Low-power IoT device connectivity with per-device billing.",                   "payload": {"data_per_device_mb": 100, "protocol": "NB-IoT/LTE-M", "billing": "per_device"}},
    {"id": "PROD-008", "name": "5G Home Internet",             "product_type": "mobile_plan", "description": "Fixed wireless 5G home broadband with unlimited data.",                       "payload": {"data_allowance_gb": "unlimited", "speed_mbps": 1000, "device": "CPE"}},
    {"id": "PROD-009", "name": "MVNO Wholesale Access",        "product_type": "wholesale",   "description": "Wholesale network access for MVNO partners.",                                  "payload": {"settlement_model": "revenue_share", "roaming_included": True}},
    {"id": "PROD-010", "name": "Unlimited Voice & Text Bundle", "product_type": "add_on",      "description": "Unlimited domestic voice and text add-on.",                                   "payload": {"voice": "unlimited", "sms": "unlimited"}},
]

PRODUCT_OFFERINGS = [
    {"id": "PO-001", "product_id": "PROD-001", "name": "Standard 5G - Month-to-Month",       "tier": "standard",    "monthly_fee": 65.00,   "payload": {"contract_months": 0,  "activation_fee": 0}},
    {"id": "PO-002", "product_id": "PROD-001", "name": "Standard 5G - 24-Month Contract",    "tier": "standard",    "monthly_fee": 55.00,   "payload": {"contract_months": 24, "activation_fee": 0}},
    {"id": "PO-003", "product_id": "PROD-002", "name": "Premium 5G Ultra - Month-to-Month",  "tier": "premium",     "monthly_fee": 95.00,   "payload": {"contract_months": 0,  "activation_fee": 25}},
    {"id": "PO-004", "product_id": "PROD-003", "name": "International Roaming - Monthly",    "tier": "standard",    "monthly_fee": 15.00,   "payload": {"auto_renew": True}},
    {"id": "PO-005", "product_id": "PROD-004", "name": "Premium 5G Slice - Monthly",         "tier": "premium",     "monthly_fee": 25.00,   "payload": {"slice_id": "SLICE-PREMIUM-001", "nssai": "01-000001"}},
    {"id": "PO-006", "product_id": "PROD-005", "name": "Enterprise Priority Lane - Annual",  "tier": "enterprise",  "monthly_fee": 200.00,  "payload": {"contract_months": 12, "min_lines": 10, "sla_doc": "SLA-ENT-2025"}},
    {"id": "PO-007", "product_id": "PROD-007", "name": "IoT Connectivity - Per Device",      "tier": "basic",       "monthly_fee": 5.00,    "payload": {"billing_unit": "per_device"}},
    {"id": "PO-008", "product_id": "PROD-009", "name": "MVNO Wholesale - Revenue Share",     "tier": "wholesale",   "monthly_fee": 0.00,    "payload": {"revenue_share_pct": 30, "settlement_day": 15}},
    {"id": "PO-009", "product_id": "PROD-006", "name": "Basic 4G - Prepaid",                 "tier": "basic",       "monthly_fee": 35.00,   "payload": {"contract_months": 0,  "prepaid": True}},
    {"id": "PO-010", "product_id": "PROD-010", "name": "Unlimited Voice & Text - Add-On",    "tier": "standard",    "monthly_fee": 10.00,   "payload": {"add_on": True}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Bill Line Items
# ─────────────────────────────────────────────────────────────────────────────

BILL_LINE_ITEMS = [
    {"id": "BLI-202604-001", "bill_id": "BILL-202604", "description": "Standard 5G Plan - April 2026",                              "amount": 65.00,  "quantity": 1.0,  "unit": "month", "charge_type": "recurring", "service_id": "SVC-VOICE-100001", "dispute_flag": False},
    {"id": "BLI-202604-002", "bill_id": "BILL-202604", "description": "International data roaming - 2.5 GB",                        "amount": 32.50,  "quantity": 2.5,  "unit": "GB",    "charge_type": "roaming",   "service_id": "SVC-ROAM-100001",  "dispute_flag": False},
    {"id": "BLI-202604-003", "bill_id": "BILL-202604", "description": "Premium 5G Slice Add-On",                                    "amount": 25.00,  "quantity": 1.0,  "unit": "month", "charge_type": "recurring", "service_id": "SVC-SLICE-100001", "dispute_flag": False},
    {"id": "BLI-202604-004", "bill_id": "BILL-202604", "description": "Data session charge - duplicate (SESSION-DUP-20260415)",     "amount": 12.50,  "quantity": 2.0,  "unit": "GB",    "charge_type": "usage",     "service_id": "SVC-DATA-100001",  "dispute_flag": True,  "rated_usage_id": "RU-DUP-001", "payload": {"session_id": "SESSION-DUP-20260415", "cdr_id": "CDR-20260415-002", "note": "Duplicate rating — original CDR-20260415-001"}},
    {"id": "BLI-202604-005", "bill_id": "BILL-202604", "description": "Taxes & surcharges",                                         "amount": 7.50,   "quantity": None, "unit": None,    "charge_type": "tax",       "dispute_flag": False},
    {"id": "BLI-202511-001", "bill_id": "BILL-202511", "description": "Enterprise Priority Lane - April 2026",                      "amount": 2500.00,"quantity": 1.0,  "unit": "month", "charge_type": "recurring", "service_id": "SVC-ENT-100002",   "dispute_flag": False},
    {"id": "BLI-202511-002", "bill_id": "BILL-202511", "description": "5G Ultra Slice (20 lines) - April 2026",                     "amount": 1000.00,"quantity": 20.0, "unit": "lines", "charge_type": "recurring", "service_id": "SVC-SLICE-100002", "dispute_flag": False},
    {"id": "BLI-202511-003", "bill_id": "BILL-202511", "description": "Partner/MVNO wholesale roaming charges - MVNO-X March",      "amount": 3870.00,"quantity": None, "unit": None,    "charge_type": "roaming",   "dispute_flag": True,  "payload": {"partner_id": "PARTNER-001", "settlement_period": "2026-03", "csp_amount": 5120.00, "partner_amount": 1920.00, "discrepancy": 3200.00}},
    {"id": "BLI-202511-004", "bill_id": "BILL-202511", "description": "Taxes & surcharges",                                         "amount": 250.00, "quantity": None, "unit": None,    "charge_type": "tax",       "dispute_flag": False},
    {"id": "BLI-202603-001", "bill_id": "BILL-202603", "description": "Standard 5G Plan - March 2026",                              "amount": 65.00,  "quantity": 1.0,  "unit": "month", "charge_type": "recurring", "dispute_flag": False},
    {"id": "BLI-202603-002", "bill_id": "BILL-202603", "description": "Taxes & surcharges",                                         "amount": 7.50,   "quantity": None, "unit": None,    "charge_type": "tax",       "dispute_flag": False},
    {"id": "BLI-202603-003", "bill_id": "BILL-202603", "description": "Miscellaneous data usage",                                   "amount": 22.50,  "quantity": 4.5,  "unit": "GB",    "charge_type": "usage",     "dispute_flag": False},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Devices
# ─────────────────────────────────────────────────────────────────────────────

DEVICES = [
    {"id": "DEV-100001-01", "customer_id": "CUST-100001", "imei": "357248090123456", "model": "iPhone 16 Pro",        "manufacturer": "Apple",   "os": "iOS 18.3",    "status": "active", "payload": {"sim_type": "eSIM",     "imsi": "310410100001001", "msisdn": "+15550101"}},
    {"id": "DEV-100001-02", "customer_id": "CUST-100001", "imei": "867415031234567", "model": "Samsung Galaxy Watch 7","manufacturer": "Samsung", "os": "Wear OS 5",   "status": "active", "payload": {"sim_type": "eSIM",     "imsi": "310410100001002", "msisdn": "+15550101W"}},
    {"id": "DEV-100002-01", "customer_id": "CUST-100002", "imei": "354551091234568", "model": "Samsung Galaxy S25 Ultra","manufacturer": "Samsung","os": "Android 15",  "status": "active", "payload": {"sim_type": "physical", "imsi": "310410100002001", "msisdn": "+15550102"}},
    {"id": "DEV-100003-01", "customer_id": "CUST-100003", "imei": "356814090234567", "model": "Google Pixel 9 Pro",   "manufacturer": "Google",  "os": "Android 15",  "status": "active", "payload": {"sim_type": "eSIM",     "imsi": "310410100003001", "msisdn": "+15550103"}},
    {"id": "DEV-100004-01", "customer_id": "CUST-100004", "imei": "352078091234560", "model": "iPhone 15",            "manufacturer": "Apple",   "os": "iOS 18.1",    "status": "active", "payload": {"sim_type": "eSIM",     "imsi": "310410100004001", "msisdn": "+15550104"}},
    {"id": "DEV-100006-01", "customer_id": "CUST-100006", "imei": "358192030987654", "model": "OnePlus 13",           "manufacturer": "OnePlus", "os": "Android 15",  "status": "active", "payload": {"sim_type": "physical", "imsi": "310410100006001", "msisdn": "+15550106"}},
    {"id": "DEV-100007-01", "customer_id": "CUST-100007", "imei": "359911041234560", "model": "Samsung Galaxy A55",   "manufacturer": "Samsung", "os": "Android 14",  "status": "active", "payload": {"sim_type": "physical", "imsi": "310410100007001", "msisdn": "+15550107"}},
    {"id": "DEV-100009-01", "customer_id": "CUST-100009", "imei": "861234567890123", "model": "iPhone 16",            "manufacturer": "Apple",   "os": "iOS 18.2",    "status": "active", "payload": {"sim_type": "eSIM",     "imsi": "310410100009001", "msisdn": "+15550109"}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Payment Records
# ─────────────────────────────────────────────────────────────────────────────

PAYMENT_RECORDS = [
    {"id": "PAY-100001-001", "billing_account_id": "BA-100001", "amount": 88.00,   "payment_date": _d(2025, 12, 10), "method": "credit_card",  "status": "success", "reference": "TXN-2025121001"},
    {"id": "PAY-100001-002", "billing_account_id": "BA-100001", "amount": 91.00,   "payment_date": _d(2026, 1,  12), "method": "credit_card",  "status": "success", "reference": "TXN-2026011201"},
    {"id": "PAY-100001-003", "billing_account_id": "BA-100001", "amount": 90.00,   "payment_date": _d(2026, 2,  10), "method": "credit_card",  "status": "success", "reference": "TXN-2026021001"},
    {"id": "PAY-100001-004", "billing_account_id": "BA-100001", "amount": 92.50,   "payment_date": _d(2026, 3,  8),  "method": "credit_card",  "status": "success", "reference": "TXN-2026030801"},
    {"id": "PAY-100001-005", "billing_account_id": "BA-100001", "amount": 95.00,   "payment_date": _d(2026, 4,  10), "method": "credit_card",  "status": "success", "reference": "TXN-2026041001"},
    {"id": "PAY-100002-001", "billing_account_id": "BA-100002", "amount": 4250.00, "payment_date": _d(2025, 12, 12), "method": "bank_transfer","status": "success", "reference": "TXN-BRD-2025121201"},
    {"id": "PAY-100002-002", "billing_account_id": "BA-100002", "amount": 4380.00, "payment_date": _d(2026, 1,  10), "method": "bank_transfer","status": "success", "reference": "TXN-BRD-2026011001"},
    {"id": "PAY-100002-003", "billing_account_id": "BA-100002", "amount": 4200.00, "payment_date": _d(2026, 2,  8),  "method": "bank_transfer","status": "success", "reference": "TXN-BRD-2026020801"},
    {"id": "PAY-100002-004", "billing_account_id": "BA-100002", "amount": 4350.00, "payment_date": _d(2026, 3,  5),  "method": "bank_transfer","status": "success", "reference": "TXN-BRD-2026030501"},
    {"id": "PAY-100002-005", "billing_account_id": "BA-100002", "amount": 4420.00, "payment_date": _d(2026, 4,  8),  "method": "bank_transfer","status": "success", "reference": "TXN-BRD-2026040801"},
    {"id": "PAY-100003-001", "billing_account_id": "BA-100003", "amount": 75.00,   "payment_date": _d(2025, 12, 12), "method": "direct_debit", "status": "success", "reference": "TXN-MR-2025121201"},
    {"id": "PAY-100003-002", "billing_account_id": "BA-100003", "amount": 78.00,   "payment_date": _d(2026, 2,  12), "method": "direct_debit", "status": "success", "reference": "TXN-MR-2026021201"},
    {"id": "PAY-100003-003", "billing_account_id": "BA-100003", "amount": 82.00,   "payment_date": _d(2026, 3,  10), "method": "direct_debit", "status": "success", "reference": "TXN-MR-2026031001"},
    {"id": "PAY-100003-004", "billing_account_id": "BA-100003", "amount": 89.00,   "payment_date": _d(2026, 4,  8),  "method": "direct_debit", "status": "success", "reference": "TXN-MR-2026040801"},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Network Functions (5G NF registry)
# ─────────────────────────────────────────────────────────────────────────────

NETWORK_FUNCTIONS = [
    {"id": "NF-UPF-EAST-01",  "nf_type": "UPF",   "name": "UPF-EAST-01",          "host": "upf-east-01.core.example.com",  "region": "US-EAST",    "status": "active",   "payload": {"capacity_gbps": 40, "sessions_active": 12450, "vendor": "Ericsson"}},
    {"id": "NF-UPF-EAST-07",  "nf_type": "UPF",   "name": "UPF-EAST-07",          "host": "upf-east-07.core.example.com",  "region": "US-EAST",    "status": "active",   "payload": {"capacity_gbps": 40, "sessions_active": 8230,  "vendor": "Ericsson", "zombie_session_risk": True}},
    {"id": "NF-UPF-WEST-01",  "nf_type": "UPF",   "name": "UPF-WEST-01",          "host": "upf-west-01.core.example.com",  "region": "US-WEST",    "status": "active",   "payload": {"capacity_gbps": 40, "sessions_active": 9870,  "vendor": "Nokia"}},
    {"id": "NF-AMF-NORTH-01", "nf_type": "AMF",   "name": "AMF-NORTH-01",         "host": "amf-north-01.core.example.com", "region": "US-NORTH",   "status": "degraded", "payload": {"registered_ues": 45000, "vendor": "Ericsson", "incident_ref": "INC-2026-0420"}},
    {"id": "NF-AMF-SOUTH-01", "nf_type": "AMF",   "name": "AMF-SOUTH-01",         "host": "amf-south-01.core.example.com", "region": "US-SOUTH",   "status": "active",   "payload": {"registered_ues": 38000, "vendor": "Nokia"}},
    {"id": "NF-SMF-NORTH-01", "nf_type": "SMF",   "name": "SMF-NORTH-01",         "host": "smf-north-01.core.example.com", "region": "US-NORTH",   "status": "degraded", "payload": {"pdu_sessions_active": 28000, "vendor": "Ericsson", "incident_ref": "INC-2026-0420"}},
    {"id": "NF-SMF-SOUTH-01", "nf_type": "SMF",   "name": "SMF-SOUTH-01",         "host": "smf-south-01.core.example.com", "region": "US-SOUTH",   "status": "active",   "payload": {"pdu_sessions_active": 22000, "vendor": "Nokia"}},
    {"id": "NF-PCF-CORE-01",  "nf_type": "PCF",   "name": "PCF-CORE-01",          "host": "pcf-core-01.core.example.com",  "region": "US-CENTRAL", "status": "active",   "payload": {"policies_active": 15000, "vendor": "Huawei"}},
    {"id": "NF-NWDAF-01",     "nf_type": "NWDAF", "name": "NWDAF-ANALYTICS-01",   "host": "nwdaf-01.analytics.example.com","region": "US-CENTRAL", "status": "active",   "payload": {"models_running": 12, "vendor": "Ericsson", "anomaly_detection": True}},
    {"id": "NF-CHF-01",       "nf_type": "CHF",   "name": "CHF-CHARGING-01",      "host": "chf-01.charging.example.com",   "region": "US-CENTRAL", "status": "active",   "payload": {"sessions_per_sec": 5000, "vendor": "Ericsson", "ocs_mode": "online"}},
    {"id": "NF-CTF-01",       "nf_type": "CTF",   "name": "CTF-TRIGGER-01",       "host": "ctf-01.charging.example.com",   "region": "US-CENTRAL", "status": "active",   "payload": {"cdrs_per_hour": 120000, "vendor": "Nokia"}},
    {"id": "NF-CGF-01",       "nf_type": "CGF",   "name": "CGF-GATEWAY-01",       "host": "cgf-01.charging.example.com",   "region": "US-CENTRAL", "status": "active",   "payload": {"mediation_throughput_gbph": 2.5, "vendor": "Ericsson"}},
    {"id": "NF-SEPP-01",      "nf_type": "SEPP",  "name": "SEPP-ROAMING-01",      "host": "sepp-01.roaming.example.com",   "region": "US-EAST",    "status": "active",   "payload": {"roaming_partners": 42, "vendor": "Nokia", "n32_interface": True}},
    {"id": "NF-NEF-01",       "nf_type": "NEF",   "name": "NEF-EXPOSURE-01",      "host": "nef-01.exposure.example.com",   "region": "US-CENTRAL", "status": "active",   "payload": {"api_calls_per_hour": 80000, "vendor": "Ericsson"}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  PDU Sessions
# ─────────────────────────────────────────────────────────────────────────────

PDU_SESSIONS = [
    {"id": "PDU-4491",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "session_id": "SESSION-ZOMBIE-4491",    "upf_node": "UPF-EAST-07", "smf_node": "SMF-NORTH-01", "start_time": _d(2026, 4, 13, 8, 0, 0),  "end_time": None,                          "data_volume_gb": 0.0,   "status": "zombie",     "payload": {"imsi": "310410100001001", "device_disconnected_at": "2026-04-13T08:00:00Z", "session_still_active_in_upf": True, "ghost_charge_gb": 15.4}},
    {"id": "PDU-5001",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "session_id": "SESSION-5001",            "upf_node": "UPF-EAST-01", "smf_node": "SMF-NORTH-01", "start_time": _d(2026, 4, 15, 9, 0, 0),  "end_time": _d(2026, 4, 15, 11, 30, 0),   "data_volume_gb": 2.0,   "status": "terminated", "payload": {"imsi": "310410100001001", "dnn": "internet", "pdu_type": "IPv4", "qfi": 9}},
    {"id": "PDU-5002",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "session_id": "SESSION-DUP-20260415",   "upf_node": "UPF-EAST-01", "smf_node": "SMF-NORTH-01", "start_time": _d(2026, 4, 15, 14, 0, 0), "end_time": _d(2026, 4, 15, 15, 30, 0),   "data_volume_gb": 2.0,   "status": "terminated", "payload": {"imsi": "310410100001001", "duplicate": True, "original_cdr": "CDR-20260415-001", "duplicate_cdr": "CDR-20260415-002"}},
    {"id": "PDU-5003",  "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "session_id": "SESSION-SLICE-001",      "upf_node": "UPF-EAST-01", "smf_node": "SMF-NORTH-01", "start_time": _d(2026, 4, 1, 0, 0, 0),   "end_time": _d(2026, 4, 30, 23, 59, 59),  "data_volume_gb": 340.0, "status": "terminated", "payload": {"imsi": "310410100002001", "nssai": "01-000002", "billed_nssai": "01-000001", "qos_mismatch": True, "promised_mbps": 100, "delivered_mbps": 15}},
    {"id": "PDU-5010",  "customer_id": "CUST-100009", "billing_account_id": "BA-100009", "session_id": "SESSION-JOC-001",        "upf_node": "UPF-WEST-01", "smf_node": "SMF-SOUTH-01", "start_time": _d(2026, 4, 18, 10, 0, 0), "end_time": _d(2026, 4, 18, 12, 0, 0),    "data_volume_gb": 1.5,   "status": "terminated", "payload": {"imsi": "310410100009001", "dnn": "internet"}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Usage Events (CDR/xDR) — BigInteger for data_volume_bytes
# ─────────────────────────────────────────────────────────────────────────────

USAGE_EVENTS = [
    {"id": "UE-001", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "session_id": "SESSION-5001",          "event_type": "data",         "data_volume_bytes": 2_147_483_648,   "duration_seconds": 9000,    "start_time": _d(2026, 4, 15, 9, 0, 0),  "end_time": _d(2026, 4, 15, 11, 30, 0),  "network_element": "UPF-EAST-01", "charging_trigger": "CHF",   "billing_period": "2026-04", "payload": {"cdr_id": "CDR-20260415-001", "rat_type": "NR",  "apn": "internet"}},
    {"id": "UE-002", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "session_id": "SESSION-DUP-20260415", "event_type": "data",         "data_volume_bytes": 2_147_483_648,   "duration_seconds": 5400,    "start_time": _d(2026, 4, 15, 14, 0, 0), "end_time": _d(2026, 4, 15, 15, 30, 0),  "network_element": "UPF-EAST-01", "charging_trigger": "CHF",   "billing_period": "2026-04", "payload": {"cdr_id": "CDR-20260415-002", "duplicate_of": "CDR-20260415-001", "duplicate_flag": True}},
    {"id": "UE-003", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "session_id": "SESSION-ZOMBIE-4491",  "event_type": "data",         "data_volume_bytes": 16_532_115_456,  "duration_seconds": 259200,  "start_time": _d(2026, 4, 13, 8, 0, 0),  "end_time": _d(2026, 4, 16, 8, 0, 0),    "network_element": "UPF-EAST-07", "charging_trigger": "CTF",   "billing_period": "2026-04", "payload": {"cdr_id": "CDR-ZOMBIE-4491", "session_type": "zombie", "actual_usage_bytes": 0}},
    {"id": "UE-004", "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "session_id": "SESSION-SLICE-001",    "event_type": "data",         "data_volume_bytes": 365_072_220_160, "duration_seconds": 2592000, "start_time": _d(2026, 4, 1, 0, 0, 0),   "end_time": _d(2026, 4, 30, 23, 59, 59), "network_element": "UPF-EAST-01", "charging_trigger": "CHF",   "billing_period": "2026-04", "payload": {"cdr_id": "CDR-SLICE-001", "billed_nssai": "01-000001", "actual_nssai": "01-000002", "qos_mismatch": True}},
    {"id": "UE-005", "customer_id": "CUST-100003", "billing_account_id": "BA-100003", "session_id": "SESSION-VOICE-MR-001", "event_type": "voice",        "data_volume_bytes": None,            "duration_seconds": 1200,    "start_time": _d(2026, 4, 20, 1, 0, 0),  "end_time": _d(2026, 4, 20, 1, 20, 0),   "network_element": "AMF-NORTH-01","charging_trigger": "CTF",   "billing_period": "2026-04", "payload": {"cdr_id": "CDR-VOICE-MR-001", "drop_reason": "amf_node_failure", "sla_breach": True}},
    {"id": "UE-006", "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "session_id": "SESSION-BA002-DELAY",  "event_type": "data",         "data_volume_bytes": 10_737_418_240,  "duration_seconds": 3600,    "start_time": _d(2026, 3, 29, 22, 0, 0), "end_time": _d(2026, 3, 29, 23, 0, 0),   "network_element": "NF-CGF-01",   "charging_trigger": "CTF",   "billing_period": "2026-04", "payload": {"cdr_id": "CDR-DELAY-001", "pipeline_stage": "CDR_COLLECTION", "delay_hours": 18, "delayed": True}},
    {"id": "UE-007", "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "session_id": "SESSION-ROAM-MVNO-001","event_type": "roaming_data", "data_volume_bytes": 5_368_709_120,  "duration_seconds": 86400,   "start_time": _d(2026, 3, 15, 0, 0, 0),  "end_time": _d(2026, 3, 15, 23, 59, 59), "network_element": "NF-SEPP-01",  "charging_trigger": "CHF",   "billing_period": "2026-03", "payload": {"cdr_id": "CDR-ROAM-MVNO-001", "visited_plmn": "234-30", "partner_id": "PARTNER-001", "csp_charged_usd": 160.00, "partner_charged_usd": 60.00}},
    {"id": "UE-008", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "session_id": "SESSION-SPIKE-001",    "event_type": "data",         "data_volume_bytes": 7_516_192_768,  "duration_seconds": 86400,   "start_time": _d(2026, 4, 21, 0, 0, 0),  "end_time": _d(2026, 4, 21, 23, 59, 59), "network_element": "UPF-EAST-01", "charging_trigger": "NWDAF", "billing_period": "2026-04", "payload": {"cdr_id": "CDR-SPIKE-001", "anomaly_detected": True, "baseline_daily_gb": 2.1, "actual_daily_gb": 7.0, "spike_factor": 3.3}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Mediation Records
# ─────────────────────────────────────────────────────────────────────────────

MEDIATION_RECORDS = [
    {"id": "MR-001", "usage_event_id": "UE-001", "cdr_id": "CDR-20260415-001", "billing_account_id": "BA-100001", "status": "rated",     "rating_attempt_count": 1, "billing_period": "2026-04", "payload": {"rated_amount_usd": 6.25,  "charge_type": "data",         "rating_engine": "CGF-01"}},
    {"id": "MR-002", "usage_event_id": "UE-002", "cdr_id": "CDR-20260415-002", "billing_account_id": "BA-100001", "status": "duplicate", "rating_attempt_count": 2, "billing_period": "2026-04", "error_code": "DUPLICATE_CDR",  "payload": {"original_mr_id": "MR-001", "duplicate_rated_amount": 6.25, "flagged_by": "mediation_dedup_check"}},
    {"id": "MR-003", "usage_event_id": "UE-003", "cdr_id": "CDR-ZOMBIE-4491",  "billing_account_id": "BA-100001", "status": "rated",     "rating_attempt_count": 1, "billing_period": "2026-04", "payload": {"rated_amount_usd": 48.00, "charge_type": "data",         "session_type": "zombie", "correction_required": True}},
    {"id": "MR-004", "usage_event_id": "UE-004", "cdr_id": "CDR-SLICE-001",    "billing_account_id": "BA-100002", "status": "rated",     "rating_attempt_count": 1, "billing_period": "2026-04", "payload": {"rated_amount_usd": 25.00, "billed_tier": "premium_5g_slice", "actual_tier": "standard", "qos_mismatch": True}},
    {"id": "MR-005", "usage_event_id": "UE-006", "cdr_id": "CDR-DELAY-001",    "billing_account_id": "BA-100002", "status": "raw",       "rating_attempt_count": 0, "billing_period": "2026-04", "error_code": "PIPELINE_DELAY", "payload": {"pipeline_stage": "CDR_COLLECTION", "delay_hours": 18, "queued_for_replay": True}},
    {"id": "MR-006", "usage_event_id": "UE-007", "cdr_id": "CDR-ROAM-MVNO-001","billing_account_id": "BA-100002", "status": "rated",     "rating_attempt_count": 1, "billing_period": "2026-03", "payload": {"rated_amount_usd": 160.00,"charge_type": "roaming_data", "partner_id": "PARTNER-001", "discrepancy_flagged": True}},
    {"id": "MR-007", "usage_event_id": "UE-008", "cdr_id": "CDR-SPIKE-001",    "billing_account_id": "BA-100001", "status": "rated",     "rating_attempt_count": 1, "billing_period": "2026-04", "payload": {"rated_amount_usd": 21.00, "anomaly_pre_bill": True,      "nwdaf_alert": True}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Rated Usage
# ─────────────────────────────────────────────────────────────────────────────

RATED_USAGE = [
    {"id": "RU-001",     "mediation_record_id": "MR-001", "bill_id": "BILL-202604", "billing_account_id": "BA-100001", "amount": 6.25,   "charge_type": "data",    "service_type": "5G_data",         "billing_period": "2026-04", "payload": {"session_id": "SESSION-5001",            "volume_gb": 2.0,  "rate_per_gb": 3.125}},
    {"id": "RU-DUP-001", "mediation_record_id": "MR-002", "bill_id": "BILL-202604", "billing_account_id": "BA-100001", "amount": 6.25,   "charge_type": "data",    "service_type": "5G_data",         "billing_period": "2026-04", "payload": {"session_id": "SESSION-DUP-20260415",    "volume_gb": 2.0,  "duplicate": True, "correction_credit": -6.25}},
    {"id": "RU-002",     "mediation_record_id": "MR-003", "bill_id": "BILL-202604", "billing_account_id": "BA-100001", "amount": 48.00,  "charge_type": "data",    "service_type": "5G_data",         "billing_period": "2026-04", "payload": {"session_id": "SESSION-ZOMBIE-4491",     "volume_gb": 15.4, "actual_usage_gb": 0.0, "zombie_charge": True}},
    {"id": "RU-003",     "mediation_record_id": "MR-004", "bill_id": "BILL-202511", "billing_account_id": "BA-100002", "amount": 25.00,  "charge_type": "data",    "service_type": "premium_5g_slice","billing_period": "2026-04", "payload": {"slice_id": "SLICE-PREMIUM-001",         "billed_nssai": "01-000001", "actual_nssai": "01-000002"}},
    {"id": "RU-004",     "mediation_record_id": "MR-006", "bill_id": "BILL-202510", "billing_account_id": "BA-100002", "amount": 160.00, "charge_type": "roaming", "service_type": "roaming_data",    "billing_period": "2026-03", "payload": {"partner_id": "PARTNER-001",              "partner_amount": 60.00, "discrepancy": 100.00}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Service Inventory
# ─────────────────────────────────────────────────────────────────────────────

SERVICE_INVENTORY = [
    {"id": "SVC-INV-VOICE-100001", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "service_type": "voice",             "service_id": "SVC-VOICE-100001",     "status": "active", "product_offering_id": "PO-001", "payload": {"msisdn": "+15550101", "imsi": "310410100001001", "plan": "Standard 5G"}},
    {"id": "SVC-INV-DATA-100001",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "service_type": "data",              "service_id": "SVC-DATA-100001",      "status": "active", "product_offering_id": "PO-001", "payload": {"apn": "internet", "ip_version": "IPv4v6", "data_allowance_gb": 30}},
    {"id": "SVC-INV-ROAM-100001",  "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "service_type": "roaming",           "service_id": "SVC-ROAM-100001",      "status": "active", "product_offering_id": "PO-004", "payload": {"roaming_zones": ["EU", "APAC", "LATAM"]}},
    {"id": "SVC-INV-SLICE-100001", "customer_id": "CUST-100001", "billing_account_id": "BA-100001", "service_type": "premium_5g_slice",  "service_id": "SVC-SLICE-100001",     "status": "active", "product_offering_id": "PO-005", "payload": {"nssai": "01-000001", "guaranteed_mbps": 100, "slice_id": "SLICE-PREMIUM-001"}},
    {"id": "SVC-INV-ENT-100002",   "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "service_type": "data",              "service_id": "SVC-ENT-100002",       "status": "active", "product_offering_id": "PO-006", "payload": {"lines": 20, "enterprise_apn": "broadcom.corp", "sla_ref": "SLA-ENT-2025"}},
    {"id": "SVC-INV-SLICE-100002", "customer_id": "CUST-100002", "billing_account_id": "BA-100002", "service_type": "premium_5g_slice",  "service_id": "SVC-SLICE-100002",     "status": "active", "product_offering_id": "PO-005", "payload": {"nssai": "01-000001", "guaranteed_mbps": 100, "billed_lines": 20}},
    {"id": "SVC-INV-VOICE-100003", "customer_id": "CUST-100003", "billing_account_id": "BA-100003", "service_type": "voice",             "service_id": "SVC-VOICE-100003",     "status": "active", "product_offering_id": "PO-001", "payload": {"msisdn": "+15550103", "imsi": "310410100003001"}},
    {"id": "SVC-INV-MVNO-100008",  "customer_id": "CUST-100008", "billing_account_id": "BA-100008", "service_type": "wholesale",         "service_id": "SVC-WHOLESALE-100008", "status": "active", "product_offering_id": "PO-008", "payload": {"mvno_id": "PARTNER-001", "subscriber_count": 85000, "roaming_enabled": True}},
]

# ─────────────────────────────────────────────────────────────────────────────
#  Partner Accounts and Settlements
# ─────────────────────────────────────────────────────────────────────────────

PARTNER_ACCOUNTS = [
    {"id": "PARTNER-001", "name": "MVNO-X Communications",    "partner_type": "MVNO",    "country_code": "US", "plmn_id": "310-999", "settlement_currency": "USD", "status": "active",
     "payload": {"subscriber_base": 85000, "roaming_agreement": "RA-2024-001", "settlement_day": 15, "revenue_share_pct": 30, "contact": "settlement@mvnox.example.com"}},
    {"id": "PARTNER-002", "name": "GlobalRoam Partners Ltd.", "partner_type": "roaming", "country_code": "GB", "plmn_id": "234-30", "settlement_currency": "USD", "status": "active",
     "payload": {"roaming_countries": ["GB", "DE", "FR", "IT", "ES"], "ir21_ref": "IR21-GRP-2025", "tac_agreement": "TAC-2025-GB-001", "contact": "billing@globalroam.example.com"}},
]

PARTNER_SETTLEMENTS = [
    {"id": "PS-MVNOX-202603",    "partner_account_id": "PARTNER-001", "billing_period": "2026-03", "csp_record_amount": 5120.00, "partner_record_amount": 1920.00, "discrepancy_amount": 3200.00, "currency": "USD", "status": "disputed",  "issue_id": "ISSUE-P7-001",
     "payload": {"csp_cdr_count": 1284, "partner_cdr_count": 482, "missing_cdrs": 802, "roaming_sessions_disputed": ["CDR-ROAM-MVNO-001", "CDR-ROAM-MVNO-002"], "dispute_raised_by": "CSP", "sepp_evidence": "SEPP-LOG-2026-03-MVNOX"}},
    {"id": "PS-GLOBALROAM-202603","partner_account_id": "PARTNER-002", "billing_period": "2026-03", "csp_record_amount": 2340.00, "partner_record_amount": 2290.00, "discrepancy_amount": 50.00,   "currency": "USD", "status": "resolved",  "issue_id": None,
     "payload": {"resolution": "Minor rounding difference in TAP file processing. Agreed to use CSP figure.", "resolved_at": "2026-04-10"}},
]


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

async def _upsert(session, model, data_list: list):
    """Insert record if primary key not already present (idempotent)."""
    for item in data_list:
        if not await session.get(model, item["id"]):
            session.add(model(**item))


# ─────────────────────────────────────────────────────────────────────────────
#  Master seed runner
# ─────────────────────────────────────────────────────────────────────────────

async def seed():
    logger.info("Creating / verifying database tables...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        for ddl in DDL_PATCHES:
            try:
                await conn.execute(text(ddl))
            except Exception as e:
                logger.debug("DDL patch skipped (%s): %s", ddl[:60], e)

    async with AsyncSessionFactory() as db:
        logger.info("Seeding use cases...")
        for uc in USE_CASES:
            await db.merge(UseCase(**uc))
        await db.commit()

        logger.info("Seeding %d customers...", len(CUSTOMERS))
        for c in CUSTOMERS:
            await db.merge(Customer(**c))
        await db.commit()

        logger.info("Seeding %d billing accounts...", len(BILLING_ACCOUNTS))
        for ba in BILLING_ACCOUNTS:
            await db.merge(BillingAccount(**ba))
        await db.commit()

        logger.info("Seeding %d bills...", len(BILLS))
        for b in BILLS:
            await db.merge(Bill(**b))
        await db.commit()

        logger.info("Seeding %d issues (P1–P10)...", len(ISSUES))
        for issue in ISSUES:
            await db.merge(Issue(**issue))
        await db.commit()

        logger.info("Seeding TMF events...")
        await _upsert(db, TMFEvent, TMF_EVENTS)
        await db.commit()

        logger.info("Seeding trouble tickets...")
        await _upsert(db, TroubleTicket, TROUBLE_TICKETS)
        await db.commit()

        logger.info("Seeding service problems...")
        await _upsert(db, ServiceProblem, SERVICE_PROBLEMS)
        await db.commit()

        logger.info("Seeding %d products + %d offerings...", len(PRODUCTS), len(PRODUCT_OFFERINGS))
        await _upsert(db, Product, PRODUCTS)
        await db.commit()
        await _upsert(db, ProductOffering, PRODUCT_OFFERINGS)
        await db.commit()

        logger.info("Seeding %d bill line items...", len(BILL_LINE_ITEMS))
        await _upsert(db, BillLineItem, BILL_LINE_ITEMS)
        await db.commit()

        logger.info("Seeding %d devices...", len(DEVICES))
        await _upsert(db, Device, DEVICES)
        await db.commit()

        logger.info("Seeding %d payment records...", len(PAYMENT_RECORDS))
        await _upsert(db, PaymentRecord, PAYMENT_RECORDS)
        await db.commit()

        logger.info("Seeding %d network functions...", len(NETWORK_FUNCTIONS))
        await _upsert(db, NetworkFunction, NETWORK_FUNCTIONS)
        await db.commit()

        logger.info("Seeding %d PDU sessions...", len(PDU_SESSIONS))
        await _upsert(db, PDUSession, PDU_SESSIONS)
        await db.commit()

        logger.info("Seeding %d usage events...", len(USAGE_EVENTS))
        await _upsert(db, UsageEvent, USAGE_EVENTS)
        await db.commit()

        logger.info("Seeding %d mediation records...", len(MEDIATION_RECORDS))
        await _upsert(db, MediationRecord, MEDIATION_RECORDS)
        await db.commit()

        logger.info("Seeding %d rated usage records...", len(RATED_USAGE))
        await _upsert(db, RatedUsage, RATED_USAGE)
        await db.commit()

        logger.info("Seeding %d service inventory records...", len(SERVICE_INVENTORY))
        await _upsert(db, ServiceInventory, SERVICE_INVENTORY)
        await db.commit()

        logger.info("Seeding partner accounts and settlements...")
        await _upsert(db, PartnerAccount, PARTNER_ACCOUNTS)
        await db.commit()
        await _upsert(db, PartnerSettlement, PARTNER_SETTLEMENTS)
        await db.commit()

    logger.info("✅ Master seed complete.")


if __name__ == "__main__":
    asyncio.run(seed())
