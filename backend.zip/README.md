# Billing Control Tower Backend

A high-fidelity agentic backend for Telecom Billing Control Tower, implementing a 4-layer autonomous orchestration model with **Standard-Aligned RAG Playbooks**.

## 🚀 Overview

This backend leverages **LangGraph** to orchestrate complex telecom billing investigations. It correlates data across BSS (Billing/CRM), OSS (Assurance/Mediation), and Network (Core/Resource) domains to proactively resolve billing discrepancies.

### Core Technologies
- **Framework**: FastAPI
- **Orchestration**: LangGraph (StateGraph)
- **RAG (Retrieval)**: FAISS with Sentence-Transformers
- **Persistence**: PostgreSQL (Business State) & SQLite (Graph Checkpoints)
- **AI**: LangChain with support for OpenAI, Azure, and Vertex AI
- **Standards**: Aligned with 3GPP 5G Charging and TM Forum ODA

## 📁 Project Structure

```text
app/
├── api/            # API Layer (FastAPI)
├── core/           # Agentic Core (Agents, Orchestrator, RAG, LLM)
├── db/             # Data Access Layer (SQLAlchemy Models & Repository)
├── main.py         # Entry point
└── settings.py     # Configuration
data/
└── playbooks/      # Standard-aligned troubleshooting SOPs (Markdown)
tests/              # Comprehensive Pytest suite
```

## 🧠 Agentic & RAG Architecture

The system implements a **4-Layer Hub-and-Spoke** model enhanced with **Retrieval-Augmented Generation**:

1.  **L1: Governance & Triage**: Handles initial classification and cross-domain correlation.
2.  **Retrieval Node**: Automatically consults **Troubleshooting Playbooks** using vector search.
3.  **L2: BSS Revenue & Care**: Interfaces with Billing (TMF678), CRM, and Payments.
4.  **L3: Service Assurance & Mediation**: Analyzes network quality and mediation usage feeds.
5.  **L4: Resource & Network**: Deep-dives into 3GPP network telemetry (SMF/CHF/UPF).

## 🛠️ Getting Started

### 1. Setup Environment
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment
Create a `.env` file with your LLM provider details (OpenAI/Azure/Vertex).

### 3. Initialize & Seed
```bash
python -c "from app.db import init_db; from app.seed import seed_all; from app.db import get_db; db=next(get_db()); init_db(); seed_all(db)"
```

### 4. Run the Application
```bash
python -m uvicorn app.main:app --reload
```

## 🧪 Testing

The project includes a comprehensive testing suite for all 10 telecom use cases and API endpoints:
```bash
pytest tests
```

## 📖 Documentation
- [Architecture & Design](docs/architecture.md): Deep dive into the 4-layer graph and RAG system.
- [Database Schema](docs/db-schema.md): SQLAlchemy models and persistence strategy.
- [Telecom Use Cases](docs/usecases.md): 10 core billing and network discrepancy scenarios.
