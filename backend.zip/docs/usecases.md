# Telecom Billing Dispute Use Cases - Detailed Analysis

This document captures the detailed use case examples and technical systems from the Excel sheet `telecom_billing_dispute_network_usecases_v0.4_updated.xls`.

## 1. Missing or Delayed Usage Feed into Billing (UC01)
- **General Issue**: Late usage delivery affects the initial invoice.
- **Example**: Emma streams high-volume video near the end of her billing cycle. Due to a watermark lag in the mediation system, the usage records are not processed before the invoice run completes. Her bill appears unusually low, but the next month's bill includes a large "catch-up" amount, causing bill shock.
- **Systems to Investigate**: Mediation (watermark/lag), Event feeds (TMF688), Billing (TMF678).
- **Remediation**: Replay late usage before the bill is finalized, or provide a controlled rebill delta.

## 2. Duplicate Charging / Duplicate Usage Rating (UC02)
- **General Issue**: The same event appears charged twice.
- **Example**: Daniel activates a short-term data add-on. Due to a technical error in the charging transaction correlation, the activation event and a subsequent interim update are both rated as separate one-off charges. He sees two identical fees on his post-bill statement and disputes the duplicate.
- **Systems to Investigate**: Charging (CHF/OCS), Transaction correlation, Mediation suppression.
- **Remediation**: Reverse duplicate rated amount.

## 3. Zombie PDU session leading to unfair data charging (UC03)
- **General Issue**: Charging continues after the session should have ended.
- **Example**: Sophie finishes a video call and leaves her handset idle overnight. A stale PDU session is not released correctly, so the charging path continues to receive usage updates. By the next morning, she sees much higher data consumption than expected.
- **Systems to Investigate**: SMF, UPF, AMF, PCF, Charging (CHF/OCS), Network traces.
- **Remediation**: Stop stale session and protect the bill.

## 4. QoS or slice entitlement mismatch with premium charging (UC04)
- **General Issue**: Premium service billed but standard performance delivered.
- **Example**: An enterprise customer pays for high-priority 5G for handheld scanners. Performance measurements (latency/throughput) align with standard service because of a policy mapping error. The invoice still includes premium charging.
- **Systems to Investigate**: PCF, SMF, QoS/Slice policy systems, RAN performance, SLA analytics.
- **Remediation**: Remove premium uplift or apply credit.

## 5. Service degradation requiring commercial compensation (UC05)
- **General Issue**: Technically correct bill but poor service quality justifies credit.
- **Example**: Oliver experiences persistent latency spikes and packet loss during peak hours, affecting remote work. Assurance data confirms area-wide degradation.
- **Systems to Investigate**: RAN/Transport monitoring, Service quality analytics, Trouble ticketing.
- **Remediation**: Apply commercial compensation or goodwill credit.

## 6. Collections hold required during billing dispute (UC06)
- **General Issue**: Partial dispute should block collections on the disputed amount only.
- **Example**: A customer disputes £28 of a £96 bill. The dunning process must be updated to hold only the £28 while the rest remains payable.
- **Systems to Investigate**: Billing, Accounts Receivable, Collections/Dunning, CRM.
- **Remediation**: Apply disputed balance hold.

## 7. Partner or wholesale charge discrepancy (UC07)
- **General Issue**: Roaming/partner charges differ from customer expectations.
- **Example**: A roaming subscriber sees higher charges than expected because home and visited network records do not reconcile cleanly.
- **Systems to Investigate**: Roaming feeds, Mediation, Wholesale settlement, Charging.
- **Remediation**: Temporary retail credit while wholesale settles.

## 8. Confusing invoice with technically valid but opaque charges (UC08)
- **General Issue**: Technically correct bill but difficult to understand.
- **Example**: A family plan with shared data, proration, and add-ons is valid but confusing to the customer.
- **Systems to Investigate**: Bill document generation, Bill inquiry, Product catalogue.
- **Remediation**: Generate a customer-safe bill narrative/explanation.

## 9. Internal anomaly discovered by monitoring before customer impact (UC09)
- **General Issue**: Proactive detection of charging anomalies.
- **Example**: Monitoring detects an increase in duplicate interim charging updates before the bill run. Ops suppresses duplicates to prevent customer impact.
- **Systems to Investigate**: Observability, Charging streams, Pre-bill controls.
- **Remediation**: Suppress risky feed before bill run.

## 10. Governed end-to-end dispute handling (UC10)
- **General Issue**: Multiple teams need a single auditable path.
- **Example**: An enterprise customer disputes charges across multiple sites, requiring input from network, billing, and finance teams.
- **Systems to Investigate**: Case management, Workflow/Approvals, RCA tools, Network evidence.
- **Remediation**: Capture auditable cross-domain resolution.
