# Architecture: 4-Layer Agentic Orchestration & RAG

The Billing Control Tower implements a tiered agentic architecture designed to bridge the gap between business billing (BSS), technical service assurance (OSS), and the physical network resources. It is enhanced with **Retrieval-Augmented Generation (RAG)** to ensure all investigations follow standard troubleshooting playbooks.

## 1. The 4-Layer Model

We use a "Hub-and-Spoke" orchestration model powered by **LangGraph**. A central Master Agent orchestrates data collection and reasoning across four specialized layers.

### Layer 1: Governance & Triage
- **Focus**: Cross-domain correlation, policy enforcement, and final summarization.
- **Agents**: Triage Agent, Master Agent, Summarize Agent.
- **RAG Component**: The **Retrieval Node** consults standard playbooks (SOPs) based on the case context before routing to technical layers.

### Layer 2: BSS Revenue & Care
- **Focus**: The financial and customer-facing view of the bill.
- **Systems**: TMF678 (Billing), CRM, Payments, AR.
- **Responsibilities**: Validating entitlements, checking for duplicate charges, and applying credits.

### Layer 3: Service Assurance & Mediation
- **Focus**: The technical validity of the usage feeds.
- **Systems**: Mediation, Service Quality Analytics, Trouble Ticketing.
- **Responsibilities**: Correlating area-wide service degradation with customer impact and verifying usage file integrity.

### Layer 4: Resource & Network (3GPP Aligned)
- **Focus**: The physical/virtual resource state.
- **Systems**: Core Network (SMF/CHF/UPF/CGF), Network Traces, Slice Performance.
- **Responsibilities**: Verifying session release states (Zombie sessions), PDU session telemetry, and physical resource RCA.

## 2. Graph Workflow

```mermaid
graph TD
    START --> Triage[Triage Agent]
    Triage --> Retrieval[Retrieval Node: FAISS RAG]
    Retrieval --> Master{Master Agent}
    
    Master -- Billing Issue --> L2[Layer 2: BSS]
    Master -- Service Quality --> L3[Layer 3: Assurance]
    Master -- Usage Anomaly --> L4[Layer 4: Resource]
    
    L2 --> Master
    L3 --> Master
    L4 --> Master
    
    Master -- Finalize --> Summarize[Summarize Agent]
    Summarize --> END
```

## 3. RAG System (Playbooks)
- **Vector Store**: FAISS (Facebook AI Similarity Search).
- **Embeddings**: `all-MiniLM-L6-v2` (Sentence-Transformers).
- **Playbooks**: Markdown-based troubleshooting and remediation logic stored in `data/playbooks/`.
- **Usage**: The system semantically retrieves the top 3 SOP sections per case to ground agent reasoning.

## 4. State Management & Persistence
- **InvestigationState**: Shared across all agents, containing findings, recommendations, tool calls, and retrieved playbooks.
- **Business Data**: PostgreSQL for cases, runs, and audit events.
- **Graph Memory**: SQLite for execution checkpoints (LangGraph `SqliteSaver`).
- **Playbook Index**: Stored locally in `data/faiss_index` for fast retrieval.
