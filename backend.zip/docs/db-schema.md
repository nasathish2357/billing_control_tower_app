# Database Schema & Persistence Strategy

The system uses a triple-persistence strategy: **PostgreSQL** for the business system of record, **SQLite** for the LangGraph execution checkpoints, and **FAISS** for the RAG vector index.

## 1. Business Data (PostgreSQL)

Managed via SQLAlchemy in `app/db/models.py`.

### Core Entities
- **`use_case`**: Catalog of investigation types (persona, category, workflow).
- **`customer` / `billing_account`**: Telecom hierarchy and financial profiles.
- **`invoice` / `invoice_line`**: Billing records and rated usage items.

### Case & Run Management
- **`billing_case`**: Stores the dispute status, chat history, and backend actions.
- **`billing_run`**: A specific execution of the agentic graph. Includes:
    - `completed_agents`: Audit trail of the routing.
    - `findings` / `recommendations`: Final results.
    - `tool_calls` / `trace`: Technical logs for UI playback.
    - `llm_outputs`: Raw responses for prompt engineering analysis.
- **`investigation_finding`**: Individual discoveries (Agent, Severity, Evidence).

## 2. Orchestration State (SQLite)

LangGraph uses `data/checkpoints.sqlite` to manage the state machine's persistence. This allows for **asynchronous human-in-the-loop** workflows where the graph can pause for an approval and resume later.

## 3. RAG Vector Store (FAISS)

The system indexes markdown playbooks from `data/playbooks/` into a FAISS vector store located in `data/faiss_index/`.
- **Retrieval**: Agents consult this index to ensure compliance with troubleshooting SOPs.
- **Reindexing**: Triggered via API to refresh SOPs without a deployment.

## 4. Integration Logic
1.  **Orchestrator** loads the case from Postgres.
2.  **LangGraph** manages transitions and saves progress to SQLite.
3.  **Agents** search FAISS for playbook guidance.
4.  **Service Layer** aggregates results back into Postgres for UI consumption.
