from __future__ import annotations

import os
from pydantic import BaseModel


class AppSettings(BaseModel):
    app_name: str = os.getenv('APP_NAME', 'Billing Control Tower Backend')
    version: str = os.getenv('APP_VERSION', '0.4.0')
    demo_mode: bool = os.getenv('DEMO_MODE', 'true').lower() == 'true'

    # Provider options
    llm_provider: str = os.getenv('LLM_PROVIDER', 'demo')  # demo | openai | azure_openai | vertex_ai
    openai_api_key: str | None = os.getenv('OPENAI_API_KEY')
    openai_model: str = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')

    azure_openai_endpoint: str | None = os.getenv('AZURE_OPENAI_ENDPOINT')
    azure_openai_api_key: str | None = os.getenv('AZURE_OPENAI_API_KEY')
    azure_openai_api_version: str = os.getenv('AZURE_OPENAI_API_VERSION', '2024-10-21')
    azure_openai_deployment: str | None = os.getenv('AZURE_OPENAI_DEPLOYMENT')

    vertex_project: str | None = os.getenv('VERTEX_PROJECT')
    vertex_location: str = os.getenv('VERTEX_LOCATION', 'us-central1')
    vertex_model: str = os.getenv('VERTEX_MODEL', 'gemini-2.0-flash')

    # Persistence / graph checkpointing
    checkpoint_sqlite_path: str = os.getenv('CHECKPOINT_SQLITE_PATH', './data/langgraph_checkpoints.sqlite')
    postgres_dsn: str | None = os.getenv('POSTGRES_DSN')
    enable_postgres: bool = os.getenv('ENABLE_POSTGRES', 'false').lower() == 'true'

    retrieval_last_indexed_at: str | None = None


settings = AppSettings()
