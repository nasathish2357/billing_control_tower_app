from __future__ import annotations

from app.db import get_store


def get_customer(customer_id: str) -> dict:
    return get_store().seed['customers'][customer_id]


def get_billing_account(account_id: str) -> dict:
    return get_store().seed['accounts'][account_id]


def get_bill(invoice_id: str) -> dict:
    return get_store().seed['invoices'][invoice_id]


def get_trouble_ticket(ticket_id: str) -> dict:
    return get_store().seed['trouble_tickets'][ticket_id]
