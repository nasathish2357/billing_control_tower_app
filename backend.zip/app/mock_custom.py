from __future__ import annotations

from app.db import get_store


def get_partner_settlement(invoice_id: str) -> dict:
    return get_store().seed['partner_settlements'][invoice_id]


def get_entitlements(customer_id: str) -> dict:
    return get_store().seed['entitlements'][customer_id]


def get_payment_profile(account_id: str) -> dict:
    return get_store().seed['payments'][account_id]


def get_collections_profile(account_id: str) -> dict:
    return get_store().seed['collections'][account_id]


def get_service_assurance(account_id: str) -> dict:
    return get_store().seed['service_assurance'][account_id]


def get_product_inventory(customer_id: str) -> dict:
    return get_store().seed['product_inventory'][customer_id]


def get_tax_profile(customer_id: str) -> dict:
    return get_store().seed['tax_profiles'][customer_id]


def get_fraud_alert(customer_id: str) -> dict:
    return get_store().seed['fraud_alerts'][customer_id]


def get_identity_event(customer_id: str) -> dict:
    return get_store().seed['identity_events'][customer_id]


def get_retention_offer(customer_id: str) -> dict:
    return get_store().seed['retention_offers'][customer_id]


def get_schedule(customer_id: str) -> dict:
    return get_store().seed['schedules'][customer_id]
