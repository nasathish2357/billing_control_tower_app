from contextlib import asynccontextmanager
from fastapi import FastAPI

from app.api.router import router
from app.settings import settings
from app.db import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize database tables
    init_db()
    yield


from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title=settings.app_name, 
    version=settings.version,
    lifespan=lifespan
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


@app.get('/health')
def health():
    return {
        'status': 'ok',
        'app': settings.app_name,
        'version': settings.version,
        'demoMode': settings.demo_mode,
        'llmProvider': settings.llm_provider,
        'retrievalLastIndexedAt': settings.retrieval_last_indexed_at,
    }
