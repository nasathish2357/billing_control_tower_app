from __future__ import annotations

from app.core.usecase_catalog import ALL_USECASES
from app.db.models import UseCaseModel, CustomerModel, BillingAccountModel, InvoiceModel, CaseModel, InvoiceLineModel


def build_seed_data() -> dict:
    usecases = ALL_USECASES

    customers = {
        'CUST_1001': {'id': 'CUST_1001', 'name': 'Acme Telecom Customer', 'segment': 'enterprise', 'billingAccountId': 'ACC_1001', 'jurisdiction': 'CA'},
        'CUST_1002': {'id': 'CUST_1002', 'name': 'Northwind Subscriber', 'segment': 'consumer', 'billingAccountId': 'ACC_1002', 'jurisdiction': 'TX'},
        'CUST_1003': {'id': 'CUST_1003', 'name': 'Contoso Mobile', 'segment': 'consumer', 'billingAccountId': 'ACC_1003', 'jurisdiction': 'WA'},
        'TELCO_CUST_EMMA': {'id': 'TELCO_CUST_EMMA', 'name': 'Emma (UC01)', 'segment': 'consumer', 'billingAccountId': 'ACC_EMMA', 'jurisdiction': 'UK'},
        'TELCO_CUST_DANIEL': {'id': 'TELCO_CUST_DANIEL', 'name': 'Daniel (UC02)', 'segment': 'consumer', 'billingAccountId': 'ACC_DANIEL', 'jurisdiction': 'UK'},
        'TELCO_CUST_SOPHIE': {'id': 'TELCO_CUST_SOPHIE', 'name': 'Sophie (UC03)', 'segment': 'consumer', 'billingAccountId': 'ACC_SOPHIE', 'jurisdiction': 'UK'},
        'TELCO_CUST_OLIVER': {'id': 'TELCO_CUST_OLIVER', 'name': 'Oliver (UC05)', 'segment': 'consumer', 'billingAccountId': 'ACC_OLIVER', 'jurisdiction': 'UK'},
        'TELCO_CUST_HANNAH': {'id': 'TELCO_CUST_HANNAH', 'name': 'Hannah (UC08)', 'segment': 'consumer', 'billingAccountId': 'ACC_HANNAH', 'jurisdiction': 'UK'},
        'TELCO_CUST_AMELIA': {'id': 'TELCO_CUST_AMELIA', 'name': 'Amelia (UC04)', 'segment': 'enterprise', 'billingAccountId': 'ACC_AMELIA', 'jurisdiction': 'UK'},
        'TELCO_CUST_JACK': {'id': 'TELCO_CUST_JACK', 'name': 'Jack (UC06)', 'segment': 'consumer', 'billingAccountId': 'ACC_JACK', 'jurisdiction': 'UK'},
        'TELCO_CUST_SOPHIA': {'id': 'TELCO_CUST_SOPHIA', 'name': 'Sophia (UC07)', 'segment': 'consumer', 'billingAccountId': 'ACC_SOPHIA', 'jurisdiction': 'UK'},
        'TELCO_CUST_LEO': {'id': 'TELCO_CUST_LEO', 'name': 'Leo (UC09)', 'segment': 'enterprise', 'billingAccountId': 'ACC_LEO', 'jurisdiction': 'UK'},
        'TELCO_CUST_MIA': {'id': 'TELCO_CUST_MIA', 'name': 'Mia (UC10)', 'segment': 'enterprise', 'billingAccountId': 'ACC_MIA', 'jurisdiction': 'UK'},
    }

    accounts = {
        'ACC_1001': {'id': 'ACC_1001', 'customerId': 'CUST_1001', 'status': 'active', 'currency': 'USD', 'autopay': False},
        'ACC_1002': {'id': 'ACC_1002', 'customerId': 'CUST_1002', 'status': 'active', 'currency': 'USD', 'autopay': True},
        'ACC_1003': {'id': 'ACC_1003', 'customerId': 'CUST_1003', 'status': 'active', 'currency': 'USD', 'autopay': False},
        'ACC_EMMA': {'id': 'ACC_EMMA', 'customerId': 'TELCO_CUST_EMMA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_DANIEL': {'id': 'ACC_DANIEL', 'customerId': 'TELCO_CUST_DANIEL', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_SOPHIE': {'id': 'ACC_SOPHIE', 'customerId': 'TELCO_CUST_SOPHIE', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_OLIVER': {'id': 'ACC_OLIVER', 'customerId': 'TELCO_CUST_OLIVER', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_HANNAH': {'id': 'ACC_HANNAH', 'customerId': 'TELCO_CUST_HANNAH', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_AMELIA': {'id': 'ACC_AMELIA', 'customerId': 'TELCO_CUST_AMELIA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_JACK': {'id': 'ACC_JACK', 'customerId': 'TELCO_CUST_JACK', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_SOPHIA': {'id': 'ACC_SOPHIA', 'customerId': 'TELCO_CUST_SOPHIA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_LEO': {'id': 'ACC_LEO', 'customerId': 'TELCO_CUST_LEO', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_MIA': {'id': 'ACC_MIA', 'customerId': 'TELCO_CUST_MIA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
    }

    invoices = {
        'INV_2026_0001': {
            'id': 'INV_2026_0001', 'accountId': 'ACC_1001', 'customerId': 'CUST_1001', 'period': '2026-02', 'amount': 1890.0,
            'baselineAmount': 1180.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_0001', 'type': 'roaming', 'amount': 540.0, 'expected': 80.0},
                {'lineId': 'LINE_0002', 'type': 'plan', 'amount': 900.0, 'expected': 900.0},
                {'lineId': 'LINE_0003', 'type': 'discount_missing', 'amount': 450.0, 'expected': 200.0},
            ],
        },
        'INV_EMMA_01': {
            'id': 'INV_EMMA_01', 'accountId': 'ACC_EMMA', 'customerId': 'TELCO_CUST_EMMA', 'period': '2026-03', 'amount': 125.0,
            'baselineAmount': 45.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_E1', 'type': 'data-usage', 'amount': 80.0, 'expected': 0.0, 'description': 'Catch-up data usage from Feb'},
                {'lineId': 'LINE_E2', 'type': 'plan', 'amount': 45.0, 'expected': 45.0},
            ],
        },
        'INV_DANIEL_01': {
            'id': 'INV_DANIEL_01', 'accountId': 'ACC_DANIEL', 'customerId': 'TELCO_CUST_DANIEL', 'period': '2026-03', 'amount': 65.0,
            'baselineAmount': 45.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_D1', 'type': 'addon', 'amount': 10.0, 'expected': 10.0, 'description': '5G Data Booster'},
                {'lineId': 'LINE_D2', 'type': 'addon-dup', 'amount': 10.0, 'expected': 0.0, 'description': '5G Data Booster (Duplicate)'},
                {'lineId': 'LINE_D3', 'type': 'plan', 'amount': 45.0, 'expected': 45.0},
            ],
        },
        'INV_SOPHIE_01': {
            'id': 'INV_SOPHIE_01', 'accountId': 'ACC_SOPHIE', 'customerId': 'TELCO_CUST_SOPHIE', 'period': '2026-03', 'amount': 150.0,
            'baselineAmount': 50.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_S1', 'type': 'data-usage', 'amount': 100.0, 'expected': 0.0, 'description': 'Overage during idle PDU session'},
                {'lineId': 'LINE_S2', 'type': 'plan', 'amount': 50.0, 'expected': 50.0},
            ],
        },
    }

    scenarios = {
        'telco_uc01': {'customerId': 'TELCO_CUST_EMMA', 'accountId': 'ACC_EMMA', 'invoiceId': 'INV_EMMA_01', 'title': 'Emma - Delayed Usage Feed'},
        'telco_uc02': {'customerId': 'TELCO_CUST_DANIEL', 'accountId': 'ACC_DANIEL', 'invoiceId': 'INV_DANIEL_01', 'title': 'Daniel - Duplicate Charging'},
        'telco_uc03': {'customerId': 'TELCO_CUST_SOPHIE', 'accountId': 'ACC_SOPHIE', 'invoiceId': 'INV_SOPHIE_01', 'title': 'Sophie - Zombie PDU Session'},
        'telco_uc04': {'customerId': 'TELCO_CUST_AMELIA', 'accountId': 'ACC_AMELIA', 'invoiceId': None, 'title': 'Amelia - Slice Entitlement Mismatch'},
        'telco_uc05': {'customerId': 'TELCO_CUST_OLIVER', 'accountId': 'ACC_OLIVER', 'invoiceId': None, 'title': 'Oliver - Service Degradation'},
        'telco_uc06': {'customerId': 'TELCO_CUST_JACK', 'accountId': 'ACC_JACK', 'invoiceId': None, 'title': 'Jack - Collections Hold'},
        'telco_uc07': {'customerId': 'TELCO_CUST_SOPHIA', 'accountId': 'ACC_SOPHIA', 'invoiceId': None, 'title': 'Sophia - Roaming Variance'},
        'telco_uc08': {'customerId': 'TELCO_CUST_HANNAH', 'accountId': 'ACC_HANNAH', 'invoiceId': None, 'title': 'Hannah - Opaque Invoice'},
        'telco_uc09': {'customerId': 'TELCO_CUST_LEO', 'accountId': 'ACC_LEO', 'invoiceId': None, 'title': 'Leo - Proactive Anomaly Detection'},
        'telco_uc10': {'customerId': 'TELCO_CUST_MIA', 'accountId': 'ACC_MIA', 'invoiceId': None, 'title': 'Mia - Governed Dispute RCA'},
        'UC01': {'customerId': 'CUST_1001', 'accountId': 'ACC_1001', 'invoiceId': 'INV_2026_0001', 'title': 'Legacy Bill Shock'},
    }

    return {
        'usecases': usecases,
        'customers': customers,
        'accounts': accounts,
        'invoices': invoices,
        'scenarios': scenarios,
        'trouble_tickets': {},
        'partner_settlements': {},
        'entitlements': {},
        'payments': {},
        'collections': {},
        'service_assurance': {},
        'product_inventory': {},
        'tax_profiles': {},
        'fraud_alerts': {},
        'identity_events': {},
        'retention_offers': {},
        'schedules': {},
        'evidence': {},
    }


def seed_all(db):
    data = build_seed_data()
    
    for uc in data['usecases']:
        db.merge(UseCaseModel(
            usecase_id=uc['usecaseId'],
            title=uc['title'],
            description=uc.get('description', uc['title']),
            category=uc['category'],
            workflow=uc['workflow'],
            recommended_priority=uc.get('recommendedPriority', 'medium'),
            metadata_json={'persona': uc.get('persona')}
        ))
        
    for cid, c in data['customers'].items():
        db.merge(CustomerModel(
            customer_id=cid,
            name=c['name'],
            segment=c['segment'],
            jurisdiction=c['jurisdiction']
        ))
        
    for aid, a in data['accounts'].items():
        db.merge(BillingAccountModel(
            account_id=aid,
            customer_id=a['customerId'],
            status=a['status'],
            currency=a['currency'],
            autopay=a['autopay']
        ))
        
    for iid, i in data['invoices'].items():
        db.merge(InvoiceModel(
            invoice_id=iid,
            account_id=i['accountId'],
            customer_id=i['customerId'],
            period=i['period'],
            amount=i['amount'],
            baseline_amount=i['baselineAmount'],
            status=i['status']
        ))
        for li in i['lineItems']:
            db.merge(InvoiceLineModel(
                line_id=li['lineId'],
                invoice_id=iid,
                type=li['type'],
                amount=li['amount'],
                expected=li['expected'],
                description=li.get('description')
            ))
        
    for sid, s in data['scenarios'].items():
        db.merge(CaseModel(
            case_id=f"CASE_{sid.upper()}",
            usecase_id=sid,
            title=s['title'],
            customer_id=s['customerId'],
            account_id=s['accountId'],
            invoice_id=s['invoiceId'],
            priority='high',
            status='open'
        ))
        
    db.commit()



