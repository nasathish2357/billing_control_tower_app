from __future__ import annotations

from dataclasses import dataclass, field
from itertools import count
from typing import Any

from app.seed import build_seed_data


@dataclass
class MemoryStore:
    seed: dict[str, Any] = field(default_factory=build_seed_data)
    cases: dict[str, dict[str, Any]] = field(default_factory=dict)
    runs: dict[str, dict[str, Any]] = field(default_factory=dict)
    approvals: dict[str, dict[str, Any]] = field(default_factory=dict)
    actions: dict[str, dict[str, Any]] = field(default_factory=dict)
    case_counter: Any = field(default_factory=lambda: count(1001))
    approval_counter: Any = field(default_factory=lambda: count(1))
    action_counter: Any = field(default_factory=lambda: count(1))

    def next_case_id(self) -> str:
        return f"CASE_{next(self.case_counter)}"

    def next_run_id(self, case_id: str) -> str:
        seq = 1 + sum(1 for run in self.runs.values() if run['caseId'] == case_id)
        case_num = case_id.split('_')[-1]
        return f"RUN_{case_num}_{seq:02d}"

    def next_approval_id(self) -> str:
        return f"APR_{next(self.approval_counter):04d}"

    def next_action_id(self) -> str:
        return f"ACT_{next(self.action_counter):04d}"
