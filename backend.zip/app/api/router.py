from __future__ import annotations

from fastapi import APIRouter, Query, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.api.schemas import ActionApplyRequest, ApprovalCreateRequest, ApprovalDecisionRequest, CaseCreateRequest, CasePatchRequest
from app.api.services import ControlTowerService
from app.db import get_db
from app import mock_tmf, mock_custom

router = APIRouter()


def get_service(db: Session = Depends(get_db)) -> ControlTowerService:
    return ControlTowerService(db)


@router.get('/api/usecases')
def list_usecases(service: ControlTowerService = Depends(get_service)):
    return service.list_usecases()


@router.get('/api/usecases/{usecase_id}')
def get_usecase(usecase_id: str, service: ControlTowerService = Depends(get_service)):
    return service.get_usecase(usecase_id)


@router.post('/api/cases')
def create_case(payload: CaseCreateRequest, service: ControlTowerService = Depends(get_service)):
    return service.create_case(payload.model_dump())


@router.get('/api/cases/{case_id}')
def get_case(case_id: str, service: ControlTowerService = Depends(get_service)):
    return service.get_case(case_id)


@router.patch('/api/cases/{case_id}')
def patch_case(case_id: str, payload: CasePatchRequest, service: ControlTowerService = Depends(get_service)):
    return service.patch_case(case_id, payload.model_dump(exclude_none=True))


@router.post('/api/cases/{case_id}/investigate')
def investigate_case(case_id: str, service: ControlTowerService = Depends(get_service)):
    return service.investigate_case(case_id)


@router.get('/api/cases/{case_id}/runs/{run_id}')
def get_run(case_id: str, run_id: str, service: ControlTowerService = Depends(get_service)):
    return service.get_run(case_id, run_id)


@router.get('/api/cases/{case_id}/stream')
def stream_case(case_id: str, runId: str = Query(...), service: ControlTowerService = Depends(get_service)):
    return StreamingResponse(service.stream_events(case_id, runId), media_type='text/event-stream')


@router.post('/api/cases/{case_id}/remediate')
def remediate_case(case_id: str, service: ControlTowerService = Depends(get_service)):
    return service.remediate_case(case_id)


@router.post('/api/cases/{case_id}/chat')
def chat_case(case_id: str, payload: dict, service: ControlTowerService = Depends(get_service)):
    return service.chat_case(case_id, payload.get('message', ''))


@router.get('/api/cases/{case_id}/stream-manifest')
def stream_manifest(case_id: str, service: ControlTowerService = Depends(get_service)):
    # SSE playback manifest for UI
    case = service.get_case(case_id)
    return {'caseId': case_id, 'manifest': case.get('backendActions', [])}


@router.get('/api/search')
def search(q: str = Query(...), service: ControlTowerService = Depends(get_service)):
    return service.search(q)


@router.post('/api/reindex')
def reindex(service: ControlTowerService = Depends(get_service)):
    return service.reindex()


# TMF & Custom Mock APIs
@router.get('/tmf/customer/{customer_id}')
def tmf_customer(customer_id: str):
    return mock_tmf.get_customer(customer_id)

@router.get('/tmf/billing-account/{account_id}')
def tmf_account(account_id: str):
    return mock_tmf.get_billing_account(account_id)

@router.get('/tmf/bill/{invoice_id}')
def tmf_bill(invoice_id: str):
    return mock_tmf.get_bill(invoice_id)

@router.get('/tmf/trouble-ticket/{ticket_id}')
def tmf_trouble_ticket(ticket_id: str):
    return mock_tmf.get_trouble_ticket(ticket_id)

@router.get('/custom/partner-settlement/{invoice_id}')
def custom_partner_settlement(invoice_id: str):
    return mock_custom.get_partner_settlement(invoice_id)

@router.get('/custom/entitlements/{customer_id}')
def custom_entitlements(customer_id: str):
    return mock_custom.get_entitlements(customer_id)

@router.get('/custom/payment-profile/{account_id}')
def custom_payment_profile(account_id: str):
    return mock_custom.get_payment_profile(account_id)

@router.get('/custom/collections-profile/{account_id}')
def custom_collections_profile(account_id: str):
    return mock_custom.get_collections_profile(account_id)

@router.get('/custom/service-assurance/{account_id}')
def custom_service_assurance(account_id: str):
    return mock_custom.get_service_assurance(account_id)

@router.get('/custom/product-inventory/{customer_id}')
def custom_product_inventory(customer_id: str):
    return mock_custom.get_product_inventory(customer_id)

@router.get('/custom/tax-profile/{customer_id}')
def custom_tax_profile(customer_id: str):
    return mock_custom.get_tax_profile(customer_id)

@router.get('/custom/fraud-alert/{customer_id}')
def custom_fraud_alert(customer_id: str):
    return mock_custom.get_fraud_alert(customer_id)

@router.get('/custom/identity-event/{customer_id}')
def custom_identity_event(customer_id: str):
    return mock_custom.get_identity_event(customer_id)

@router.get('/custom/retention-offer/{customer_id}')
def custom_retention_offer(customer_id: str):
    return mock_custom.get_retention_offer(customer_id)

@router.get('/custom/schedule/{customer_id}')
def custom_schedule(customer_id: str):
    return mock_custom.get_schedule(customer_id)

