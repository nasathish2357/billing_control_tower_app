from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class CaseCreateRequest(BaseModel):
    usecaseId: str
    title: str
    customerId: str
    accountId: str
    invoiceId: str
    priority: Literal['low', 'medium', 'high'] = 'medium'
    notes: str | None = None


class CasePatchRequest(BaseModel):
    status: str | None = None
    assignedTo: str | None = None
    notes: str | None = None


class ApprovalCreateRequest(BaseModel):
    requestedBy: str = 'system'
    reason: str = 'Investigate recommended action'


class ApprovalDecisionRequest(BaseModel):
    actor: str = 'reviewer'
    comment: str | None = None


class ActionApplyRequest(BaseModel):
    actionType: Literal['create_adjustment', 'close_case', 'notify_customer', 'open_dispute', 'create_credit', 'schedule_followup']
    actor: str = 'operator'
    comment: str | None = None


class Finding(BaseModel):
    findingId: str
    type: str
    severity: Literal['low', 'medium', 'high']
    title: str
    detail: str
    evidenceIds: list[str] = Field(default_factory=list)
    agent: str
    llmSummary: str | None = None


class ToolCallRecord(BaseModel):
    server: str
    toolName: str
    arguments: dict[str, Any]
    resultPreview: dict[str, Any] | list[Any] | str | None = None


class TraceEvent(BaseModel):
    seq: int
    node: str
    status: Literal['started', 'completed']
    message: str
    data: dict[str, Any] = Field(default_factory=dict)


class RunRecord(BaseModel):
    runId: str
    caseId: str
    status: Literal['queued', 'running', 'completed', 'failed']
    completedAgents: list[str] = Field(default_factory=list)
    findings: list[Finding] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    toolCalls: list[ToolCallRecord] = Field(default_factory=list)
    trace: list[TraceEvent] = Field(default_factory=list)
    promptCatalog: list[str] = Field(default_factory=list)


class CaseRecord(BaseModel):
    caseId: str
    usecaseId: str
    title: str
    customerId: str
    accountId: str
    invoiceId: str
    priority: str
    notes: str | None = None
    status: str = 'open'
    assignedTo: str | None = None
    latestRunId: str | None = None
    approvals: list[dict[str, Any]] = Field(default_factory=list)
    actions: list[dict[str, Any]] = Field(default_factory=list)
    findings: list[dict[str, Any]] = Field(default_factory=list)
