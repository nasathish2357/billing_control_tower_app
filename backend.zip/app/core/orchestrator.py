from __future__ import annotations

import sqlite3
from typing import Any, TypedDict, Annotated, List, Literal
from operator import add

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver

from app.core.agents import execute_agent
from app.db.repository import PostgresRepository
from app.core.llm import get_llm_provider
from app.core.mcp import MCPClient
from app.core.retrieval import get_retriever
from app.settings import settings


class InvestigationState(TypedDict):
    caseId: str
    runId: str
    case: Annotated[dict[str, Any], "The case data"]
    context: Annotated[dict[str, Any], "Accumulated context from tools"]
    findings: Annotated[List[dict[str, Any]], add]
    recommendations: Annotated[List[str], add]
    completedAgents: Annotated[List[str], add]
    playbooks: Annotated[List[dict[str, Any]], add]
    toolCalls: Annotated[List[dict[str, Any]], add]
    promptCatalog: Annotated[List[str], add]
    llmOutputs: Annotated[dict[str, Any], "LLM responses per agent"]
    trace: Annotated[List[dict[str, Any]], add]
    status: str
    next_node: str


class InvestigationOrchestrator:
    def __init__(self, db_session=None, llm=None, mcp=None):
        self.repo = PostgresRepository(db_session) if db_session else None
        self.db = db_session
        self.llm = llm or get_llm_provider()
        self.mcp = mcp or MCPClient()
        # Correctly initialize SqliteSaver
        self.conn = sqlite3.connect(settings.checkpoint_sqlite_path, check_same_thread=False)
        self.checkpointer = SqliteSaver(self.conn)
        self.graph = self._build_graph()

    def _build_graph(self):
        builder = StateGraph(InvestigationState)
        
        # Define nodes
        builder.add_node("triage", self._triage_node)
        builder.add_node("retrieval", self._retrieval_node)
        builder.add_node("master_agent", self._master_node)
        builder.add_node("layer_2_bss", self._layer_2_node)
        builder.add_node("layer_3_assurance", self._layer_3_node)
        builder.add_node("layer_4_resource", self._layer_4_node)
        builder.add_node("summarize", self._summarize_node)

        # Define edges
        builder.add_edge(START, "triage")
        builder.add_edge("triage", "retrieval")
        builder.add_edge("retrieval", "master_agent")
        
        # Master routes to layers or summarize
        builder.add_conditional_edges(
            "master_agent",
            self._route_from_master,
            {
                "layer_2": "layer_2_bss",
                "layer_3": "layer_3_assurance",
                "layer_4": "layer_4_resource",
                "finish": "summarize"
            }
        )
        
        # Layers return to master
        builder.add_edge("layer_2_bss", "master_agent")
        builder.add_edge("layer_3_assurance", "master_agent")
        builder.add_edge("layer_4_resource", "master_agent")
        
        builder.add_edge("summarize", END)
        
        return builder.compile(checkpointer=self.checkpointer)

    def _trace(self, state: InvestigationState, node: str, message: str):
        seq = len(state.get('trace', [])) + 1
        return {'trace': [{'seq': seq, 'node': node, 'status': 'completed', 'message': message, 't': datetime.now(UTC).isoformat()}]}

    def _triage_node(self, state: InvestigationState) -> dict:
        case = self.repo.get_case(state['caseId']) if self.repo else {'case_id': state['caseId']}
        # Initialize context
        updates = {
            'case': {'caseId': case.case_id, 'usecaseId': case.usecase_id, 'customerId': case.customer_id, 'accountId': case.account_id, 'invoiceId': case.invoice_id} if hasattr(case, 'case_id') else case,
            'context': {},
            'status': 'running'
        }
        # Execute triage agent
        result = execute_agent('triage', {**state, **updates}, self.llm, self.mcp)
        return {
            'case': updates['case'],
            'context': result['context'],
            'findings': result.get('findings', []),
            'completedAgents': ['triage'],
            **self._trace(state, 'triage', "Triage complete. Initial context gathered.")
        }

    def _retrieval_node(self, state: InvestigationState) -> dict:
        case_title = state['case'].get('title', '')
        usecase_id = state['case'].get('usecaseId', '')
        query = f"{case_title} {usecase_id}"
        
        retriever = get_retriever()
        results = retriever.search(query, top_k=3)
        
        return {
            'playbooks': results,
            'completedAgents': ['retrieval'],
            **self._trace(state, 'retrieval', f"Found {len(results)} relevant playbooks for this case.")
        }

    def _master_node(self, state: InvestigationState) -> dict:
        # Master agent analyzes findings and decides next layer
        # For simplicity, we'll use a deterministic router based on the usecase if findings are empty
        # but the master agent can also use LLM to decide.
        return {
            'completedAgents': ['master_agent'],
            **self._trace(state, 'master_agent', "Master agent evaluating next steps...")
        }

    def _route_from_master(self, state: InvestigationState) -> Literal["layer_2", "layer_3", "layer_4", "finish"]:
        case = state['case']
        completed = state.get('completedAgents', [])
        uid = case.get('usecaseId', '').lower()
        
        # Define layer requirements per usecase
        # L2: Billing/BSS, L3: Assurance/Mediation, L4: Resource/Network
        routing_map = {
            'telco_uc01': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc02': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
            'telco_uc03': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
            'telco_uc04': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc05': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc06': ['layer_2_bss'],
            'telco_uc07': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc08': ['layer_2_bss'],
            'telco_uc09': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
            'telco_uc10': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
        }
        
        required_layers = routing_map.get(uid, ['layer_2_bss'])
        
        for layer in required_layers:
            if layer not in completed:
                # Return 'layer_2', 'layer_3', or 'layer_4'
                return "_".join(layer.split("_")[:2])
        
        return "finish"

    def _layer_2_node(self, state: InvestigationState) -> dict:
        result = execute_agent('layer_2_bss', state, self.llm, self.mcp)
        return {
            'context': result['context'],
            'findings': result.get('findings', []),
            'recommendations': result.get('recommendations', []),
            'completedAgents': ['layer_2_bss'],
            **self._trace(state, 'layer_2_bss', "Layer 2 (BSS) investigation complete.")
        }

    def _layer_3_node(self, state: InvestigationState) -> dict:
        result = execute_agent('layer_3_assurance', state, self.llm, self.mcp)
        return {
            'context': result['context'],
            'findings': result.get('findings', []),
            'recommendations': result.get('recommendations', []),
            'completedAgents': ['layer_3_assurance'],
            **self._trace(state, 'layer_3_assurance', "Layer 3 (Assurance) investigation complete.")
        }

    def _layer_4_node(self, state: InvestigationState) -> dict:
        result = execute_agent('layer_4_resource', state, self.llm, self.mcp)
        return {
            'context': result['context'],
            'findings': result.get('findings', []),
            'recommendations': result.get('recommendations', []),
            'completedAgents': ['layer_4_resource'],
            **self._trace(state, 'layer_4_resource', "Layer 4 (Resource) investigation complete.")
        }

    def _summarize_node(self, state: InvestigationState) -> dict:
        return {
            'status': 'completed',
            'completedAgents': ['summarize'],
            **self._trace(state, 'summarize', "Final summary generated. Investigation complete.")
        }

    def run(self, case_id: str, run_id: str) -> dict[str, Any]:
        config = {"configurable": {"thread_id": run_id}}
        initial_state = {
            'caseId': case_id,
            'runId': run_id,
            'findings': [],
            'recommendations': [],
            'completedAgents': [],
            'playbooks': [],
            'toolCalls': [],
            'promptCatalog': [],
            'llmOutputs': {},
            'trace': [],
            'context': {}
        }
        result = self.graph.invoke(initial_state, config=config)
        return dict(result)

from datetime import datetime, UTC

