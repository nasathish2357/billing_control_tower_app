from __future__ import annotations

import os
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any

class PlaybookRetriever:
    def __init__(self, playbooks_dir: str = "data/playbooks"):
        self.playbooks_dir = playbooks_dir
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.index = None
        self.documents = []
        self._initialize_index()

    def _initialize_index(self):
        if not os.path.exists(self.playbooks_dir):
            return

        chunks = []
        for filename in os.listdir(self.playbooks_dir):
            if filename.endswith(".md"):
                path = os.path.join(self.playbooks_dir, filename)
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                    # Simple chunking by playbook section (--- or ##)
                    sections = content.split("---")
                    for section in sections:
                        if section.strip():
                            chunks.append({
                                "text": section.strip(),
                                "source": filename
                            })

        if not chunks:
            return

        self.documents = chunks
        texts = [doc["text"] for doc in chunks]
        embeddings = self.model.encode(texts)
        
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dimension)
        self.index.add(embeddings.astype('float32'))

    def search(self, query: str, top_k: int = 2) -> List[Dict[str, Any]]:
        if self.index is None:
            return []

        query_vector = self.model.encode([query])
        distances, indices = self.index.search(query_vector.astype('float32'), top_k)
        
        results = []
        for idx in indices[0]:
            if idx != -1 and idx < len(self.documents):
                results.append(self.documents[idx])
        return results

# Singleton instance
_retriever = None

def get_retriever() -> PlaybookRetriever:
    global _retriever
    if _retriever is None:
        _retriever = PlaybookRetriever()
    return _retriever
