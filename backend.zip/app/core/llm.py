from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from app.settings import settings


@dataclass
class LLMResponse:
    content: str
    raw: dict[str, Any] | None = None


class BaseLLMProvider:
    provider_name: str = 'base'

    def complete(self, *, agent_name: str, system_prompt: str, user_prompt: str, tools: list[dict[str, Any]] | None = None) -> LLMResponse:
        raise NotImplementedError


class DemoLLMProvider(BaseLLMProvider):
    provider_name = 'demo'

    def complete(self, *, agent_name: str, system_prompt: str, user_prompt: str, tools: list[dict[str, Any]] | None = None) -> LLMResponse:
        tool_names = ', '.join(t.get('name', '') for t in (tools or [])) or 'no-tools'
        content = f'[{agent_name}] Demo reasoning summary. Considered tools: {tool_names}. Prompt intent captured successfully.'
        return LLMResponse(content=content, raw={'provider': self.provider_name})


class OpenAIChatProvider(BaseLLMProvider):
    provider_name = 'openai'

    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model

    def complete(self, *, agent_name: str, system_prompt: str, user_prompt: str, tools: list[dict[str, Any]] | None = None) -> LLMResponse:
        headers = {'Authorization': f'Bearer {self.api_key}', 'Content-Type': 'application/json'}
        payload = {
            'model': self.model,
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': user_prompt},
            ],
            'temperature': 0,
        }
        response = httpx.post('https://api.openai.com/v1/chat/completions', headers=headers, json=payload, timeout=30.0)
        response.raise_for_status()
        data = response.json()
        content = data['choices'][0]['message']['content']
        return LLMResponse(content=content, raw=data)


class AzureOpenAIProvider(BaseLLMProvider):
    provider_name = 'azure_openai'

    def __init__(self, endpoint: str, api_key: str, deployment: str, api_version: str):
        self.endpoint = endpoint.rstrip('/')
        self.api_key = api_key
        self.deployment = deployment
        self.api_version = api_version

    def complete(self, *, agent_name: str, system_prompt: str, user_prompt: str, tools: list[dict[str, Any]] | None = None) -> LLMResponse:
        url = f'{self.endpoint}/openai/deployments/{self.deployment}/chat/completions?api-version={self.api_version}'
        headers = {'api-key': self.api_key, 'Content-Type': 'application/json'}
        payload = {
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': user_prompt},
            ],
            'temperature': 0,
        }
        response = httpx.post(url, headers=headers, json=payload, timeout=30.0)
        response.raise_for_status()
        data = response.json()
        return LLMResponse(content=data['choices'][0]['message']['content'], raw=data)


class VertexAIProvider(BaseLLMProvider):
    provider_name = 'vertex_ai'

    def __init__(self, project: str, location: str, model: str):
        self.project = project
        self.location = location
        self.model = model

    def complete(self, *, agent_name: str, system_prompt: str, user_prompt: str, tools: list[dict[str, Any]] | None = None) -> LLMResponse:
        try:
            from langchain_google_vertexai import ChatVertexAI
            llm = ChatVertexAI(model_name=self.model, project=self.project, location=self.location, temperature=0)
            result = llm.invoke([('system', system_prompt), ('human', user_prompt)])
            content = getattr(result, 'content', str(result))
            return LLMResponse(content=content, raw={'provider': self.provider_name, 'model': self.model})
        except Exception:
            return DemoLLMProvider().complete(agent_name=agent_name, system_prompt=system_prompt, user_prompt=user_prompt, tools=tools)


def get_llm_provider() -> BaseLLMProvider:
    provider = settings.llm_provider.lower()
    if provider == 'azure_openai' and settings.azure_openai_endpoint and settings.azure_openai_api_key and settings.azure_openai_deployment:
        return AzureOpenAIProvider(settings.azure_openai_endpoint, settings.azure_openai_api_key, settings.azure_openai_deployment, settings.azure_openai_api_version)
    if provider == 'vertex_ai' and settings.vertex_project:
        return VertexAIProvider(settings.vertex_project, settings.vertex_location, settings.vertex_model)
    if provider == 'openai' and settings.openai_api_key:
        return OpenAIChatProvider(settings.openai_api_key, settings.openai_model)
    return DemoLLMProvider()
