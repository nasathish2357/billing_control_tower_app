from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any
from datetime import datetime, UTC

from app.core.mcp import MCPClient
from app.core.prompts import PROMPTS


@dataclass
class AgentDefinition:
    name: str
    layer: int
    tools: list[str]


AGENTS: dict[str, AgentDefinition] = {
    # Layer 1: Governance & Control
    'triage': AgentDefinition('triage', 1, ['tmf_get_customer', 'tmf_get_billing_account']),
    'master_agent': AgentDefinition('master_agent', 1, []),
    'governance': AgentDefinition('governance', 1, ['tmf_get_trouble_ticket']),
    
    # Layer 2: BSS Revenue & Care
    'layer_2_bss': AgentDefinition('layer_2_bss', 2, ['tmf_get_bill', 'custom_get_entitlements', 'custom_get_product_inventory', 'custom_get_payment_profile']),
    
    # Layer 3: Service Assurance & Mediation
    'layer_3_assurance': AgentDefinition('layer_3_assurance', 3, ['custom_get_service_assurance', 'custom_get_partner_settlement']),
    
    # Layer 4: Resource & Network
    'layer_4_resource': AgentDefinition('layer_4_resource', 4, ['custom_get_fraud_alert', 'custom_get_identity_event']),
    
    'summarize': AgentDefinition('summarize', 1, []),
}

# Mapping old agent names to new ones for compatibility if needed
LEGACY_AGENT_MAP = {
    'collect_case_context': 'triage',
    'bill_insight_agent': 'layer_2_bss',
    'usage_integrity_agent': 'layer_3_assurance',
    'policy_validation_agent': 'governance',
}


def render_prompt(agent_name: str, *, case: dict[str, Any], context: dict[str, Any], findings: list[dict[str, Any]], invoice: dict[str, Any] | None, tool_specs: list[dict[str, Any]], playbooks: list[dict[str, Any]] = []) -> tuple[str, str]:
    # Fallback to a generic prompt if not in PROMPTS
    prompt = PROMPTS.get(agent_name, PROMPTS.get('collect_case_context'))
    system = prompt['system']
    
    playbook_text = "\n".join([f"Source: {p['source']}\n{p['text']}" for p in playbooks])
    user = prompt['user'].format(case=case, context=context, findings=findings, invoice=invoice, tools=tool_specs)
    if playbook_text:
        user += f"\n\nRelevant Standard Playbooks:\n{playbook_text}"
    return system, user


def _record_tool_calls(state: dict[str, Any], calls: list[dict[str, Any]]):
    previews = []
    for call in calls:
        result = call['result']
        preview = result if isinstance(result, (dict, list, str)) else str(result)
        previews.append({
            'server': call['server'],
            'toolName': call['toolName'],
            'arguments': call['arguments'],
            'resultPreview': preview,
        })
    state.setdefault('toolCalls', []).extend(previews)


def _append_finding(state: dict[str, Any], *, agent: str, finding_id: str, finding_type: str, severity: str, title: str, detail: str, evidence_ids: list[str], llm_summary: str):
    state.setdefault('findings', []).append({
        'findingId': finding_id,
        'type': finding_type,
        'severity': severity,
        'title': title,
        'detail': detail,
        'evidenceIds': evidence_ids,
        'agent': agent,
        'llmSummary': llm_summary,
    })


def execute_agent(agent_name: str, state: dict[str, Any], llm, mcp: MCPClient) -> dict[str, Any]:
    case = state['case']
    invoice = state.get('context', {}).get('invoice')
    tool_calls = []
    
    def tool(name: str, **kwargs):
        call = mcp.call_tool(name, **kwargs)
        tool_calls.append(call)
        return call['result']

    agent_def = AGENTS.get(agent_name)
    if not agent_def:
        # Check legacy map
        mapped_name = LEGACY_AGENT_MAP.get(agent_name)
        if mapped_name:
            return execute_agent(mapped_name, state, llm, mcp)
        raise ValueError(f"Unknown agent: {agent_name}")

    context_for_prompt = {}
    
    # Layered logic
    if agent_name == 'triage':
        state['context']['customer'] = tool('tmf_get_customer', customer_id=case['customerId'])
        state['context']['account'] = tool('tmf_get_billing_account', account_id=case['accountId'])
        context_for_prompt = {'customer': state['context']['customer'], 'account': state['context']['account']}
        
    elif agent_name == 'layer_2_bss':
        state['context']['invoice'] = tool('tmf_get_bill', invoice_id=case['invoiceId'])
        state['context']['entitlements'] = tool('custom_get_entitlements', customer_id=case['customerId'])
        invoice = state['context']['invoice']
        context_for_prompt = {'invoice': invoice, 'entitlements': state['context']['entitlements']}
        
    elif agent_name == 'layer_3_assurance':
        state['context']['service'] = tool('custom_get_service_assurance', account_id=case['accountId'])
        state['context']['partner_settlement'] = tool('custom_get_partner_settlement', invoice_id=case['invoiceId'])
        context_for_prompt = {'service': state['context']['service'], 'partnerSettlement': state['context']['partner_settlement']}
        
    elif agent_name == 'layer_4_resource':
        state['context']['fraud'] = tool('custom_get_fraud_alert', customer_id=case['customerId'])
        state['context']['identity'] = tool('custom_get_identity_event', customer_id=case['customerId'])
        # Simulate 5G Charging Plane (SMF/CHF/UPF)
        if 'telco' in case.get('usecaseId', ''):
            state['context']['charging_plane'] = {
                'smf': {'status': 'released', 'release_time': '2026-03-01T23:59:59Z', 'ctf_trigger': 'sent'},
                'chf': {'status': 'active', 'last_update': '2026-03-02T08:00:00Z', 'abmf_state': 'deducting', 'rf_rating': 'standard_data'},
                'upf': {'status': 'idle', 'last_usage_report': '2026-03-02T07:55:00Z'},
                'cgf': {'cdr_count': 142, 'status': 'delivered_to_billing'}
            }
        context_for_prompt = {'fraud': state['context']['fraud'], 'identity': state['context']['identity'], 'chargingPlane': state.get('context', {}).get('charging_plane')}

    elif agent_name == 'master_agent':
        context_for_prompt = {'findings': state.get('findings', [])}

    # LLM Call
    tool_specs = mcp.describe_tools(agent_def.tools)
    playbooks = state.get('playbooks', [])
    system_prompt, user_prompt = render_prompt(agent_name, case=case, context=context_for_prompt, findings=state.get('findings', []), invoice=invoice, tool_specs=tool_specs, playbooks=playbooks)
    llm_response = llm.complete(agent_name=agent_name, system_prompt=system_prompt, user_prompt=user_prompt, tools=tool_specs)

    _record_tool_calls(state, tool_calls)
    state.setdefault('promptCatalog', []).append(agent_name)
    state.setdefault('llmOutputs', {})[agent_name] = llm_response.content

    # Layered findings
    if agent_name == 'triage':
        _append_finding(state, agent=agent_name, finding_id='FND_TRIAGE', finding_type='context', severity='low', title='Case context collected', detail='Customer and account details verified.', evidence_ids=[], llm_summary=llm_response.content)
        
    elif agent_name == 'layer_2_bss' and invoice:
        overage = round(invoice['amount'] - invoice['baselineAmount'], 2)
        if overage > 0:
            _append_finding(state, agent=agent_name, finding_id='FND_BSS_01', finding_type='billing-variance', severity='high' if overage > 50 else 'medium', title='Invoice variance detected', detail=f"Bill shock of {overage} GBP identified.", evidence_ids=['EVD_0001'], llm_summary=llm_response.content)
            state.setdefault('recommendations', []).append(f"Apply credit for {overage} GBP if technical error is confirmed.")

    elif agent_name == 'layer_3_assurance':
        service = state['context'].get('service', {})
        if service.get('slaBreach'):
            _append_finding(state, agent=agent_name, finding_id='FND_ASR_01', finding_type='sla-breach', severity='high', title='SLA Breach confirmed', detail='Network monitoring confirms service degradation during billing period.', evidence_ids=['EVD_0004'], llm_summary=llm_response.content)
            state.setdefault('recommendations', []).append("Issue SLA compensation credit.")

    elif agent_name == 'layer_4_resource':
        cp = state.get('context', {}).get('charging_plane')
        if cp and cp['smf']['status'] == 'released' and cp['chf']['status'] == 'active':
            _append_finding(state, agent=agent_name, finding_id='FND_RES_01', finding_type='zombie-session', severity='high', title='Standard-Aligned Zombie PDU Detection', detail='SMF CTF released session at 23:59, but CHF (Nchf interface) remained active until 08:00 due to signaling timeout. ABMF continued deducting balance.', evidence_ids=['SMF_LOG_99', 'CHF_CDR_42'], llm_summary=llm_response.content)
            state.setdefault('recommendations', []).append("Reverse CHF usage charges for the 8-hour zombie window using RF/ABMF correction.")

    state.setdefault('completedAgents', []).append(agent_name)
    return state

