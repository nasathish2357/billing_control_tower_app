from __future__ import annotations

TELECOM_USECASES = [
    {
        'usecaseId': 'telco_uc01',
        'title': 'Missing or Delayed Usage Feed',
        'description': 'Investigate bill shock caused by watermark lag or delayed usage delivery in mediation.',
        'category': 'billing',
        'recommendedPriority': 'high',
        'workflow': ['triage', 'master_agent', 'layer_3_assurance', 'layer_2_bss', 'summarize'],
        'interactionMode': 'pre-bill',
        'autoRemediate': True,
        'persona': 'Emma',
        'scenario_example': 'Emma streams high-volume video near the end of her billing cycle. Due to a watermark lag in the mediation system, the usage records are not processed before the invoice run completes.',
        'typical_systems': ['TMF688 Event feeds', 'Mediation (watermark/lag)', 'TMF678 CustomerBill'],
        'layer_focus': {
            'L1': 'Governance and cross-domain correlation',
            'L3': 'Mediation replay and watermark analysis',
            'L2': 'Billing impact assessment and rebill calculation'
        }
    },
    {
        'usecaseId': 'telco_uc02',
        'title': 'Duplicate Charging / Usage Rating',
        'description': 'Detect and reverse duplicate charges caused by transaction correlation errors.',
        'category': 'billing',
        'recommendedPriority': 'medium',
        'workflow': ['triage', 'master_agent', 'layer_2_bss', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'Daniel',
        'scenario_example': 'Daniel activates a short-term data add-on. Due to a technical error in the charging transaction correlation, the activation event and a subsequent interim update are both rated as separate one-off charges.',
        'typical_systems': ['Charging (CHF/OCS)', 'Transaction correlation', 'TMF678 CustomerBill'],
        'layer_focus': {
            'L2': 'Charge reversal and credit application'
        }
    },
    {
        'usecaseId': 'telco_uc03',
        'title': 'Zombie PDU Session',
        'description': 'Investigate unfair data charging from sessions that failed to release correctly.',
        'category': 'billing',
        'recommendedPriority': 'medium',
        'workflow': ['triage', 'master_agent', 'layer_4_resource', 'layer_2_bss', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'Sophie',
        'scenario_example': 'Sophie finishes a video call and leaves her handset idle overnight. A stale PDU session is not released correctly, so the charging path continues to receive usage updates.',
        'typical_systems': ['SMF', 'UPF', 'AMF', 'Charging (CHF/OCS)', 'Network traces'],
        'layer_focus': {
            'L4': 'Session state verification and resource release',
            'L2': 'Usage correction and explanation'
        }
    },
    {
        'usecaseId': 'telco_uc04',
        'title': 'QoS or Slice Entitlement Mismatch',
        'description': 'Resolve premium billing for standard delivered performance levels.',
        'category': 'billing',
        'recommendedPriority': 'high',
        'workflow': ['triage', 'master_agent', 'layer_4_resource', 'layer_2_bss', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'Enterprise UK',
        'scenario_example': 'A distribution company in the UK pays for a higher-priority 5G service. Performance measurements look similar to standard connectivity because the policy mapping is incorrect.',
        'typical_systems': ['PCF', 'SMF', 'QoS/Slice policy', 'RAN performance', 'TMF678'],
        'layer_focus': {
            'L4': 'SLA/KPI verification from network probes',
            'L2': 'Premium uplift removal and credit'
        }
    },
    {
        'usecaseId': 'telco_uc05',
        'title': 'Service Degradation Compensation',
        'description': 'Apply commercial compensation for technically valid but poor quality service.',
        'category': 'assurance',
        'recommendedPriority': 'high',
        'workflow': ['triage', 'master_agent', 'layer_3_assurance', 'layer_2_bss', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'Oliver',
        'scenario_example': 'Oliver experiences persistent latency spikes and packet loss during peak hours. Assurance data confirms repeated degradation in the serving area.',
        'typical_systems': ['RAN monitoring', 'Service quality analytics', 'Trouble ticketing'],
        'layer_focus': {
            'L3': 'Area-wide service quality correlation',
            'L2': 'Goodwill credit application'
        }
    },
    {
        'usecaseId': 'telco_uc06',
        'title': 'Collections Hold Requirement',
        'description': 'Protect disputed balances from entering dunning/collections reminder cycles.',
        'category': 'payments',
        'recommendedPriority': 'medium',
        'workflow': ['triage', 'master_agent', 'layer_1_governance', 'layer_2_bss', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'Glasgow Customer',
        'scenario_example': 'A customer disputes £28 of charges linked to international usage. The accounts receivable process must be updated to hold the disputed amount.',
        'typical_systems': ['Billing', 'Accounts Receivable', 'Collections/Dunning'],
        'layer_focus': {
            'L1': 'Dispute governance and approval',
            'L2': 'Collections hold and AR adjustment'
        }
    },
    {
        'usecaseId': 'telco_uc07',
        'title': 'Partner / Wholesale Discrepancy',
        'description': 'Address roaming or interconnect settlement variances affecting retail bills.',
        'category': 'settlement',
        'recommendedPriority': 'medium',
        'workflow': ['triage', 'master_agent', 'layer_3_assurance', 'layer_2_bss', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'London Traveler',
        'scenario_example': 'A subscriber travels outside the UK. The visited network records and home operator rating do not reconcile cleanly, producing higher roaming charges than expected.',
        'typical_systems': ['Roaming feeds', 'Mediation', 'Wholesale settlement'],
        'layer_focus': {
            'L3': 'Feeder reconciliation and mediation audit',
            'L2': 'Retail credit while wholesale settles'
        }
    },
    {
        'usecaseId': 'telco_uc08',
        'title': 'Opaque Invoice Explanation',
        'description': 'Generate customer-friendly narratives for complex or confusing valid charges.',
        'category': 'billing',
        'recommendedPriority': 'medium',
        'workflow': ['triage', 'master_agent', 'layer_2_bss', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'Hannah',
        'scenario_example': 'Hannah has a family plan with shared data and add-ons. Her invoice contains prorated items and bundle adjustments that are valid but confusing.',
        'typical_systems': ['Bill generation', 'Product catalogue', 'CRM'],
        'layer_focus': {
            'L2': 'Bill narrative generation and offer mapping'
        }
    },
    {
        'usecaseId': 'telco_uc09',
        'title': 'Internal Monitoring Anomaly',
        'description': 'Proactively remediate charging anomalies discovered before customer impact.',
        'category': 'billing',
        'recommendedPriority': 'high',
        'workflow': ['triage', 'master_agent', 'layer_1_governance', 'layer_3_assurance', 'summarize'],
        'interactionMode': 'pre-bill',
        'autoRemediate': True,
        'persona': 'Ops Monitoring',
        'scenario_example': 'Monitoring highlights an unusual increase in duplicate interim charging updates. Ops suppress the duplicates to prevent them appearing on customer invoices.',
        'typical_systems': ['Observability', 'Charging streams', 'Pre-bill controls'],
        'layer_focus': {
            'L1': 'Proactive incident governance',
            'L3': 'Anomaly suppression in mediation'
        }
    },
    {
        'usecaseId': 'telco_uc10',
        'title': 'Governed End-to-End Dispute',
        'description': 'Orchestrate complex disputes requiring cross-domain network and finance alignment.',
        'category': 'billing',
        'recommendedPriority': 'high',
        'workflow': ['triage', 'master_agent', 'layer_1_governance', 'layer_2_bss', 'layer_3_assurance', 'layer_4_resource', 'summarize'],
        'interactionMode': 'post-bill',
        'autoRemediate': False,
        'persona': 'Enterprise Multi-site',
        'scenario_example': 'A UK enterprise customer disputes premium connectivity charges across multiple business sites, requiring input from network, billing, and finance teams.',
        'typical_systems': ['Case management', 'Workflow/Approvals', 'Network evidence'],
        'layer_focus': {
            'L1': 'Cross-domain orchestration and audit trail'
        }
    }
]

LEGACY_USECASES = [
    {
        'usecaseId': 'UC01',
        'title': 'Bill Shock Investigation (Legacy)',
        'description': 'Investigate invoice anomalies and roaming spikes.',
        'category': 'billing',
        'recommendedPriority': 'high',
        'workflow': ['triage', 'master_agent', 'layer_2_bss', 'summarize'],
    },
    # ... other legacy usecases can be simplified or merged
]

ALL_USECASES = TELECOM_USECASES + LEGACY_USECASES
