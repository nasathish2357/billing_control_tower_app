from __future__ import annotations

from typing import Any, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import select, update, delete
from .models import (
    UseCaseModel, CustomerModel, BillingAccountModel, InvoiceModel, 
    InvoiceLineModel, CaseModel, CaseRunModel, InvestigationFindingModel,
    RecommendationModel, ApprovalModel, FinancialActionModel, CaseExplanationModel,
    AuditEventModel
)

class PostgresRepository:
    def __init__(self, db: Session):
        self.db = db

    # Use Cases
    def get_usecases(self) -> List[UseCaseModel]:
        return list(self.db.scalars(select(UseCaseModel)).all())

    def get_usecase(self, usecase_id: str) -> Optional[UseCaseModel]:
        return self.db.scalars(select(UseCaseModel).where(UseCaseModel.usecase_id == usecase_id)).first()

    def upsert_usecase(self, data: dict) -> UseCaseModel:
        uc = self.get_usecase(data['usecaseId'])
        if uc:
            uc.title = data['title']
            uc.description = data['description']
            uc.category = data['category']
            uc.recommended_priority = data['recommendedPriority']
            uc.workflow = data['workflow']
            uc.metadata_json = {k: v for k, v in data.items() if k not in ('usecaseId', 'title', 'description', 'category', 'recommendedPriority', 'workflow')}
        else:
            uc = UseCaseModel(
                usecase_id=data['usecaseId'],
                title=data['title'],
                description=data['description'],
                category=data['category'],
                recommended_priority=data['recommendedPriority'],
                workflow=data['workflow'],
                metadata_json={k: v for k, v in data.items() if k not in ('usecaseId', 'title', 'description', 'category', 'recommendedPriority', 'workflow')}
            )
            self.db.add(uc)
        self.db.commit()
        return uc

    # Cases
    def get_case(self, case_id: str) -> Optional[CaseModel]:
        return self.db.scalars(select(CaseModel).where(CaseModel.case_id == case_id)).first()

    def create_case(self, data: dict) -> CaseModel:
        case = CaseModel(
            case_id=data['caseId'],
            usecase_id=data['usecaseId'],
            title=data['title'],
            customer_id=data['customerId'],
            account_id=data['accountId'],
            invoice_id=data['invoiceId'],
            priority=data['priority'],
            notes=data.get('notes'),
            status=data.get('status', 'open'),
            telecom_context=data.get('telecom_context', {})
        )
        self.db.add(case)
        self.db.commit()
        return case

    def update_case(self, case_id: str, updates: dict) -> Optional[CaseModel]:
        case = self.get_case(case_id)
        if not case:
            return None
        for k, v in updates.items():
            if hasattr(case, k):
                setattr(case, k, v)
        self.db.commit()
        return case

    # Runs
    def create_run(self, data: dict) -> CaseRunModel:
        run = CaseRunModel(
            run_id=data['runId'],
            case_id=data['caseId'],
            status=data['status'],
            mode=data.get('mode', 'investigate'),
            trace=data.get('trace', []),
            findings=data.get('findings', []),
            recommendations=data.get('recommendations', []),
            completed_agents=data.get('completedAgents', []),
            tool_calls=data.get('toolCalls', []),
            prompt_catalog=data.get('promptCatalog', []),
            llm_outputs=data.get('llmOutputs', {})
        )
        self.db.add(run)
        self.db.commit()
        return run

    def get_run(self, run_id: str) -> Optional[CaseRunModel]:
        return self.db.scalars(select(CaseRunModel).where(CaseRunModel.run_id == run_id)).first()

    def get_runs_for_case(self, case_id: str) -> List[CaseRunModel]:
        return list(self.db.scalars(
            select(CaseRunModel).where(CaseRunModel.case_id == case_id).order_by(CaseRunModel.started_at.desc())
        ).all())

    # Findings
    def create_finding(self, data: dict) -> InvestigationFindingModel:
        finding = InvestigationFindingModel(
            finding_id=data['finding_id'],
            case_id=data['case_id'],
            run_id=data['run_id'],
            agent=data['agent'],
            type=data['type'],
            severity=data['severity'],
            title=data['title'],
            detail=data['detail'],
            evidence_ids=data.get('evidence_ids', []),
            llm_summary=data.get('llm_summary')
        )
        self.db.add(finding)
        self.db.commit()
        return finding

    # Recommendations
    def create_recommendation(self, data: dict) -> RecommendationModel:
        rec = RecommendationModel(
            recommendation_id=data['recommendation_id'],
            case_id=data['case_id'],
            run_id=data['run_id'],
            type=data['type'],
            title=data['title'],
            description=data['description'],
            action_type=data['action_type'],
            status=data.get('status', 'proposed')
        )
        self.db.add(rec)
        self.db.commit()
        return rec
