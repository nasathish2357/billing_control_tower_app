from __future__ import annotations

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from app.memory import MemoryStore
from app.settings import settings
from app.db.models import Base

# Legacy Memory Store
_STORE: MemoryStore | None = None


def get_store() -> MemoryStore:
    global _STORE
    if _STORE is None:
        _STORE = MemoryStore()
    return _STORE


def reset_store() -> MemoryStore:
    global _STORE
    _STORE = MemoryStore()
    return _STORE


# PostgreSQL setup
POSTGRES_DSN = settings.postgres_dsn or "postgresql+psycopg://postgres:postgres@localhost:5432/billing_control_tower"

if settings.enable_postgres:
    try:
        engine = create_engine(POSTGRES_DSN)
    except Exception as e:
        print(f"Warning: Failed to connect to Postgres ({e}). Falling back to SQLite.")
        engine = create_engine("sqlite:///./data/local.sqlite")
else:
    # Ensure data directory exists
    os.makedirs("./data", exist_ok=True)
    engine = create_engine("sqlite:///./data/local.sqlite")

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

