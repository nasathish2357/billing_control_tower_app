import pytest
from app.core.orchestrator import InvestigationOrchestrator
from app.db.models import CaseModel

@pytest.mark.parametrize("usecase_id", [
    'telco_uc01', 'telco_uc02', 'telco_uc03', 'telco_uc04', 'telco_uc05',
    'telco_uc06', 'telco_uc07', 'telco_uc08', 'telco_uc09', 'telco_uc10'
])
def test_all_telecom_flows(db, usecase_id):
    orchestrator = InvestigationOrchestrator(db_session=db)
    case = db.query(CaseModel).filter(CaseModel.usecase_id == usecase_id).first()
    assert case is not None
    
    run_id = f"test-flow-{usecase_id}"
    result = orchestrator.run(case.case_id, run_id)
    
    nodes = [t['node'] for t in result['trace']]
    assert 'triage' in nodes
    assert 'retrieval' in nodes
    assert 'master_agent' in nodes
    assert result['status'] == 'completed'
    
    # Verify expected layers for specific complex cases
    if usecase_id in ['telco_uc03', 'telco_uc09', 'telco_uc10']:
        assert 'layer_4_resource' in nodes
    
    if usecase_id in ['telco_uc01', 'telco_uc02', 'telco_uc04', 'telco_uc05', 'telco_uc07']:
        assert 'layer_3_assurance' in nodes
