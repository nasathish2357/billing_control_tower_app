import pytest

def test_health_check(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_list_usecases(client):
    response = client.get("/api/usecases")
    assert response.status_code == 200
    assert len(response.json()) >= 6

def test_create_and_investigate_case(client):
    # 1. Create case
    payload = {
        "usecaseId": "telco_uc01",
        "title": "Test Case",
        "customerId": "TELCO_CUST_EMMA",
        "accountId": "ACC_EMMA",
        "invoiceId": "INV_EMMA_01",
        "priority": "high"
    }
    resp = client.post("/api/cases", json=payload)
    assert resp.status_code == 200
    case_id = resp.json()["caseId"]
    
    # 2. Investigate
    inv_resp = client.post(f"/api/cases/{case_id}/investigate")
    assert inv_resp.status_code == 200
    run_data = inv_resp.json()
    assert run_data["status"] == "completed"
    assert len(run_data["findings"]) > 0

def test_chat_api(client):
    # Setup: Investigate first to have findings
    case_payload = {
        "usecaseId": "telco_uc03",
        "title": "Chat Test",
        "customerId": "TELCO_CUST_SOPHIE",
        "accountId": "ACC_SOPHIE",
        "invoiceId": "INV_SOPHIE_01",
        "priority": "high"
    }
    case_id = client.post("/api/cases", json=case_payload).json()["caseId"]
    client.post(f"/api/cases/{case_id}/investigate")
    
    # Chat
    chat_resp = client.post(f"/api/cases/{case_id}/chat", json={"message": "What did you find about the zombie session?"})
    assert chat_resp.status_code == 200
    content = chat_resp.json()["content"]
    assert len(content) > 0
    # The LLM should mention something about findings if it's working
    # Since we use real LLM in tests (if API key provided) or fake if not
    # We just check it's a string for now

def test_search_and_reindex(client):
    client.post("/api/reindex")
    search_resp = client.get("/api/search?q=zombie")
    assert search_resp.status_code == 200
    assert len(search_resp.json()["results"]) > 0
