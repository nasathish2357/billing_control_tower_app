# Playbook: Service Quality & SLA Assurance
## Domain: Layer 3 (Assurance)
## Use Cases: UC04, UC05

### 1. Troubleshooting: QoS / Slice Mismatch (UC04)
- **Standard**: 3GPP PCF (Policy Control Function) / Slice SLA.
- **Steps**:
    1. Fetch PCF Policy for the subscriber's S-NSSAI (Slice ID).
    2. Query RAN Performance Metrics for throughput/latency during the billed period.
    3. Compare "Promised QoS" vs "Delivered QoS" telemetry.
- **Finding**: "Policy Mapping Error: Subscriber billed for Premium Slice but mapped to Standard QoS profile."

### 2. Troubleshooting: Service Degradation (UC05)
- **Standard**: GSMA/TM Forum SLA monitoring.
- **Steps**:
    1. Query OSS Trouble Tickets (TMF621) for area-wide outages.
    2. Analyze Network Performance metrics for packet loss or latency spikes.
    3. Correlate timestamp with customer's location and billing period.
- **Finding**: "Confirmed service degradation in Sector [X] due to transport fiber cut."

### 3. Remediation: Commercial Adjustments
- **QoS Mismatch**: 
    1. Downgrade current bill item to "Standard" rate.
    2. Propose credit for the "Premium Uplift" amount.
- **Degradation**:
    1. Lookup "SLA Compensation Matrix" based on downtime duration.
    2. Propose "Goodwill Credit" via `TMF678`.
    3. Update Trouble Ticket status to "Bill Impacted - Resolved."
