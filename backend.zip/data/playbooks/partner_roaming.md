# Playbook: Partner & Roaming Settlement
## Domain: Layer 3 (Assurance) & Layer 2 (BSS)
## Use Cases: UC07

### 1. Troubleshooting: Roaming Discrepancy (UC07)
- **Standard**: GSMA TAP/RAP (Transferred Account Procedure).
- **Steps**:
    1. Fetch Visited Network (VPMN) CDRs.
    2. Compare with Home Network (HPMN) rated records in the BSS.
    3. Check for currency conversion or Roaming Pass entitlement errors.
- **Finding**: "Mismatch between VPMN record and HPMN billing; roaming pass was not activated in visited core."

### 2. Remediation: Partner Settlement Actions
- **Action**: Propose a temporary retail credit to the customer while the wholesale dispute is settled via the GSMA RAP process.
- **API**: TMF678 (Retail Adjustment) & Wholesale Dispute Log.
