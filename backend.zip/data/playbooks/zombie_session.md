# Playbook: Troubleshooting Zombie PDU Sessions
## ID: PLB-TECH-001
## Domain: Layer 4 (Network/Resource)

### Step 1: Session Verification
- **Action**: Query SMF for PDU Session state.
- **Goal**: Confirm if SMF recorded a `Session Release` at the expected time.
- **Evidence**: `Nsmf_PDUSession_SMContext` logs.

### Step 2: Usage Correlation
- **Action**: Fetch UPF Usage Reports (URRs).
- **Goal**: Compare UPF reports with SMF release logs.
- **Anomaly**: If SMF shows release but UPF continued reporting, UPF heartbeat may be stale.

### Step 3: Charging Interface Check
- **Action**: Query CHF (Charging Function) for Nchf_ConvergedCharging events.
- **Goal**: Check if `Charging Data Request [Release]` was received.
- **Root Cause**: If SMF released but CHF did not receive Release message, the session is "Zombie" in the charging plane.

---

# Playbook: Remediation for Zombie Charging
## ID: PLB-BIZ-001
## Domain: Layer 2 (BSS/Billing)

### Step 1: Impact Assessment
- **Condition**: Troubleshooting confirms PLB-TECH-001 (Zombie Session).
- **Action**: Calculate duration between SMF intended release and CHF actual closure.

### Step 2: Rating Lookup
- **Action**: Use Rating Function (RF) to determine the cost of the "Zombie" usage.
- **Evidence**: CDRs from CGF (Charging Gateway Function).

### Step 3: Adjustment Application
- **Action**: Propose a "Technical Error Credit" for the calculated amount.
- **API**: TMF678 (Billing Management).

### Step 4: Communication
- **Action**: Generate customer-safe explanation: "A network session synchronization error caused an overcharge."
- **API**: TMF621 (Trouble Ticket update).
