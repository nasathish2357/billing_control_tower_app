# Playbook: Usage & Charging Integrity
## Domain: Layer 3 (Assurance) & Layer 4 (Resource)
## Use Cases: UC01, UC02, UC03, UC09

### 1. Troubleshooting: Delayed Usage Feed (UC01)
- **Standard**: 3GPP Offline Charging / Mediation Lag.
- **Steps**:
    1. Query Mediation System for "Watermark" or "File Lag" on the date of the missing usage.
    2. Check `TMF635` Usage records for "late-arriving" flags.
    3. Correlate with Invoice run timestamp in `TMF678`.
- **Finding**: "Delayed mediation watermark caused usage to fall into next billing cycle."

### 2. Troubleshooting: Duplicate Charging (UC02, UC09)
- **Standard**: 3GPP Converged Charging (CHF).
- **Steps**:
    1. Search for duplicate `Charging Data Request [Update]` with identical transaction IDs.
    2. Verify if the Rating Function (RF) applied a "Double-Dip" on the same interim update.
    3. Check for failed "De-duplication" logic in the Charging Gateway (CGF).
- **Finding**: "Duplicate interim update transaction detected in CHF; de-duplication failed."

### 3. Troubleshooting: Zombie PDU Sessions (UC03)
- **Standard**: 3GPP 5G Core Session Management.
- **Steps**:
    1. Compare SMF `Session Release` time with CHF `Session Closure` time.
    2. Check UPF heartbeat logs for "Ghost" traffic reports.
- **Finding**: "PDU Session release message lost on Nchf interface; session remained active in charging plane."

### 4. Remediation: Usage Corrections
- **Delayed Usage**: Propose "Bill Smoothing" or deferral of the catch-up charge.
- **Duplicate/Zombie**: 
    1. Calculate the overcharged volume/amount.
    2. Trigger `TMF678` Adjustment for the delta.
    3. (UC09 Proactive) Suppress the duplicate records in CGF before they reach the bill.
