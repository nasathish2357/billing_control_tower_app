"""
Billing Control Tower — Master Test Suite (MVP3 ground truth).

Covers all acceptance criteria across the full backend:
  - Core: health, use-cases (all 10 full_graph), issues
  - Remediation flows: P1, P2, P3, P4, P5 (interrupt+resume), P6, P7, P9, P10
  - Chat: P8 bill explanation and intent classification
  - Events: TMF event list, simulate
  - Approvals: pending list, approve/reject
  - Context: customer billing context
  - KG: rebuild, issue relationships, customer billing-context, bill trace, not-found
  - Simulation: types, dry-run, active list, invalid type
  - TMF Mock APIs: all 11 resource types
  - Dashboard: all 5 routes
  - Audit: search, action-type filter, action list
  - Self-service: eBill enrolment, appointments

Run:  pytest tests/test_billing_control_tower.py -v
asyncio_mode = auto (set in pytest.ini) — no markers needed.
"""
import os
import sys
import asyncio
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

# Windows: psycopg3 async requires SelectorEventLoop
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# Enable LangGraph debug tracing for tool/checkpointer visibility
os.environ.setdefault("LANGGRAPH_DEBUG", "1")

from app.main import app

# Per-test LLM timeout (seconds). Gemini 2.5 Flash can be slow.
_TEST_TIMEOUT = 180


@pytest_asyncio.fixture
async def client():
    # httpx ASGITransport does NOT call the ASGI lifespan, so setup_checkpointer()
    # is never called and graph.checkpointer stays None.  Inject MemorySaver directly
    # so interrupt()/Command(resume=...) work for P1/P5/P7/P10 approval flows.
    from langgraph.checkpoint.memory import MemorySaver
    import app.agents.checkpoint_setup as _cs
    from app.agents.graph_builder import reset_agentic_graph

    _cs._checkpointer = MemorySaver()
    reset_agentic_graph()          # discard any singleton built without a checkpointer

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
        timeout=_TEST_TIMEOUT,
    ) as c:
        yield c

    reset_agentic_graph()          # clean up after each test
    _cs._checkpointer = None


# ─────────────────────────────────────────────────────────────────────────────
#  Health
# ─────────────────────────────────────────────────────────────────────────────

async def test_health(client):
    response = await client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["mvp"] == "3"


# ─────────────────────────────────────────────────────────────────────────────
#  Use Cases — all 10 must be full_graph
# ─────────────────────────────────────────────────────────────────────────────

async def test_use_cases(client):
    """All 10 use cases exist and every one is full_graph."""
    response = await client.get("/api/v1/use-cases")
    assert response.status_code == 200
    use_cases = response.json()
    assert len(use_cases) == 10
    flow_types = {uc["id"]: uc["flow_type"] for uc in use_cases}
    for p in ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10"]:
        assert p in flow_types, f"{p} not found in use cases"
        assert flow_types[p] == "full_graph", f"{p} expected full_graph, got {flow_types[p]}"


# ─────────────────────────────────────────────────────────────────────────────
#  Issues
# ─────────────────────────────────────────────────────────────────────────────

async def test_issues_list(client):
    """All 10 issues (P1–P10) are seeded."""
    response = await client.get("/api/v1/issues")
    assert response.status_code == 200
    issues = response.json()
    assert len(issues) >= 10
    use_case_ids = {i["use_case_id"] for i in issues}
    for uc in ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10"]:
        assert uc in use_case_ids, f"Issue for {uc} not found"


async def test_get_issue_by_id(client):
    response = await client.get("/api/v1/issues/ISSUE-P2-001")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == "ISSUE-P2-001"
    assert data["use_case_id"] == "P2"


async def test_get_issue_not_found(client):
    response = await client.get("/api/v1/issues/ISSUE-DOES-NOT-EXIST")
    assert response.status_code == 404


# ─────────────────────────────────────────────────────────────────────────────
#  Remediation Flows — all 10 use cases
# ─────────────────────────────────────────────────────────────────────────────

async def test_remediate_p1(client):
    """P1 Missing usage feed: L3 mediation replay → L2 bill protection hold."""
    response = await client.post("/api/v1/issues/ISSUE-P1-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P1"
    assert data["status"] in ("remediated", "pending_approval")


async def test_remediate_p2(client):
    """P2 Duplicate charge: L2 evidence → L3 mediation → L4 rating → L2 credit."""
    response = await client.post("/api/v1/issues/ISSUE-P2-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P2"
    assert data["status"] in ("remediated", "pending_approval")


async def test_remediate_p3(client):
    """P3 Zombie PDU session: L4 session cleanup → L2 credit."""
    response = await client.post("/api/v1/issues/ISSUE-P3-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P3"
    assert data["status"] in ("remediated", "pending_approval")


async def test_remediate_p4(client):
    """P4 QoS/NSSAI mismatch: L2 entitlement → L3 QoS → L4 slice → L2 surcharge removal."""
    response = await client.post("/api/v1/issues/ISSUE-P4-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P4"
    assert data["status"] in ("remediated", "pending_approval")


async def test_remediate_p5_interrupt(client):
    """P5 SLA breach: compensation $75 > $50 threshold → always pending_approval."""
    response = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P5"
    assert data["status"] == "pending_approval"
    assert "approval_id" in data
    assert "thread_id" in data


async def test_remediate_p5_resume_after_approval(client):
    """Full P5 interrupt → approve → resume cycle."""
    # 1. Trigger — must interrupt
    res1 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert res1.status_code == 200
    assert res1.json()["status"] == "pending_approval"
    approval_id = res1.json()["approval_id"]

    # 2. Approve
    res2 = await client.post(
        f"/api/v1/approvals/{approval_id}/approve",
        json={"notes": "Approved by automated test.", "approver_id": "TEST-USER-001", "reason_code": "WITHIN_AUTHORITY"},
    )
    assert res2.status_code == 200
    assert res2.json()["status"] == "approved"

    # 3. Resume
    res3 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/resume")
    assert res3.status_code == 200
    data3 = res3.json()
    assert data3["final_state"]["is_remediated"] is True
    assert "audit_trace_id" in data3["final_state"]


async def test_remediate_p6(client):
    """P6 Collections hold: L2 ticket + dunning + collections hold."""
    response = await client.post("/api/v1/issues/ISSUE-P6-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P6"
    assert data["status"] in ("remediated", "pending_approval")


async def test_remediate_p7(client):
    """P7 Partner discrepancy: L4 SEPP/CHF → L3 mediation → L2 retail + recovery."""
    response = await client.post("/api/v1/issues/ISSUE-P7-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P7"
    assert data["status"] in ("remediated", "awaiting_approval", "pending_approval")


async def test_remediate_p9(client):
    """P9 Proactive risk: risk assessment → L2 pre-bill hold."""
    response = await client.post("/api/v1/issues/ISSUE-P9-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P9"
    assert data["status"] in ("remediated", "pending_approval")


async def test_remediate_p10(client):
    """P10 Governed dispute ($320): L2+L3+L4 → always pending_approval."""
    response = await client.post("/api/v1/issues/ISSUE-P10-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P10"
    assert data["status"] in ("remediated", "awaiting_approval", "pending_approval")


# ─────────────────────────────────────────────────────────────────────────────
#  Chat (P8) — bill explanation + intent coverage
# ─────────────────────────────────────────────────────────────────────────────

async def test_chat_bill_explanation(client):
    """P8 non-streaming bill explanation — LLM fallback ensures non-empty response."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P8-001",
        "message": "Why is my bill higher this month?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]


async def test_chat_issue_analysis_intent(client):
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-INTENT-001",
        "message": "Can you analyze the usage delay issue for my account?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert len(data["final_response"]) > 0


async def test_chat_proactive_risk_summary(client):
    """P9 proactive_risk_summary intent — fetches live risk before LLM response."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P9-RISK",
        "message": "What is the billing risk on my account right now?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]


async def test_chat_partner_charge_explanation(client):
    """partner_charge_explanation intent."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P7-PARTNER",
        "message": "Why are there wholesale partner charges on my account?",
        "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]


async def test_chat_governed_case_summary(client):
    """governed_case_summary intent."""
    response = await client.post("/api/v1/chat", json={
        "conversation_id": "TEST-CHAT-P10-GOV",
        "message": "Can you summarise the status of my dispute case?",
        "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002",
    })
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert data["final_response"]


async def test_chat_stream_sse(client):
    """SSE streaming chat endpoint — verify event frames are emitted."""
    import json as _json
    response = await client.post("/api/v1/chat/stream", json={
        "conversation_id": "TEST-STREAM-SSE-001",
        "message": "Explain my bill",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    })
    assert response.status_code == 200
    assert "text/event-stream" in response.headers.get("content-type", "")

    body = response.text
    events = []
    for frame in body.split("\n\n"):
        frame = frame.strip()
        if not frame:
            continue
        event_type, data_str = None, None
        for line in frame.split("\n"):
            if line.startswith("event:"):
                event_type = line[len("event:"):].strip()
            elif line.startswith("data:"):
                data_str = line[len("data:"):].strip()
        if event_type and data_str:
            try:
                events.append((event_type, _json.loads(data_str)))
            except _json.JSONDecodeError:
                pass

    event_types = [e for e, _ in events]
    assert "conversation_started" in event_types, "Missing conversation_started event"
    assert "final" in event_types, "Missing final event"

    final_data = next((d for e, d in events if e == "final"), {})
    assert final_data.get("final_response"), "final event missing final_response"


# ─────────────────────────────────────────────────────────────────────────────
#  Events
# ─────────────────────────────────────────────────────────────────────────────

async def test_get_events(client):
    response = await client.get("/api/v1/events")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_simulate_event(client):
    response = await client.post("/api/v1/events/simulate/P5")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P5"
    assert "event_id" in data
    assert data["status"] == "new"
    assert "correlation" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Approvals
# ─────────────────────────────────────────────────────────────────────────────

async def test_list_pending_approvals(client):
    response = await client.get("/api/v1/approvals/pending")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_approve_nonexistent_returns_400(client):
    response = await client.post(
        "/api/v1/approvals/APPR-INVALID-99999999/approve",
        json={"notes": "test", "approver_id": "USER-001", "reason_code": "WITHIN_AUTHORITY"},
    )
    assert response.status_code == 400


# ─────────────────────────────────────────────────────────────────────────────
#  Context
# ─────────────────────────────────────────────────────────────────────────────

async def test_customer_billing_context(client):
    response = await client.get("/api/v1/customers/CUST-100001/billing-context")
    assert response.status_code == 200
    data = response.json()
    assert data["customer_id"] == "CUST-100001"
    assert "billing_accounts" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Knowledge Graph
# ─────────────────────────────────────────────────────────────────────────────

async def test_kg_rebuild(client):
    response = await client.post("/api/v1/kg/rebuild")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "rebuilt"
    assert data["node_count"] > 0
    assert data["edge_count"] > 0
    assert "entity_types" in data
    for expected in ("Customer", "BillingAccount", "Bill", "Issue",
                     "NetworkFunction", "PDUSession", "UsageEvent", "PartnerAccount"):
        assert expected in data["entity_types"], f"{expected} missing from KG entity_types"


async def test_kg_issue_relationships_p2(client):
    response = await client.get("/api/v1/kg/issue/ISSUE-P2-001/relationships")
    assert response.status_code == 200
    data = response.json()
    assert data["issue_id"] == "ISSUE-P2-001"
    assert "issue" in data
    assert isinstance(data["nodes"], list)
    assert isinstance(data["edges"], list)


async def test_kg_issue_relationships_p5(client):
    response = await client.get("/api/v1/kg/issue/ISSUE-P5-001/relationships")
    assert response.status_code == 200
    data = response.json()
    assert "nodes" in data
    assert isinstance(data["nodes"], list)


async def test_kg_customer_billing_context(client):
    response = await client.get("/api/v1/kg/customer/CUST-100001/billing-context")
    assert response.status_code == 200
    data = response.json()
    assert data["customer_id"] == "CUST-100001"
    assert "customer" in data
    assert "billing_tree" in data
    assert isinstance(data["billing_account_count"], int)


async def test_kg_bill_to_usage_trace(client):
    response = await client.get("/api/v1/kg/trace/bill/BILL-202604")
    assert response.status_code == 200
    data = response.json()
    assert data["bill_id"] == "BILL-202604"
    assert "usage_chain" in data
    assert isinstance(data["line_item_count"], int)


async def test_kg_customer_not_found(client):
    response = await client.get("/api/v1/kg/customer/CUST-DOES-NOT-EXIST/billing-context")
    assert response.status_code in (404, 200)


# ─────────────────────────────────────────────────────────────────────────────
#  Simulation
# ─────────────────────────────────────────────────────────────────────────────

async def test_simulation_types(client):
    response = await client.get("/api/v1/simulation/types")
    assert response.status_code == 200
    data = response.json()
    assert "simulation_types" in data
    types = [t["type"] for t in data["simulation_types"]]
    for expected in ("duplicate_charge", "zombie_pdu_session", "usage_delay",
                     "qos_mismatch", "sla_breach", "partner_discrepancy", "proactive_risk"):
        assert expected in types
    assert len(types) == 7


async def test_simulation_dry_run(client):
    response = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "duplicate_charge", "customer_id": "CUST-100001",
                "billing_account_id": "BA-100001", "dry_run": "true"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["dry_run"] is True
    assert data["simulation_type"] == "duplicate_charge"
    assert data["use_case_id"] == "P2"
    assert data["issue_id"] is None
    assert data["artifacts_created"] > 0


async def test_simulation_active_list(client):
    response = await client.get("/api/v1/simulation/active")
    assert response.status_code == 200
    data = response.json()
    assert "active_simulation_count" in data
    assert "simulations" in data


async def test_simulation_invalid_type_returns_400(client):
    response = await client.post(
        "/api/v1/simulation/inject",
        params={"simulation_type": "not_a_real_type"},
    )
    assert response.status_code == 400


# ─────────────────────────────────────────────────────────────────────────────
#  TMF Mock APIs
# ─────────────────────────────────────────────────────────────────────────────

async def test_tmf_product_catalog(client):
    response = await client.get("/api/v1/mock-tmf/product-catalog/product")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_product_offerings(client):
    response = await client.get("/api/v1/mock-tmf/product-catalog/productOffering")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_trouble_tickets(client):
    response = await client.get("/api/v1/mock-tmf/trouble-ticket")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_service_inventory(client):
    response = await client.get("/api/v1/mock-tmf/service-inventory/service")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_customer_bills(client):
    response = await client.get("/api/v1/mock-tmf/customer-bill")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_bill_line_items(client):
    response = await client.get("/api/v1/mock-tmf/customer-bill/BILL-202604/line-items")
    assert response.status_code == 200
    data = response.json()
    assert "lineItems" in data
    assert isinstance(data["lineItems"], list)
    assert len(data["lineItems"]) > 0


async def test_tmf_events(client):
    response = await client.get("/api/v1/mock-tmf/event")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_service_problem(client):
    response = await client.get("/api/v1/mock-tmf/service-problem")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_audit_records(client):
    response = await client.get("/api/v1/mock-tmf/audit-record")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


async def test_tmf_hub_registration(client):
    response = await client.post(
        "/api/v1/mock-tmf/hub",
        params={"callback_url": "https://test.example.com/notify"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "id" in data
    assert data["callback"] == "https://test.example.com/notify"


async def test_tmf_trouble_ticket_patch(client):
    """PATCH trouble-ticket status update."""
    response = await client.patch(
        "/api/v1/mock-tmf/trouble-ticket/TT-P5-001",
        params={"status": "in_progress"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "in_progress"


# ─────────────────────────────────────────────────────────────────────────────
#  Dashboard
# ─────────────────────────────────────────────────────────────────────────────

async def test_dashboard_summary(client):
    response = await client.get("/api/v1/dashboard/summary")
    assert response.status_code == 200
    data = response.json()
    assert "issues" in data
    assert "control_cases" in data
    assert "approvals" in data
    assert "financial_exposure" in data
    assert data["issues"]["total"] >= 10


async def test_dashboard_prebill_risks(client):
    response = await client.get("/api/v1/dashboard/prebill-risks")
    assert response.status_code == 200
    data = response.json()
    assert "prebill_risk_accounts" in data
    assert "accounts" in data


async def test_dashboard_postbill_disputes(client):
    response = await client.get("/api/v1/dashboard/postbill-disputes")
    assert response.status_code == 200
    data = response.json()
    assert "dispute_count" in data
    assert "disputes" in data


async def test_dashboard_layer_health(client):
    response = await client.get("/api/v1/dashboard/layer-health")
    assert response.status_code == 200
    data = response.json()
    for layer in ("L1", "L2", "L3", "L4"):
        assert layer in data
        assert "status" in data[layer]


async def test_dashboard_audit_summary(client):
    response = await client.get("/api/v1/dashboard/audit-summary")
    assert response.status_code == 200
    data = response.json()
    assert "recent_audit_count" in data
    assert "recent_traces" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Audit
# ─────────────────────────────────────────────────────────────────────────────

async def test_audit_search_no_filters(client):
    response = await client.get("/api/v1/audit/search")
    assert response.status_code == 200
    data = response.json()
    assert "traces" in data
    assert "total" in data


async def test_audit_search_by_action_type(client):
    response = await client.get("/api/v1/audit/search", params={"action_type": "event_correlation"})
    assert response.status_code == 200
    data = response.json()
    for trace in data["traces"]:
        assert trace["action_type"] == "event_correlation"


async def test_audit_action_types(client):
    response = await client.get("/api/v1/audit/actions")
    assert response.status_code == 200
    data = response.json()
    assert "action_types" in data
    assert "total_traces" in data


# ─────────────────────────────────────────────────────────────────────────────
#  Self-Service — eBill and Appointments
# ─────────────────────────────────────────────────────────────────────────────

async def test_ebill_enrolment(client):
    response = await client.post("/api/v1/self-service/ebill", json={
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "email_for_ebill": "alice@example.com",
    })
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "enrolled"
    assert data["customer_id"] == "CUST-100001"
    assert "reference" in data
    assert "ebill_email" in data


async def test_ebill_enrolment_customer_not_found(client):
    response = await client.post("/api/v1/self-service/ebill", json={
        "customer_id": "CUST-DOES-NOT-EXIST",
    })
    assert response.status_code == 404


async def test_create_appointment_callback(client):
    response = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P2-001",
        "appointment_type": "callback",
        "scheduled_at": "2026-05-10T14:00:00",
        "notes": "Customer wants to discuss duplicate charge",
    })
    assert response.status_code == 201
    data = response.json()
    assert data["appointment_type"] == "callback"
    assert data["status"] == "scheduled"
    assert data["customer_id"] == "CUST-100001"
    assert "id" in data


async def test_get_appointment(client):
    create_resp = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100003",
        "appointment_type": "video_call",
        "scheduled_at": "2026-05-12T10:30:00",
        "notes": "SLA compensation discussion",
    })
    assert create_resp.status_code == 201
    appt_id = create_resp.json()["id"]

    get_resp = await client.get(f"/api/v1/appointments/{appt_id}")
    assert get_resp.status_code == 200
    data = get_resp.json()
    assert data["id"] == appt_id
    assert data["appointment_type"] == "video_call"
    assert data["customer_id"] == "CUST-100003"


async def test_appointment_invalid_type(client):
    response = await client.post("/api/v1/appointments", json={
        "customer_id": "CUST-100001",
        "appointment_type": "telepathy",
        "scheduled_at": "2026-05-15T09:00:00",
    })
    assert response.status_code == 400


async def test_appointment_not_found(client):
    response = await client.get("/api/v1/appointments/APPT-DOES-NOT-EXIST")
    assert response.status_code == 404
