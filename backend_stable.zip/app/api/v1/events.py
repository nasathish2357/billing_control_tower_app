"""
MVP2 Events API

Routes:
  POST /events                          — create event
  GET  /events                          — list events (filter by status, use_case_id)
  GET  /events/{event_id}               — get event
  POST /events/simulate/{use_case_id}   — simulate event for a use case (triggers L1 correlation)
"""
import datetime
import logging
import uuid
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import TMFEvent
from app.api.v1.schemas import TMFEventOut, TMFEventCreate

logger = logging.getLogger(__name__)
router = APIRouter()

# Map use_case_id → event_type for simulation
USE_CASE_EVENT_MAP = {
    "P1": "SuspectedUsageDelayEvent",
    "P2": "DuplicateChargingEvent",
    "P3": "ZombieSessionSuspectedEvent",
    "P4": "QoSMismatchEvent",
    "P5": "ServiceDegradationEvent",
    "P6": "CollectionsRiskEvent",
    "P9": "BillingRiskDetectedEvent",
}

ISSUE_ID_MAP = {
    "P1": "ISSUE-P1-001",
    "P2": "ISSUE-P2-001",
    "P3": "ISSUE-P3-001",
    "P4": "ISSUE-P4-001",
    "P5": "ISSUE-P5-001",
    "P6": "ISSUE-P6-001",
    "P9": "ISSUE-P9-001",
}


@router.post("/events", response_model=TMFEventOut, status_code=201)
async def create_event(body: TMFEventCreate, db: AsyncSession = Depends(get_db)):
    """Create a new TMF event."""
    ev_id = f"EVT-{body.use_case_id or 'GEN'}-{str(uuid.uuid4())[:8].upper()}"
    ev = TMFEvent(
        id=ev_id,
        event_type=body.event_type,
        use_case_id=body.use_case_id,
        source_layer=body.source_layer,
        severity=body.severity or "medium",
        status="new",
        customer_id=body.customer_id,
        billing_account_id=body.billing_account_id,
        issue_id=body.issue_id,
        description=body.description,
        payload=body.payload or {},
    )
    db.add(ev)
    await db.commit()
    await db.refresh(ev)
    return ev


@router.get("/events", response_model=List[TMFEventOut])
async def list_events(
    status: Optional[str] = Query(None),
    use_case_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """List TMF events with optional filters."""
    q = select(TMFEvent).order_by(TMFEvent.created_at.desc())
    if status:
        q = q.where(TMFEvent.status == status)
    if use_case_id:
        q = q.where(TMFEvent.use_case_id == use_case_id)
    result = await db.execute(q)
    return result.scalars().all()


@router.get("/events/{event_id}", response_model=TMFEventOut)
async def get_event(event_id: str, db: AsyncSession = Depends(get_db)):
    """Get a single TMF event."""
    result = await db.execute(select(TMFEvent).where(TMFEvent.id == event_id))
    ev = result.scalar_one_or_none()
    if not ev:
        raise HTTPException(status_code=404, detail=f"Event {event_id} not found")
    return ev


@router.post("/events/simulate/{use_case_id}")
async def simulate_event(use_case_id: str, db: AsyncSession = Depends(get_db)):
    """
    Simulate a TMF event for a given use case.
    Creates the event and triggers L1 Monitoring correlation.
    """
    event_type = USE_CASE_EVENT_MAP.get(use_case_id.upper())
    if not event_type:
        raise HTTPException(
            status_code=400,
            detail=f"No event simulation available for use case {use_case_id}. Supported: {list(USE_CASE_EVENT_MAP.keys())}",
        )

    uc = use_case_id.upper()
    ev_id = f"EVT-SIM-{uc}-{str(uuid.uuid4())[:8].upper()}"
    ev = TMFEvent(
        id=ev_id,
        event_type=event_type,
        use_case_id=uc,
        source_layer="L1",
        severity="high",
        status="new",
        issue_id=ISSUE_ID_MAP.get(uc),
        description=f"Simulated {event_type} for use case {uc} — demo/test injection.",
        payload={"simulated": True, "use_case_id": uc, "injected_at": datetime.datetime.utcnow().isoformat()},
    )
    db.add(ev)
    await db.commit()

    # Trigger L1 Monitoring correlation
    try:
        from app.agents.tools.l1_tools import correlate_event
        correlation = await correlate_event(db, ev_id)
    except Exception as e:
        logger.warning("L1 correlation failed after simulation: %s", e)
        correlation = {"warning": str(e)}

    logger.info("Event simulated: %s → %s", ev_id, event_type)
    return {
        "event_id": ev_id,
        "event_type": event_type,
        "use_case_id": uc,
        "status": "new",
        "correlation": correlation,
    }
