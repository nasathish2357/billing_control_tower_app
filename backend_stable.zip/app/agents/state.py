"""
LangGraph state definitions for Billing Control Tower.

Design rules (from engineering addendum):
  - State must be SMALL and reference-based.
  - Never store full TMF payloads in state.
  - Store only IDs, summaries, and policy flags.
  - Large evidence stays in PostgreSQL evidence_packs table.
"""
from typing import Any, Optional, List, TypedDict


class RemediationState(TypedDict, total=False):
    """
    Lightweight state for P1–P6, P9 remediation graphs.
    Only compact references and summaries — no large payloads.
    """
    # Core references
    issue_id: str
    use_case_id: str
    control_case_id: str
    thread_id: str
    customer_id: str
    billing_account_id: str
    bill_id: Optional[str]
    event_id: Optional[str]              # MVP2: linked TMF event

    # Evidence (IDs + summaries only — payloads in PostgreSQL)
    evidence_pack_ids: List[str]
    evidence_summary: str
    playbook_summary: str

    # KG context (MVP2 — compact string)
    kg_context: Optional[str]

    # Policy
    policy_decision: Optional[str]       # auto_remediation_allowed, approval_required, reject
    planned_action_ids: List[str]

    # Human approval (MVP2)
    approval_id: Optional[str]
    approval_status: Optional[str]       # pending, approved, rejected

    # Outcome
    final_response_summary: Optional[str]
    audit_trace_id: Optional[str]
    is_remediated: bool
    requires_human_approval: bool
    error: Optional[str]


class ChatState(TypedDict, total=False):
    """
    Lightweight state for P8 chat / bill explanation graph.
    Only compact references — no full bill payloads in state.
    """
    # Session
    conversation_id: str
    customer_id: str
    billing_account_id: str
    thread_id: str
    message: str                         # raw user message string
    messages: List[Any]                  # LangChain Message objects (HumanMessage etc.)

    # Resolved intent
    intent: Optional[str]                # bill_explanation, compare_previous_bill, issue_status,
                                         # remediate_issue, escalate_to_human,
                                         # issue_analysis, remediation_explanation,
                                         # collections_hold_request, compensation_eligibility_check

    # Context references (IDs + summaries only)
    current_bill_id: Optional[str]
    current_bill_summary: Optional[str]
    previous_bill_ids: List[str]
    previous_bill_summary: Optional[str]
    customer_summary: Optional[str]
    issue_id: Optional[str]
    evidence_summary: str                # accumulated evidence from load_* nodes

    # RAG
    playbook_summary: Optional[str]

    # LLM output
    explanation: Optional[str]
    final_response: Optional[str]        # explanation text (what generate_explanation_llm returns)
    escalation_required: bool
    control_case_id: Optional[str]

    # Audit
    audit_trace_id: Optional[str]

    # SSE streaming tokens
    stream_tokens: List[str]

    # Error
    error: Optional[str]
