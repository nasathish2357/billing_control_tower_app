"""
Approval Manager — MVP2

Manages human approval lifecycle for high-risk agentic actions.
Integrates with LangGraph checkpointer for interrupt/resume.

Flow:
  1. Graph node reaches high-risk action.
  2. approval_manager.create_approval() stores the approval record.
  3. Graph interrupts — checkpoint saved by PostgresSaver.
  4. API returns approval_id and thread_id to caller.
  5. Human approves/rejects via API.
  6. resume_graph() reloads state from thread_id and continues execution.
"""
import datetime
import logging
import uuid
from typing import Dict, Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.models import Approval, ControlCase

logger = logging.getLogger(__name__)


async def create_approval(
    db: AsyncSession,
    *,
    thread_id: str,
    issue_id: str,
    control_case_id: str,
    action: str,
    risk_reason: str,
    amount: Optional[float] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """
    Create a pending approval record for a high-risk agentic action.
    The calling graph node should interrupt after calling this.
    """
    approval_id = f"APPR-{issue_id}-{str(uuid.uuid4())[:8].upper()}"

    # Mark control case as requiring human approval
    cc_result = await db.execute(select(ControlCase).where(ControlCase.id == control_case_id))
    cc = cc_result.scalar_one_or_none()
    if cc:
        cc.requires_human_approval = True

    approval = Approval(
        id=approval_id,
        thread_id=thread_id,
        issue_id=issue_id,
        control_case_id=control_case_id,
        action=action,
        risk_reason=risk_reason,
        status="pending",
        amount=amount,
    )
    db.add(approval)

    if commit:
        await db.commit()

    logger.info(
        "Approval %s created for thread=%s action=%s amount=%s",
        approval_id, thread_id, action, amount,
    )
    return {
        "approval_id": approval_id,
        "thread_id": thread_id,
        "issue_id": issue_id,
        "control_case_id": control_case_id,
        "action": action,
        "risk_reason": risk_reason,
        "amount": amount,
        "status": "pending",
    }


async def get_approval(db: AsyncSession, approval_id: str) -> Optional[Approval]:
    """Fetch an approval record by ID."""
    result = await db.execute(select(Approval).where(Approval.id == approval_id))
    return result.scalar_one_or_none()


async def get_pending_approvals(db: AsyncSession) -> list:
    """Fetch all pending approvals."""
    result = await db.execute(
        select(Approval)
        .where(Approval.status == "pending")
        .order_by(Approval.created_at.desc())
    )
    return result.scalars().all()


async def decide_approval(
    db: AsyncSession,
    approval_id: str,
    *,
    approved: bool,
    notes: Optional[str] = None,
    commit: bool = True,
) -> Dict[str, Any]:
    """Approve or reject an approval record."""
    result = await db.execute(select(Approval).where(Approval.id == approval_id))
    approval = result.scalar_one_or_none()
    if not approval:
        return {"error": f"Approval {approval_id} not found"}

    if approval.status != "pending":
        return {"error": f"Approval {approval_id} is already {approval.status}"}

    approval.status = "approved" if approved else "rejected"
    approval.approver_notes = notes
    approval.decided_at = datetime.datetime.utcnow()

    if commit:
        await db.commit()

    logger.info("Approval %s %s (notes=%s)", approval_id, approval.status, notes)
    return {
        "approval_id": approval_id,
        "thread_id": approval.thread_id,
        "status": approval.status,
        "decided_at": approval.decided_at.isoformat(),
    }


async def resume_graph(
    thread_id: str,
    approved: bool,
    graph,
    checkpointer,
) -> Dict[str, Any]:
    """
    Resume a checkpointed LangGraph from the given thread_id.

    Uses Command(resume=...) — the correct LangGraph 1.x API for resuming
    after an interrupt(). The resume value is passed back to the interrupt()
    call site in l1_supervisor_node as human_input.

    Args:
        thread_id: LangGraph thread ID used during the original run.
        approved: Whether the human approved the action.
        graph: The compiled LangGraph StateGraph.
        checkpointer: The checkpointer instance (PostgresSaver or MemorySaver).

    Returns:
        Final graph state after resumption.
    """
    from langgraph.types import Command as LGCommand

    decision = "approved" if approved else "rejected"

    config = {
        "configurable": {"thread_id": thread_id},
        "recursion_limit": 50,
    }

    try:
        # Resume by injecting the approval decision as the interrupt resume value.
        # interrupt() in l1_supervisor_node receives {"decision": decision} as human_input
        # and routes with approval_status = decision.
        final_state = await graph.ainvoke(
            LGCommand(resume={"decision": decision}),
            config=config,
        )
        logger.info("Graph resumed for thread=%s approved=%s", thread_id, approved)
        return {
            "thread_id": thread_id,
            "resumed": True,
            "approved": approved,
            "final_state": {
                k: v for k, v in final_state.items()
                if k in ("issue_id", "control_case_id", "audit_trace_id",
                         "is_remediated", "final_response_summary", "policy_decision")
            },
        }
    except Exception as e:
        logger.error("Graph resume failed for thread=%s: %s", thread_id, e)
        return {"error": str(e), "thread_id": thread_id, "resumed": False}
