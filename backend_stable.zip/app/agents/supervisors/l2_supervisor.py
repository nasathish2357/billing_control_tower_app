"""
L2 BSS Domain Supervisor Graph.

Architecture:
  START → l2_supervisor_entry
  l2_supervisor_entry → (Command) → l2_bss_correction_agent | l2_collections_agent
                                  | l2_ticketing_agent | l2_done
  l2_bss_correction_agent → (edge) → l2_supervisor_entry
  l2_collections_agent    → (edge) → l2_supervisor_entry
  l2_ticketing_agent      → (edge) → l2_supervisor_entry
  l2_done → END

Sub-agents are created via factory.create_agent().
Routing from agents back to supervisor uses explicit graph edges (not Command).
"""
import logging
from typing import Literal

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory
from app.agents.prompts.templates import (
    L2_BSS_CORRECTION_SYSTEM,
    L2_COLLECTIONS_SYSTEM,
    L2_TICKETING_SYSTEM,
    build_l2_agent_prompt,
)
from app.agents.tools import L2_TOOLS, SHARED_TOOLS

logger = logging.getLogger(__name__)

_L2_TASK_MAP = {
    "P1":  {"role": "correction",  "task": "Apply bill protection hold for delayed usage feed."},
    "P2":  {"role": "correction",  "task": "Retrieve bill evidence, then apply duplicate charge credit after domain confirmation."},
    "P3":  {"role": "correction",  "task": "Apply credit for confirmed zombie session charges."},
    "P4":  {"role": "correction",  "task": "Retrieve entitlement. Remove premium surcharge if QoS/NSSAI mismatch confirmed."},
    "P5":  {"role": "ticketing",   "task": "Open service complaint ticket. Apply compensation credit for SLA breach."},
    "P6":  {"role": "collections", "task": "Open billing dispute ticket. Check dunning state. Apply collections hold. Separate disputed balance."},
    "P7":  {"role": "correction",  "task": "Apply retail customer correction. Create partner settlement recovery case."},
    "P9":  {"role": "correction",  "task": "Apply proactive pre-bill review hold — anomaly detected before billing."},
    "P10": {"role": "ticketing",   "task": "Open governed dispute ticket. Apply charge reversal and compensation credit."},
}

L2_AGENTS = Literal["l2_bss_correction_agent", "l2_collections_agent", "l2_ticketing_agent", "l2_done"]


def _pick_l2_agent(use_case_id: str, state: AgentState) -> tuple[str, str]:
    config = _L2_TASK_MAP.get(use_case_id, {"role": "correction", "task": "Apply BSS correction."})
    role = config["role"]
    task = config["task"]

    if role == "correction":
        return "l2_bss_correction_agent", task
    if role == "collections":
        return "l2_collections_agent", task
    # ticketing: P5/P10 need ticket first, then correction
    messages = state.get("messages", [])
    if any("l2_ticketing_agent" in str(getattr(m, "content", "")) for m in messages):
        return "l2_bss_correction_agent", "Apply compensation credit after ticket is opened."
    return "l2_ticketing_agent", task


async def l2_supervisor_entry(state: AgentState) -> Command[L2_AGENTS]:
    """L2 Supervisor entry — routes to the appropriate L2 sub-agent."""
    use_case_id = state.get("use_case_id", "P2")
    logger.info("[L2 Supervisor] entry use_case=%s", use_case_id)

    messages = state.get("messages", [])
    correction_done = any(
        "l2_bss_correction_agent" in str(getattr(m, "content", "")) for m in messages
    )
    collections_done = any(
        "l2_collections_agent" in str(getattr(m, "content", "")) for m in messages
    )

    if use_case_id == "P6" and correction_done and not collections_done:
        return Command(
            goto="l2_collections_agent",
            update={"messages": [AIMessage(content="L2 Supervisor: Routing to collections agent for P6 hold.")]},
        )

    if correction_done or collections_done:
        return Command(
            goto="l2_done",
            update={"messages": [AIMessage(content="L2 Supervisor: All L2 operations complete.")]},
        )

    next_agent, task = _pick_l2_agent(use_case_id, state)
    logger.info("[L2 Supervisor] routing to %s | task: %s", next_agent, task[:60])
    return Command(
        goto=next_agent,
        update={
            "next_agent": next_agent,
            "messages": [AIMessage(content=f"L2 Supervisor routing to {next_agent}: {task}")],
        },
    )


async def l2_done(state: AgentState) -> dict:
    """L2 work complete — exit subgraph."""
    logger.info("[L2 Supervisor] done — exiting subgraph")
    return {
        "messages": [AIMessage(content="L2 BSS domain operations complete. Returning to L1 Supervisor.")],
    }


def build_l2_supervisor_graph(factory: AgentFactory, checkpointer=None):
    """
    Build the L2 BSS supervisor StateGraph.

    Sub-agents are created via factory.create_agent().
    Explicit edges route agents back to l2_supervisor_entry for re-evaluation.
    Runtime context (use_case_id, evidence_summary) is injected by factory into prompts.
    """
    l2_correction_node = factory.create_agent(
        tools=L2_TOOLS + SHARED_TOOLS,
        system_prompt=build_l2_agent_prompt(
            "correction",
            "Apply billing correction appropriate for the current use case.",
            "", "",
        ),
        name="l2_bss_correction_agent",
    )

    l2_collections_node = factory.create_agent(
        tools=L2_TOOLS + SHARED_TOOLS,
        system_prompt=build_l2_agent_prompt(
            "collections",
            "Apply collections hold and separate disputed balance.",
            "", "",
        ),
        name="l2_collections_agent",
    )

    l2_ticketing_node = factory.create_agent(
        tools=L2_TOOLS + SHARED_TOOLS,
        system_prompt=build_l2_agent_prompt(
            "ticketing",
            "Open trouble ticket for the current billing dispute.",
            "", "",
        ),
        name="l2_ticketing_agent",
    )

    builder = StateGraph(AgentState)
    builder.add_node("l2_supervisor_entry", l2_supervisor_entry)
    builder.add_node("l2_bss_correction_agent", l2_correction_node)
    builder.add_node("l2_collections_agent", l2_collections_node)
    builder.add_node("l2_ticketing_agent", l2_ticketing_node)
    builder.add_node("l2_done", l2_done)

    builder.add_edge(START, "l2_supervisor_entry")
    # Explicit edges: agents return to supervisor entry for re-evaluation
    builder.add_edge("l2_bss_correction_agent", "l2_supervisor_entry")
    builder.add_edge("l2_collections_agent", "l2_supervisor_entry")
    builder.add_edge("l2_ticketing_agent", "l2_supervisor_entry")
    builder.add_edge("l2_done", END)

    return builder.compile(checkpointer=checkpointer)
