"""
L3 OSS Domain Supervisor Graph.

Architecture:
  START → l3_supervisor_entry
  l3_supervisor_entry → (Command) → l3_mediation_agent | l3_qos_agent
                                  | l3_service_problem_agent | l3_done
  l3_mediation_agent       → (edge) → l3_supervisor_entry
  l3_qos_agent             → (edge) → l3_supervisor_entry
  l3_service_problem_agent → (edge) → l3_supervisor_entry
  l3_done → END

Sub-agents created via factory.create_agent() with explicit edge routing.
"""
import logging
from typing import Literal

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory
from app.agents.prompts.templates import (
    L3_MEDIATION_SYSTEM,
    L3_QOS_SYSTEM,
    L3_SERVICE_PROBLEM_SYSTEM,
)
from app.agents.tools import L3_TOOLS, SHARED_TOOLS

logger = logging.getLogger(__name__)

_L3_TASK_MAP = {
    "P1":  {"role": "mediation",       "task": "Check mediation backlog for delayed CDR events. Create replay job."},
    "P2":  {"role": "mediation",       "task": "Retrieve mediation records confirming duplicate rating events."},
    "P4":  {"role": "qos",             "task": "Retrieve QoS evidence (throughput, NSSAI, packet loss) for entitlement analysis."},
    "P5":  {"role": "service_problem", "task": "Evaluate SLA breach for voice outage. Create service problem record."},
    "P7":  {"role": "mediation",       "task": "Validate CSP mediation CDR count for partner settlement period."},
    "P10": {"role": "service_problem", "task": "Evaluate SLA breach for multi-domain enterprise outage. Create service problem."},
}

L3_AGENTS = Literal["l3_mediation_agent", "l3_qos_agent", "l3_service_problem_agent", "l3_done"]


def _pick_l3_agent(use_case_id: str) -> tuple[str, str]:
    config = _L3_TASK_MAP.get(use_case_id, {"role": "mediation", "task": "Gather OSS evidence."})
    role = config["role"]
    task = config["task"]
    agent_map = {
        "mediation": "l3_mediation_agent",
        "qos": "l3_qos_agent",
        "service_problem": "l3_service_problem_agent",
    }
    return agent_map.get(role, "l3_mediation_agent"), task


async def l3_supervisor_entry(state: AgentState) -> Command[L3_AGENTS]:
    """L3 Supervisor entry — routes to the appropriate L3 sub-agent."""
    use_case_id = state.get("use_case_id", "P2")
    logger.info("[L3 Supervisor] entry use_case=%s", use_case_id)

    messages = state.get("messages", [])
    visited = {str(getattr(m, "content", "")) for m in messages}
    if any("l3_" in c and "_agent" in c for c in visited):
        return Command(
            goto="l3_done",
            update={"messages": [AIMessage(content="L3 Supervisor: All OSS operations complete.")]},
        )

    next_agent, task = _pick_l3_agent(use_case_id)
    logger.info("[L3 Supervisor] routing to %s | task: %s", next_agent, task[:60])
    return Command(
        goto=next_agent,
        update={
            "next_agent": next_agent,
            "messages": [AIMessage(content=f"L3 Supervisor routing to {next_agent}: {task}")],
        },
    )


async def l3_done(state: AgentState) -> dict:
    """L3 work complete — exit subgraph."""
    logger.info("[L3 Supervisor] done — exiting subgraph")
    return {
        "messages": [AIMessage(content="L3 OSS domain operations complete. Returning to L1 Supervisor.")],
    }


def build_l3_supervisor_graph(factory: AgentFactory, checkpointer=None):
    """
    Build the L3 OSS supervisor StateGraph.

    Sub-agents: l3_mediation_agent, l3_qos_agent, l3_service_problem_agent.
    Each is created via factory.create_agent() with explicit edge routing.
    """
    l3_mediation_node = factory.create_agent(
        tools=L3_TOOLS + SHARED_TOOLS,
        system_prompt=L3_MEDIATION_SYSTEM,
        name="l3_mediation_agent",
    )

    l3_qos_node = factory.create_agent(
        tools=L3_TOOLS + SHARED_TOOLS,
        system_prompt=L3_QOS_SYSTEM,
        name="l3_qos_agent",
    )

    l3_service_problem_node = factory.create_agent(
        tools=L3_TOOLS + SHARED_TOOLS,
        system_prompt=L3_SERVICE_PROBLEM_SYSTEM,
        name="l3_service_problem_agent",
    )

    builder = StateGraph(AgentState)
    builder.add_node("l3_supervisor_entry", l3_supervisor_entry)
    builder.add_node("l3_mediation_agent", l3_mediation_node)
    builder.add_node("l3_qos_agent", l3_qos_node)
    builder.add_node("l3_service_problem_agent", l3_service_problem_node)
    builder.add_node("l3_done", l3_done)

    builder.add_edge(START, "l3_supervisor_entry")
    builder.add_edge("l3_mediation_agent", "l3_supervisor_entry")
    builder.add_edge("l3_qos_agent", "l3_supervisor_entry")
    builder.add_edge("l3_service_problem_agent", "l3_supervisor_entry")
    builder.add_edge("l3_done", END)

    return builder.compile(checkpointer=checkpointer)
