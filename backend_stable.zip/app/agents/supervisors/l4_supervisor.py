"""
L4 Network Domain Supervisor Graph.

Architecture:
  START → l4_supervisor_entry
  l4_supervisor_entry → (Command) → l4_session_agent | l4_rating_agent
                                  | l4_roaming_agent | l4_done
  l4_session_agent  → (edge) → l4_supervisor_entry
  l4_rating_agent   → (edge) → l4_supervisor_entry
  l4_roaming_agent  → (edge) → l4_supervisor_entry
  l4_done → END

Sub-agents created via factory.create_agent() with explicit edge routing.
"""
import logging
from typing import Literal

from langchain_core.messages import AIMessage
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory
from app.agents.prompts.templates import (
    L4_SESSION_SYSTEM,
    L4_RATING_SYSTEM,
    L4_ROAMING_SYSTEM,
)
from app.agents.tools import L4_TOOLS, SHARED_TOOLS

logger = logging.getLogger(__name__)

_L4_TASK_MAP = {
    "P2":  {"role": "rating",  "task": "Retrieve CHF/CTF rating trigger evidence for duplicate charge investigation."},
    "P3":  {"role": "session", "task": "Retrieve PDU session evidence. Terminate zombie session."},
    "P4":  {"role": "session", "task": "Retrieve 5G slice performance evidence for NSSAI/entitlement mismatch."},
    "P7":  {"role": "roaming", "task": "Retrieve SEPP N32 CDR export evidence and CHF roaming charging records."},
    "P10": {"role": "session", "task": "Audit PDU sessions and network functions for multi-domain outage window."},
}

L4_AGENTS = Literal["l4_session_agent", "l4_rating_agent", "l4_roaming_agent", "l4_done"]


def _pick_l4_agent(use_case_id: str) -> tuple[str, str]:
    config = _L4_TASK_MAP.get(use_case_id, {"role": "session", "task": "Gather network evidence."})
    role = config["role"]
    task = config["task"]
    agent_map = {
        "session": "l4_session_agent",
        "rating": "l4_rating_agent",
        "roaming": "l4_roaming_agent",
    }
    return agent_map.get(role, "l4_session_agent"), task


async def l4_supervisor_entry(state: AgentState) -> Command[L4_AGENTS]:
    """L4 Supervisor entry — routes to the appropriate L4 sub-agent."""
    use_case_id = state.get("use_case_id", "P3")
    logger.info("[L4 Supervisor] entry use_case=%s", use_case_id)

    messages = state.get("messages", [])
    visited = {str(getattr(m, "content", "")) for m in messages}
    if any("l4_" in c and "_agent" in c for c in visited):
        return Command(
            goto="l4_done",
            update={"messages": [AIMessage(content="L4 Supervisor: All network operations complete.")]},
        )

    next_agent, task = _pick_l4_agent(use_case_id)
    logger.info("[L4 Supervisor] routing to %s | task: %s", next_agent, task[:60])
    return Command(
        goto=next_agent,
        update={
            "next_agent": next_agent,
            "messages": [AIMessage(content=f"L4 Supervisor routing to {next_agent}: {task}")],
        },
    )


async def l4_done(state: AgentState) -> dict:
    """L4 work complete — exit subgraph."""
    logger.info("[L4 Supervisor] done — exiting subgraph")
    return {
        "messages": [AIMessage(content="L4 Network domain operations complete. Returning to L1 Supervisor.")],
    }


def build_l4_supervisor_graph(factory: AgentFactory, checkpointer=None):
    """
    Build the L4 Network supervisor StateGraph.

    Sub-agents: l4_session_agent, l4_rating_agent, l4_roaming_agent.
    Each is created via factory.create_agent() with explicit edge routing.
    """
    l4_session_node = factory.create_agent(
        tools=L4_TOOLS + SHARED_TOOLS,
        system_prompt=L4_SESSION_SYSTEM,
        name="l4_session_agent",
    )

    l4_rating_node = factory.create_agent(
        tools=L4_TOOLS + SHARED_TOOLS,
        system_prompt=L4_RATING_SYSTEM,
        name="l4_rating_agent",
    )

    l4_roaming_node = factory.create_agent(
        tools=L4_TOOLS + SHARED_TOOLS,
        system_prompt=L4_ROAMING_SYSTEM,
        name="l4_roaming_agent",
    )

    builder = StateGraph(AgentState)
    builder.add_node("l4_supervisor_entry", l4_supervisor_entry)
    builder.add_node("l4_session_agent", l4_session_node)
    builder.add_node("l4_rating_agent", l4_rating_node)
    builder.add_node("l4_roaming_agent", l4_roaming_node)
    builder.add_node("l4_done", l4_done)

    builder.add_edge(START, "l4_supervisor_entry")
    builder.add_edge("l4_session_agent", "l4_supervisor_entry")
    builder.add_edge("l4_rating_agent", "l4_supervisor_entry")
    builder.add_edge("l4_roaming_agent", "l4_supervisor_entry")
    builder.add_edge("l4_done", END)

    return builder.compile(checkpointer=checkpointer)
