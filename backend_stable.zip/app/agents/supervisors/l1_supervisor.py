"""
L1 Root Supervisor — the top-level orchestrator of the Billing Control Tower.

This is a LangGraph StateGraph node (not a sub-graph).
It routes to domain supervisor sub-graphs (L2, L3, L4) via Command,
coordinates policy/audit/risk agents (also nodes), and handles
human-in-the-loop approval using langgraph.types.interrupt.

Architecture:
  START → l1_supervisor → [l2_supervisor | l3_supervisor | l4_supervisor |
                            l1_policy_agent | l1_audit_agent | l1_risk_agent |
                            chat_agent | __end__]
  Each domain supervisor returns Command(goto="l1_supervisor") when done.

Owner-layer rule:
  L1 communicates only with owner-layer orchestrators.
  L1 never invokes L2/L3/L4 sub-components directly.

Spec reference:
  master_prompt/tmforum_billing_dispute_agentic_ai_3_incremental_mvp_scopes_updated.txt
  Section: MVP 3 Full P10 Flow, MVP 2 Human Approval, L1 Component Ecosystem.
"""
import logging
from typing import Any, Dict, Literal, Set

from langchain_core.messages import AIMessage
from langgraph.types import Command, interrupt

from app.agents.agent_state import AgentState

logger = logging.getLogger(__name__)

# ── Use-case domain plan ───────────────────────────────────────────────────────
# Ordered sequence of domain supervisors L1 must visit for each use case.
# L1 works through these sequentially, synchronising outcomes.
USE_CASE_DOMAIN_PLAN: Dict[str, list] = {
    "P1":  ["l3_supervisor", "l2_supervisor"],
    "P2":  ["l2_supervisor", "l3_supervisor", "l4_supervisor"],     # L2 gets evidence, L3+L4 confirm, L2 applies credit
    "P3":  ["l4_supervisor", "l2_supervisor"],
    "P4":  ["l2_supervisor", "l3_supervisor", "l4_supervisor"],
    "P5":  ["l3_supervisor", "l2_supervisor"],
    "P6":  ["l2_supervisor"],                                       # L2-only per spec
    "P7":  ["l4_supervisor", "l3_supervisor", "l2_supervisor"],
    "P8":  ["chat_agent"],
    "P9":  ["l1_risk_agent", "l2_supervisor"],
    "P10": ["l2_supervisor", "l3_supervisor", "l4_supervisor"],     # All three simultaneously; L1 synchronises
}

# Use cases that may trigger human approval interrupt
APPROVAL_USE_CASES = {"P1", "P5", "P7", "P10"}


# ── L1 Supervisor Node ────────────────────────────────────────────────────────

async def l1_supervisor_node(state: AgentState) -> Command:
    """
    L1 Root Supervisor node — the central intelligence layer.

    Decision flow:
      1. If policy == approval_required and approval not resolved → interrupt for human input.
      2. If is_remediated and no audit yet → route to l1_audit_agent.
      3. If audit done → END.
      4. Otherwise → use domain plan to pick the next unvisited supervisor.
    """
    use_case_id = state.get("use_case_id", "P2")
    issue_id = state.get("issue_id", "")
    policy = state.get("policy_decision")
    approval_status = state.get("approval_status")
    audit_trace_id = state.get("audit_trace_id")
    is_remediated = state.get("is_remediated", False)

    logger.info(
        "[L1 Supervisor] use_case=%s issue=%s policy=%s approval=%s remediated=%s",
        use_case_id, issue_id, policy, approval_status, is_remediated,
    )

    # ── Step 1: Human approval interrupt ──────────────────────────────────────
    if policy == "approval_required" and approval_status not in ("approved", "rejected"):
        logger.info("[L1 Supervisor] pausing for human approval, approval_id=%s", state.get("approval_id"))
        human_input = interrupt({
            "prompt": "Human approval required before executing high-risk billing action.",
            "approval_id": state.get("approval_id"),
            "action": f"Remediation action for use case {use_case_id}",
            "risk_reason": (state.get("evidence_summary") or "")[-300:],
        })
        decision = "rejected"
        if isinstance(human_input, dict):
            decision = human_input.get("decision", "rejected")
        return Command(
            goto="l1_supervisor",
            update={"approval_status": decision},
        )

    # ── Step 2: Write audit and close ─────────────────────────────────────────
    if is_remediated and not audit_trace_id:
        return Command(goto="l1_audit_agent")

    if audit_trace_id:
        return Command(goto="__end__")

    # ── Step 3: Determine next domain supervisor from plan ────────────────────
    plan = USE_CASE_DOMAIN_PLAN.get(use_case_id, ["l2_supervisor"])
    messages = state.get("messages", [])
    visited = _visited_supervisors(messages, state.get("visited_supervisors") or set())

    next_supervisor = _next_in_plan(plan, visited)

    if next_supervisor is None:
        # All planned supervisors visited — mark remediated → route to audit
        return Command(
            goto="l1_supervisor",
            update={
                "is_remediated": True,
                "messages": [AIMessage(content=f"L1 Supervisor: All domain outcomes synchronised for {use_case_id}.")],
            },
        )

    # ── Step 4: Check if policy evaluation needed before financial action ─────
    if (
        next_supervisor == "l2_supervisor"
        and use_case_id in APPROVAL_USE_CASES
        and policy is None
    ):
        return Command(
            goto="l1_policy_agent",
            update={"messages": [AIMessage(content="L1 Supervisor: Evaluating policy before L2 financial action.")]},
        )

    logger.info("[L1 Supervisor] routing → %s", next_supervisor)
    visited = state.get("visited_supervisors") or set()
    visited = set(visited) | {next_supervisor}
    return Command(
        goto=next_supervisor,
        update={
            "next_agent": next_supervisor,
            "visited_supervisors": visited,
            "messages": [AIMessage(content=f"L1 Supervisor delegating to {next_supervisor} for {use_case_id}.")],
        },
    )


# ── L1 Policy Agent Node ──────────────────────────────────────────────────────

async def l1_policy_agent_node(state: AgentState) -> Command[Literal["l1_supervisor"]]:
    """
    Evaluate policy for the current use case and mark approval requirements.
    Uses l1_tools.decide_action_policy().
    """
    from app.agents.tools.l1_tools import decide_action_policy
    from app.config import get_settings

    settings = get_settings()
    use_case_id = state.get("use_case_id", "")
    amount = _estimate_amount(use_case_id)

    decision = decide_action_policy(
        action=f"remediate_{use_case_id.lower()}",
        amount=amount,
        threshold=settings.human_approval_credit_threshold,
        bulk_customer_impact=(use_case_id == "P10"),
        auto_remediation_enabled=settings.auto_remediation_enabled,
    )

    updates: Dict[str, Any] = {
        "policy_decision": decision["policy_decision"],
        "requires_human_approval": decision["requires_human_approval"],
    }

    if decision["requires_human_approval"]:
        try:
            from app.agents.approval_manager import create_approval
            from app.db.database import AsyncSessionFactory
            async with AsyncSessionFactory() as db:
                appr = await create_approval(
                    db,
                    thread_id=state.get("thread_id", ""),
                    issue_id=state.get("issue_id", ""),
                    control_case_id=state.get("control_case_id", ""),
                    action=f"remediate_{use_case_id.lower()}",
                    risk_reason=decision.get("risk_reason", "Policy threshold exceeded."),
                    amount=amount,
                )
            updates["approval_id"] = appr["approval_id"]
            updates["approval_status"] = "pending"
        except Exception as exc:
            logger.warning("[L1 Policy Agent] approval record creation failed: %s", exc)

    return Command(goto="l1_supervisor", update=updates)


# ── L1 Audit Agent Node ───────────────────────────────────────────────────────

async def l1_audit_agent_node(state: AgentState) -> Command[Literal["l1_supervisor"]]:
    """Write governance audit trace and mark control case resolved."""
    import datetime
    from sqlalchemy import select
    from app.agents.tools.l1_tools import write_governance_audit
    from app.models.models import Issue, ControlCase
    from app.db.database import AsyncSessionFactory

    async with AsyncSessionFactory() as db:
        issue_result = await db.execute(select(Issue).where(Issue.id == state.get("issue_id", "")))
        issue = issue_result.scalar_one_or_none()
        if issue:
            issue.status = "remediated"
            issue.updated_at = datetime.datetime.utcnow()

        cc_result = await db.execute(select(ControlCase).where(ControlCase.id == state.get("control_case_id", "")))
        cc = cc_result.scalar_one_or_none()
        if cc:
            cc.status = "resolved"
            cc.resolved_at = datetime.datetime.utcnow()

        trace_id = await write_governance_audit(
            db,
            control_case_id=state.get("control_case_id", ""),
            action_type="agentic_remediation",
            actor="l1_supervisor",
            summary=(
                f"Agentic remediation complete for {state.get('use_case_id')} "
                f"issue {state.get('issue_id')}. "
                f"{(state.get('evidence_summary') or '')[-200:]}"
            ),
            issue_id=state.get("issue_id"),
            use_case_id=state.get("use_case_id"),
            evidence_pack_ids=state.get("evidence_pack_ids", []),
            approval_id=state.get("approval_id"),
            decision=state.get("policy_decision"),
            actions_taken=state.get("planned_action_ids", []),
            commit=True,
        )

    return Command(
        goto="l1_supervisor",
        update={
            "audit_trace_id": trace_id,
            "final_response_summary": (
                f"\u2705 {state.get('use_case_id')} remediation complete. "
                f"Audit: {trace_id}. "
                f"{(state.get('evidence_summary') or '')[-200:]}"
            ),
        },
    )


# ── L1 Risk Agent Node ────────────────────────────────────────────────────────

async def l1_risk_agent_node(state: AgentState) -> Command[Literal["l1_supervisor"]]:
    """Proactive billing risk assessment (used by P9)."""
    from app.agents.tools.l1_tools import assess_billing_risk
    from app.db.database import AsyncSessionFactory

    async with AsyncSessionFactory() as db:
        risk = await assess_billing_risk(db, state.get("billing_account_id", ""))

    return Command(
        goto="l1_supervisor",
        update={
            "evidence_summary": ((state.get("evidence_summary") or "") + "\n" + risk["evidence_summary"]),
            "kg_context": f"risk_level={risk['risk_level']} score={risk['risk_score']}",
            "messages": [AIMessage(content=f"L1 Risk Agent: {risk['evidence_summary']}")],
        },
    )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _visited_supervisors(messages: list, state_visited: set) -> set:
    """
    Combine visited set from state with any supervisors mentioned in messages.
    State-based tracking is primary; message-based is fallback for chat_agent.
    """
    visited = set(state_visited or [])
    # Fallback: detect chat_agent and risk_agent from message content
    for msg in messages:
        content = getattr(msg, "content", "") or ""
        for supervisor in ("l1_risk_agent", "chat_agent"):
            if supervisor in content:
                visited.add(supervisor)
    return visited


def _next_in_plan(plan: list, visited: set):
    for step in plan:
        if step not in visited:
            return step
    return None


def _estimate_amount(use_case_id: str) -> float:
    defaults = {
        "P1": 38.50, "P2": 12.50, "P3": 12.00, "P4": 29.99,
        "P5": 75.00, "P6": 12.50, "P7": 89.99, "P10": 320.00,
    }
    return defaults.get(use_case_id, 50.0)
