"""
L2 BSS domain tools — self-contained, no imports from services/ or components/.

All BSS logic (bill retrieval, adjustments, holds, tickets, compensation,
surcharge removal, bill protection) lives directly in this file.
Tools own their own DB sessions and return compact JSON strings.
"""
import datetime
import json
import logging
import uuid
from typing import Optional

from langchain_core.tools import tool
from sqlalchemy import select

logger = logging.getLogger(__name__)

# ── Mock entitlement catalog (inlined from l2_product_entitlement) ─────────────
_ENTITLEMENT_CATALOG = {
    "BA-100001": {
        "plan_name": "Premium 5G Unlimited", "plan_tier": "premium",
        "promised_throughput_mbps": 100, "qos_profile": "eMBB_100Mbps",
        "slice_id": "SLICE-PREMIUM-001", "nssai": "01-000001",
        "monthly_surcharge_usd": 25.00, "sla_uptime_pct": 99.9,
        "sla_max_outage_minutes": 60,
    },
    "BA-100002": {
        "plan_name": "Standard 4G", "plan_tier": "standard",
        "promised_throughput_mbps": 20, "qos_profile": "eMBB_20Mbps",
        "slice_id": None, "nssai": None,
        "monthly_surcharge_usd": 0.0, "sla_uptime_pct": 99.5,
        "sla_max_outage_minutes": 120,
    },
    "BA-100003": {
        "plan_name": "Basic Voice & Data", "plan_tier": "basic",
        "promised_throughput_mbps": 5, "qos_profile": "best_effort",
        "slice_id": None, "nssai": None,
        "monthly_surcharge_usd": 0.0, "sla_uptime_pct": 98.0,
        "sla_max_outage_minutes": 240,
    },
}

_DEFAULT_ENTITLEMENT = {
    "plan_name": "Unknown Plan", "plan_tier": "unknown",
    "promised_throughput_mbps": 0, "qos_profile": "unknown",
    "slice_id": None, "nssai": None,
    "monthly_surcharge_usd": 0.0, "sla_uptime_pct": 0.0,
    "sla_max_outage_minutes": 60,
}


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()


def _get_entitlement(billing_account_id: str) -> dict:
    return _ENTITLEMENT_CATALOG.get(billing_account_id, _DEFAULT_ENTITLEMENT)


# ── Tools ──────────────────────────────────────────────────────────────────────

@tool
async def get_current_bill_tool(billing_account_id: str, bill_id: Optional[str] = None) -> str:
    """
    Retrieve the current or a specific bill for a billing account.

    Args:
        billing_account_id: Billing account ID (e.g. BA-100001).
        bill_id: Specific bill ID. If omitted, returns the latest bill.

    Returns:
        JSON with bill_id, billing_period, amount_due, line_items_count, disputed_items_count, summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import Bill

    async with AsyncSessionFactory() as db:
        if bill_id:
            result = await db.execute(select(Bill).where(Bill.id == bill_id))
            bill = result.scalar_one_or_none()
        else:
            result = await db.execute(
                select(Bill)
                .where(Bill.billing_account_id == billing_account_id)
                .order_by(Bill.billing_period.desc())
                .limit(1)
            )
            bill = result.scalar_one_or_none()

    if not bill:
        return json.dumps({"error": f"No bill found for account {billing_account_id}"})

    line_items = bill.payload.get("line_items", []) if bill.payload else []
    disputed = [li for li in line_items if li.get("dispute_flag")]
    return json.dumps({
        "bill_id": bill.id,
        "billing_period": bill.billing_period,
        "amount_due": bill.amount_due,
        "previous_amount": bill.previous_amount,
        "status": bill.status,
        "line_items_count": len(line_items),
        "disputed_items_count": len(disputed),
        "summary": (
            f"Bill {bill.id}: ${bill.amount_due or 0:.2f} due "
            f"({len(disputed)} disputed items)."
        ),
    })


@tool
async def get_previous_bills_tool(billing_account_id: str, months: int = 3) -> str:
    """
    Retrieve previous bills for a billing account for comparison purposes.

    Args:
        billing_account_id: Billing account ID.
        months: Number of previous months to retrieve (default 3).

    Returns:
        JSON with list of previous bills (bill_id, billing_period, amount_due, status).
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import Bill

    async with AsyncSessionFactory() as db:
        result = await db.execute(
            select(Bill)
            .where(Bill.billing_account_id == billing_account_id)
            .order_by(Bill.billing_period.desc())
            .limit(months + 1)
            .offset(1)
        )
        bills = result.scalars().all()

    return json.dumps({
        "bills": [
            {"bill_id": b.id, "billing_period": b.billing_period, "amount_due": b.amount_due, "status": b.status}
            for b in bills
        ],
        "summary": f"Found {len(bills)} previous bill(s) for {billing_account_id}.",
    })


@tool
async def get_customer_context_tool(customer_id: str, billing_account_id: str) -> str:
    """
    Retrieve lightweight customer and billing account context.

    Args:
        customer_id: Customer ID (e.g. CUST-001).
        billing_account_id: Billing account ID (e.g. BA-100001).

    Returns:
        JSON with customer_name, segment, account_status, currency, summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import Customer, BillingAccount

    async with AsyncSessionFactory() as db:
        r1 = await db.execute(select(Customer).where(Customer.id == customer_id))
        customer = r1.scalar_one_or_none()
        r2 = await db.execute(select(BillingAccount).where(BillingAccount.id == billing_account_id))
        ba = r2.scalar_one_or_none()

    name = customer.name if customer else "Unknown"
    segment = customer.segment if customer else "Unknown"
    status = ba.status if ba else "Unknown"
    currency = ba.currency if ba else "USD"
    return json.dumps({
        "customer_id": customer_id,
        "customer_name": name,
        "segment": segment,
        "account_status": status,
        "currency": currency,
        "summary": f"Customer: {name} ({segment}) | Account: {status} | Currency: {currency}",
    })


@tool
async def apply_billing_adjustment(
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    adjustment_type: str,
    amount: float,
    reason_code: str,
) -> str:
    """
    Apply a billing adjustment (credit, rebill, or waiver). Writes an EvidencePack to PostgreSQL.

    Args:
        control_case_id: Control case this adjustment belongs to.
        issue_id: Issue ID the adjustment is tied to.
        billing_account_id: Billing account to apply the adjustment to.
        adjustment_type: One of: credit | rebill | waiver.
        amount: Adjustment amount in account currency.
        reason_code: Short machine-readable reason (e.g. duplicate_charge).

    Returns:
        JSON with evidence_pack_id, summary, status.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack

    evp_id = f"EVP-L2-{issue_id}-{_short_id()}"
    summary = f"L2 applied {adjustment_type} of ${amount:.2f} — reason: {reason_code}"

    async with AsyncSessionFactory() as db:
        evp = EvidencePack(
            id=evp_id, control_case_id=control_case_id, source_layer="L2",
            summary=summary,
            payload={
                "adjustment_type": adjustment_type, "amount": amount,
                "reason_code": reason_code, "billing_account_id": billing_account_id,
                "applied_at": datetime.datetime.utcnow().isoformat(),
            },
        )
        db.add(evp)
        await db.commit()

    return json.dumps({"evidence_pack_id": evp_id, "summary": summary, "status": "applied"})


@tool
async def place_collections_hold_tool(
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    amount: float,
) -> str:
    """
    Place a simple collections hold on a disputed billing balance (quick hold, no debt split).

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        billing_account_id: Billing account to place the hold on.
        amount: Amount to hold (disputed portion).

    Returns:
        JSON with evidence_pack_id, summary, status.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack

    evp_id = f"EVP-L2-HOLD-{issue_id}-{_short_id()}"
    summary = f"L2 collections hold placed on ${amount:.2f} for account {billing_account_id}"

    async with AsyncSessionFactory() as db:
        evp = EvidencePack(
            id=evp_id, control_case_id=control_case_id, source_layer="L2",
            summary=summary,
            payload={
                "action": "collections_hold", "disputed_amount": amount,
                "billing_account_id": billing_account_id,
                "applied_at": datetime.datetime.utcnow().isoformat(),
            },
        )
        db.add(evp)
        await db.commit()

    return json.dumps({"evidence_pack_id": evp_id, "summary": summary, "status": "hold_placed"})


@tool
async def apply_compensation_credit(
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    amount: float,
    reason: str,
    approval_id: Optional[str] = None,
) -> str:
    """
    Apply a compensation credit (e.g. for SLA breach or outage). Creates a CompensationDecision and EvidencePack.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        billing_account_id: Billing account ID.
        amount: Compensation amount in USD.
        reason: Human-readable reason for the compensation.
        approval_id: Approval record ID if human approved (optional).

    Returns:
        JSON with comp_id, evidence_pack_id, summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack, CompensationDecision

    comp_id = f"COMP-{issue_id}-{_short_id()}"
    evp_id = f"EVP-COMP-L2-{_short_id()}"
    summary = f"L2: Compensation credit ${amount:.2f} applied. Ref {comp_id}. Reason: {reason}."

    async with AsyncSessionFactory() as db:
        comp = CompensationDecision(
            id=comp_id, issue_id=issue_id, control_case_id=control_case_id,
            billing_account_id=billing_account_id, compensation_type="credit",
            amount=amount, reason=reason, status="applied",
            approval_id=approval_id, applied_at=datetime.datetime.utcnow(),
        )
        evp = EvidencePack(
            id=evp_id, control_case_id=control_case_id, source_layer="L2",
            summary=summary, payload={"comp_id": comp_id, "amount": amount, "reason": reason},
        )
        db.add(comp)
        db.add(evp)
        await db.commit()

    return json.dumps({"comp_id": comp_id, "evidence_pack_id": evp_id, "summary": summary})


@tool
async def open_trouble_ticket_tool(
    control_case_id: str,
    issue_id: str,
    customer_id: str,
    billing_account_id: str,
    ticket_type: str,
    priority: str,
    description: str,
) -> str:
    """
    Open a trouble ticket for a billing issue, complaint, or governed dispute.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        customer_id: Customer ID.
        billing_account_id: Billing account ID.
        ticket_type: billing_dispute | service_complaint | qos_complaint | governed_multi_domain_dispute.
        priority: low | medium | high | critical.
        description: Ticket description text.

    Returns:
        JSON with ticket_id and summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import TroubleTicket

    tt_id = f"TT-{issue_id}-{str(uuid.uuid4())[:6].upper()}"

    async with AsyncSessionFactory() as db:
        tt = TroubleTicket(
            id=tt_id, issue_id=issue_id, control_case_id=control_case_id,
            customer_id=customer_id, billing_account_id=billing_account_id,
            ticket_type=ticket_type, status="open", priority=priority,
            description=description, payload={},
        )
        db.add(tt)
        await db.commit()

    summary = f"L2: Trouble ticket {tt_id} opened — {ticket_type} ({priority})."
    logger.info("L2: opened ticket %s for issue %s", tt_id, issue_id)
    return json.dumps({"ticket_id": tt_id, "status": "open", "ticket_type": ticket_type,
                        "priority": priority, "summary": summary})


@tool
async def apply_collections_hold_tool(
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    disputed_amount: float,
    undisputed_amount: float,
    hold_reason: str,
) -> str:
    """
    Apply a collections hold separating disputed from undisputed balance.
    Dunning continues only on the undisputed portion.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        billing_account_id: Billing account ID.
        disputed_amount: Amount under dispute — placed on hold.
        undisputed_amount: Amount not disputed — remains collectible.
        hold_reason: Short reason for the hold (e.g. invoice_dispute).

    Returns:
        JSON with hold_id and summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import CollectionsHold

    hold_id = f"HOLD-{issue_id}-{str(uuid.uuid4())[:6].upper()}"

    async with AsyncSessionFactory() as db:
        hold = CollectionsHold(
            id=hold_id, issue_id=issue_id, control_case_id=control_case_id,
            billing_account_id=billing_account_id,
            disputed_amount=disputed_amount, undisputed_amount=undisputed_amount,
            hold_reason=hold_reason, status="active", dunning_paused=True,
        )
        db.add(hold)
        await db.commit()

    summary = (
        f"L2: Collections hold {hold_id} applied. "
        f"Disputed ${disputed_amount:.2f} on hold; "
        f"undisputed ${undisputed_amount:.2f} remains collectible."
    )
    logger.info("L2: collections hold %s applied for %s", hold_id, billing_account_id)
    return json.dumps({"hold_id": hold_id, "disputed_amount": disputed_amount,
                        "undisputed_amount": undisputed_amount, "dunning_paused": True,
                        "status": "active", "summary": summary})


@tool
async def apply_surcharge_removal_tool(
    billing_account_id: str,
    surcharge_amount: float,
    reason: str,
) -> str:
    """
    Remove a premium surcharge from a billing account (e.g. QoS/NSSAI mismatch confirmed).

    Args:
        billing_account_id: Billing account ID.
        surcharge_amount: Amount of surcharge to remove (USD).
        reason: Reason for removal.

    Returns:
        JSON with adjustment_id and summary.
    """
    adjustment_id = f"ADJ-QOS-{billing_account_id}-SURCHARGE-{_short_id()}"
    summary = f"L2: Premium surcharge ${surcharge_amount:.2f} removed from {billing_account_id}. Reason: {reason}."
    logger.info("L2: surcharge removal %s — $%.2f", adjustment_id, surcharge_amount)
    return json.dumps({
        "adjustment_id": adjustment_id,
        "billing_account_id": billing_account_id,
        "adjustment_type": "surcharge_removal",
        "amount_removed": surcharge_amount,
        "reason": reason,
        "status": "applied",
        "summary": summary,
    })


@tool
async def apply_bill_protection_hold_tool(
    billing_account_id: str,
    billing_period: str,
    estimated_impact_usd: float,
) -> str:
    """
    Apply a bill protection hold to prevent billing before delayed usage is replayed.

    Args:
        billing_account_id: Billing account ID.
        billing_period: Billing period being protected (e.g. 2026-04).
        estimated_impact_usd: Estimated financial exposure pending replay.

    Returns:
        JSON with hold_reference and summary.
    """
    hold_ref = f"BILL-PROTECT-{billing_account_id}-{billing_period}"
    summary = (
        f"Bill protection hold {hold_ref} applied for {billing_period}. "
        f"Up to ${estimated_impact_usd:.2f} protected pending mediation replay."
    )
    logger.info("L2: bill protection hold %s applied for %s %s", hold_ref, billing_account_id, billing_period)
    return json.dumps({
        "hold_reference": hold_ref,
        "billing_account_id": billing_account_id,
        "billing_period": billing_period,
        "protected_amount_usd": estimated_impact_usd,
        "status": "active",
        "protection_type": "pre_bill_usage_replay_pending",
        "summary": summary,
    })
