"""
Shared tools available to all agent layers (L1, L2, L3, L4).

These tools are cross-layer concerns:
  - Vector DB playbook retrieval
  - Knowledge Graph queries
  - Governance audit writing   (logic in l1_tools.write_governance_audit)
  - Billing risk assessment    (logic in l1_tools.assess_billing_risk)
"""
import json
import logging
from typing import Optional

from langchain_core.tools import tool

logger = logging.getLogger(__name__)


@tool
async def retrieve_playbook(query: str, n_results: int = 2) -> str:
    """
    Search the ChromaDB vector store for relevant remediation playbooks.

    Args:
        query: Natural language query describing the billing issue.
        n_results: Number of playbook chunks to retrieve (default 2).

    Returns:
        JSON string with matching playbook documents and metadata.
    """
    try:
        from app.vector_db.vector_store import similarity_search
        results = await similarity_search(query, n_results=n_results)
        if results:
            return json.dumps({"playbooks": [r["document"] for r in results]})
        return json.dumps({"playbooks": ["Standard remediation: gather evidence from L2/L3/L4, apply credit if confirmed."]})
    except Exception as exc:
        logger.warning("retrieve_playbook failed: %s", exc)
        return json.dumps({"playbooks": ["No playbook found — apply standard remediation protocol."]})


@tool
async def query_knowledge_graph(issue_id: str) -> str:
    """
    Query the NetworkX Knowledge Graph for entities and relationships
    reachable from the given issue_id.

    Args:
        issue_id: The issue ID to query KG relationships for.

    Returns:
        JSON string with nodes, edges, and relationship counts.
    """
    try:
        from app.kg.kg_queries import get_issue_relationships
        from app.db.database import AsyncSessionFactory
        async with AsyncSessionFactory() as db:
            result = await get_issue_relationships(db, issue_id)
        return json.dumps({
            "issue_id": result["issue_id"],
            "total_nodes": result.get("total_nodes", 0),
            "total_edges": result.get("total_edges", 0),
            "summary": f"KG: {result.get('total_nodes', 0)} nodes, {result.get('total_edges', 0)} edges reachable.",
        })
    except Exception as exc:
        logger.warning("query_knowledge_graph failed: %s", exc)
        return json.dumps({"summary": "KG: query failed — proceeding with direct evidence.", "error": str(exc)})


@tool
async def write_audit_trace(
    control_case_id: str,
    action_type: str,
    actor: str,
    summary: str,
    issue_id: Optional[str] = None,
    use_case_id: Optional[str] = None,
    evidence_pack_ids: Optional[str] = None,
    approval_id: Optional[str] = None,
    policy_decision: Optional[str] = None,
    actions_taken: Optional[str] = None,
) -> str:
    """
    Write a governance audit trace for a completed remediation action.

    Args:
        control_case_id: The control case this trace belongs to.
        action_type: Type of action (e.g. agentic_remediation, event_correlation).
        actor: The agent or component that performed the action.
        summary: Human-readable summary of what was done.
        issue_id: Associated issue ID (optional).
        use_case_id: Use case label P1-P10 (optional).
        evidence_pack_ids: JSON-encoded list of evidence pack IDs (optional).
        approval_id: Approval record ID if human approval was involved (optional).
        policy_decision: The policy decision taken (optional).
        actions_taken: JSON-encoded list of action IDs taken (optional).

    Returns:
        JSON string with the created audit_trace_id.
    """
    from app.agents.tools.l1_tools import write_governance_audit
    from app.db.database import AsyncSessionFactory

    evp_ids = json.loads(evidence_pack_ids) if evidence_pack_ids else []
    act_taken = json.loads(actions_taken) if actions_taken else []

    async with AsyncSessionFactory() as db:
        trace_id = await write_governance_audit(
            db,
            control_case_id=control_case_id,
            action_type=action_type,
            actor=actor,
            summary=summary,
            issue_id=issue_id,
            use_case_id=use_case_id,
            evidence_pack_ids=evp_ids,
            approval_id=approval_id,
            decision=policy_decision,
            actions_taken=act_taken,
        )
    return json.dumps({"audit_trace_id": trace_id})


@tool
async def assess_billing_risk_tool(billing_account_id: str) -> str:
    """
    Run a proactive billing risk assessment for a billing account.
    Returns risk level, score (0-100), and detected risk signals.

    Args:
        billing_account_id: The billing account to assess.

    Returns:
        JSON string with risk_level, risk_score, signal_count, signals list, and summary.
    """
    from app.agents.tools.l1_tools import assess_billing_risk
    from app.db.database import AsyncSessionFactory

    async with AsyncSessionFactory() as db:
        result = await assess_billing_risk(db, billing_account_id)

    return json.dumps({
        "billing_account_id": result["billing_account_id"],
        "risk_level": result["risk_level"],
        "risk_score": result["risk_score"],
        "signal_count": result["signal_count"],
        "evidence_summary": result["evidence_summary"],
        "signals": [
            {"type": s["type"], "severity": s["severity"], "description": s["description"]}
            for s in result.get("signals", [])
        ],
    })
