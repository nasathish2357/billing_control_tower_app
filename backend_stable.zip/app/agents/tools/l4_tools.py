"""
L4 Network domain tools — self-contained, no imports from services/ or components/.

All network-layer logic (PDU session evidence, zombie session cleanup, rating trigger
evidence, SEPP CDR export, CHF roaming records) lives directly in this file.
Tools own their DB sessions and return compact JSON strings.
"""
import datetime
import json
import logging
import uuid
from typing import Optional

from langchain_core.tools import tool
from sqlalchemy import select

logger = logging.getLogger(__name__)


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()


# ── Tools ──────────────────────────────────────────────────────────────────────

@tool
async def get_session_evidence_tool(
    control_case_id: str,
    issue_id: str,
    session_id: str,
    billing_account_id: str,
) -> str:
    """
    Retrieve PDU session evidence for a zombie or anomalous session.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        session_id: PDU session ID (e.g. PDU-4491).
        billing_account_id: Billing account ID.

    Returns:
        JSON with evidence_pack_id, session_id, erroneous_charge_usd, and summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack

    evp_id = f"EVP-L4-SES-{issue_id}-{_short_id()}"
    summary = f"L4: Zombie session {session_id} confirmed — 6 hours of illegitimate charges after device disconnect."
    payload = {
        "session_id": session_id,
        "billing_account_id": billing_account_id,
        "session_start": "2026-04-15T08:00:00Z",
        "device_last_seen": "2026-04-15T10:00:00Z",
        "session_close_recorded_at": "2026-04-15T16:00:00Z",
        "zombie_hours": 6.0,
        "bytes_charged_during_zombie": 1_200_000_000,
        "estimated_erroneous_charge_usd": 12.00,
        "confirmed_zombie": True,
        "note": "Device disconnected at 10:00 UTC; session remained active in PCRF/UPF until 16:00 UTC.",
    }

    async with AsyncSessionFactory() as db:
        evp = EvidencePack(id=evp_id, control_case_id=control_case_id,
                            source_layer="L4", summary=summary, payload=payload)
        db.add(evp)
        await db.commit()

    logger.info("L4: session evidence stored %s", evp_id)
    return json.dumps({
        "evidence_pack_id": evp_id,
        "session_id": session_id,
        "erroneous_charge_usd": 12.00,
        "zombie_confirmed": True,
        "summary": summary,
    })


@tool
async def cleanup_zombie_session_tool(
    control_case_id: str,
    issue_id: str,
    session_id: str,
) -> str:
    """
    Terminate a zombie PDU session that is still accruing charges after disconnect.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        session_id: PDU session ID to terminate (e.g. PDU-4491).

    Returns:
        JSON with evidence_pack_id and summary confirming session termination.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack

    evp_id = f"EVP-L4-CLEAN-{issue_id}-{_short_id()}"
    summary = f"L4: Zombie session {session_id} terminated — PCRF and UPF updated, charging stopped."
    payload = {
        "action": "session_cleanup", "session_id": session_id,
        "executed_at": datetime.datetime.utcnow().isoformat(),
        "pcrf_updated": True, "upf_session_released": True, "charging_stopped": True,
    }

    async with AsyncSessionFactory() as db:
        evp = EvidencePack(id=evp_id, control_case_id=control_case_id,
                            source_layer="L4", summary=summary, payload=payload)
        db.add(evp)
        await db.commit()

    logger.info("L4: session cleanup executed %s", evp_id)
    return json.dumps({"evidence_pack_id": evp_id, "session_terminated": True, "summary": summary})


@tool
async def get_rating_evidence_tool(
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    bill_id: str,
) -> str:
    """
    Retrieve rating trigger evidence from the network charging function (CHF/CTF)
    for a duplicate charge investigation.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        billing_account_id: Billing account ID.
        bill_id: Bill ID to check rating records for.

    Returns:
        JSON with evidence_pack_id, duplicate_amount, and rating trigger summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack

    evp_id = f"EVP-L4-RATE-{issue_id}-{_short_id()}"
    summary = (
        "L4: Two rating triggers (RT-001, RT-002) fired for the same session "
        "SID-20260415-001 — $12.50 duplicate charge confirmed."
    )
    payload = {
        "billing_account_id": billing_account_id, "bill_id": bill_id,
        "rating_events": [
            {"trigger_id": "RT-001", "session_id": "SID-20260415-001",
             "amount": 12.50, "triggered_at": "2026-04-15T14:00:00Z"},
            {"trigger_id": "RT-002", "session_id": "SID-20260415-001",
             "amount": 12.50, "triggered_at": "2026-04-15T14:00:05Z", "duplicate": True},
        ],
        "duplicate_confirmed": True, "duplicate_amount": 12.50,
    }

    async with AsyncSessionFactory() as db:
        evp = EvidencePack(id=evp_id, control_case_id=control_case_id,
                            source_layer="L4", summary=summary, payload=payload)
        db.add(evp)
        await db.commit()

    return json.dumps({"evidence_pack_id": evp_id, "duplicate_amount": 12.50,
                        "duplicate_confirmed": True, "summary": summary})


@tool
async def get_sepp_cdr_evidence_tool(
    control_case_id: str,
    issue_id: str,
    partner_account_id: str,
    billing_period: str,
) -> str:
    """
    Retrieve SEPP N32 CDR export evidence confirming the CSP's roaming CDR records
    for a partner/wholesale charge discrepancy investigation.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        partner_account_id: Partner account ID (e.g. PARTNER-001).
        billing_period: Billing period (e.g. 2026-03).

    Returns:
        JSON with evidence_pack_id, csr_export_complete, partner_ingestion_gap_confirmed,
        sepp_log_ref, and evidence_summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack, PartnerSettlement, UsageEvent, NetworkFunction

    evp_id = f"EVP-L4-SEPP-{_short_id()}"

    async with AsyncSessionFactory() as db:
        # Pull settlement record
        r = await db.execute(
            select(PartnerSettlement)
            .where(PartnerSettlement.partner_account_id == partner_account_id,
                   PartnerSettlement.billing_period == billing_period)
            .limit(1)
        )
        settlement = r.scalar_one_or_none()
        csp_amount = settlement.csp_record_amount if settlement else 0.0
        partner_amount = settlement.partner_record_amount if settlement else 0.0
        discrepancy = settlement.discrepancy_amount if settlement else 0.0
        s_payload = (settlement.payload or {}) if settlement else {}
        csp_cdr_count = s_payload.get("csp_cdr_count", "unknown")
        partner_cdr_count = s_payload.get("partner_cdr_count", "unknown")
        sepp_log_ref = s_payload.get("sepp_evidence", f"SEPP-LOG-{billing_period}-{partner_account_id}")

        # SEPP NF status
        sepp_r = await db.execute(select(NetworkFunction).where(NetworkFunction.nf_type == "SEPP").limit(1))
        sepp_nf = sepp_r.scalar_one_or_none()
        sepp_name = sepp_nf.name if sepp_nf else "SEPP-ROAMING-01"
        sepp_status = sepp_nf.status if sepp_nf else "unknown"

        summary = (
            f"L4 SEPP Evidence: CSP exported {csp_cdr_count} CDRs (${csp_amount:.2f}) "
            f"to partner {partner_account_id} for {billing_period} via {sepp_name} "
            f"(status: {sepp_status}). Partner acknowledged {partner_cdr_count} CDRs (${partner_amount:.2f}). "
            f"Discrepancy: ${discrepancy:.2f}. SEPP log ref: {sepp_log_ref}."
        )

        evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L4",
                            summary=summary,
                            payload={"csp_amount": csp_amount, "partner_amount": partner_amount,
                                     "discrepancy": discrepancy, "sepp_log_ref": sepp_log_ref})
        db.add(evp)
        await db.commit()

    logger.info("L4: SEPP evidence for %s %s — discrepancy $%.2f", partner_account_id, billing_period, discrepancy)
    return json.dumps({
        "evidence_pack_id": evp_id,
        "csr_export_complete": True,
        "partner_ingestion_gap_confirmed": discrepancy > 0,
        "sepp_log_ref": sepp_log_ref,
        "discrepancy_usd": discrepancy,
        "evidence_summary": summary,
    })


@tool
async def get_chf_roaming_records_tool(
    control_case_id: str,
    billing_account_id: str,
    billing_period: str,
) -> str:
    """
    Retrieve CHF (Charging Function) roaming charging records for a billing account
    and period — used to validate partner settlement discrepancies.

    Args:
        control_case_id: Control case ID.
        billing_account_id: Billing account ID.
        billing_period: Billing period (e.g. 2026-03).

    Returns:
        JSON with evidence_pack_id and roaming charging record summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack, UsageEvent, MediationRecord, NetworkFunction

    evp_id = f"EVP-L4-CHF-{_short_id()}"

    async with AsyncSessionFactory() as db:
        r = await db.execute(
            select(UsageEvent).where(
                UsageEvent.billing_account_id == billing_account_id,
                UsageEvent.billing_period == billing_period,
                UsageEvent.event_type.in_(["roaming_data", "roaming_voice"]),
            )
        )
        roaming_events = r.scalars().all()

        mr_r = await db.execute(
            select(MediationRecord)
            .where(MediationRecord.billing_account_id == billing_account_id,
                   MediationRecord.billing_period == billing_period)
            .limit(10)
        )
        mediation_records = mr_r.scalars().all()

        chf_r = await db.execute(select(NetworkFunction).where(NetworkFunction.nf_type == "CHF").limit(1))
        chf_nf = chf_r.scalar_one_or_none()
        chf_name = chf_nf.name if chf_nf else "CHF-CHARGING-01"

        total_bytes = sum(ue.data_volume_bytes or 0 for ue in roaming_events)
        total_duration_s = sum(ue.duration_seconds or 0 for ue in roaming_events)
        cdr_ids = [(ue.payload or {}).get("cdr_id", ue.id) for ue in roaming_events]

        summary = (
            f"L4 CHF Evidence: {len(roaming_events)} roaming usage events for "
            f"{billing_account_id} in {billing_period} via {chf_name}. "
            f"Total roaming data: {total_bytes / 1_073_741_824:.2f} GB, "
            f"Duration: {total_duration_s // 3600}h. "
            f"CDR IDs: {cdr_ids[:3]}{'...' if len(cdr_ids) > 3 else ''}."
        )

        evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L4",
                            summary=summary,
                            payload={"roaming_event_count": len(roaming_events),
                                     "total_bytes": total_bytes, "chf_node": chf_name})
        db.add(evp)
        await db.commit()

    logger.info("L4: CHF records for %s %s — %d roaming events", billing_account_id, billing_period, len(roaming_events))
    return json.dumps({
        "evidence_pack_id": evp_id,
        "roaming_event_count": len(roaming_events),
        "total_volume_bytes": total_bytes,
        "total_duration_seconds": total_duration_s,
        "mediation_record_count": len(mediation_records),
        "evidence_summary": summary,
    })
