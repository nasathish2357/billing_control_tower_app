"""
L3 OSS domain tools — self-contained, no imports from services/ or components/.

All OSS logic (mediation evidence, mediation backlog, replay jobs, QoS evidence,
slice performance, SLA breach evaluation, service problem creation) lives
directly in this file. Tools own their DB sessions and return compact JSON strings.
"""
import datetime
import json
import logging
import uuid
from typing import Optional

from langchain_core.tools import tool
from sqlalchemy import select

logger = logging.getLogger(__name__)

# ── Mock data (inlined from l3_mediation_replay + l3_qos_slice) ───────────────
_MEDIATION_BACKLOG = {
    "BA-100001": {"delayed_events": 847, "delay_hours": 18, "pipeline_stage": "CDR_COLLECTION",
                   "estimated_impact_usd": 38.50, "billing_period": "2026-04"},
    "BA-100002": {"delayed_events": 0, "delay_hours": 0, "pipeline_stage": "RATED",
                   "estimated_impact_usd": 0.0, "billing_period": "2026-04"},
    "BA-100003": {"delayed_events": 23, "delay_hours": 4, "pipeline_stage": "MEDIATION_PROCESSING",
                   "estimated_impact_usd": 5.20, "billing_period": "2026-04"},
}

_QOS_METRICS = {
    "BA-100001": {"slice_id": "SLICE-PREMIUM-001", "active_nssai": "01-000002",
                   "avg_throughput_mbps": 15.0, "peak_throughput_mbps": 22.0,
                   "packet_loss_pct": 0.8, "latency_ms": 45, "measurement_period": "2026-04",
                   "qci": 9, "nwdaf_confidence": 0.94},
    "BA-100002": {"slice_id": None, "active_nssai": None,
                   "avg_throughput_mbps": 18.5, "peak_throughput_mbps": 20.0,
                   "packet_loss_pct": 0.2, "latency_ms": 30, "measurement_period": "2026-04",
                   "qci": 9, "nwdaf_confidence": 0.91},
    "BA-100003": {"slice_id": None, "active_nssai": None,
                   "avg_throughput_mbps": 4.2, "peak_throughput_mbps": 5.0,
                   "packet_loss_pct": 1.2, "latency_ms": 80, "measurement_period": "2026-04",
                   "qci": 9, "nwdaf_confidence": 0.88},
}

# SLA thresholds per billing account (inlined from l2_product_entitlement catalog)
_SLA_THRESHOLDS = {
    "BA-100001": {"plan_name": "Premium 5G Unlimited", "sla_max_outage_minutes": 60},
    "BA-100002": {"plan_name": "Standard 4G", "sla_max_outage_minutes": 120},
    "BA-100003": {"plan_name": "Basic Voice & Data", "sla_max_outage_minutes": 240},
}


def _short_id() -> str:
    return str(uuid.uuid4())[:8].upper()


# ── Tools ──────────────────────────────────────────────────────────────────────

@tool
async def get_mediation_evidence_tool(
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    bill_id: str,
) -> str:
    """
    Retrieve mediation evidence for a billing dispute from the OSS mediation engine.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        billing_account_id: Billing account ID.
        bill_id: Bill ID to check mediation records for.

    Returns:
        JSON with evidence_pack_id and summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import EvidencePack

    evp_id = f"EVP-L3-MED-{issue_id}-{_short_id()}"
    summary = "L3 mediation: duplicate CDR rating confirmed — two rating triggers for a single data session."
    payload = {
        "mediation_records": [{
            "event_id": "MED-EVENT-001", "session_id": "SID-20260415-001",
            "rated_at": "2026-04-15T14:00:00Z", "usage_bytes": 2_000_000_000,
            "rating_trigger_count": 2, "duplicate_detected": True,
            "note": "Rating engine emitted two triggers for single CDR due to retry loop.",
        }],
        "billing_account_id": billing_account_id, "bill_id": bill_id,
        "retrieved_at": datetime.datetime.utcnow().isoformat(),
    }

    async with AsyncSessionFactory() as db:
        evp = EvidencePack(id=evp_id, control_case_id=control_case_id,
                            source_layer="L3", summary=summary, payload=payload)
        db.add(evp)
        await db.commit()

    return json.dumps({"evidence_pack_id": evp_id, "summary": summary})


@tool
async def get_mediation_backlog_tool(billing_account_id: str) -> str:
    """
    Get the current mediation backlog for a billing account (delayed CDR events).

    Args:
        billing_account_id: Billing account ID.

    Returns:
        JSON with delayed_events, delay_hours, pipeline_stage, estimated_impact_usd, evidence_summary.
    """
    backlog = _MEDIATION_BACKLOG.get(billing_account_id, {
        "delayed_events": 0, "delay_hours": 0, "pipeline_stage": "UNKNOWN",
        "estimated_impact_usd": 0.0, "billing_period": "unknown",
    })
    summary = (
        f"{backlog['delayed_events']} usage events delayed "
        f"{backlog['delay_hours']}h in {backlog['pipeline_stage']}. "
        f"Estimated bill impact: ${backlog['estimated_impact_usd']:.2f}."
    )
    logger.info("L3: mediation backlog for %s: %d events delayed %.1fh",
                billing_account_id, backlog["delayed_events"], backlog["delay_hours"])
    return json.dumps({"billing_account_id": billing_account_id, **backlog, "evidence_summary": summary})


@tool
async def create_mediation_replay_tool(
    control_case_id: str,
    issue_id: str,
    billing_account_id: str,
    events_count: int,
) -> str:
    """
    Create a mediation replay job to reprocess delayed or missing CDR events.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID triggering the replay.
        billing_account_id: Billing account ID.
        events_count: Number of delayed events to replay.

    Returns:
        JSON with job_id, evidence_pack_id, events_replayed, evidence_summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import MediationJob, EvidencePack

    job_id = f"MJ-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    evp_id = f"EVP-L3-REPLAY-{_short_id()}"
    summary = f"Mediation replay job {job_id}: {events_count} events successfully replayed."

    async with AsyncSessionFactory() as db:
        job = MediationJob(
            id=job_id, issue_id=issue_id, control_case_id=control_case_id,
            billing_account_id=billing_account_id, job_type="backlog_replay",
            status="completed", events_count=events_count, events_replayed=events_count,
            completed_at=datetime.datetime.utcnow(),
            payload={"replay_trigger": "usage_delay_remediation",
                     "replay_completed_at": datetime.datetime.utcnow().isoformat()},
        )
        evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L3",
                            summary=summary, payload={"job_id": job_id, "events_replayed": events_count})
        db.add(job)
        db.add(evp)
        await db.commit()

    logger.info("L3: replay job %s created — %d events replayed", job_id, events_count)
    return json.dumps({"job_id": job_id, "evidence_pack_id": evp_id, "status": "completed",
                        "events_replayed": events_count, "evidence_summary": summary})


@tool
async def evaluate_sla_breach_tool(
    billing_account_id: str,
    outage_duration_hours: float,
    service_type: str,
) -> str:
    """
    Evaluate whether an outage constitutes an SLA breach and compute compensation.

    Args:
        billing_account_id: Billing account ID.
        outage_duration_hours: Duration of the outage in hours.
        service_type: Service type affected (voice | data | data_and_voice | premium_5g_slice).

    Returns:
        JSON with sla_breached, compensation_recommended, compensation_amount, evidence_summary.
    """
    sla = _SLA_THRESHOLDS.get(billing_account_id,
                               {"plan_name": "Unknown Plan", "sla_max_outage_minutes": 60})
    outage_minutes = outage_duration_hours * 60
    sla_breach = outage_minutes > sla["sla_max_outage_minutes"]
    overage_minutes = max(0.0, outage_minutes - sla["sla_max_outage_minutes"])
    compensation_amount = round((overage_minutes / 60) * 5.0, 2)

    summary = (
        f"{service_type.capitalize()} service outage {outage_duration_hours:.1f}h. "
        f"SLA threshold: {sla['sla_max_outage_minutes']}min. "
        f"Breach: {sla_breach}. Overage: {overage_minutes:.0f}min. "
        f"Recommended compensation: ${compensation_amount:.2f}."
    )
    logger.info("L3: SLA evaluation for %s: breach=%s compensation=$%.2f",
                billing_account_id, sla_breach, compensation_amount)
    return json.dumps({
        "billing_account_id": billing_account_id,
        "service_type": service_type,
        "plan_name": sla["plan_name"],
        "outage_duration_hours": outage_duration_hours,
        "sla_max_minutes": sla["sla_max_outage_minutes"],
        "sla_breach": sla_breach,
        "overage_minutes": round(overage_minutes, 1),
        "compensation_recommended": sla_breach,
        "compensation_amount": compensation_amount,
        "evidence_summary": summary,
    })


@tool
async def create_service_problem_tool(
    control_case_id: str,
    issue_id: str,
    customer_id: str,
    billing_account_id: str,
    problem_type: str,
    severity: str,
    description: str,
    affected_start_iso: str,
    affected_end_iso: str,
) -> str:
    """
    Create a ServiceProblem record for a confirmed service degradation or outage.

    Args:
        control_case_id: Control case ID.
        issue_id: Issue ID.
        customer_id: Customer ID.
        billing_account_id: Billing account ID.
        problem_type: service_degradation | multi_domain_outage.
        severity: low | medium | high | critical.
        description: Problem description.
        affected_start_iso: ISO datetime when service was first affected.
        affected_end_iso: ISO datetime when service was restored.

    Returns:
        JSON with service_problem_id, evidence_pack_id, and summary.
    """
    from app.db.database import AsyncSessionFactory
    from app.models.models import ServiceProblem, EvidencePack

    start = datetime.datetime.fromisoformat(affected_start_iso)
    end = datetime.datetime.fromisoformat(affected_end_iso)
    duration_min = (end - start).total_seconds() / 60
    sla_breach = duration_min > 60

    sp_id = f"SP-{issue_id}-{str(uuid.uuid4())[:6].upper()}"
    evp_id = f"EVP-L3-SP-{_short_id()}"
    evp_summary = f"L3: Service problem created — {problem_type} ({severity}). {description[:100]}"

    async with AsyncSessionFactory() as db:
        sp = ServiceProblem(
            id=sp_id, issue_id=issue_id, control_case_id=control_case_id,
            customer_id=customer_id, service_id=f"SVC-{billing_account_id}",
            problem_type=problem_type, severity=severity, status="open",
            sla_breach=sla_breach, affected_period_start=start, affected_period_end=end,
            description=description, payload={"description": description, "severity": severity},
        )
        evp = EvidencePack(id=evp_id, control_case_id=control_case_id, source_layer="L3",
                            summary=evp_summary,
                            payload={"problem_type": problem_type, "severity": severity})
        db.add(sp)
        db.add(evp)
        await db.commit()

    logger.info("L3: service problem %s created (sla_breach=%s)", sp_id, sla_breach)
    return json.dumps({"service_problem_id": sp_id, "evidence_pack_id": evp_id,
                        "sla_breach": sla_breach, "summary": evp_summary})


@tool
async def get_qos_evidence_tool(billing_account_id: str) -> str:
    """
    Retrieve QoS service quality evidence for a billing account.

    Args:
        billing_account_id: Billing account ID.

    Returns:
        JSON with avg_throughput_mbps, active_nssai, packet_loss_pct, and summary.
    """
    metrics = _QOS_METRICS.get(billing_account_id, {
        "slice_id": None, "active_nssai": None, "avg_throughput_mbps": 0.0,
        "peak_throughput_mbps": 0.0, "packet_loss_pct": 0.0, "latency_ms": 0,
        "measurement_period": "unknown", "qci": 9, "nwdaf_confidence": 0.0,
    })
    summary = (
        f"L3 QoS: avg {metrics['avg_throughput_mbps']} Mbps, "
        f"NSSAI {metrics['active_nssai']}, "
        f"packet loss {metrics['packet_loss_pct']}%."
    )
    logger.info("L3: QoS for %s avg_mbps=%.1f nssai=%s",
                billing_account_id, metrics["avg_throughput_mbps"], metrics.get("active_nssai"))
    return json.dumps({
        "billing_account_id": billing_account_id,
        "source": "NWDAF",
        **metrics,
        "summary": summary,
    })


@tool
async def get_slice_performance_tool(billing_account_id: str, slice_id: Optional[str] = None) -> str:
    """
    Retrieve 5G network slice performance evidence for a billing account.

    Args:
        billing_account_id: Billing account ID.
        slice_id: Slice ID if known; otherwise derived from account data.

    Returns:
        JSON with slice performance metrics and evidence_summary.
    """
    qos = _QOS_METRICS.get(billing_account_id, {
        "slice_id": None, "active_nssai": None, "avg_throughput_mbps": 0.0,
        "peak_throughput_mbps": 0.0, "packet_loss_pct": 0.0, "latency_ms": 0,
        "qci": 9, "nwdaf_confidence": 0.0, "measurement_period": "unknown",
    })
    effective_slice = slice_id or qos.get("slice_id")
    summary = (
        f"Slice {effective_slice}: avg {qos['avg_throughput_mbps']} Mbps, "
        f"NSSAI {qos['active_nssai']}, packet loss {qos['packet_loss_pct']}%, "
        f"latency {qos['latency_ms']}ms (NWDAF confidence {qos['nwdaf_confidence']:.0%})."
    )
    return json.dumps({
        "billing_account_id": billing_account_id,
        "slice_id": effective_slice,
        "active_nssai": qos["active_nssai"],
        "avg_throughput_mbps": qos["avg_throughput_mbps"],
        "peak_throughput_mbps": qos["peak_throughput_mbps"],
        "packet_loss_pct": qos["packet_loss_pct"],
        "latency_ms": qos["latency_ms"],
        "qci": qos["qci"],
        "nwdaf_confidence": qos["nwdaf_confidence"],
        "measurement_period": qos["measurement_period"],
        "evidence_summary": summary,
    })
