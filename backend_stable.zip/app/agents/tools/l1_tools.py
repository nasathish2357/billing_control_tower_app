"""
L1 tools — consolidated from the former components/ folder.

Contains ALL L1-layer business logic:
  - Audit governance   (write_governance_audit)
  - Proactive risk     (assess_billing_risk, get_high_risk_accounts)
  - Policy evaluation  (decide_action_policy)
  - Event monitoring   (correlate_event, get_new_events)
  - Simulation         (inject_simulation, …)

Some functions are @tool decorated (for agent use).
Plain async functions are exported for direct use by API endpoints
and L1 supervisor node functions.
"""
import datetime
import json
import logging
import uuid
from typing import Any, Dict, List, Optional

from langchain_core.tools import tool
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


# ── Audit Governance ──────────────────────────────────────────────────────────

async def write_governance_audit(
    db: AsyncSession,
    control_case_id: str,
    action_type: str,
    actor: str,
    summary: str,
    *,
    issue_id: Optional[str] = None,
    evidence_pack_ids: Optional[List[str]] = None,
    approval_id: Optional[str] = None,
    decision: Optional[str] = None,
    actions_taken: Optional[List[str]] = None,
    use_case_id: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
    commit: bool = True,
) -> str:
    """Write a rich governance audit trace. Returns the audit trace ID."""
    from app.models.models import AuditTrace

    trace_id = f"TRACE-{use_case_id or 'GOV'}-{str(uuid.uuid4())[:8].upper()}"

    details: Dict[str, Any] = {}
    if issue_id:
        details["issue_id"] = issue_id
    if evidence_pack_ids:
        details["evidence_pack_ids"] = evidence_pack_ids
    if approval_id:
        details["approval_id"] = approval_id
    if decision:
        details["policy_decision"] = decision
    if actions_taken:
        details["actions_taken"] = actions_taken
    if use_case_id:
        details["use_case_id"] = use_case_id
    if extra:
        details.update(extra)
    details["recorded_at"] = datetime.datetime.utcnow().isoformat()

    trace = AuditTrace(
        id=trace_id,
        control_case_id=control_case_id,
        action_type=action_type,
        actor=actor,
        summary=summary,
        details=details,
    )
    db.add(trace)
    if commit:
        await db.commit()

    logger.info("Audit [%s] cc=%s action=%s actor=%s", trace_id, control_case_id, action_type, actor)
    return trace_id


# ── Proactive Risk ────────────────────────────────────────────────────────────

_ANOMALY_USAGE_MULTIPLIER = 2.5


async def assess_billing_risk(
    db: AsyncSession,
    billing_account_id: str,
    billing_period: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Assess proactive billing risk for a billing account.
    Returns risk_level, risk_score (0-100), signals list, and evidence_summary.
    """
    from app.models.models import UsageEvent, MediationRecord, Bill, PDUSession

    signals: List[Dict[str, Any]] = []
    risk_points = 0

    pdu_result = await db.execute(
        select(PDUSession).where(PDUSession.billing_account_id == billing_account_id)
    )
    pdu_sessions = pdu_result.scalars().all()
    zombie_sessions = [s for s in pdu_sessions if s.status == "zombie"]
    if zombie_sessions:
        risk_points += 30 * len(zombie_sessions)
        signals.append({
            "type": "zombie_pdu_session", "severity": "HIGH",
            "count": len(zombie_sessions),
            "session_ids": [s.id for s in zombie_sessions],
            "description": f"{len(zombie_sessions)} zombie PDU session(s) detected — accruing charges after disconnect.",
        })

    usage_result = await db.execute(
        select(UsageEvent).where(UsageEvent.billing_account_id == billing_account_id)
    )
    usage_events = usage_result.scalars().all()

    anomaly_events = [u for u in usage_events
                      if (u.payload or {}).get("anomaly_flag")
                      or (u.payload or {}).get("charge_type") == "zombie_session"]
    if anomaly_events:
        risk_points += 20 * len(anomaly_events)
        signals.append({
            "type": "usage_anomaly", "severity": "HIGH",
            "count": len(anomaly_events),
            "event_ids": [u.id for u in anomaly_events],
            "description": f"{len(anomaly_events)} anomalous usage event(s) flagged.",
        })

    duplicate_events = [u for u in usage_events
                        if (u.payload or {}).get("charge_type") == "duplicate"]
    if duplicate_events:
        risk_points += 25 * len(duplicate_events)
        signals.append({
            "type": "duplicate_usage", "severity": "HIGH",
            "count": len(duplicate_events),
            "event_ids": [u.id for u in duplicate_events],
            "description": f"{len(duplicate_events)} duplicate usage event(s) — possible double-charge.",
        })

    med_result = await db.execute(
        select(MediationRecord).where(MediationRecord.billing_account_id == billing_account_id)
    )
    mediation_records = med_result.scalars().all()
    error_records = [r for r in mediation_records if r.status in ("error", "duplicate")]
    if error_records:
        risk_points += 15 * len(error_records)
        signals.append({
            "type": "mediation_error", "severity": "MEDIUM",
            "count": len(error_records),
            "record_ids": [r.id for r in error_records],
            "description": f"{len(error_records)} mediation record(s) in error/duplicate state.",
        })

    bill_result = await db.execute(
        select(Bill).where(Bill.billing_account_id == billing_account_id)
        .order_by(Bill.billing_period.desc())
        .limit(3)
    )
    recent_bills = bill_result.scalars().all()
    disputed_bills = [b for b in recent_bills if b.status == "Disputed"]
    if disputed_bills:
        risk_points += 10 * len(disputed_bills)
        signals.append({
            "type": "disputed_bill", "severity": "MEDIUM",
            "count": len(disputed_bills),
            "bill_ids": [b.id for b in disputed_bills],
            "description": f"{len(disputed_bills)} bill(s) in Disputed status in last 3 periods.",
        })

    risk_score = min(100, risk_points)
    if risk_score >= 70:
        risk_level = "CRITICAL"
    elif risk_score >= 40:
        risk_level = "HIGH"
    elif risk_score >= 15:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    signal_count = len(signals)
    summary = (
        f"Proactive risk assessment for {billing_account_id}: {risk_level} "
        f"(score {risk_score}/100). {signal_count} risk signal(s) detected. "
        f"{'Immediate review recommended.' if risk_level in ('HIGH', 'CRITICAL') else 'Monitor for changes.'}"
    )
    logger.info("L1 Risk: %s — level=%s score=%d signals=%d", billing_account_id, risk_level, risk_score, signal_count)
    return {
        "billing_account_id": billing_account_id,
        "risk_level": risk_level,
        "risk_score": risk_score,
        "signal_count": signal_count,
        "signals": signals,
        "evidence_summary": summary,
    }


async def get_high_risk_accounts(db: AsyncSession, threshold: int = 40) -> List[Dict[str, Any]]:
    """Scan all billing accounts and return those with risk scores above threshold."""
    from app.models.models import BillingAccount

    ba_result = await db.execute(select(BillingAccount))
    accounts = ba_result.scalars().all()

    high_risk = []
    for ba in accounts:
        assessment = await assess_billing_risk(db, ba.id)
        if assessment["risk_score"] >= threshold:
            high_risk.append({
                "billing_account_id": ba.id,
                "customer_id": ba.customer_id,
                "risk_level": assessment["risk_level"],
                "risk_score": assessment["risk_score"],
                "signal_count": assessment["signal_count"],
            })

    high_risk.sort(key=lambda x: x["risk_score"], reverse=True)
    return high_risk


# ── Policy Evaluation ─────────────────────────────────────────────────────────

def decide_action_policy(
    *,
    action: str,
    amount: Optional[float] = None,
    threshold: float = 50.0,
    confidence: Optional[float] = None,
    bulk_customer_impact: bool = False,
    network_remediation: bool = False,
    rollback_available: bool = True,
    auto_remediation_enabled: bool = True,
) -> Dict[str, Any]:
    """
    Evaluate closed-loop approval policy for a proposed action.
    Returns policy_decision: auto_remediation_allowed | approval_required.
    """
    reasons = []
    if not auto_remediation_enabled:
        reasons.append("auto remediation is disabled")
    if amount is not None and amount > threshold:
        reasons.append(f"amount ${amount:.2f} exceeds threshold ${threshold:.2f}")
    if bulk_customer_impact:
        reasons.append("bulk customer impact")
    if confidence is not None and confidence < 0.75:
        reasons.append(f"low confidence {confidence:.0%}")
    if network_remediation and not rollback_available:
        reasons.append("network remediation without rollback")

    requires_approval = bool(reasons)
    return {
        "action": action,
        "policy_decision": "approval_required" if requires_approval else "auto_remediation_allowed",
        "requires_human_approval": requires_approval,
        "risk_reason": "; ".join(reasons) if reasons else None,
    }


def auto_allow(action: str) -> Dict[str, Any]:
    """Return an explicit auto-allow decision for low-risk actions."""
    return {
        "action": action,
        "policy_decision": "auto_remediation_allowed",
        "requires_human_approval": False,
        "risk_reason": None,
    }


@tool
async def evaluate_remediation_policy_tool(
    action: str,
    amount: float = 0.0,
    bulk_customer_impact: bool = False,
) -> str:
    """
    Evaluate whether a proposed remediation action requires human approval.

    Args:
        action: Action identifier (e.g. remediate_p5).
        amount: Financial amount involved in USD.
        bulk_customer_impact: True if action affects multiple customers.

    Returns:
        JSON with policy_decision (auto_remediation_allowed | approval_required),
        requires_human_approval, and risk_reason.
    """
    from app.config import get_settings
    settings = get_settings()
    result = decide_action_policy(
        action=action,
        amount=amount,
        threshold=settings.human_approval_credit_threshold,
        bulk_customer_impact=bulk_customer_impact,
        auto_remediation_enabled=settings.auto_remediation_enabled,
    )
    return json.dumps(result)


# ── Event Monitoring ──────────────────────────────────────────────────────────

EVENT_TO_USE_CASE: Dict[str, str] = {
    "SuspectedUsageDelayEvent": "P1",
    "DuplicateChargingEvent": "P2",
    "ZombieSessionSuspectedEvent": "P3",
    "QoSMismatchEvent": "P4",
    "ServiceDegradationEvent": "P5",
    "CollectionsRiskEvent": "P6",
    "BillingRiskDetectedEvent": "P9",
    "MediationReplayCompletedEvent": "P1",
    "RemediationCompletedEvent": None,
}


async def correlate_event(db: AsyncSession, event_id: str) -> Dict[str, Any]:
    """
    Correlate a TMFEvent to an Issue and create/update a ControlCase.
    Returns a dict with correlation results.
    """
    from app.models.models import TMFEvent, ControlCase, Issue, AuditTrace

    result = await db.execute(select(TMFEvent).where(TMFEvent.id == event_id))
    event = result.scalar_one_or_none()
    if not event:
        return {"error": f"Event {event_id} not found"}

    if event.status == "correlated":
        return {"message": f"Event {event_id} already correlated", "event_id": event_id}

    use_case_id = event.use_case_id or EVENT_TO_USE_CASE.get(event.event_type)
    if not use_case_id:
        logger.warning("L1 Monitoring: no use_case_id mapping for event_type=%s", event.event_type)
        return {"warning": f"No use_case mapping for event_type={event.event_type}"}

    issue: Optional[Issue] = None
    if event.issue_id:
        issue_result = await db.execute(select(Issue).where(Issue.id == event.issue_id))
        issue = issue_result.scalar_one_or_none()

    if not issue:
        logger.warning("L1 Monitoring: no issue found for event %s", event_id)
        return {"warning": f"No issue linked to event {event_id}"}

    cc_id = f"CC-MON-{event_id}-{str(uuid.uuid4())[:6].upper()}"
    thread_id = f"THREAD-MON-{event_id}"
    cc = ControlCase(
        id=cc_id,
        issue_id=issue.id,
        status="investigating",
        thread_id=thread_id,
        requires_human_approval=False,
    )
    db.add(cc)

    event.status = "correlated"
    event.control_case_id = cc_id
    event.correlated_at = datetime.datetime.utcnow()

    trace_id = f"TRACE-MON-{event_id}-{str(uuid.uuid4())[:6].upper()}"
    trace = AuditTrace(
        id=trace_id,
        control_case_id=cc_id,
        action_type="event_correlation",
        actor="l1_monitoring",
        summary=f"L1 Monitoring correlated {event.event_type} to issue {issue.id} — ControlCase {cc_id} created.",
        details={
            "event_id": event_id,
            "event_type": event.event_type,
            "use_case_id": use_case_id,
            "issue_id": issue.id,
            "control_case_id": cc_id,
        },
    )
    db.add(trace)
    await db.commit()

    logger.info("L1 Monitoring: event=%s correlated → issue=%s cc=%s", event_id, issue.id, cc_id)
    return {
        "event_id": event_id,
        "event_type": event.event_type,
        "use_case_id": use_case_id,
        "issue_id": issue.id,
        "control_case_id": cc_id,
        "thread_id": thread_id,
        "audit_trace_id": trace_id,
    }


async def get_new_events(db: AsyncSession, limit: int = 20):
    """Fetch all unprocessed (new) events."""
    from app.models.models import TMFEvent
    result = await db.execute(
        select(TMFEvent)
        .where(TMFEvent.status == "new")
        .order_by(TMFEvent.created_at)
        .limit(limit)
    )
    return result.scalars().all()


@tool
async def correlate_event_tool(event_id: str) -> str:
    """
    Correlate a TMF billing event to an issue and create a control case.

    Args:
        event_id: The TMF event ID to correlate (e.g. EVT-P1-001).

    Returns:
        JSON with correlation result including control_case_id and use_case_id.
    """
    from app.db.database import AsyncSessionFactory
    async with AsyncSessionFactory() as db:
        result = await correlate_event(db, event_id)
    return json.dumps(result)


# ── Simulation ────────────────────────────────────────────────────────────────

SIMULATION_TYPES = [
    "duplicate_charge", "zombie_pdu_session", "usage_delay",
    "qos_mismatch", "sla_breach", "partner_discrepancy", "proactive_risk",
]

SIMULATION_USE_CASE_MAP = {
    "duplicate_charge": "P2",
    "zombie_pdu_session": "P3",
    "usage_delay": "P1",
    "qos_mismatch": "P4",
    "sla_breach": "P5",
    "partner_discrepancy": "P7",
    "proactive_risk": "P9",
}

_active_simulations: Dict[str, Dict[str, Any]] = {}


async def inject_simulation(
    db: AsyncSession,
    *,
    simulation_type: str,
    customer_id: str = "CUST-100001",
    billing_account_id: str = "BA-100001",
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    Inject a billing anomaly scenario. Creates supporting data records.
    If dry_run=True, returns what would be created without writing to DB.
    """
    from app.models.models import (
        SimulationRun, Issue, UsageEvent, PDUSession, MediationRecord,
    )

    if simulation_type not in SIMULATION_TYPES:
        return {"error": f"Unknown simulation type: {simulation_type}. Valid: {SIMULATION_TYPES}"}

    sim_id = f"SIM-{simulation_type.upper()[:8]}-{str(uuid.uuid4())[:6].upper()}"
    use_case_id = SIMULATION_USE_CASE_MAP[simulation_type]
    issue_id = f"SIM-ISSUE-{sim_id}"
    now = datetime.datetime.utcnow()
    artifacts = []

    if simulation_type == "duplicate_charge":
        ue_id = f"SIM-UE-DUP-{sim_id}"
        artifacts = [
            {"type": "UsageEvent", "id": ue_id, "description": "Duplicate 2GB data session injected"},
            {"type": "Issue", "id": issue_id, "use_case": "P2", "description": "Simulated duplicate charge"},
        ]
        if not dry_run:
            ue = UsageEvent(
                id=ue_id, customer_id=customer_id,
                billing_account_id=billing_account_id,
                session_id=f"SIM-SESSION-{sim_id}",
                event_type="data", data_volume_bytes=2_000_000_000,
                start_time=now - datetime.timedelta(hours=2),
                end_time=now - datetime.timedelta(hours=1),
                charging_trigger="CHF",
                billing_period=now.strftime("%Y-%m"),
                payload={"charge_type": "duplicate", "simulation_id": sim_id},
                created_at=now,
            )
            issue = Issue(
                id=issue_id, use_case_id="P2",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Duplicate charge of 2GB data session injected by {sim_id}.",
                status="open",
            )
            db.add(ue)
            db.add(issue)

    elif simulation_type == "zombie_pdu_session":
        pdu_id = f"SIM-PDU-ZOMBIE-{sim_id}"
        artifacts = [
            {"type": "PDUSession", "id": pdu_id, "description": "Zombie PDU session injected"},
            {"type": "Issue", "id": issue_id, "use_case": "P3", "description": "Simulated zombie PDU session"},
        ]
        if not dry_run:
            pdu = PDUSession(
                id=pdu_id, customer_id=customer_id,
                billing_account_id=billing_account_id,
                session_id=f"SIM-PDU-SESSION-{sim_id}",
                upf_node="UPF-EAST-SIM", smf_node="SMF-EAST-SIM",
                start_time=now - datetime.timedelta(hours=8),
                end_time=None,
                data_volume_gb=3.2, status="zombie",
                payload={"simulation_id": sim_id, "charge_type": "zombie_session"},
            )
            issue = Issue(
                id=issue_id, use_case_id="P3",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Zombie PDU session {pdu_id} injected — continuing to charge after disconnect.",
                status="open",
            )
            db.add(pdu)
            db.add(issue)

    elif simulation_type == "usage_delay":
        mr_id = f"SIM-MR-DELAY-{sim_id}"
        artifacts = [
            {"type": "MediationRecord", "id": mr_id, "description": "Missing/delayed mediation record"},
            {"type": "Issue", "id": issue_id, "use_case": "P1", "description": "Simulated usage delay"},
        ]
        if not dry_run:
            mr = MediationRecord(
                id=mr_id, billing_account_id=billing_account_id,
                status="raw",
                rating_attempt_count=0,
                billing_period=now.strftime("%Y-%m"),
                payload={"simulation_id": sim_id, "delay_hours": 24, "pipeline_stage": "CDR_COLLECTION"},
                created_at=now,
            )
            issue = Issue(
                id=issue_id, use_case_id="P1",
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] Usage delay: mediation record {mr_id} stuck in CDR_COLLECTION for 24h.",
                status="open",
            )
            db.add(mr)
            db.add(issue)

    elif simulation_type in ("qos_mismatch", "sla_breach", "partner_discrepancy", "proactive_risk"):
        uc_map = {"qos_mismatch": "P4", "sla_breach": "P5", "partner_discrepancy": "P7", "proactive_risk": "P9"}
        desc_map = {
            "qos_mismatch": "QoS mismatch: premium 5G slice charged but 4G QoS delivered for 48h.",
            "sla_breach": "Service degradation: 10h voice outage detected. SLA breach, compensation required.",
            "partner_discrepancy": "Partner discrepancy: $2,800 gap between CSP and partner settlement records.",
            "proactive_risk": "Proactive risk: 50GB anomalous data spike detected (8× average).",
        }
        artifacts = [{"type": "Issue", "id": issue_id, "use_case": uc_map[simulation_type],
                       "description": f"Simulated {simulation_type}"}]
        if not dry_run:
            extra_records = []
            if simulation_type == "proactive_risk":
                ue_id = f"SIM-UE-ANOMALY-{sim_id}"
                artifacts.insert(0, {"type": "UsageEvent", "id": ue_id, "description": "Anomalous usage spike"})
                extra_records.append(UsageEvent(
                    id=ue_id, customer_id=customer_id,
                    billing_account_id=billing_account_id,
                    session_id=f"SIM-SPIKE-{sim_id}",
                    event_type="data", data_volume_bytes=50_000_000_000,
                    start_time=now - datetime.timedelta(hours=1),
                    end_time=now,
                    charging_trigger="CHF",
                    billing_period=now.strftime("%Y-%m"),
                    payload={"anomaly_flag": True, "simulation_id": sim_id, "spike_multiplier": 8.0},
                    created_at=now,
                ))
            issue = Issue(
                id=issue_id, use_case_id=uc_map[simulation_type],
                customer_id=customer_id, billing_account_id=billing_account_id,
                description=f"[SIMULATION] {desc_map[simulation_type]}",
                status="open",
            )
            for r in extra_records:
                db.add(r)
            db.add(issue)

    sim_run = SimulationRun(
        id=sim_id,
        use_case_id=use_case_id,
        run_type=simulation_type,
        is_dry_run=dry_run,
        status="completed" if not dry_run else "dry_run",
        result_summary=f"Simulation {simulation_type} for {billing_account_id}",
        payload={
            "artifacts": artifacts,
            "customer_id": customer_id,
            "billing_account_id": billing_account_id,
            "simulation_type": simulation_type,
        },
        created_at=now,
    )

    if not dry_run:
        db.add(sim_run)
        await db.commit()
        _active_simulations[sim_id] = {
            "simulation_type": simulation_type,
            "issue_id": issue_id,
            "use_case_id": use_case_id,
            "artifacts": artifacts,
            "created_at": now.isoformat(),
        }

    logger.info("L1 Simulation: %s injected — id=%s dry_run=%s", simulation_type, sim_id, dry_run)
    return {
        "simulation_id": sim_id,
        "simulation_type": simulation_type,
        "use_case_id": use_case_id,
        "issue_id": issue_id if not dry_run else None,
        "dry_run": dry_run,
        "artifacts_created": len(artifacts),
        "artifacts": artifacts,
        "status": "injected" if not dry_run else "dry_run_preview",
        "next_step": f"POST /api/v1/issues/{issue_id}/remediate to trigger the {use_case_id} flow." if not dry_run else None,
    }


async def get_simulation_status(sim_id: str) -> Dict[str, Any]:
    """Return the status of an active simulation."""
    if sim_id in _active_simulations:
        return {"simulation_id": sim_id, "status": "active", **_active_simulations[sim_id]}
    return {"simulation_id": sim_id, "status": "not_found_or_reset"}


async def reset_simulations(db: AsyncSession) -> Dict[str, Any]:
    """Reset all simulation-created records."""
    from app.models.models import Issue, UsageEvent, PDUSession, MediationRecord

    deleted_counts: Dict[str, int] = {}

    issues_result = await db.execute(select(Issue).where(Issue.description.like("[SIMULATION]%")))
    sim_issues = issues_result.scalars().all()
    for i in sim_issues:
        await db.delete(i)
    deleted_counts["issues"] = len(sim_issues)

    ue_result = await db.execute(select(UsageEvent))
    all_ues = ue_result.scalars().all()
    sim_ues = [ue for ue in all_ues if ue.payload and "simulation_id" in ue.payload]
    for ue in sim_ues:
        await db.delete(ue)
    deleted_counts["usage_events"] = len(sim_ues)

    await db.commit()
    _active_simulations.clear()

    logger.info("L1 Simulation: reset complete — deleted %s", deleted_counts)
    return {"status": "reset", "deleted": deleted_counts}


def list_active_simulations() -> List[Dict[str, Any]]:
    """Return all simulations currently tracked in memory."""
    return [{"simulation_id": k, **v} for k, v in _active_simulations.items()]


# ── L1 Tools list (for agent tool binding) ────────────────────────────────────

L1_TOOLS = [
    evaluate_remediation_policy_tool,
    correlate_event_tool,
]