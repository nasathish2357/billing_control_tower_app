"""Domain-specific and shared tools for billing control tower agents."""
from app.agents.tools.shared_tools import (
    retrieve_playbook,
    query_knowledge_graph,
    write_audit_trace,
    assess_billing_risk_tool,
)
from app.agents.tools.l1_tools import (
    evaluate_remediation_policy_tool,
    correlate_event_tool,
)
from app.agents.tools.l2_tools import (
    get_current_bill_tool,
    get_previous_bills_tool,
    get_customer_context_tool,
    apply_billing_adjustment,
    place_collections_hold_tool,
    apply_compensation_credit,
    open_trouble_ticket_tool,
    apply_collections_hold_tool,
    apply_surcharge_removal_tool,
    apply_bill_protection_hold_tool,
)
from app.agents.tools.l3_tools import (
    get_mediation_evidence_tool,
    create_mediation_replay_tool,
    evaluate_sla_breach_tool,
    create_service_problem_tool,
    get_qos_evidence_tool,
    get_slice_performance_tool,
    get_mediation_backlog_tool,
)
from app.agents.tools.l4_tools import (
    get_session_evidence_tool,
    cleanup_zombie_session_tool,
    get_rating_evidence_tool,
    get_sepp_cdr_evidence_tool,
    get_chf_roaming_records_tool,
)

L1_TOOLS = [
    evaluate_remediation_policy_tool,
    correlate_event_tool,
]

L2_TOOLS = [
    get_current_bill_tool,
    get_previous_bills_tool,
    get_customer_context_tool,
    apply_billing_adjustment,
    place_collections_hold_tool,
    apply_compensation_credit,
    open_trouble_ticket_tool,
    apply_collections_hold_tool,
    apply_surcharge_removal_tool,
    apply_bill_protection_hold_tool,
]

L3_TOOLS = [
    get_mediation_evidence_tool,
    create_mediation_replay_tool,
    evaluate_sla_breach_tool,
    create_service_problem_tool,
    get_qos_evidence_tool,
    get_slice_performance_tool,
    get_mediation_backlog_tool,
]

L4_TOOLS = [
    get_session_evidence_tool,
    cleanup_zombie_session_tool,
    get_rating_evidence_tool,
    get_sepp_cdr_evidence_tool,
    get_chf_roaming_records_tool,
]

SHARED_TOOLS = [
    retrieve_playbook,
    query_knowledge_graph,
    write_audit_trace,
    assess_billing_risk_tool,
]

__all__ = [
    "L1_TOOLS", "L2_TOOLS", "L3_TOOLS", "L4_TOOLS", "SHARED_TOOLS",
]
