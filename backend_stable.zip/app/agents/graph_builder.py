"""
Hierarchical Multi-Agent Graph Builder — Billing Control Tower.

Architecture (from master_prompt spec):
  L1 Supervisor (root orchestrator — one StateGraph)
  ├── l1_policy_agent    — policy evaluation before high-risk L2 actions
  ├── l1_audit_agent     — governance audit trace writer
  ├── l1_risk_agent      — proactive billing risk assessment (P9)
  ├── chat_agent         — bill explanation + self-service (P8)
  ├── L2 Supervisor Graph (StateGraph with L2 sub-agent nodes)
  │   ├── l2_bss_correction_agent  — billing adjustments, credits, bill protection
  │   ├── l2_collections_agent     — dunning state + collections hold
  │   └── l2_ticketing_agent       — trouble ticket opening
  ├── L3 Supervisor Graph (StateGraph with L3 sub-agent nodes)
  │   ├── l3_mediation_agent       — mediation evidence + replay jobs
  │   ├── l3_qos_agent             — QoS + slice performance evidence
  │   └── l3_service_problem_agent — SLA breach evaluation + service problems
  └── L4 Supervisor Graph (StateGraph with L4 sub-agent nodes)
      ├── l4_session_agent         — PDU session evidence + zombie cleanup
      ├── l4_rating_agent          — rating trigger evidence (duplicate charge)
      └── l4_roaming_agent         — SEPP CDR + CHF roaming evidence (P7)

LangGraph integration:
  - Master graph is a flat StateGraph; each domain supervisor is a compiled subgraph.
  - Domain supervisor subgraphs are added as nodes via add_node().
  - Command is used for all routing between layers.
  - l1_supervisor_node is the central routing hub; all supervisors return Command(goto="l1_supervisor").
  - interrupt() in l1_supervisor_node handles HITL approval pauses (P1, P5, P7, P10).
  - Sub-agents use langchain.agents.create_agent via AgentFactory.make_agent_node().
  - Spec rule: do NOT use langgraph.prebuilt.create_react_agent or AgentExecutor.
  - Spec rule: keep tool schemas shallow; all large payloads in PostgreSQL.
"""
import logging

from langgraph.graph import END, START, StateGraph

from app.agents.agent_state import AgentState
from app.agents.factory import AgentFactory
from app.agents.supervisors.l1_supervisor import (
    l1_supervisor_node,
    l1_policy_agent_node,
    l1_audit_agent_node,
    l1_risk_agent_node,
)
from app.agents.supervisors.l2_supervisor import build_l2_supervisor_graph
from app.agents.supervisors.l3_supervisor import build_l3_supervisor_graph
from app.agents.supervisors.l4_supervisor import build_l4_supervisor_graph

logger = logging.getLogger(__name__)


# ── Chat agent node ───────────────────────────────────────────────────────────

async def chat_agent_node(state: AgentState) -> dict:
    """
    Chat agent — handles P8 bill explanation and self-service intents.
    Bridges the master AgentState into the existing chat_graph.
    """
    from langchain_core.messages import AIMessage

    try:
        from app.agents.chat_graph import chat_graph

        chat_input = {
            "conversation_id": state.get("conversation_id") or state.get("thread_id", ""),
            "customer_id": state.get("customer_id", ""),
            "billing_account_id": state.get("billing_account_id", ""),
            "thread_id": state.get("thread_id", ""),
            "messages": state.get("messages", []),
            "intent": state.get("intent"),
            "current_bill_id": state.get("current_bill_id"),
            "previous_bill_ids": state.get("previous_bill_ids", []),
            "evidence_summary": state.get("evidence_summary", ""),
            "playbook_summary": state.get("playbook_summary", ""),
            "escalation_required": state.get("escalation_required", False),
            "final_response": None,
            "audit_trace_id": None,
            "error": None,
        }
        result = await chat_graph.ainvoke(chat_input)
        return {
            "final_response_summary": result.get("final_response", ""),
            "audit_trace_id": result.get("audit_trace_id"),
            "escalation_required": result.get("escalation_required", False),
            "intent": result.get("intent"),
            "is_remediated": True,
            "messages": [AIMessage(content=result.get("final_response", "chat complete"))],
        }
    except Exception as exc:
        logger.error("[chat_agent_node] failed: %s", exc)
        return {
            "error": str(exc),
            "is_remediated": True,
            "messages": [AIMessage(content=f"Chat agent error: {exc}")],
        }


# ── Master graph builder ──────────────────────────────────────────────────────

def build_agentic_graph(checkpointer=None):
    """
    Build and compile the full hierarchical multi-agent graph.

    The master graph structure:
      START → l1_supervisor
      l1_supervisor ↔ l1_policy_agent (Command-based)
      l1_supervisor ↔ l1_audit_agent  (Command-based)
      l1_supervisor ↔ l1_risk_agent   (Command-based)
      l1_supervisor ↔ chat_agent      (Command-based)
      l1_supervisor ↔ l2_supervisor   (domain subgraph)
      l1_supervisor ↔ l3_supervisor   (domain subgraph)
      l1_supervisor ↔ l4_supervisor   (domain subgraph)
      l1_supervisor → __end__

    Each domain supervisor subgraph internally routes to its own sub-agents
    and returns Command(goto="l1_supervisor") when done.

    Args:
        checkpointer: LangGraph checkpointer (PostgresSaver or MemorySaver).
                      Required for interrupt/resume HITL approval flows.

    Returns:
        Compiled LangGraph StateGraph.
    """
    from app.llm.gemini_provider import get_llm

    llm = get_llm()
    factory = AgentFactory(llm)

    # ── Build domain supervisor subgraphs ─────────────────────────────────────
    # checkpointer=True → subgraphs inherit the master graph's checkpointer.
    # This is required for interrupt/resume to work correctly: the master graph
    # saves checkpoints that span subgraph boundaries, and on resume, LangGraph
    # needs to replay through the subgraph using the parent's checkpointer.
    l2_graph = build_l2_supervisor_graph(factory, checkpointer=True)
    l3_graph = build_l3_supervisor_graph(factory, checkpointer=True)
    l4_graph = build_l4_supervisor_graph(factory, checkpointer=True)

    # ── Assemble master StateGraph ────────────────────────────────────────────
    builder = StateGraph(AgentState)

    # L1 layer nodes
    builder.add_node("l1_supervisor", l1_supervisor_node)
    builder.add_node("l1_policy_agent", l1_policy_agent_node)
    builder.add_node("l1_audit_agent", l1_audit_agent_node)
    builder.add_node("l1_risk_agent", l1_risk_agent_node)
    builder.add_node("chat_agent", chat_agent_node)

    # Domain supervisor subgraphs as nodes in the master graph
    # These subgraphs internally route to their sub-agents and return to l1_supervisor.
    builder.add_node("l2_supervisor", l2_graph)
    builder.add_node("l3_supervisor", l3_graph)
    builder.add_node("l4_supervisor", l4_graph)

    # Entry point: all requests start at L1 Supervisor
    builder.add_edge(START, "l1_supervisor")

    # Domain supervisor subgraphs return plain state dicts (no Command).
    # Explicit edges route them back to l1_supervisor for re-evaluation after
    # each domain subgraph completes. l1_supervisor's logic prevents re-visiting
    # the same supervisor (visited_supervisors tracking) and terminates when done.
    builder.add_edge("l2_supervisor", "l1_supervisor")
    builder.add_edge("l3_supervisor", "l1_supervisor")
    builder.add_edge("l4_supervisor", "l1_supervisor")

    # chat_agent returns a plain dict — route back to l1_supervisor so it can
    # proceed to the audit phase (is_remediated=True triggers l1_audit_agent).
    builder.add_edge("chat_agent", "l1_supervisor")

    # l1_policy_agent, l1_audit_agent, l1_risk_agent use Command(goto="l1_supervisor")
    # so they don't need explicit edges here.

    compiled = builder.compile(checkpointer=checkpointer)
    logger.info("build_agentic_graph: compiled with checkpointer=%r", type(checkpointer).__name__ if checkpointer else None)
    return compiled


# ── Singleton with lazy init ──────────────────────────────────────────────────

_agentic_graph = None


def get_agentic_graph(checkpointer=None):
    """Return the compiled hierarchical agentic graph (lazy singleton)."""
    global _agentic_graph
    if _agentic_graph is None:
        _agentic_graph = build_agentic_graph(checkpointer)
        logger.info("✅ Hierarchical agentic graph compiled (L1→L2/L3/L4 supervisor subgraphs).")
    return _agentic_graph


def reset_agentic_graph():
    """Reset the singleton — call when checkpointer changes."""
    global _agentic_graph
    _agentic_graph = None
