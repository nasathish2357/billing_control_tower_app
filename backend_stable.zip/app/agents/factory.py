"""
Agent Factory — creates domain sub-agent node functions for LangGraph supervisors.

Design rules (from master_prompt spec):
  - Supervisors call factory.create_agent() to get an async node function.
  - Each agent node runs: LLM → tool calls → LLM → ... until no more tool calls.
  - Agent nodes return a plain dict (state update); routing is via explicit graph edges.
  - Agents inject use_case_id and evidence_summary from runtime state into prompts.
  - Uses a direct async loop (not langchain.agents.create_agent internals) to avoid
    'Event loop is closed' errors in pytest-asyncio environments on Windows.
"""
import logging
from typing import Callable, Sequence

from langchain_core.language_models import BaseChatModel
from langchain_core.tools import BaseTool

logger = logging.getLogger(__name__)

AGENT_MAX_ITERATIONS = 8


class AgentFactory:
    """Factory for creating domain sub-agent node functions."""

    def __init__(self, llm: BaseChatModel):
        self.llm = llm

    def create_agent(
        self,
        tools: Sequence[BaseTool],
        system_prompt: str,
        *,
        name: str = "agent",
        checkpointer=None,
    ) -> Callable:
        """
        Create a domain sub-agent as an async LangGraph node function.

        The returned function runs a tool-calling loop:
          LLM (with bound tools) → execute tool calls → LLM → repeat until done.

        Returns plain dict (state update), NOT a Command.
        Supervisors add explicit graph edges for routing back to supervisor entry.
        Runtime context (use_case_id, evidence_summary) is injected from state.

        Args:
            tools: Domain-specific tools this agent may call.
            system_prompt: Base system prompt string for this agent's role.
            name: Agent name — used as the node name in the supervisor graph.
            checkpointer: Unused at node level (master graph checkpoints).

        Returns:
            Async node function: (state: dict) -> dict
        """
        from langchain_core.messages import SystemMessage, ToolMessage

        llm_with_tools = self.llm.bind_tools(list(tools)) if tools else self.llm
        tool_by_name = {t.name: t for t in (tools or [])}

        async def agent_node(state: dict) -> dict:
            logger.info("[%s] invoking tool-calling loop (max=%d)", name, AGENT_MAX_ITERATIONS)
            try:
                # Inject runtime context from state into the system prompt
                use_case_id = state.get("use_case_id", "")
                evidence = (state.get("evidence_summary") or "")[:300]
                issue_id = state.get("issue_id", "")
                control_case_id = state.get("control_case_id", "")

                runtime_ctx = ""
                if use_case_id:
                    runtime_ctx += f"\nActive use case: {use_case_id}"
                if issue_id:
                    runtime_ctx += f"\nIssue ID: {issue_id}"
                if control_case_id:
                    runtime_ctx += f"\nControl case ID: {control_case_id}"
                if evidence:
                    runtime_ctx += f"\nEvidence so far: {evidence}"

                full_prompt = system_prompt + runtime_ctx
                existing = state.get("messages", [])
                messages = [SystemMessage(content=full_prompt)] + list(existing)

                all_new_messages = []
                for iteration in range(AGENT_MAX_ITERATIONS):
                    response = await llm_with_tools.ainvoke(messages)
                    messages.append(response)
                    all_new_messages.append(response)

                    tool_calls = getattr(response, "tool_calls", None) or []
                    if not tool_calls:
                        logger.info("[%s] finished after %d iteration(s)", name, iteration + 1)
                        break

                    for tc in tool_calls:
                        tool_name = tc.get("name") or tc.get("function", {}).get("name", "")
                        tool_args = tc.get("args") or tc.get("function", {}).get("arguments", {})
                        tool_id = tc.get("id", tool_name)

                        tool_fn = tool_by_name.get(tool_name)
                        if tool_fn is None:
                            tool_result = f"Error: tool '{tool_name}' not found."
                        else:
                            try:
                                if hasattr(tool_fn, "ainvoke"):
                                    tool_result = await tool_fn.ainvoke(tool_args)
                                else:
                                    import asyncio
                                    tool_result = await asyncio.get_event_loop().run_in_executor(
                                        None, lambda: tool_fn.invoke(tool_args)
                                    )
                            except Exception as tex:
                                tool_result = f"Tool error: {tex}"

                        tool_msg = ToolMessage(
                            content=str(tool_result),
                            tool_call_id=tool_id,
                        )
                        messages.append(tool_msg)
                        all_new_messages.append(tool_msg)
                else:
                    logger.warning("[%s] reached max_iterations=%d", name, AGENT_MAX_ITERATIONS)

                return {
                    "messages": all_new_messages,
                    "agent_role": name,
                }

            except Exception as exc:
                logger.error("[%s] agent node error: %s", name, exc)
                return {
                    "error": str(exc),
                    "agent_role": name,
                }

        agent_node.__name__ = name
        return agent_node

    def make_agent_node(
        self,
        agent_name: str,
        tools: Sequence[BaseTool],
        system_prompt: str,
        return_to: str,
        *,
        checkpointer=None,
    ) -> Callable:
        """
        Deprecated: use create_agent() instead.
        Kept for backward compatibility. Supervisors now use create_agent() + explicit edges.
        """
        logger.warning(
            "make_agent_node('%s') is deprecated — use create_agent() with explicit graph edges.",
            agent_name,
        )
        return self.create_agent(tools, system_prompt, name=agent_name, checkpointer=checkpointer)
