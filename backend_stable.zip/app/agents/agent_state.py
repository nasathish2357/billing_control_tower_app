"""
Unified AgentState — hierarchical multi-agent billing control tower.

Merges RemediationState + ChatState into a single TypedDict that
all supervisors and sub-agents share through the graph.

Design rules:
  - messages carries inter-agent communication (add_messages reducer).
  - All large payloads stay in PostgreSQL; only IDs/summaries in state.
  - next_agent / agent_role support supervisor routing via Command.
"""
from typing import Annotated, List, Optional, Set
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages


class AgentState(TypedDict, total=False):
    # ── Agent communication ──────────────────────────────────────────────────
    messages: Annotated[list, add_messages]

    # ── Supervisor routing ───────────────────────────────────────────────────
    next_agent: Optional[str]       # which node to route to next
    agent_role: Optional[str]       # currently active agent role label

    # ── Core context ─────────────────────────────────────────────────────────
    use_case_id: str                # P1-P10
    issue_id: Optional[str]
    control_case_id: Optional[str]
    thread_id: str
    customer_id: Optional[str]
    billing_account_id: Optional[str]
    bill_id: Optional[str]
    event_id: Optional[str]

    # ── Chat context (P8) ────────────────────────────────────────────────────
    conversation_id: Optional[str]
    intent: Optional[str]
    current_bill_id: Optional[str]
    previous_bill_ids: List[str]
    escalation_required: bool

    # ── Partner settlement context (P7) ──────────────────────────────────────
    partner_account_id: Optional[str]
    billing_period: Optional[str]
    retail_overcharge_usd: Optional[float]
    retail_correction_required: Optional[bool]
    discrepancy_amount: Optional[float]
    l4_evidence_ref: Optional[str]
    partner_recovery_ref: Optional[str]
    sepp_export_complete: Optional[bool]
    partner_ingestion_gap_confirmed: Optional[bool]

    # ── Evidence (reference-based) ───────────────────────────────────────────
    evidence_pack_ids: List[str]
    evidence_summary: str
    playbook_summary: Optional[str]
    kg_context: Optional[str]

    # ── Policy & approval ────────────────────────────────────────────────────
    policy_decision: Optional[str]      # auto_remediation_allowed | approval_required
    requires_human_approval: bool
    approval_id: Optional[str]
    approval_status: Optional[str]      # pending | approved | rejected

    # ── Planned actions ──────────────────────────────────────────────────────
    planned_action_ids: List[str]

    # ── Outcome ──────────────────────────────────────────────────────────────
    final_response_summary: Optional[str]
    audit_trace_id: Optional[str]
    is_remediated: bool

    # ── Error ────────────────────────────────────────────────────────────────
    error: Optional[str]

    # ── L1 routing tracker (set of supervisor names already visited) ──────────
    # Updated by l1_supervisor_node via Command update.
    # Avoids fragile string-matching on message content for routing decisions.
    visited_supervisors: Optional[Set[str]]
