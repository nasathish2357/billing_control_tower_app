import sys
import asyncio

# ── Windows fix ────────────────────────────────────────────────────────────────
# psycopg3 async mode is incompatible with ProactorEventLoop (Windows default).
# This MUST be the very first statement before any SQLAlchemy / psycopg import.
# ──────────────────────────────────────────────────────────────────────────────
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import logging
import logging.config
from contextlib import asynccontextmanager


from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.db.database import engine, Base
from app.api.v1.endpoints import router as api_v1_router

settings = get_settings()

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 Starting Billing Control Tower MVP2...")
    # Create all tables on startup (idempotent — won't drop existing data)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✅ Database tables verified/created.")

    # Initialize LangGraph checkpointer (auto-creates tables, idempotent)
    from app.agents.checkpoint_setup import setup_checkpointer
    await setup_checkpointer()

    yield
    from app.agents.checkpoint_setup import close_checkpointer
    await close_checkpointer()
    await engine.dispose()
    logger.info("🛑 Database connections closed.")


app = FastAPI(
    title=settings.app_name,
    description="Telecom Billing Dispute Agentic AI — MVP2 Backend",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# CORS
origins = [o.strip() for o in settings.cors_allow_origins.split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount versioned API (MVP1)
app.include_router(api_v1_router, prefix=settings.api_v1_prefix)

# Mount MVP2 routers
from app.api.v1.events import router as events_router
from app.api.v1.approvals import router as approvals_router
from app.api.v1.context import router as context_router
from app.api.v1.kg import router as kg_router

app.include_router(events_router, prefix=settings.api_v1_prefix, tags=["events"])
app.include_router(approvals_router, prefix=settings.api_v1_prefix, tags=["approvals"])
app.include_router(context_router, prefix=settings.api_v1_prefix, tags=["context"])
app.include_router(kg_router, prefix=settings.api_v1_prefix, tags=["knowledge-graph"])


@app.get("/")
async def root():
    return {"service": settings.app_name, "version": "MVP2", "docs": "/docs"}
