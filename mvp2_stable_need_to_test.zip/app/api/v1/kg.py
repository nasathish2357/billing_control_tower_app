"""
MVP2 KG API

Routes:
  GET  /kg/issue/{issue_id}/relationships  — get KG relationships for an issue
  POST /kg/rebuild                          — optional backup: force KG rebuild
"""
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/kg/issue/{issue_id}/relationships")
async def get_issue_kg_relationships(issue_id: str, db: AsyncSession = Depends(get_db)):
    """
    Return knowledge graph relationships for an issue.
    Builds KG from PostgreSQL (cached 60s) and traverses from issue_id.
    """
    try:
        from app.kg.kg_queries import get_issue_relationships
        result = await get_issue_relationships(db, issue_id)
        if "error" in result:
            raise HTTPException(status_code=503, detail=result["error"])
        return result
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")


@router.post("/kg/rebuild")
async def rebuild_kg(db: AsyncSession = Depends(get_db)):
    """
    Optional backup endpoint: force a KG rebuild from PostgreSQL.
    Useful for development, testing, or after bulk data changes.
    The KG normally rebuilds automatically on each request (cached 60s).
    """
    try:
        from app.kg.kg_builder import build_graph, invalidate_cache
        invalidate_cache()
        G = await build_graph(db)
        if G is None:
            raise HTTPException(status_code=503, detail="networkx not installed — KG not available")
        return {
            "status": "rebuilt",
            "node_count": G.number_of_nodes(),
            "edge_count": G.number_of_edges(),
        }
    except ImportError:
        raise HTTPException(status_code=503, detail="KG module not available (networkx not installed)")
