"""
MVP2 seed data: TMF events, trouble tickets, service problems.
Run after app/db/seed.py (which seeds MVP1 base data).
"""
import sys, asyncio
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

import datetime
import logging
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import AsyncSessionFactory, engine, Base
from app.models.models import (
    TMFEvent, TroubleTicket, ServiceProblem,
)

logger = logging.getLogger(__name__)

# ── Event templates ──────────────────────────────────────────────────────────

EVENTS = [
    {
        "id": "EVT-P1-001",
        "event_type": "SuspectedUsageDelayEvent",
        "use_case_id": "P1",
        "source_layer": "L4",
        "severity": "high",
        "status": "new",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P1-001",
        "description": "847 usage events delayed in mediation pipeline. Bill-run exposure risk for BA-100001.",
        "payload": {
            "mediation_backlog_count": 847,
            "delay_hours": 18,
            "affected_billing_period": "2026-04",
            "pipeline_stage": "CDR_COLLECTION",
        },
    },
    {
        "id": "EVT-P2-001",
        "event_type": "DuplicateChargingEvent",
        "use_case_id": "P2",
        "source_layer": "L3",
        "severity": "high",
        "status": "new",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P2-001",
        "description": "Duplicate data session charge detected for BA-100001 — 25.60 USD double-rated.",
        "payload": {
            "duplicate_session_id": "SESSION-DUP-20260415",
            "duplicate_amount": 25.60,
            "original_cdr_id": "CDR-20260415-001",
            "duplicate_cdr_id": "CDR-20260415-002",
        },
    },
    {
        "id": "EVT-P3-001",
        "event_type": "ZombieSessionSuspectedEvent",
        "use_case_id": "P3",
        "source_layer": "L4",
        "severity": "critical",
        "status": "new",
        "customer_id": "CUST-100002",
        "billing_account_id": "BA-100002",
        "issue_id": "ISSUE-P3-001",
        "description": "PDU session SESSION-ZOMBIE-001 active for 72+ hours without network activity.",
        "payload": {
            "session_id": "SESSION-ZOMBIE-001",
            "duration_hours": 72,
            "data_charged_gb": 15.4,
            "actual_usage_gb": 0.0,
            "upf_node": "UPF-EAST-07",
        },
    },
    {
        "id": "EVT-P4-001",
        "event_type": "QoSMismatchEvent",
        "use_case_id": "P4",
        "source_layer": "L4",
        "severity": "medium",
        "status": "new",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P4-001",
        "description": "QoS delivered 15 Mbps vs promised 100 Mbps for premium slice. Premium surcharge applied incorrectly.",
        "payload": {
            "promised_throughput_mbps": 100,
            "delivered_throughput_mbps": 15,
            "slice_id": "SLICE-PREMIUM-001",
            "nssai": "01-000001",
            "surcharge_amount": 25.00,
        },
    },
    {
        "id": "EVT-P5-001",
        "event_type": "ServiceDegradationEvent",
        "use_case_id": "P5",
        "source_layer": "L3",
        "severity": "high",
        "status": "new",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P5-001",
        "description": "8-hour voice service outage April 20 2026. SLA threshold exceeded (60 min). Compensation required.",
        "payload": {
            "outage_start": "2026-04-20T02:00:00Z",
            "outage_end": "2026-04-20T10:00:00Z",
            "duration_hours": 8,
            "sla_threshold_minutes": 60,
            "service_type": "voice",
            "compensation_eligibility": True,
        },
    },
    {
        "id": "EVT-P6-001",
        "event_type": "CollectionsRiskEvent",
        "use_case_id": "P6",
        "source_layer": "L2",
        "severity": "medium",
        "status": "new",
        "customer_id": "CUST-100003",
        "billing_account_id": "BA-100003",
        "issue_id": "ISSUE-P6-001",
        "description": "Customer raised invoice dispute. Collections risk — dunning should be paused.",
        "payload": {
            "disputed_amount": 12.50,
            "total_balance": 89.99,
            "undisputed_amount": 77.49,
            "dunning_stage": "first_notice",
        },
    },
    {
        "id": "EVT-P9-001",
        "event_type": "BillingRiskDetectedEvent",
        "use_case_id": "P9",
        "source_layer": "L1",
        "severity": "high",
        "status": "new",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "issue_id": "ISSUE-P9-001",
        "description": "Internal monitoring detected data spike 3x normal usage on BA-100001. Pre-bill anomaly. No customer impact yet.",
        "payload": {
            "baseline_daily_gb": 2.1,
            "current_daily_gb": 6.8,
            "spike_factor": 3.2,
            "detection_source": "NWDAF",
            "pre_bill_exposure_usd": 48.00,
        },
    },
]

TROUBLE_TICKETS = [
    {
        "id": "TT-P6-001",
        "issue_id": "ISSUE-P6-001",
        "customer_id": "CUST-100003",
        "billing_account_id": "BA-100003",
        "ticket_type": "billing_dispute",
        "status": "open",
        "priority": "medium",
        "description": "Customer disputes charge of $12.50 on April 2026 bill. Requests collections hold.",
        "payload": {"channel": "web_portal", "reference_charge": "LINE-ITEM-009"},
    },
    {
        "id": "TT-P5-001",
        "issue_id": "ISSUE-P5-001",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
        "ticket_type": "service_complaint",
        "status": "open",
        "priority": "high",
        "description": "Voice service outage on April 20 2026 (8 hours). Customer requesting compensation.",
        "payload": {"channel": "call_center", "affected_service": "voice"},
    },
]

SERVICE_PROBLEMS = [
    {
        "id": "SP-P5-001",
        "issue_id": "ISSUE-P5-001",
        "customer_id": "CUST-100001",
        "service_id": "SVC-VOICE-100001",
        "problem_type": "service_degradation",
        "severity": "high",
        "status": "open",
        "sla_breach": True,
        "affected_period_start": datetime.datetime(2026, 4, 20, 2, 0, 0),
        "affected_period_end": datetime.datetime(2026, 4, 20, 10, 0, 0),
        "description": "Complete voice service interruption for 8 hours. SLA max allowable: 60 minutes. Breach confirmed.",
        "payload": {
            "service_type": "voice",
            "root_cause": "core_node_failure",
            "affected_nodes": ["AMF-NORTH-01", "SMF-NORTH-01"],
            "sla_doc_ref": "SLA-ENTERPRISE-2025-001",
        },
    },
    {
        "id": "SP-P4-001",
        "issue_id": "ISSUE-P4-001",
        "customer_id": "CUST-100001",
        "service_id": "SVC-DATA-PREMIUM-100001",
        "problem_type": "qos_breach",
        "severity": "medium",
        "status": "open",
        "sla_breach": True,
        "affected_period_start": datetime.datetime(2026, 4, 1, 0, 0, 0),
        "affected_period_end": datetime.datetime(2026, 4, 30, 23, 59, 59),
        "description": "QoS entitlement mismatch: premium slice promised 100 Mbps, delivered 15 Mbps for entire April period.",
        "payload": {
            "slice_id": "SLICE-PREMIUM-001",
            "promised_qos": "100Mbps_eMBB",
            "delivered_qos": "15Mbps_shared",
            "nssai_configured": "01-000001",
            "nssai_active": "01-000002",
        },
    },
]


async def seed_mvp2():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionFactory() as session:
        # Seed events
        for ev_data in EVENTS:
            existing = await session.get(TMFEvent, ev_data["id"])
            if not existing:
                ev = TMFEvent(**ev_data)
                session.add(ev)
                logger.info("Seeded event %s", ev_data["id"])

        # Seed trouble tickets
        for tt_data in TROUBLE_TICKETS:
            existing = await session.get(TroubleTicket, tt_data["id"])
            if not existing:
                tt = TroubleTicket(**tt_data)
                session.add(tt)
                logger.info("Seeded trouble ticket %s", tt_data["id"])

        # Seed service problems
        for sp_data in SERVICE_PROBLEMS:
            existing = await session.get(ServiceProblem, sp_data["id"])
            if not existing:
                sp = ServiceProblem(**sp_data)
                session.add(sp)
                logger.info("Seeded service problem %s", sp_data["id"])

        await session.commit()
        logger.info("MVP2 seed data committed.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(seed_mvp2())
