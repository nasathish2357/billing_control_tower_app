"""
KG Builder — MVP2

Builds a NetworkX DiGraph as a derived read model from PostgreSQL.

Design rules (from master prompt):
  - PostgreSQL is the source of truth.
  - KG is a read-only derived model — no transactional writes.
  - KG is rebuilt from DB records on demand.
  - PostgreSQL evidence_packs / audit_traces hold large payloads.
  - KG stores only entity type, ID, and lightweight properties.

Relationships modelled:
  Customer → BillingAccount → Bill
  Issue → ControlCase → EvidencePack
  Issue → ControlCase → AuditTrace
  TMFEvent → Issue
  TroubleTicket → ControlCase
  ServiceProblem → Issue
  Approval → ControlCase
"""
import asyncio
import datetime
import logging
import time
import uuid
from typing import Optional

logger = logging.getLogger(__name__)

try:
    import networkx as nx
    _NX_AVAILABLE = True
except ImportError:
    _NX_AVAILABLE = False
    logger.warning("networkx not installed — KG builder will return empty graphs.")


# ── In-memory cache ───────────────────────────────────────────────────────────

_cached_graph = None
_cache_built_at: Optional[datetime.datetime] = None
_CACHE_TTL_SECONDS = 60   # rebuild if cache is older than 60s


def _is_cache_valid() -> bool:
    if _cached_graph is None or _cache_built_at is None:
        return False
    age = (datetime.datetime.utcnow() - _cache_built_at).total_seconds()
    return age < _CACHE_TTL_SECONDS


async def build_graph(db) -> "nx.DiGraph":
    """
    Build a NetworkX DiGraph from the current PostgreSQL state.
    Returns cached graph if cache is still valid (< 60s old).
    """
    global _cached_graph, _cache_built_at

    if _is_cache_valid():
        logger.debug("KG: using cached graph (%d nodes)", _cached_graph.number_of_nodes())
        return _cached_graph

    if not _NX_AVAILABLE:
        return None

    from sqlalchemy import select
    from app.models.models import (
        Customer, BillingAccount, Bill, Issue, ControlCase,
        EvidencePack, AuditTrace, TMFEvent, TroubleTicket,
        ServiceProblem, Approval,
    )

    t0 = time.time()
    G = nx.DiGraph()

    # ── Customers ────────────────────────────────────────────────────────────
    result = await db.execute(select(Customer))
    for c in result.scalars():
        G.add_node(c.id, type="Customer", name=c.name, segment=c.segment)

    # ── Billing Accounts ─────────────────────────────────────────────────────
    result = await db.execute(select(BillingAccount))
    for ba in result.scalars():
        G.add_node(ba.id, type="BillingAccount", status=ba.status)
        if ba.customer_id in G:
            G.add_edge(ba.customer_id, ba.id, rel="HAS_BILLING_ACCOUNT")

    # ── Bills ────────────────────────────────────────────────────────────────
    result = await db.execute(select(Bill))
    for b in result.scalars():
        G.add_node(b.id, type="Bill", period=b.billing_period, amount=b.amount_due, status=b.status)
        if b.billing_account_id in G:
            G.add_edge(b.billing_account_id, b.id, rel="HAS_BILL")

    # ── Issues ───────────────────────────────────────────────────────────────
    result = await db.execute(select(Issue))
    for iss in result.scalars():
        G.add_node(iss.id, type="Issue", use_case=iss.use_case_id, status=iss.status)
        if iss.billing_account_id in G:
            G.add_edge(iss.billing_account_id, iss.id, rel="HAS_ISSUE")

    # ── Control Cases ─────────────────────────────────────────────────────────
    result = await db.execute(select(ControlCase))
    for cc in result.scalars():
        G.add_node(cc.id, type="ControlCase", status=cc.status)
        if cc.issue_id in G:
            G.add_edge(cc.issue_id, cc.id, rel="HAS_CONTROL_CASE")

    # ── Evidence Packs ────────────────────────────────────────────────────────
    result = await db.execute(select(EvidencePack))
    for evp in result.scalars():
        G.add_node(evp.id, type="EvidencePack", layer=evp.source_layer)
        if evp.control_case_id in G:
            G.add_edge(evp.control_case_id, evp.id, rel="HAS_EVIDENCE")

    # ── Audit Traces ──────────────────────────────────────────────────────────
    result = await db.execute(select(AuditTrace))
    for at in result.scalars():
        G.add_node(at.id, type="AuditTrace", action_type=at.action_type)
        if at.control_case_id in G:
            G.add_edge(at.control_case_id, at.id, rel="HAS_AUDIT")

    # ── TMF Events ────────────────────────────────────────────────────────────
    result = await db.execute(select(TMFEvent))
    for ev in result.scalars():
        G.add_node(ev.id, type="TMFEvent", event_type=ev.event_type, status=ev.status)
        if ev.issue_id and ev.issue_id in G:
            G.add_edge(ev.id, ev.issue_id, rel="TRIGGERED_ISSUE")
        if ev.control_case_id and ev.control_case_id in G:
            G.add_edge(ev.id, ev.control_case_id, rel="CORRELATED_TO")

    # ── Trouble Tickets ────────────────────────────────────────────────────────
    result = await db.execute(select(TroubleTicket))
    for tt in result.scalars():
        G.add_node(tt.id, type="TroubleTicket", ticket_type=tt.ticket_type, status=tt.status)
        if tt.issue_id and tt.issue_id in G:
            G.add_edge(tt.id, tt.issue_id, rel="RELATED_TO_ISSUE")
        if tt.control_case_id and tt.control_case_id in G:
            G.add_edge(tt.id, tt.control_case_id, rel="RELATED_TO_CASE")

    # ── Service Problems ──────────────────────────────────────────────────────
    result = await db.execute(select(ServiceProblem))
    for sp in result.scalars():
        G.add_node(sp.id, type="ServiceProblem", problem_type=sp.problem_type, sla_breach=sp.sla_breach)
        if sp.issue_id and sp.issue_id in G:
            G.add_edge(sp.id, sp.issue_id, rel="RELATES_TO_ISSUE")

    # ── Approvals ─────────────────────────────────────────────────────────────
    result = await db.execute(select(Approval))
    for ap in result.scalars():
        G.add_node(ap.id, type="Approval", action=ap.action, status=ap.status)
        if ap.control_case_id in G:
            G.add_edge(ap.control_case_id, ap.id, rel="REQUIRES_APPROVAL")

    elapsed_ms = (time.time() - t0) * 1000
    logger.info(
        "KG built: %d nodes, %d edges in %.1fms",
        G.number_of_nodes(), G.number_of_edges(), elapsed_ms,
    )

    # ── Persist snapshot metadata ─────────────────────────────────────────────
    try:
        from app.models.models import KGSnapshot
        snap_id = f"KG-SNAP-{str(uuid.uuid4())[:8].upper()}"
        snap = KGSnapshot(
            id=snap_id,
            node_count=G.number_of_nodes(),
            edge_count=G.number_of_edges(),
            build_duration_ms=elapsed_ms,
            status="ready",
        )
        db.add(snap)
        await db.commit()
    except Exception as e:
        logger.warning("KG snapshot persist failed: %s", e)

    _cached_graph = G
    _cache_built_at = datetime.datetime.utcnow()
    return G


def invalidate_cache():
    """Force the next build_graph() call to rebuild from DB."""
    global _cached_graph, _cache_built_at
    _cached_graph = None
    _cache_built_at = None
