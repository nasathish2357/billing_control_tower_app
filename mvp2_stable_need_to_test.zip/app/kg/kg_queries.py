"""
KG Queries — MVP2

Graph query functions over the NetworkX DiGraph built by kg_builder.
All queries operate on the derived read model — no writes to PostgreSQL.
"""
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


async def get_issue_relationships(db, issue_id: str) -> Dict[str, Any]:
    """
    Return all KG nodes and edges reachable from the given issue_id.
    Includes: billing account, customer, bills, control cases, evidence packs, events.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"issue_id": issue_id, "nodes": [], "edges": [], "error": "networkx not available"}

    if issue_id not in G:
        return {"issue_id": issue_id, "nodes": [], "edges": [], "warning": "issue not in graph"}

    # Collect direct neighbours (in + out)
    nodes = []
    edges = []
    visited = {issue_id}

    # Outgoing (children)
    for successor in G.successors(issue_id):
        edge_data = G[issue_id][successor]
        edges.append({"from": issue_id, "to": successor, "rel": edge_data.get("rel")})
        if successor not in visited:
            visited.add(successor)
            nodes.append({"id": successor, **G.nodes[successor]})
            # One more hop for control case children
            for child in G.successors(successor):
                child_edge = G[successor][child]
                edges.append({"from": successor, "to": child, "rel": child_edge.get("rel")})
                if child not in visited:
                    visited.add(child)
                    nodes.append({"id": child, **G.nodes[child]})

    # Incoming (parents — e.g. events that triggered this issue)
    for predecessor in G.predecessors(issue_id):
        edge_data = G[predecessor][issue_id]
        edges.append({"from": predecessor, "to": issue_id, "rel": edge_data.get("rel")})
        if predecessor not in visited:
            visited.add(predecessor)
            nodes.append({"id": predecessor, **G.nodes[predecessor]})

    # Add the issue node itself
    issue_node = {"id": issue_id, **G.nodes[issue_id]}

    return {
        "issue_id": issue_id,
        "issue": issue_node,
        "nodes": nodes,
        "edges": edges,
        "total_nodes": len(nodes) + 1,
        "total_edges": len(edges),
    }


async def get_customer_billing_context(db, customer_id: str) -> Dict[str, Any]:
    """
    Return full billing context for a customer from the KG:
    Customer → BillingAccounts → Bills → Issues → ControlCases.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"customer_id": customer_id, "error": "networkx not available"}

    if customer_id not in G:
        return {"customer_id": customer_id, "warning": "customer not in graph"}

    def _collect_subtree(node_id: str, max_depth: int = 3) -> List[Dict[str, Any]]:
        collected = []
        for successor in G.successors(node_id):
            node_data = {"id": successor, **G.nodes[successor]}
            node_data["rel"] = G[node_id][successor].get("rel")
            if max_depth > 0:
                node_data["children"] = _collect_subtree(successor, max_depth - 1)
            collected.append(node_data)
        return collected

    return {
        "customer_id": customer_id,
        "customer": {"id": customer_id, **G.nodes[customer_id]},
        "billing_tree": _collect_subtree(customer_id),
    }


async def find_impacted_entities(db, event_id: str) -> Dict[str, Any]:
    """
    From a TMFEvent node, find all downstream entities:
    Event → Issue → ControlCase → EvidencePack / AuditTrace.
    """
    from app.kg.kg_builder import build_graph
    G = await build_graph(db)
    if G is None:
        return {"event_id": event_id, "error": "networkx not available"}

    if event_id not in G:
        return {"event_id": event_id, "warning": "event not in graph"}

    try:
        import networkx as nx
        reachable = list(nx.descendants(G, event_id))
        nodes = [{"id": n, **G.nodes[n]} for n in reachable]
        edges = [
            {"from": u, "to": v, "rel": G[u][v].get("rel")}
            for u, v in nx.edge_bfs(G, event_id)
        ]
    except Exception as e:
        return {"event_id": event_id, "error": str(e)}

    return {
        "event_id": event_id,
        "event": {"id": event_id, **G.nodes[event_id]},
        "impacted_nodes": nodes,
        "impacted_edges": edges,
        "total_impacted": len(nodes),
    }
