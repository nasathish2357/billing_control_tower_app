"""
SQLAlchemy ORM models for Billing Control Tower MVP1 + MVP2.

Design principle: Large TMF-style payloads are stored in JSON/JSONB columns
on the database rows. Only compact references (IDs, summaries) are placed in
LangGraph state, keeping checkpointed state lightweight.
"""

import datetime
from typing import List, Optional
from sqlalchemy import String, ForeignKey, DateTime, Float, JSON, Text, Boolean, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class UseCase(Base):
    __tablename__ = "use_cases"

    id: Mapped[str] = mapped_column(String(10), primary_key=True)   # P1 … P10
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text)
    priority: Mapped[str] = mapped_column(String(10))
    flow_type: Mapped[str] = mapped_column(String(30), default="simplified_deterministic")
    status: Mapped[str] = mapped_column(String(20), default="active")


class Customer(Base):
    __tablename__ = "customers"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # CUST-100001
    name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str] = mapped_column(String(200))
    segment: Mapped[str] = mapped_column(String(50))                 # Consumer, Enterprise

    billing_accounts: Mapped[List["BillingAccount"]] = relationship(back_populates="customer")


class BillingAccount(Base):
    __tablename__ = "billing_accounts"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # BA-100001
    customer_id: Mapped[str] = mapped_column(ForeignKey("customers.id"))
    currency: Mapped[str] = mapped_column(String(10), default="USD")
    status: Mapped[str] = mapped_column(String(30))

    customer: Mapped["Customer"] = relationship(back_populates="billing_accounts")
    bills: Mapped[List["Bill"]] = relationship(back_populates="billing_account")


class Bill(Base):
    __tablename__ = "bills"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # BILL-202604
    billing_account_id: Mapped[str] = mapped_column(ForeignKey("billing_accounts.id"))
    billing_period: Mapped[str] = mapped_column(String(20))         # 2026-04
    amount_due: Mapped[float] = mapped_column(Float)
    previous_amount: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    due_date: Mapped[datetime.datetime] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(30))                  # Paid, Disputed, Pending
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    billing_account: Mapped["BillingAccount"] = relationship(back_populates="bills")


class Issue(Base):
    __tablename__ = "issues"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # ISSUE-P2-001
    use_case_id: Mapped[str] = mapped_column(ForeignKey("use_cases.id"))
    customer_id: Mapped[str] = mapped_column(String(50))
    billing_account_id: Mapped[str] = mapped_column(String(50))
    bill_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="open")
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    updated_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    use_case: Mapped["UseCase"] = relationship()
    control_cases: Mapped[List["ControlCase"]] = relationship(back_populates="issue")


class ControlCase(Base):
    __tablename__ = "control_cases"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # CC-P2-001
    issue_id: Mapped[str] = mapped_column(ForeignKey("issues.id"))
    status: Mapped[str] = mapped_column(String(30))
    thread_id: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    requires_human_approval: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)

    issue: Mapped["Issue"] = relationship(back_populates="control_cases")
    evidence_packs: Mapped[List["EvidencePack"]] = relationship(back_populates="control_case")
    audit_traces: Mapped[List["AuditTrace"]] = relationship(back_populates="control_case")
    approvals: Mapped[List["Approval"]] = relationship(back_populates="control_case")


class EvidencePack(Base):
    __tablename__ = "evidence_packs"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # EVP-P2-L3-001
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    source_layer: Mapped[str] = mapped_column(String(30))
    summary: Mapped[str] = mapped_column(Text)
    payload: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)

    control_case: Mapped["ControlCase"] = relationship(back_populates="evidence_packs")


class AuditTrace(Base):
    __tablename__ = "audit_traces"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)   # TRACE-P2-001
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    action_type: Mapped[str] = mapped_column(String(50))
    actor: Mapped[str] = mapped_column(String(50))
    summary: Mapped[str] = mapped_column(Text)
    details: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)

    control_case: Mapped["ControlCase"] = relationship(back_populates="audit_traces")


# ─────────────────────────────────────────────────────────────────────────────
# MVP2 Models
# ─────────────────────────────────────────────────────────────────────────────

class TMFEvent(Base):
    """TMF688-style event lifecycle table for event-driven correlation."""
    __tablename__ = "tmf_events"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # EVT-P1-001
    event_type: Mapped[str] = mapped_column(String(100))
    use_case_id: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    source_layer: Mapped[str] = mapped_column(String(10))                # L1, L2, L3, L4
    severity: Mapped[str] = mapped_column(String(20), default="medium")  # low, medium, high, critical
    status: Mapped[str] = mapped_column(String(20), default="new")       # new, correlated, resolved
    customer_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    description: Mapped[str] = mapped_column(Text)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    correlated_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


class Approval(Base):
    """Human approval record for high-risk agentic actions. Linked to LangGraph thread_id for resume."""
    __tablename__ = "approvals"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # APPR-P5-001
    thread_id: Mapped[str] = mapped_column(String(200))
    issue_id: Mapped[str] = mapped_column(String(50))
    control_case_id: Mapped[str] = mapped_column(ForeignKey("control_cases.id"))
    action: Mapped[str] = mapped_column(String(100))                     # e.g. "apply_compensation"
    risk_reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending")   # pending, approved, rejected
    approver_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    amount: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    decided_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)

    control_case: Mapped["ControlCase"] = relationship(back_populates="approvals")


class ServiceProblem(Base):
    """L3 OSS service problem lifecycle (TMF656-inspired)."""
    __tablename__ = "service_problems"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # SP-P5-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    customer_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    service_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    problem_type: Mapped[str] = mapped_column(String(100))               # service_degradation, outage, qos_breach
    severity: Mapped[str] = mapped_column(String(20), default="medium")
    status: Mapped[str] = mapped_column(String(20), default="open")      # open, investigating, resolved
    sla_breach: Mapped[bool] = mapped_column(Boolean, default=False)
    affected_period_start: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    affected_period_end: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    description: Mapped[str] = mapped_column(Text)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class TroubleTicket(Base):
    """L2 BSS trouble ticket (TMF621-inspired)."""
    __tablename__ = "trouble_tickets"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # TT-P6-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    customer_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    ticket_type: Mapped[str] = mapped_column(String(100))                # billing_dispute, service_complaint
    status: Mapped[str] = mapped_column(String(20), default="open")      # open, in_progress, resolved, closed
    priority: Mapped[str] = mapped_column(String(20), default="medium")
    description: Mapped[str] = mapped_column(Text)
    resolution: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    resolved_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class MediationJob(Base):
    """L3 mediation replay job tracking."""
    __tablename__ = "mediation_jobs"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # MJ-P1-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    job_type: Mapped[str] = mapped_column(String(50))                    # usage_replay, backlog_replay
    status: Mapped[str] = mapped_column(String(20), default="queued")    # queued, running, completed, failed
    events_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    events_replayed: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    payload: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    completed_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class CollectionsHold(Base):
    """L2 collections hold record for disputed balances."""
    __tablename__ = "collections_holds"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # HOLD-P6-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[str] = mapped_column(String(50))
    disputed_amount: Mapped[float] = mapped_column(Float)
    undisputed_amount: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    hold_reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="active")    # active, released, expired
    dunning_paused: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
    released_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)


class CompensationDecision(Base):
    """L2 compensation decision record for SLA breaches / service degradation."""
    __tablename__ = "compensation_decisions"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # COMP-P5-001
    issue_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    control_case_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    billing_account_id: Mapped[str] = mapped_column(String(50))
    compensation_type: Mapped[str] = mapped_column(String(50))           # credit, waiver, rebill, voucher
    amount: Mapped[float] = mapped_column(Float)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending")   # pending, approved, applied, rejected
    approval_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    applied_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)


class KGSnapshot(Base):
    """Metadata for NetworkX knowledge graph snapshots (derived read model from PostgreSQL)."""
    __tablename__ = "kg_snapshots"

    id: Mapped[str] = mapped_column(String(50), primary_key=True)        # KG-SNAP-001
    node_count: Mapped[int] = mapped_column(Integer, default=0)
    edge_count: Mapped[int] = mapped_column(Integer, default=0)
    build_duration_ms: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="ready")     # building, ready, stale
    built_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.utcnow)
