import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
import sys
import asyncio

# Windows fix: psycopg3 async requires SelectorEventLoop
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from app.main import app

@pytest.fixture
def anyio_backend():
    return "asyncio"

@pytest_asyncio.fixture
async def client():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c

# ─────────────────────────────────────────────
#  Health Check (MVP2 verification)
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_health_check(client):
    response = await client.get("/api/v1/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["mvp"] == "2"


@pytest.mark.anyio
async def test_use_case_flow_types_mvp2(client):
    response = await client.get("/api/v1/use-cases")
    assert response.status_code == 200
    flow_types = {item["id"]: item["flow_type"] for item in response.json()}

    for use_case_id in ["P1", "P2", "P3", "P4", "P5", "P6", "P8", "P9"]:
        assert flow_types[use_case_id] == "full_graph"

    assert flow_types["P7"] == "simplified_deterministic"
    assert flow_types["P10"] == "simplified_deterministic"

# ─────────────────────────────────────────────
#  Events Endpoints
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_get_events(client):
    response = await client.get("/api/v1/events")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)

@pytest.mark.anyio
async def test_simulate_event(client):
    response = await client.post("/api/v1/events/simulate/P5")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P5"
    assert "event_id" in data
    assert data["status"] == "new"
    assert "correlation" in data

# ─────────────────────────────────────────────
#  Approvals Endpoints
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_get_pending_approvals(client):
    response = await client.get("/api/v1/approvals/pending")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)

# ─────────────────────────────────────────────
#  Knowledge Graph Endpoints
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_kg_issue_relationships(client):
    # This requires the KG feature to be enabled and seeded
    response = await client.get("/api/v1/kg/issue/ISSUE-P5-001/relationships")
    assert response.status_code == 200
    data = response.json()
    assert "nodes" in data
    assert "edges" in data
    assert isinstance(data["nodes"], list)

# ─────────────────────────────────────────────
#  LangGraph Orchestration (Interrupt for Approval)
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_remediate_p5_interrupt(client):
    # P5 goes through full LangGraph and should interrupt for human approval
    # due to compensation amount threshold.
    response = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert response.status_code == 200
    data = response.json()
    assert data["use_case_id"] == "P5"
    # The LangGraph will pause because requires_human_approval will be True
    assert data["status"] == "pending_approval"
    assert "approval_id" in data
    assert "thread_id" in data

# ─────────────────────────────────────────────
#  Context Endpoints
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_customer_billing_context(client):
    response = await client.get("/api/v1/customers/CUST-100001/billing-context")
    assert response.status_code == 200
    data = response.json()
    assert data["customer_id"] == "CUST-100001"
    assert "billing_accounts" in data

# ─────────────────────────────────────────────
#  Human Approval Resume (P5)
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_remediate_p5_resume_after_approval(client):
    # 1. Trigger P5 remediation
    res1 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate")
    assert res1.status_code == 200
    data1 = res1.json()
    assert data1["status"] == "pending_approval"
    approval_id = data1["approval_id"]

    # 2. Approve the action
    res2 = await client.post(f"/api/v1/approvals/{approval_id}/approve", json={"notes": "Approved by test."})
    assert res2.status_code == 200
    assert res2.json()["status"] == "approved"

    # 3. Resume graph
    res3 = await client.post("/api/v1/issues/ISSUE-P5-001/remediate/resume")
    assert res3.status_code == 200
    data3 = res3.json()
    assert data3["final_state"]["is_remediated"] is True
    assert "audit_trace_id" in data3["final_state"]

# ─────────────────────────────────────────────
#  Other MVP2 LangGraphs (P1, P6, P9)
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_remediate_p1(client):
    response = await client.post("/api/v1/issues/ISSUE-P1-001/remediate")
    assert response.status_code == 200
    assert response.json()["status"] in ["remediated", "pending_approval"]
    assert response.json()["use_case_id"] == "P1"

@pytest.mark.anyio
async def test_remediate_p6(client):
    response = await client.post("/api/v1/issues/ISSUE-P6-001/remediate")
    assert response.status_code == 200
    assert response.json()["status"] in ["remediated", "pending_approval"]
    assert response.json()["use_case_id"] == "P6"

@pytest.mark.anyio
async def test_remediate_p9(client):
    response = await client.post("/api/v1/issues/ISSUE-P9-001/remediate")
    assert response.status_code == 200
    assert response.json()["use_case_id"] == "P9"

# ─────────────────────────────────────────────
#  MVP2 Chat Expansion
# ─────────────────────────────────────────────
@pytest.mark.anyio
async def test_chat_mvp2_intent(client):
    payload = {
        "conversation_id": "TEST-MVP2-001",
        "message": "Can you analyze the usage delay issue for my account?",
        "customer_id": "CUST-100001",
        "billing_account_id": "BA-100001",
    }
    response = await client.post("/api/v1/chat", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "final_response" in data
    assert len(data["final_response"]) > 0
