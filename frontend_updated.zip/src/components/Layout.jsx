import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import Chip from './Chip';

const Layout = () => {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="side-brand">Billing Control Tower</div>
        
        <nav className="menu">
          <NavLink 
            to="/csp" 
            className={({ isActive }) => `menu-link ${isActive ? 'active' : ''}`}
          >
            CSP Control Tower
          </NavLink>
          <NavLink 
            to="/agents" 
            className={({ isActive }) => `menu-link ${isActive ? 'active' : ''}`}
          >
            Agentic Control Tower
          </NavLink>
          <NavLink 
            to="/bills" 
            className={({ isActive }) => `menu-link ${isActive ? 'active' : ''}`}
          >
            Bills Drill-down
          </NavLink>
        </nav>

        <div className="side-logos">
          <div className="logo-row">
            <Chip align="left">TCS</Chip>
            <Chip align="left">etiya</Chip>
            <Chip align="left">CALVI</Chip>
            <Chip align="left">TMForum</Chip>
          </div>
          <div className="logo-row">
            <Chip align="right">vodafone</Chip>
            <Chip align="right">turk telecom</Chip>
            <Chip align="right">orange</Chip>
            <Chip align="right">stc</Chip>
          </div>
        </div>
      </aside>

      <main className="content overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
