import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './views/Dashboard';
import AgenticTower from './views/AgenticTower';
import BillsDrilldown from './views/BillsDrilldown';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/csp" replace />} />
          <Route path="csp" element={<Dashboard />} />
          <Route path="agents" element={<AgenticTower />} />
          <Route path="bills" element={<BillsDrilldown />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;

