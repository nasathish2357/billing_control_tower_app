import React, { useState, useEffect } from 'react';
import { getCases, investigateCase, chatCase, remediateCase } from '../api';
import Panel from '../components/Panel';
import { Play, Loader2, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const AgenticTower = () => {
  const [usecases, setUsecases] = useState([]);
  const [selectedCaseId, setSelectedCaseId] = useState('');
  const [runData, setRunData] = useState(null);
  const [messages, setMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [isInvestigating, setIsInvestigating] = useState(false);
  const [isChatting, setIsChatting] = useState(false);

  // Known cases for demo fallback
  const demoCases = [
    { usecaseId: 'CASE_TELCO_UC01', title: 'Delayed Usage Feed' },
    { usecaseId: 'CASE_TELCO_UC03', title: 'Zombie PDU Session' },
    { usecaseId: 'CASE_TELCO_UC04', title: 'Slice Entitlement' },
    { usecaseId: 'CASE_TELCO_UC07', title: 'Roaming Variance' },
    { usecaseId: 'CASE_TELCO_UC09', title: 'Proactive Anomaly' },
  ];

  useEffect(() => {
    getCases().then(res => {
      if (res.data && res.data.length > 0) {
        setUsecases(res.data);
      } else {
        setUsecases(demoCases);
      }
    }).catch(err => {
      console.error(err);
      setUsecases(demoCases);
    });
  }, []);

  const handleInvestigate = async () => {
    if (!selectedCaseId) return;
    setIsInvestigating(true);
    setRunData(null);
    try {
      const res = await investigateCase(selectedCaseId);
      setRunData(res.data);
    } catch (e) {
      console.error(e);
      // Fallback for demo if API fails
      setRunData({
        runId: 'RUN_DEMO_123',
        trace: [
          { node: 'Monitoring Agent', message: 'Detected anomaly in usage feed' },
          { node: 'Usage Integrity Agent', message: 'Verified 1.8GB gap in mediation' },
          { node: 'Bill Insight Agent', message: 'Staged bill note for correction' }
        ],
        findings: [{ title: 'Mediation Lag', detail: 'Lag > 10 min within cut-off window' }]
      });
    } finally {
      setIsInvestigating(false);
    }
  };

  const handleSendChat = async () => {
    if (!chatInput.trim() || !selectedCaseId) return;
    const userMsg = { role: 'user', content: chatInput };
    setMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsChatting(true);
    
    try {
      const res = await chatCase(selectedCaseId, chatInput);
      setMessages(prev => [...prev, { role: 'assistant', content: res.data.content }]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsChatting(false);
    }
  };

  const handleRemediate = async () => {
    if (!selectedCaseId) return;
    try {
      const res = await remediateCase(selectedCaseId);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `Remediation executed successfully. Action: ${res.data.action?.detail || 'Done.'}` 
      }]);
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: 'assistant', content: 'Failed to execute remediation.' }]);
    }
  };

  return (
    <div className="flex flex-col gap-5 h-full">
      <div className="flex items-center justify-between bg-white border border-[#dbe3ec] rounded-[22px] p-4 shadow-sm">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-bold text-[#0f172a] m-0">Select Investigation Case</h2>
          <select 
            className="picker"
            value={selectedCaseId}
            onChange={(e) => setSelectedCaseId(e.target.value)}
          >
            <option value="">-- Choose Case --</option>
            {usecases.map(c => (
              <option key={c.caseId || c.usecaseId || c.id} value={c.caseId || c.usecaseId || c.id}>
                {c.caseId || c.usecaseId || c.id} - {c.title}
              </option>
            ))}
          </select>
        </div>
        <button 
          onClick={handleInvestigate}
          disabled={!selectedCaseId || isInvestigating}
          className="flex items-center gap-2 px-6 py-2.5 bg-[#0f4c81] text-white font-bold rounded-xl hover:bg-[#0b2d4d] transition-colors disabled:opacity-50"
        >
          {isInvestigating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5" />}
          {isInvestigating ? 'Analyzing...' : 'Run Investigation'}
        </button>
      </div>

      <div className="panel-grid two flex-1 min-h-0">
        <Panel title="Agentic Flow Trace" className="flex flex-col">
          <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
            {!runData && !isInvestigating ? (
              <div className="h-40 flex items-center justify-center border-2 border-dashed border-[#dbe3ec] rounded-xl text-[#64748b]">
                Select a case and run investigation to see the trace.
              </div>
            ) : isInvestigating ? (
               <div className="h-40 flex flex-col items-center justify-center gap-3 text-[#0f4c81]">
                 <Loader2 className="w-8 h-8 animate-spin" />
                 <span className="font-semibold text-sm animate-pulse">Agents are working...</span>
               </div>
            ) : (
              <div className="space-y-4">
                {runData?.trace?.map((t, i) => (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    key={i} 
                    className="flex gap-4 group"
                  >
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        t.node.includes('layer') ? 'bg-[#e7f7ef] text-[#106b3b]' : 'bg-[#eef3f8] text-[#0f4c81]'
                      }`}>
                        {i + 1}
                      </div>
                      {i < runData.trace.length - 1 && <div className="w-px h-full bg-[#dbe3ec] mt-2" />}
                    </div>
                    <div className="flex-1 pb-4">
                      <div className="text-xs font-bold uppercase tracking-wider text-[#64748b] mb-1">{t.node}</div>
                      <div className="text-sm bg-[#f8fafc] p-3 rounded-xl border border-[#dbe3ec]">
                        {t.message}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </Panel>

        <div className="flex flex-col gap-5 min-h-0">
          <Panel title="Key Findings" className="max-h-[250px] overflow-y-auto custom-scrollbar">
            <div className="grid grid-cols-1 gap-3">
              {runData?.findings?.map((f, i) => (
                <div key={i} className="p-3 bg-[#fff3d6] border border-[#f3d28c] rounded-xl">
                  <div className="font-bold text-sm text-[#9a5b00] mb-1">{f.title}</div>
                  <div className="text-xs text-[#9a5b00]/80">{f.detail}</div>
                </div>
              ))}
              {!runData?.findings?.length && !isInvestigating && (
                <div className="text-[#64748b] text-sm italic">No findings available.</div>
              )}
            </div>
          </Panel>

          <Panel title="AI Assistant" className="flex-1 flex flex-col min-h-0">
             <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-2 mb-4">
              <AnimatePresence>
                {messages.map((m, i) => (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={i}
                    className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${
                      m.role === 'user' ? 'bg-[#0f4c81] text-white rounded-br-none' : 'bg-[#f8fafc] text-[#0f172a] rounded-bl-none border border-[#dbe3ec]'
                    }`}>
                      {m.content.replace('[ACTION:REMEDIATE]', '')}
                      {m.content.includes('[ACTION:REMEDIATE]') && (
                        <div className="mt-3 border-t border-[#dbe3ec] pt-3">
                          <button 
                            onClick={handleRemediate}
                            className="w-full bg-[#106b3b] text-white text-xs font-bold py-2 rounded-lg hover:bg-[#0c512c] transition-colors"
                          >
                            Approve Remediation
                          </button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {isChatting && (
                <div className="flex justify-start">
                  <div className="bg-[#f8fafc] border border-[#dbe3ec] p-3 rounded-2xl rounded-bl-none animate-pulse text-xs text-[#64748b]">AI is typing...</div>
                </div>
              )}
            </div>
            <div className="flex gap-2 mt-auto">
              <input 
                type="text" 
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendChat()}
                placeholder="Ask about the RCA..."
                className="flex-1 border border-[#dbe3ec] rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-[#0f4c81] bg-white"
              />
              <button 
                onClick={handleSendChat}
                className="p-2.5 bg-[#0f4c81] text-white rounded-xl hover:bg-[#0b2d4d] transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
};

export default AgenticTower;
