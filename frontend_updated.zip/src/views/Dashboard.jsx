import React, { useState, useEffect } from 'react';
import Tile from '../components/Tile';
import Panel from '../components/Panel';
import { getUsecases } from '../api';

const Dashboard = () => {
  useEffect(() => {
    // getUsecases().then(res => setUsecases(res.data)).catch(console.error);
  }, []);

  return (
    <div className="flex flex-col gap-5">
      <section className="top-strip">
        <Tile label="Protected Revenue" value="$1.84M" sub="This Month" />
        <Tile label="Avoided Impact" value="99.95%" sub="SLA Maintained" />
        <Tile label="Active Cases" value="6" sub="Agentic Investigation" />
        <Tile label="Approval Backlog" value="3" sub="Requires Action" />
        <Tile label="Pre-Bill Cases" value="6" sub="Quarantine / Replay" />
        <Tile label="Post-Bill Cases" value="8" sub="Correction / Credit" />
      </section>

      <section className="panel-grid two">
        <Panel title="Billing Portfolio">
          <div className="triple-section">
            <div>
              <h3>Use Case Specifics</h3>
              <div className="mini-grid">
                <div className="mini-card"><span>Duplicate charging</span><strong>1</strong></div>
                <div className="mini-card"><span>Usage integrity</span><strong>1</strong></div>
                <div className="mini-card"><span>Session fairness</span><strong>1</strong></div>
              </div>
            </div>
            <div>
              <h3>Pre-bill</h3>
              <div className="metric-grid">
                <div className="metric-card"><span>Protected Invoices</span><strong>1</strong></div>
                <div className="metric-card"><span>Rebill Candidates</span><strong>2</strong></div>
              </div>
            </div>
            <div>
              <h3>Post-bill</h3>
              <div className="metric-grid">
                <div className="metric-card"><span>Credits Posted</span><strong>2</strong></div>
                <div className="metric-card"><span>Pending Review</span><strong>3</strong></div>
              </div>
            </div>
          </div>
        </Panel>

        <Panel title="Actionable Focus">
          <div className="focus-list">
            <div className="focus-item">
              <div>
                <strong>Premium slice entitlement mismatch</strong>
                <span>ENT-200041 • NorthField Warehousing</span>
              </div>
              <span className="badge amber">Approval</span>
            </div>
            <div className="focus-item">
              <div>
                <strong>Sustained degradation compensation</strong>
                <span>ACC-100551 • Oliver P.</span>
              </div>
              <span className="badge amber">Approval</span>
            </div>
            <div className="focus-item">
              <div>
                <strong>Governed B2B multi-site dispute</strong>
                <span>ENT-200099 • Enterprise Multi-Site</span>
              </div>
              <span className="badge amber">Approval</span>
            </div>
          </div>
        </Panel>
      </section>

      <section className="panel-grid two">
        <Panel title="TM Forum API Mapping">
          <div className="api-grid">
             <div className="api-item"><span>TMF678</span><strong>CustomerBill</strong><span className="badge">10 Cases</span></div>
             <div className="api-item"><span>TMF621</span><strong>TroubleTicket</strong><span className="badge">8 Cases</span></div>
             <div className="api-item"><span>TMF688</span><strong>Event</strong><span className="badge">7 Cases</span></div>
             <div className="api-item"><span>TMF656</span><strong>ServiceProblem</strong><span className="badge">4 Cases</span></div>
          </div>
        </Panel>

        <Panel title="Resolution Mix">
          <div className="metric-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <div className="metric-card"><span>Auto-Resolved</span><strong>42%</strong></div>
            <div className="metric-card"><span>Guarded Action</span><strong>35%</strong></div>
            <div className="metric-card"><span>Human Review</span><strong>23%</strong></div>
          </div>
        </Panel>
      </section>
    </div>
  );
};

export default Dashboard;
