import React, { useState, useEffect } from 'react';
import Panel from '../components/Panel';
import { getUsecases } from '../api';

const BillsDrilldown = () => {
  const [usecases, setUsecases] = useState([]);
  const [selectedCase, setSelectedCase] = useState(null);
  const [search, setSearch] = useState('');

  // Known cases for demo fallback
  const demoCases = [
    { usecaseId: 'CASE_TELCO_UC01', title: 'Delayed Usage Feed', status: 'Open' },
    { usecaseId: 'CASE_TELCO_UC03', title: 'Zombie PDU Session', status: 'Investigating' },
    { usecaseId: 'CASE_TELCO_UC04', title: 'Slice Entitlement', status: 'Open' },
    { usecaseId: 'CASE_TELCO_UC07', title: 'Roaming Variance', status: 'Resolved' },
    { usecaseId: 'CASE_TELCO_UC09', title: 'Proactive Anomaly', status: 'Open' },
  ];

  useEffect(() => {
    getUsecases().then(res => {
      const data = (res.data && res.data.length > 0) ? res.data : demoCases;
      setUsecases(data);
      if (data.length > 0) {
        setSelectedCase(data[0]);
      }
    }).catch(err => {
      console.error(err);
      setUsecases(demoCases);
      setSelectedCase(demoCases[0]);
    });
  }, []);

  const filteredCases = usecases.filter(c => {
    const id = c.usecaseId || c.id || '';
    return c.title.toLowerCase().includes(search.toLowerCase()) || 
           id.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="panel-grid two" style={{ height: 'calc(100vh - 48px)' }}>
      <Panel className="list-pane flex flex-col h-full" title={
        <div className="flex justify-between items-center w-full">
          <span>Bills</span>
          <input 
            className="search text-sm font-normal" 
            placeholder="Search" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      }>
        <div className="bill-list">
          {filteredCases.map(c => (
            <div 
              key={c.usecaseId || c.id} 
              className={`bill-card ${selectedCase?.usecaseId === (c.usecaseId || c.id) || selectedCase?.id === (c.usecaseId || c.id) ? 'active' : ''}`}
              onClick={() => setSelectedCase(c)}
            >
              <div className="flex justify-between items-start mb-2">
                <strong>{c.usecaseId || c.id}</strong>
                <span className={`badge ${c.status === 'Open' ? 'amber' : 'green'}`}>{c.status || 'Active'}</span>
              </div>
              <span className="text-[#0f172a] text-sm">{c.title}</span>
            </div>
          ))}
        </div>
      </Panel>

      <div className="detail-pane h-full overflow-y-auto custom-scrollbar">
        {selectedCase ? (
          <>
            <div className="detail-grid">
              <div className="detail-block">
                <h3>Customer & Account</h3>
                <div className="bg-[#f8fafc] border border-[#dbe3ec] rounded-2xl p-4">
                  <div className="text-sm mb-2"><strong className="text-[#0f172a]">Customer:</strong> {selectedCase.title.split(' ')[0]} User</div>
                  <div className="text-sm mb-2"><strong className="text-[#0f172a]">Account:</strong> ACC-{selectedCase.usecaseId || selectedCase.id}</div>
                  <div className="text-sm"><strong className="text-[#0f172a]">Segment:</strong> Consumer</div>
                </div>
              </div>
              <div className="detail-block">
                <h3>Dispute Context</h3>
                <div className="bg-[#f8fafc] border border-[#dbe3ec] rounded-2xl p-4">
                  <div className="text-sm mb-2"><strong className="text-[#0f172a]">Category:</strong> {(selectedCase.usecaseId || selectedCase.id || '').replace('_', ' ')}</div>
                  <div className="text-sm mb-2"><strong className="text-[#0f172a]">Timing:</strong> Post-bill</div>
                  <div className="text-sm"><strong className="text-[#0f172a]">Outcome:</strong> Under Review</div>
                </div>
              </div>
            </div>

            <div className="detail-kpis">
               <div className="kpi"><span>Total</span><strong>$250.00</strong></div>
               <div className="kpi"><span>Disputed</span><strong>$50.00</strong></div>
               <div className="kpi"><span>Undisputed</span><strong>$200.00</strong></div>
               <div className="kpi"><span>Status</span><strong className="text-[#b7791f]">Pending</strong></div>
            </div>

            <div className="detail-block">
              <h3>Invoice Lines</h3>
              <div className="table bill">
                <div className="table-head">
                  <div>Service / Item</div>
                  <div>Qty</div>
                  <div>Rate</div>
                  <div>Total</div>
                  <div>Status</div>
                </div>
                <div className="table-row">
                  <div className="text-sm font-semibold">Base Plan</div>
                  <div className="text-sm text-[#64748b]">1</div>
                  <div className="text-sm text-[#64748b]">$200.00</div>
                  <div className="text-sm font-semibold">$200.00</div>
                  <div><span className="badge green">Valid</span></div>
                </div>
                <div className="table-row">
                  <div className="text-sm font-semibold text-[#0f172a]">{selectedCase.title}</div>
                  <div className="text-sm text-[#64748b]">1</div>
                  <div className="text-sm text-[#64748b]">$50.00</div>
                  <div className="text-sm font-semibold">$50.00</div>
                  <div><span className="badge amber">Disputed</span></div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-[#64748b]">
            Select a bill to view details.
          </div>
        )}
      </div>
    </div>
  );
};

export default BillsDrilldown;
