# Billing Control Tower — Investigation Playbooks

## UC01 — Missing or Delayed Usage Feed (Pre-bill)

**Issue family:** charging-integrity / mediation-delay

**Standard investigation steps:**
1. L4 detects collection or trigger gap — publishes suspected usage delay event
2. L1 Monitoring Agent correlates and opens control case
3. L1 requests L3 mediation backlog and replay feasibility evidence
4. L3 confirms replay is feasible and returns affected service count
5. L1 requests L2 billing exposure and bill-run state
6. L1 orchestrates L3 replay and L2 bill protection (hold affected charges)
7. Audit record written with full evidence chain

**Owner-layer actions:**
- L3 owns: mediation replay, usage re-collection, watermark correction
- L2 owns: bill-run hold, charge protection, account-level correction

**Key signals:**
- Mediation queue backlog > threshold
- Usage watermark lag > billing cycle boundary
- Missing CDR window in rating system

**TMF APIs:** TMF688 Event, TMF678 CustomerBill, mediation job controls

---

## UC02 — Duplicate Charging / Usage Rating (Pre-bill and Post-bill)

**Issue family:** charging-integrity / duplicate-rating

**Standard investigation steps:**
1. L2 ticketing agent opens dispute ticket for duplicate charge
2. L2 escalates to L1 when network-side evidence is needed
3. L1 requests L4 network trigger evidence (session updates, timing)
4. L4 returns duplicate interim update count and trigger pattern
5. L1 requests L3 mediation duplication evidence
6. L3 confirms duplicate export and suppression availability
7. L1 instructs L2 to apply credit/rebill
8. Audit record written

**Key signals:**
- Two charges for same addon within same billing cycle
- Repeated interim CDR updates with same content
- Mediation export batch replayed without suppression flag

**TMF APIs:** TMF621 TroubleTicket, TMF678 CustomerBill, TMF635 ProductUsage

---

## UC03 — Zombie PDU Session Leading to Unfair Data Charging (Post-bill)

**Issue family:** network-integrity / zombie-session

**Standard investigation steps:**
1. L4 detects SMF released / CHF still active state mismatch
2. L4 publishes zombie session suspected event
3. L1 Monitoring correlates and opens control case
4. L1 requests L4 deep RCA and safe session cleanup with rollback plan
5. L4 confirms zombie session root cause and impact scope
6. L1 requests L2 charge-impact assessment
7. L1 approves L4 resource remediation (session termination)
8. L2 applies charge correction for affected billing period

**Key signals:**
- SMF session status: released
- CHF/ABMF status: active (still deducting)
- UPF idle but CDR count still incrementing
- Session release time vs last usage report gap > 30 minutes

**TMF APIs:** TMF702 ResourceActivation, TMF678 CustomerBill, TMF688 Event

---

## UC04 — QoS or Slice Entitlement Mismatch with Premium Charging (Post-bill)

**Issue family:** service-quality / entitlement-mismatch

**Standard investigation steps:**
1. L2 BSS identifies premium charge without matching QoS evidence
2. L2 escalates to L1 for service validation
3. L1 requests L4 network slice evidence (actual 5QI vs expected)
4. L4 returns slice assignment and delivered technical state
5. L1 requests L3 SLA/QoS service-level evidence
6. L3 confirms delivered tier vs commercial promise
7. L1 instructs L2 to remove premium surcharge or apply compensation

**Key signals:**
- Actual 5QI > expected 5QI (lower priority delivered)
- Network slice: shared-standard vs dedicated-premium
- Service assurance QoS mismatch flag

**TMF APIs:** TMF638 ServiceInventory, TMF628 Performance, TMF678 CustomerBill

---

## UC05 — Service Degradation Requiring Commercial Compensation (Post-bill)

**Issue family:** service-quality / sla-breach

**Standard investigation steps:**
1. Customer raises service quality complaint via portal/care
2. L2 ticketing opens case
3. L2 triages and escalates to L1 for service evidence
4. L1 requests L3 SLA breach evidence (downtime window, severity)
5. L3 confirms SLA breach and recommended compensation band
6. L1 recommends compensation to L2
7. L2 applies credit and manages customer communication

**Compensation bands:**
- Low: < 30 minutes downtime → 5% credit
- Medium: 30–120 minutes → 10% credit
- High: > 120 minutes → 20% credit or goodwill offer

**TMF APIs:** TMF656 ServiceProblem, TMF628 Performance, TMF678 CustomerBill

---

## UC06 — Collections Hold Required During Billing Dispute (Post-bill)

**Issue family:** billing-dispute / collections-governance

**Standard investigation steps:**
1. Customer disputes invoice
2. L2 ticketing opens dispute ticket
3. L2 BSS identifies disputed amount and current dunning state
4. L2 applies disputed-balance hold to protect customer from collections
5. Collections hold confirmed in AR/collections system
6. Audit record written for compliance

**Key rule:** Disputed amounts must be separated from undisputed debt in collections.

**TMF APIs:** TMF621 TroubleTicket, TMF666 Account, TMF678 CustomerBill

---

## UC07 — Partner or Wholesale Charge Discrepancy (Post-bill)

**Issue family:** settlement / roaming-discrepancy

**Standard investigation steps:**
1. Customer reports unexpected roaming charges
2. L2 ticketing opens partner charge dispute
3. L2 escalates to L1 for partner network evidence
4. L1 requests L4 roaming/exposure evidence
5. L4 returns partner event mismatch and roaming window
6. L1 requests L3 mediation TAP file audit
7. L1 instructs L2 to apply retail credit while wholesale recovery proceeds

**Key signals:**
- TAP file processing delay
- PLMN mismatch in roaming records
- CDR timestamp discrepancy > 15 minutes

**TMF APIs:** TMF678 CustomerBill, TMF688 Event, TMF628 Performance

---

## UC08 — Confusing Invoice with Technically Valid Charges (Post-bill)

**Issue family:** billing-clarity / bill-explanation

**Standard investigation steps:**
1. Customer asks for bill explanation (not a formal dispute)
2. L2 care agent handles via bill explanation flow
3. L2 BSS fetches bill details, product context, usage summary
4. L2 generates customer-readable explanation
5. If explanation reveals genuine cross-domain mismatch → escalate to L1
6. Audit record written

**Key output:**
- Plain-language explanation of each line item
- Mapping of usage to plan and session periods
- Flagging of any items requiring follow-up

**TMF APIs:** TMF678 CustomerBill, TMF635 ProductUsage, TMF621 TroubleTicket (optional)

---

## UC09 — Internal Anomaly Discovered by Monitoring Before Customer Impact (Pre-bill)

**Issue family:** billing-risk / proactive-monitoring

**Standard investigation steps:**
1. Origin layer (L4 or L3) detects billing-risk anomaly proactively
2. Anomaly published to event plane
3. L1 Monitoring correlates and opens proactive control case
4. L1 requests evidence from affected layers
5. L1 coordinates preventive action (suppress, replay, bill protection)
6. Full trace written to audit before customer impact

**Key principle:** Contain before the bill runs.

**TMF APIs:** TMF688 Event, TMF678 CustomerBill, mediation controls

---

## UC10 — Governed End-to-End Dispute Handling (Pre-bill and Post-bill)

**Issue family:** billing-dispute / cross-domain-governance

**Standard investigation steps:**
1. Multi-domain issue escalated to L1
2. L1 creates governed control case with critical severity
3. L1 requests evidence from L2 (ticket, bill, collections)
4. L1 requests evidence from L3 (service impact, topology, replay)
5. L1 requests evidence from L4 (alarm RCA, session state, remediation options)
6. Human approval required for high-risk actions (class C/D)
7. Each layer executes its own remediation steps
8. Synchronized outcome and full audit trail written

**Approval classes:**
- Class A: read-only → no approval needed
- Class B: local low-risk → auto-approve
- Class C: cross-domain with policy gate → requires supervisor approval
- Class D: high-risk financial/network → requires multi-approver sign-off

**TMF APIs:** TMF621 TroubleTicket, TMF678 CustomerBill, TMF656 ServiceProblem, TMF642 Alarm, TMF702 ResourceActivation, Audit/evidence log
