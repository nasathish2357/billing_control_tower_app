from app.core.orchestrator import InvestigationOrchestrator
from app.db import SessionLocal
from app.db.models import CaseModel

db = SessionLocal()
orchestrator = InvestigationOrchestrator(db_session=db)
case = db.query(CaseModel).filter(CaseModel.usecase_id == 'telco_uc03').first()
result = orchestrator.run(case.case_id, "test_run_1")

print("Number of findings:", len(result['findings']))
for f in result['findings']:
    print(f['findingId'])

print("Number of completed agents:", len(result['completedAgents']))
for c in result['completedAgents']:
    print(c)
