from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import logging
import time
import uuid
import traceback

from app.api.router import router
from app.settings import settings
from app.db import init_db

# Configure standard logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%dT%H:%M:%SZ'
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize database tables
    init_db()
    yield


from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title=settings.app_name, 
    version=settings.version,
    lifespan=lifespan
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def log_requests(request: Request, call_next):
    trace_id = str(uuid.uuid4())
    request.state.trace_id = trace_id
    start_time = time.time()
    
    logger.info(f"Incoming Request - trace_id={trace_id} method={request.method} path={request.url.path}")
    
    try:
        response = await call_next(request)
        process_time = time.time() - start_time
        logger.info(f"Outgoing Response - trace_id={trace_id} status_code={response.status_code} latency_ms={process_time * 1000:.2f}")
        return response
    except Exception as e:
        process_time = time.time() - start_time
        logger.error(f"Unhandled Exception - trace_id={trace_id} method={request.method} path={request.url.path} latency_ms={process_time * 1000:.2f} error='{str(e)}'", exc_info=True)
        raise

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    trace_id = getattr(request.state, "trace_id", str(uuid.uuid4()))
    logger.error(f"Global Error Handler - trace_id={trace_id} error='{str(exc)}'", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal Server Error", "trace_id": trace_id, "detail": str(exc)},
    )

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    trace_id = getattr(request.state, "trace_id", str(uuid.uuid4()))
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": "HTTP Exception", "trace_id": trace_id, "detail": exc.detail},
    )

app.include_router(router)


@app.get('/health')
def health():
    return {
        'status': 'ok',
        'app': settings.app_name,
        'version': settings.version,
        'demoMode': settings.demo_mode,
        'llmProvider': settings.llm_provider,
        'retrievalLastIndexedAt': settings.retrieval_last_indexed_at,
    }
