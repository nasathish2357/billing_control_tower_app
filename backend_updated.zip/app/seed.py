from __future__ import annotations

from app.core.usecase_catalog import ALL_USECASES
from app.db.models import UseCaseModel, CustomerModel, BillingAccountModel, InvoiceModel, CaseModel, InvoiceLineModel


def build_seed_data() -> dict:
    usecases = ALL_USECASES

    customers = {
        'CUST_1001': {'id': 'CUST_1001', 'name': 'Acme Telecom Customer', 'segment': 'enterprise', 'billingAccountId': 'ACC_1001', 'jurisdiction': 'CA'},
        'CUST_1002': {'id': 'CUST_1002', 'name': 'Northwind Subscriber', 'segment': 'consumer', 'billingAccountId': 'ACC_1002', 'jurisdiction': 'TX'},
        'CUST_1003': {'id': 'CUST_1003', 'name': 'Contoso Mobile', 'segment': 'consumer', 'billingAccountId': 'ACC_1003', 'jurisdiction': 'WA'},
        'TELCO_CUST_EMMA': {'id': 'TELCO_CUST_EMMA', 'name': 'Emma (UC01)', 'segment': 'consumer', 'billingAccountId': 'ACC_EMMA', 'jurisdiction': 'UK'},
        'TELCO_CUST_DANIEL': {'id': 'TELCO_CUST_DANIEL', 'name': 'Daniel (UC02)', 'segment': 'consumer', 'billingAccountId': 'ACC_DANIEL', 'jurisdiction': 'UK'},
        'TELCO_CUST_SOPHIE': {'id': 'TELCO_CUST_SOPHIE', 'name': 'Sophie (UC03)', 'segment': 'consumer', 'billingAccountId': 'ACC_SOPHIE', 'jurisdiction': 'UK'},
        'TELCO_CUST_OLIVER': {'id': 'TELCO_CUST_OLIVER', 'name': 'Oliver (UC05)', 'segment': 'consumer', 'billingAccountId': 'ACC_OLIVER', 'jurisdiction': 'UK'},
        'TELCO_CUST_HANNAH': {'id': 'TELCO_CUST_HANNAH', 'name': 'Hannah (UC08)', 'segment': 'consumer', 'billingAccountId': 'ACC_HANNAH', 'jurisdiction': 'UK'},
        'TELCO_CUST_AMELIA': {'id': 'TELCO_CUST_AMELIA', 'name': 'Amelia (UC04)', 'segment': 'enterprise', 'billingAccountId': 'ACC_AMELIA', 'jurisdiction': 'UK'},
        'TELCO_CUST_JACK': {'id': 'TELCO_CUST_JACK', 'name': 'Jack (UC06)', 'segment': 'consumer', 'billingAccountId': 'ACC_JACK', 'jurisdiction': 'UK'},
        'TELCO_CUST_SOPHIA': {'id': 'TELCO_CUST_SOPHIA', 'name': 'Sophia (UC07)', 'segment': 'consumer', 'billingAccountId': 'ACC_SOPHIA', 'jurisdiction': 'UK'},
        'TELCO_CUST_LEO': {'id': 'TELCO_CUST_LEO', 'name': 'Leo (UC09)', 'segment': 'enterprise', 'billingAccountId': 'ACC_LEO', 'jurisdiction': 'UK'},
        'TELCO_CUST_MIA': {'id': 'TELCO_CUST_MIA', 'name': 'Mia (UC10)', 'segment': 'enterprise', 'billingAccountId': 'ACC_MIA', 'jurisdiction': 'UK'},
    }

    accounts = {
        'ACC_1001': {'id': 'ACC_1001', 'customerId': 'CUST_1001', 'status': 'active', 'currency': 'USD', 'autopay': False},
        'ACC_1002': {'id': 'ACC_1002', 'customerId': 'CUST_1002', 'status': 'active', 'currency': 'USD', 'autopay': True},
        'ACC_1003': {'id': 'ACC_1003', 'customerId': 'CUST_1003', 'status': 'active', 'currency': 'USD', 'autopay': False},
        'ACC_EMMA': {'id': 'ACC_EMMA', 'customerId': 'TELCO_CUST_EMMA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_DANIEL': {'id': 'ACC_DANIEL', 'customerId': 'TELCO_CUST_DANIEL', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_SOPHIE': {'id': 'ACC_SOPHIE', 'customerId': 'TELCO_CUST_SOPHIE', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_OLIVER': {'id': 'ACC_OLIVER', 'customerId': 'TELCO_CUST_OLIVER', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_HANNAH': {'id': 'ACC_HANNAH', 'customerId': 'TELCO_CUST_HANNAH', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_AMELIA': {'id': 'ACC_AMELIA', 'customerId': 'TELCO_CUST_AMELIA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_JACK': {'id': 'ACC_JACK', 'customerId': 'TELCO_CUST_JACK', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_SOPHIA': {'id': 'ACC_SOPHIA', 'customerId': 'TELCO_CUST_SOPHIA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_LEO': {'id': 'ACC_LEO', 'customerId': 'TELCO_CUST_LEO', 'status': 'active', 'currency': 'GBP', 'autopay': True},
        'ACC_MIA': {'id': 'ACC_MIA', 'customerId': 'TELCO_CUST_MIA', 'status': 'active', 'currency': 'GBP', 'autopay': True},
    }

    invoices = {
        'INV_2026_0001': {
            'id': 'INV_2026_0001', 'accountId': 'ACC_1001', 'customerId': 'CUST_1001', 'period': '2026-02', 'amount': 1890.0,
            'baselineAmount': 1180.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_0001', 'type': 'roaming', 'amount': 540.0, 'expected': 80.0},
                {'lineId': 'LINE_0002', 'type': 'plan', 'amount': 900.0, 'expected': 900.0},
                {'lineId': 'LINE_0003', 'type': 'discount_missing', 'amount': 450.0, 'expected': 200.0},
            ],
        },
        'INV_EMMA_01': {
            'id': 'INV_EMMA_01', 'accountId': 'ACC_EMMA', 'customerId': 'TELCO_CUST_EMMA', 'period': '2026-03', 'amount': 125.0,
            'baselineAmount': 45.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_E1', 'type': 'data-usage', 'amount': 80.0, 'expected': 0.0, 'description': 'Catch-up data usage from Feb'},
                {'lineId': 'LINE_E2', 'type': 'plan', 'amount': 45.0, 'expected': 45.0},
            ],
        },
        'INV_DANIEL_01': {
            'id': 'INV_DANIEL_01', 'accountId': 'ACC_DANIEL', 'customerId': 'TELCO_CUST_DANIEL', 'period': '2026-03', 'amount': 65.0,
            'baselineAmount': 45.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_D1', 'type': 'addon', 'amount': 10.0, 'expected': 10.0, 'description': '5G Data Booster'},
                {'lineId': 'LINE_D2', 'type': 'addon-dup', 'amount': 10.0, 'expected': 0.0, 'description': '5G Data Booster (Duplicate)'},
                {'lineId': 'LINE_D3', 'type': 'plan', 'amount': 45.0, 'expected': 45.0},
            ],
        },
        'INV_SOPHIE_01': {
            'id': 'INV_SOPHIE_01', 'accountId': 'ACC_SOPHIE', 'customerId': 'TELCO_CUST_SOPHIE', 'period': '2026-03', 'amount': 150.0,
            'baselineAmount': 50.0, 'status': 'issued',
            'lineItems': [
                {'lineId': 'LINE_S1', 'type': 'data-usage', 'amount': 100.0, 'expected': 0.0, 'description': 'Overage during idle PDU session'},
                {'lineId': 'LINE_S2', 'type': 'plan', 'amount': 50.0, 'expected': 50.0},
            ],
        },
    }

    scenarios = {
        'telco_uc01': {'customerId': 'TELCO_CUST_EMMA', 'accountId': 'ACC_EMMA', 'invoiceId': 'INV_EMMA_01', 'title': 'Emma - Delayed Usage Feed'},
        'telco_uc02': {'customerId': 'TELCO_CUST_DANIEL', 'accountId': 'ACC_DANIEL', 'invoiceId': 'INV_DANIEL_01', 'title': 'Daniel - Duplicate Charging'},
        'telco_uc03': {'customerId': 'TELCO_CUST_SOPHIE', 'accountId': 'ACC_SOPHIE', 'invoiceId': 'INV_SOPHIE_01', 'title': 'Sophie - Zombie PDU Session'},
        'telco_uc04': {'customerId': 'TELCO_CUST_AMELIA', 'accountId': 'ACC_AMELIA', 'invoiceId': None, 'title': 'Amelia - Slice Entitlement Mismatch'},
        'telco_uc05': {'customerId': 'TELCO_CUST_OLIVER', 'accountId': 'ACC_OLIVER', 'invoiceId': None, 'title': 'Oliver - Service Degradation'},
        'telco_uc06': {'customerId': 'TELCO_CUST_JACK', 'accountId': 'ACC_JACK', 'invoiceId': None, 'title': 'Jack - Collections Hold'},
        'telco_uc07': {'customerId': 'TELCO_CUST_SOPHIA', 'accountId': 'ACC_SOPHIA', 'invoiceId': None, 'title': 'Sophia - Roaming Variance'},
        'telco_uc08': {'customerId': 'TELCO_CUST_HANNAH', 'accountId': 'ACC_HANNAH', 'invoiceId': None, 'title': 'Hannah - Opaque Invoice'},
        'telco_uc09': {'customerId': 'TELCO_CUST_LEO', 'accountId': 'ACC_LEO', 'invoiceId': None, 'title': 'Leo - Proactive Anomaly Detection'},
        'telco_uc10': {'customerId': 'TELCO_CUST_MIA', 'accountId': 'ACC_MIA', 'invoiceId': None, 'title': 'Mia - Governed Dispute RCA'},
        'UC01': {'customerId': 'CUST_1001', 'accountId': 'ACC_1001', 'invoiceId': 'INV_2026_0001', 'title': 'Legacy Bill Shock'},
    }

    return {
        'usecases': usecases,
        'customers': customers,
        'accounts': accounts,
        'invoices': invoices,
        'scenarios': scenarios,
        'trouble_tickets': {
            'TT_EMMA_1': {'ticketId': 'TT_EMMA_1', 'customerId': 'TELCO_CUST_EMMA', 'status': 'open', 'description': 'Customer complaining about unexpected data usage charges.'},
            'TT_DANIEL_1': {'ticketId': 'TT_DANIEL_1', 'customerId': 'TELCO_CUST_DANIEL', 'status': 'open', 'description': 'Customer claims double charge for 5G booster.'},
            'TT_HANNAH_1': {'ticketId': 'TT_HANNAH_1', 'customerId': 'TELCO_CUST_HANNAH', 'status': 'open', 'description': 'Invoice lacks clarity on roaming fees.'},
            'TT_MIA_1': {'ticketId': 'TT_MIA_1', 'customerId': 'TELCO_CUST_MIA', 'status': 'escalated', 'description': 'B2B Governed Dispute for multi-site rollout billing.'}
        },
        'partner_settlements': {
            'INV_SOPHIA_01': {'invoiceId': 'INV_SOPHIA_01', 'partnerId': 'PRT_ROAM_EU', 'status': 'disputed', 'discrepancyAmount': 45.0, 'reason': 'TAP file processing delay'}
        },
        'entitlements': {
            'TELCO_CUST_AMELIA': {'customerId': 'TELCO_CUST_AMELIA', 'entitlements': [{'type': 'network_slice', 'level': 'premium', 'status': 'inactive_error', 'expected': 'active'}], 'lastUpdated': '2026-03-01T00:00:00Z'},
            'CUST_1001': {'customerId': 'CUST_1001', 'entitlements': [{'type': 'voice', 'level': 'unlimited', 'status': 'active'}]}
        },
        'payments': {
            'ACC_JACK': {'accountId': 'ACC_JACK', 'lastPaymentStatus': 'failed', 'failedReason': 'insufficient_funds', 'paymentDate': '2026-03-05T12:00:00Z'}
        },
        'collections': {
            'ACC_JACK': {'accountId': 'ACC_JACK', 'status': 'in_collections', 'dunningLevel': 2, 'holdApplied': True}
        },
        'service_assurance': {
            'ACC_EMMA': {'accountId': 'ACC_EMMA', 'slaBreach': False, 'networkEvents': ['Delayed mediation feed from 4G PGW.']},
            'ACC_OLIVER': {'accountId': 'ACC_OLIVER', 'slaBreach': True, 'downtimeMinutes': 145, 'networkEvents': ['Sustained 5G RAN degradation in sector 4.']},
            'ACC_LEO': {'accountId': 'ACC_LEO', 'slaBreach': False, 'networkEvents': ['Proactive anomaly detected: high latency on enterprise VPN.']}
        },
        'product_inventory': {
            'TELCO_CUST_DANIEL': {'customerId': 'TELCO_CUST_DANIEL', 'products': [{'id': 'PROD_5G_BOOSTER', 'name': '5G Data Booster', 'status': 'active', 'quantity': 1}]}
        },
        'tax_profiles': {},
        'fraud_alerts': {
            'TELCO_CUST_SOPHIE': {'customerId': 'TELCO_CUST_SOPHIE', 'alerts': [{'alertId': 'FA_001', 'type': 'zombie_session', 'severity': 'high', 'detail': 'Session active on CHF but released on SMF'}]},
            'TELCO_CUST_LEO': {'customerId': 'TELCO_CUST_LEO', 'alerts': [{'alertId': 'FA_002', 'type': 'usage_spike', 'severity': 'medium', 'detail': 'Unusual data exfiltration pattern detected'}]}
        },
        'identity_events': {
            'TELCO_CUST_SOPHIE': {'customerId': 'TELCO_CUST_SOPHIE', 'events': [{'eventId': 'ID_001', 'type': 'sim_swap_attempt', 'status': 'blocked'}]}
        },
        'retention_offers': {},
        'schedules': {},
        'evidence': {},
        'charging_plane': {
            'TELCO_CUST_SOPHIE': {
                'smf': {'status': 'released', 'release_time': '2026-03-01T23:59:59Z', 'ctf_trigger': 'sent'},
                'chf': {'status': 'active', 'last_update': '2026-03-02T08:00:00Z', 'abmf_state': 'deducting', 'rf_rating': 'standard_data'},
                'upf': {'status': 'idle', 'last_usage_report': '2026-03-02T07:55:00Z'},
                'cgf': {'cdr_count': 142, 'status': 'delivered_to_billing'}
            }
        }
    }


def seed_all(db):
    data = build_seed_data()
    
    for uc in data['usecases']:
        db.merge(UseCaseModel(
            usecase_id=uc['usecaseId'],
            title=uc['title'],
            description=uc.get('description', uc['title']),
            category=uc['category'],
            workflow=uc['workflow'],
            recommended_priority=uc.get('recommendedPriority', 'medium'),
            metadata_json={'persona': uc.get('persona')}
        ))
        
    for cid, c in data['customers'].items():
        db.merge(CustomerModel(
            customer_id=cid,
            name=c['name'],
            segment=c['segment'],
            jurisdiction=c['jurisdiction']
        ))
        
    for aid, a in data['accounts'].items():
        db.merge(BillingAccountModel(
            account_id=aid,
            customer_id=a['customerId'],
            status=a['status'],
            currency=a['currency'],
            autopay=a['autopay']
        ))
        
    for iid, i in data['invoices'].items():
        db.merge(InvoiceModel(
            invoice_id=iid,
            account_id=i['accountId'],
            customer_id=i['customerId'],
            period=i['period'],
            amount=i['amount'],
            baseline_amount=i['baselineAmount'],
            status=i['status']
        ))
        for li in i['lineItems']:
            db.merge(InvoiceLineModel(
                line_id=li['lineId'],
                invoice_id=iid,
                type=li['type'],
                amount=li['amount'],
                expected=li['expected'],
                description=li.get('description')
            ))
        
    for sid, s in data['scenarios'].items():
        db.merge(CaseModel(
            case_id=f"CASE_{sid.upper()}",
            usecase_id=sid,
            title=s['title'],
            customer_id=s['customerId'],
            account_id=s['accountId'],
            invoice_id=s['invoiceId'],
            priority='high',
            status='open'
        ))
        
    db.commit()



