from __future__ import annotations

import os
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any
from rank_bm25 import BM25Okapi
import re

class PlaybookRetriever:
    def __init__(self, playbooks_dir: str = "data/playbooks"):
        self.playbooks_dir = playbooks_dir
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.index = None
        self.bm25 = None
        self.documents = []
        self._initialize_index()

    def _initialize_index(self):
        if not os.path.exists(self.playbooks_dir):
            return

        chunks = []
        for filename in os.listdir(self.playbooks_dir):
            if filename.endswith(".md"):
                path = os.path.join(self.playbooks_dir, filename)
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                    # Simple chunking by playbook section (--- or ##)
                    sections = content.split("---")
                    for section in sections:
                        if section.strip():
                            chunks.append({
                                "text": section.strip(),
                                "source": filename
                            })

        if not chunks:
            return

        self.documents = chunks
        texts = [doc["text"] for doc in chunks]
        
        # Build FAISS Index
        embeddings = self.model.encode(texts)
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dimension)
        self.index.add(embeddings.astype('float32'))
        
        # Build BM25 Index
        tokenized_corpus = [self._tokenize(text) for text in texts]
        self.bm25 = BM25Okapi(tokenized_corpus)

    def _tokenize(self, text: str) -> List[str]:
        return re.findall(r'\w+', text.lower())

    def search(self, query: str, top_k: int = 2) -> List[Dict[str, Any]]:
        if self.index is None or self.bm25 is None:
            return []

        # 1. FAISS (Dense) Search
        query_vector = self.model.encode([query])
        # Search more to fuse later
        k_retrieve = min(10, len(self.documents))
        faiss_distances, faiss_indices = self.index.search(query_vector.astype('float32'), k_retrieve)
        
        # 2. BM25 (Sparse) Search
        tokenized_query = self._tokenize(query)
        bm25_scores = self.bm25.get_scores(tokenized_query)
        bm25_indices = np.argsort(bm25_scores)[::-1][:k_retrieve]

        # 3. Reciprocal Rank Fusion (RRF)
        rrf_scores = {i: 0.0 for i in range(len(self.documents))}
        k_rrf = 60
        
        for rank, idx in enumerate(faiss_indices[0]):
            if idx != -1:
                rrf_scores[idx] += 1.0 / (k_rrf + rank + 1)
                
        for rank, idx in enumerate(bm25_indices):
            rrf_scores[idx] += 1.0 / (k_rrf + rank + 1)
            
        # Sort by RRF score descending
        sorted_indices = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)
        
        results = []
        for idx in sorted_indices[:top_k]:
            if rrf_scores[idx] > 0:
                results.append(self.documents[idx])
        return results

# Singleton instance
_retriever = None

def get_retriever() -> PlaybookRetriever:
    global _retriever
    if _retriever is None:
        _retriever = PlaybookRetriever()
    return _retriever
