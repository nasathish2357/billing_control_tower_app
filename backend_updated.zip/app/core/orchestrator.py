from __future__ import annotations

import sqlite3
from typing import Any, TypedDict, Annotated, List, Literal
from operator import add

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver

from app.core.agents import execute_agent
from app.db.repository import PostgresRepository
from app.core.llm import get_llm_provider
from app.core.mcp import MCPClient
from app.core.retrieval import get_retriever
from app.settings import settings
import logging
import traceback

logger = logging.getLogger(__name__)


def merge_dicts(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    return {**a, **b}

class InvestigationState(TypedDict):
    caseId: str
    runId: str
    case: Annotated[dict[str, Any], "The case data"]
    context: Annotated[dict[str, Any], merge_dicts]
    findings: Annotated[List[dict[str, Any]], add]
    recommendations: Annotated[List[str], add]
    completedAgents: Annotated[List[str], add]
    playbooks: Annotated[List[dict[str, Any]], add]
    toolCalls: Annotated[List[dict[str, Any]], add]
    promptCatalog: Annotated[List[str], add]
    llmOutputs: Annotated[dict[str, Any], merge_dicts]
    trace: Annotated[List[dict[str, Any]], add]
    status: str
    next_node: str


class InvestigationOrchestrator:
    def __init__(self, db_session=None, llm=None, mcp=None):
        self.repo = PostgresRepository(db_session) if db_session else None
        self.db = db_session
        self.llm = llm or get_llm_provider()
        self.mcp = mcp or MCPClient()
        self.conn = sqlite3.connect(settings.checkpoint_sqlite_path, check_same_thread=False)
        self.checkpointer = SqliteSaver(self.conn)
        self.graph = self._build_graph()

    def _build_layer_subgraph(self, layer_name: str, node_fn):
        """Helper to build a layer-specific sub-graph."""
        builder = StateGraph(InvestigationState)
        builder.add_node("orchestrator", node_fn)
        builder.add_edge(START, "orchestrator")
        builder.add_edge("orchestrator", END)
        return builder.compile()

    def _build_graph(self):
        builder = StateGraph(InvestigationState)
        
        # Define layer sub-graphs as nodes
        bss_subgraph = self._build_layer_subgraph("layer_2_bss", self._layer_2_node)
        assurance_subgraph = self._build_layer_subgraph("layer_3_assurance", self._layer_3_node)
        resource_subgraph = self._build_layer_subgraph("layer_4_resource", self._layer_4_node)

        # Define main nodes
        builder.add_node("triage", self._triage_node)
        builder.add_node("retrieval", self._retrieval_node)
        builder.add_node("master_agent", self._master_node)
        builder.add_node("bss_layer", bss_subgraph)
        builder.add_node("assurance_layer", assurance_subgraph)
        builder.add_node("resource_layer", resource_subgraph)
        builder.add_node("remediation", self._remediation_node)
        builder.add_node("summarize", self._summarize_node)

        # Define edges
        builder.add_edge(START, "triage")
        builder.add_edge("triage", "retrieval")
        builder.add_edge("retrieval", "master_agent")
        
        builder.add_conditional_edges(
            "master_agent",
            self._route_from_master,
            {
                "layer_2": "bss_layer",
                "layer_3": "assurance_layer",
                "layer_4": "resource_layer",
                "remediate": "remediation",
                "finish": "summarize"
            }
        )
        
        # Layers return to master for next instruction
        builder.add_edge("bss_layer", "master_agent")
        builder.add_edge("assurance_layer", "master_agent")
        builder.add_edge("resource_layer", "master_agent")
        
        builder.add_edge("remediation", "summarize")
        builder.add_edge("summarize", END)
        
        # Compile with interrupt for human-in-the-loop remediation
        return builder.compile(
            checkpointer=self.checkpointer,
            interrupt_before=["remediation"]
        )

    def _trace(self, state: InvestigationState, node: str, message: str):
        seq = len(state.get('trace', [])) + 1
        return {'trace': [{'seq': seq, 'node': node, 'status': 'completed', 'message': message, 't': datetime.now(UTC).isoformat()}]}

    def _triage_node(self, state: InvestigationState) -> dict:
        case = self.repo.get_case(state['caseId']) if self.repo else {'case_id': state['caseId']}
        updates = {
            'case': {'caseId': case.case_id, 'usecaseId': case.usecase_id, 'customerId': case.customer_id, 'accountId': case.account_id, 'invoiceId': case.invoice_id} if hasattr(case, 'case_id') else case,
            'context': {},
            'status': 'running'
        }
        try:
            logger.info(f"[{state['runId']}] Running triage node")
            result = execute_agent('triage', {**state, **updates}, self.llm, self.mcp)
            return {
                'case': updates['case'],
                **result,
                **self._trace(state, 'triage', "Triage complete. Customer context gathered.")
            }
        except Exception as e:
            return {
                'findings': [{'title': 'Triage Error', 'detail': str(e), 'severity': 'high', 'type': 'system_error'}],
                'completedAgents': ['triage'],
                **self._trace(state, 'triage', f"Triage failed: {str(e)}")
            }

    def _retrieval_node(self, state: InvestigationState) -> dict:
        case_title = state['case'].get('title', '')
        usecase_id = state['case'].get('usecaseId', '')
        query = f"{case_title} {usecase_id}"
        retriever = get_retriever()
        results = retriever.search(query, top_k=3)
        return {
            'playbooks': results,
            'completedAgents': ['retrieval'],
            **self._trace(state, 'retrieval', f"Retrieved {len(results)} playbooks.")
        }

    def _master_node(self, state: InvestigationState) -> dict:
        # Master Agent (Closed Loop Control) logic
        return {
            'completedAgents': ['master_agent'],
            **self._trace(state, 'master_agent', "Master agent (Closed Loop Control) routing investigation...")
        }

    def _route_from_master(self, state: InvestigationState) -> Literal["layer_2", "layer_3", "layer_4", "remediate", "finish"]:
        case = state['case']
        completed = state.get('completedAgents', [])
        uid = case.get('usecaseId', '').lower()
        
        routing_map = {
            'telco_uc01': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc02': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
            'telco_uc03': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
            'telco_uc04': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc05': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc06': ['layer_2_bss'],
            'telco_uc07': ['layer_2_bss', 'layer_3_assurance'],
            'telco_uc08': ['layer_2_bss'],
            'telco_uc09': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
            'telco_uc10': ['layer_2_bss', 'layer_3_assurance', 'layer_4_resource'],
        }
        
        required_layers = routing_map.get(uid, ['layer_2_bss'])
        for layer in required_layers:
            if layer not in completed:
                return "_".join(layer.split("_")[:2])
        
        if state.get('recommendations') and 'remediation' not in completed:
            return "remediate"
        
        return "finish"

    def _layer_2_node(self, state: InvestigationState) -> dict:
        try:
            result = execute_agent('layer_2_bss', state, self.llm, self.mcp)
            return {**result, **self._trace(state, 'layer_2_bss', "Layer 2 (BSS) investigation complete.")}
        except Exception as e:
            return {'findings': [{'title': 'L2 Error', 'detail': str(e), 'severity': 'high', 'type': 'system_error'}], 'completedAgents': ['layer_2_bss'], **self._trace(state, 'layer_2_bss', f"L2 failed: {str(e)}")}

    def _layer_3_node(self, state: InvestigationState) -> dict:
        try:
            result = execute_agent('layer_3_assurance', state, self.llm, self.mcp)
            return {**result, **self._trace(state, 'layer_3_assurance', "Layer 3 (Assurance) investigation complete.")}
        except Exception as e:
            return {'findings': [{'title': 'L3 Error', 'detail': str(e), 'severity': 'high', 'type': 'system_error'}], 'completedAgents': ['layer_3_assurance'], **self._trace(state, 'layer_3_assurance', f"L3 failed: {str(e)}")}

    def _layer_4_node(self, state: InvestigationState) -> dict:
        try:
            result = execute_agent('layer_4_resource', state, self.llm, self.mcp)
            return {**result, **self._trace(state, 'layer_4_resource', "Layer 4 (Resource) investigation complete.")}
        except Exception as e:
            return {'findings': [{'title': 'L4 Error', 'detail': str(e), 'severity': 'high', 'type': 'system_error'}], 'completedAgents': ['layer_4_resource'], **self._trace(state, 'layer_4_resource', f"L4 failed: {str(e)}")}

    def _remediation_node(self, state: InvestigationState) -> dict:
        return {
            'completedAgents': ['remediation'],
            **self._trace(state, 'remediation', "Remediation applied successfully.")
        }

    def _summarize_node(self, state: InvestigationState) -> dict:
        return {
            'status': 'completed',
            'completedAgents': ['summarize'],
            **self._trace(state, 'summarize', "Investigation complete. Final summary generated.")
        }

    def run(self, case_id: str, run_id: str) -> dict[str, Any]:
        config = {"configurable": {"thread_id": run_id}}
        initial_state = {
            'caseId': case_id, 'runId': run_id, 'findings': [], 'recommendations': [],
            'completedAgents': [], 'playbooks': [], 'toolCalls': [], 'promptCatalog': [],
            'llmOutputs': {}, 'trace': [], 'context': {}
        }
        result = self.graph.invoke(initial_state, config=config)
        return dict(result)

    async def astream_run(self, case_id: str, run_id: str):
        """Native event streaming for LangGraph."""
        config = {"configurable": {"thread_id": run_id}}
        initial_state = {
            'caseId': case_id, 'runId': run_id, 'findings': [], 'recommendations': [],
            'completedAgents': [], 'playbooks': [], 'toolCalls': [], 'promptCatalog': [],
            'llmOutputs': {}, 'trace': [], 'context': {}
        }
        
        async for event in self.graph.astream_events(initial_state, config=config, version="v2"):
            kind = event["event"]
            if kind == "on_chat_model_stream":
                content = event["data"]["chunk"].content
                if content:
                    yield {"type": "token", "content": content, "node": event["metadata"].get("langgraph_node")}
            elif kind == "on_chain_start" and event["name"] == "InvestigationOrchestrator":
                pass # Root start
            elif kind == "on_chain_end" and event["name"] == "InvestigationOrchestrator":
                yield {"type": "done", "state": event["data"]["output"]}
            elif kind.endswith("_start"):
                node = event["metadata"].get("langgraph_node")
                if node:
                    yield {"type": "node_start", "node": node}
            elif kind.endswith("_end"):
                node = event["metadata"].get("langgraph_node")
                if node:
                    yield {"type": "node_end", "node": node, "output": event["data"].get("output")}


from datetime import datetime, UTC

