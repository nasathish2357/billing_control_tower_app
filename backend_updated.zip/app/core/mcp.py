from __future__ import annotations

from typing import Any, Callable
import logging
import traceback

from app.db import get_store

logger = logging.getLogger(__name__)


class MCPClient:
    def __init__(self):
        self.store = get_store()
        self.registry: dict[str, tuple[str, Callable[..., Any], dict[str, Any]]] = {}
        self._register_defaults()

    def _register(self, name: str, server: str, fn: Callable[..., Any], schema: dict[str, Any]):
        self.registry[name] = (server, fn, schema)

    def _register_defaults(self):
        self._register('tmf_get_customer', 'mock-tmf', lambda customer_id: self.store.seed['customers'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('tmf_get_billing_account', 'mock-tmf', lambda account_id: self.store.seed['accounts'].get(account_id, {}), {'account_id': 'str'})
        self._register('tmf_get_bill', 'mock-tmf', lambda invoice_id: self.store.seed['invoices'].get(invoice_id, {}), {'invoice_id': 'str'})
        self._register('tmf_get_trouble_ticket', 'mock-tmf', lambda ticket_id: self.store.seed['trouble_tickets'].get(ticket_id, {}), {'ticket_id': 'str'})
        self._register('custom_get_partner_settlement', 'mock-custom', lambda invoice_id: self.store.seed['partner_settlements'].get(invoice_id, {}), {'invoice_id': 'str'})
        self._register('custom_get_entitlements', 'mock-custom', lambda customer_id: self.store.seed['entitlements'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('custom_get_payment_profile', 'mock-custom', lambda account_id: self.store.seed['payments'].get(account_id, {}), {'account_id': 'str'})
        self._register('custom_get_collections_profile', 'mock-custom', lambda account_id: self.store.seed['collections'].get(account_id, {}), {'account_id': 'str'})
        self._register('custom_get_service_assurance', 'mock-custom', lambda account_id: self.store.seed['service_assurance'].get(account_id, {}), {'account_id': 'str'})
        self._register('custom_get_product_inventory', 'mock-custom', lambda customer_id: self.store.seed['product_inventory'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('custom_get_tax_profile', 'mock-custom', lambda customer_id: self.store.seed['tax_profiles'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('custom_get_fraud_alert', 'mock-custom', lambda customer_id: self.store.seed['fraud_alerts'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('custom_get_identity_event', 'mock-custom', lambda customer_id: self.store.seed['identity_events'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('custom_get_retention_offer', 'mock-custom', lambda customer_id: self.store.seed['retention_offers'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('custom_get_schedule', 'mock-custom', lambda customer_id: self.store.seed['schedules'].get(customer_id, {}), {'customer_id': 'str'})
        self._register('custom_get_charging_plane', 'mock-custom', lambda customer_id: self.store.seed.get('charging_plane', {}).get(customer_id, {}), {'customer_id': 'str'})

    def describe_tools(self, tool_names: list[str]) -> list[dict[str, Any]]:
        descriptions = []
        for name in tool_names:
            server, _, schema = self.registry[name]
            descriptions.append({'name': name, 'server': server, 'arguments': schema})
        return descriptions

    def call_tool(self, tool_name: str, **kwargs):
        server, fn, _ = self.registry.get(tool_name, ('unknown', None, None))
        if not fn:
            logger.error(f"Tool execution failed: '{tool_name}' not found in registry")
            return {'server': server, 'toolName': tool_name, 'arguments': kwargs, 'result': {'error': f"Tool {tool_name} not found"}}
            
        try:
            logger.info(f"Executing tool '{tool_name}' on server '{server}' with args: {kwargs}")
            result = fn(**kwargs)
            return {'server': server, 'toolName': tool_name, 'arguments': kwargs, 'result': result}
        except Exception as e:
            logger.error(f"Error executing tool '{tool_name}': {str(e)}\n{traceback.format_exc()}")
            return {'server': server, 'toolName': tool_name, 'arguments': kwargs, 'result': {'error': str(e), 'status': 'failed'}}
