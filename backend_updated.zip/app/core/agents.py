from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any
from datetime import datetime, UTC

from app.core.mcp import MCPClient
from app.core.prompts import PROMPTS


@dataclass
class AgentDefinition:
    name: str
    layer: int
    tools: list[str]


AGENTS: dict[str, AgentDefinition] = {
    # Layer 1: Governance & Control (Master / Orchestration)
    'triage': AgentDefinition('triage', 1, ['tmf_get_customer', 'tmf_get_billing_account']),
    'master_agent': AgentDefinition('master_agent', 1, []), # The "Closed Loop Control Agent"
    'governance': AgentDefinition('governance', 1, ['tmf_get_trouble_ticket']),
    
    # Layer 2: BSS Revenue & Care Ecosystem
    'layer_2_bss': AgentDefinition('layer_2_bss', 2, ['tmf_get_bill', 'custom_get_entitlements']),
    'bill_analyzer': AgentDefinition('bill_analyzer', 2, ['tmf_get_bill']),
    'entitlement_verifier': AgentDefinition('entitlement_verifier', 2, ['custom_get_entitlements']),
    
    # Layer 3: Service Assurance & Mediation Ecosystem
    'layer_3_assurance': AgentDefinition('layer_3_assurance', 3, ['custom_get_service_assurance', 'custom_get_partner_settlement']),
    'sla_validator': AgentDefinition('sla_validator', 3, ['custom_get_service_assurance']),
    'mediation_auditor': AgentDefinition('mediation_auditor', 3, ['custom_get_partner_settlement']),
    
    # Layer 4: Resource & Network Ecosystem
    'layer_4_resource': AgentDefinition('layer_4_resource', 4, ['custom_get_fraud_alert', 'custom_get_identity_event', 'custom_get_charging_plane']),
    'fraud_auditor': AgentDefinition('fraud_auditor', 4, ['custom_get_fraud_alert']),
    'network_auditor': AgentDefinition('network_auditor', 4, ['custom_get_charging_plane']),
    
    'summarize': AgentDefinition('summarize', 1, []),
}

# Mapping internal names for flexibility
LEGACY_AGENT_MAP = {
    'collect_case_context': 'triage',
    'bill_insight_agent': 'bill_analyzer',
    'usage_integrity_agent': 'mediation_auditor',
    'policy_validation_agent': 'entitlement_verifier',
    'service_assurance_agent': 'sla_validator',
    'fraud_review_agent': 'fraud_auditor',
}


def render_prompt(agent_name: str, *, case: dict[str, Any], context: dict[str, Any], findings: list[dict[str, Any]], invoice: dict[str, Any] | None, tool_specs: list[dict[str, Any]], playbooks: list[dict[str, Any]] = []) -> tuple[str, str]:
    # Fallback to a generic prompt if not in PROMPTS
    prompt = PROMPTS.get(agent_name, PROMPTS.get('collect_case_context'))
    system = prompt['system']
    
    playbook_text = "\n".join([f"Source: {p['source']}\n{p['text']}" for p in playbooks])
    user = prompt['user'].format(case=case, context=context, findings=findings, invoice=invoice, tools=tool_specs)
    if playbook_text:
        user += f"\n\nRelevant Standard Playbooks:\n{playbook_text}"
    return system, user


def _record_tool_calls(calls: list[dict[str, Any]]) -> list[dict[str, Any]]:
    previews = []
    for call in calls:
        result = call['result']
        preview = result if isinstance(result, (dict, list, str)) else str(result)
        previews.append({
            'server': call['server'],
            'toolName': call['toolName'],
            'arguments': call['arguments'],
            'resultPreview': preview,
        })
    return previews


def _create_finding(agent: str, finding_id: str, finding_type: str, severity: str, title: str, detail: str, evidence_ids: list[str], llm_summary: str) -> dict[str, Any]:
    return {
        'findingId': finding_id,
        'type': finding_type,
        'severity': severity,
        'title': title,
        'detail': detail,
        'evidenceIds': evidence_ids,
        'agent': agent,
        'llmSummary': llm_summary,
    }


def execute_agent(agent_name: str, state: dict[str, Any], llm, mcp: MCPClient) -> dict[str, Any]:
    case = state['case']
    invoice = state.get('context', {}).get('invoice')
    tool_calls = []
    
    def tool(name: str, **kwargs):
        call = mcp.call_tool(name, **kwargs)
        tool_calls.append(call)
        return call['result']

    agent_def = AGENTS.get(agent_name)
    if not agent_def:
        mapped_name = LEGACY_AGENT_MAP.get(agent_name)
        if mapped_name:
            return execute_agent(mapped_name, state, llm, mcp)
        raise ValueError(f"Unknown agent: {agent_name}")

    context_for_prompt = {}
    new_context = {}
    new_findings = []
    new_recommendations = []
    
    # --- Layered Logic & Sub-Agent Delegation ---
    
    if agent_name == 'triage':
        new_context['customer'] = tool('tmf_get_customer', customer_id=case['customerId'])
        new_context['account'] = tool('tmf_get_billing_account', account_id=case['accountId'])
        context_for_prompt = {'customer': new_context['customer'], 'account': new_context['account']}
        
    elif agent_name == 'layer_2_bss':
        # BSS Orchestrator delegates to sub-agents
        import logging
        l2_logger = logging.getLogger(__name__)
        l2_logger.info("L2 BSS Orchestrator delegating to sub-agents...")
        bill_res = execute_agent('bill_analyzer', state, llm, mcp)
        ent_res = execute_agent('entitlement_verifier', state, llm, mcp)
        
        new_context = {**bill_res['context'], **ent_res['context']}
        new_findings = bill_res['findings'] + ent_res['findings']
        new_recommendations = bill_res['recommendations'] + ent_res['recommendations']
        context_for_prompt = new_context

    elif agent_name == 'bill_analyzer':
        new_context['invoice'] = tool('tmf_get_bill', invoice_id=case['invoiceId'])
        context_for_prompt = {'invoice': new_context['invoice']}

    elif agent_name == 'entitlement_verifier':
        new_context['entitlements'] = tool('custom_get_entitlements', customer_id=case['customerId'])
        context_for_prompt = {'entitlements': new_context['entitlements']}
        
    elif agent_name == 'layer_3_assurance':
        # Assurance Orchestrator delegation
        sla_res = execute_agent('sla_validator', state, llm, mcp)
        med_res = execute_agent('mediation_auditor', state, llm, mcp)
        new_context = {**sla_res['context'], **med_res['context']}
        new_findings = sla_res['findings'] + med_res['findings']
        new_recommendations = sla_res['recommendations'] + med_res['recommendations']
        context_for_prompt = new_context

    elif agent_name == 'sla_validator':
        new_context['service'] = tool('custom_get_service_assurance', account_id=case['accountId'])
        context_for_prompt = {'service': new_context['service']}

    elif agent_name == 'mediation_auditor':
        new_context['partner_settlement'] = tool('custom_get_partner_settlement', invoice_id=case['invoiceId'])
        context_for_prompt = {'partnerSettlement': new_context['partner_settlement']}
        
    elif agent_name == 'layer_4_resource':
        # Resource Orchestrator delegation
        fraud_res = execute_agent('fraud_auditor', state, llm, mcp)
        net_res = execute_agent('network_auditor', state, llm, mcp)
        new_context = {**fraud_res['context'], **net_res['context']}
        new_findings = fraud_res['findings'] + net_res['findings']
        new_recommendations = fraud_res['recommendations'] + net_res['recommendations']
        context_for_prompt = new_context

    elif agent_name == 'fraud_auditor':
        new_context['fraud'] = tool('custom_get_fraud_alert', customer_id=case['customerId'])
        context_for_prompt = {'fraud': new_context['fraud']}

    elif agent_name == 'network_auditor':
        new_context['identity'] = tool('custom_get_identity_event', customer_id=case['customerId'])
        new_context['charging_plane'] = tool('custom_get_charging_plane', customer_id=case['customerId'])
        context_for_prompt = {'identity': new_context['identity'], 'chargingPlane': new_context['charging_plane']}

    elif agent_name == 'master_agent':
        context_for_prompt = {'findings': state.get('findings', [])}

    # --- LLM Execution ---
    
    tool_specs = mcp.describe_tools(agent_def.tools)
    playbooks = state.get('playbooks', [])
    system_prompt, user_prompt = render_prompt(agent_name, case=case, context=context_for_prompt, findings=state.get('findings', []), invoice=invoice, tool_specs=tool_specs, playbooks=playbooks)
    llm_response = llm.complete(agent_name=agent_name, system_prompt=system_prompt, user_prompt=user_prompt, tools=tool_specs)

    new_tool_calls = _record_tool_calls(tool_calls)

    # --- Post-Processing Findings ---
    
    if agent_name == 'triage':
        new_findings.append(_create_finding(agent=agent_name, finding_id='FND_TRIAGE', finding_type='context', severity='low', title='Case context collected', detail='Customer and account details verified.', evidence_ids=[], llm_summary=llm_response.content))
        
    elif agent_name == 'bill_analyzer' and new_context.get('invoice'):
        inv = new_context['invoice']
        overage = round(inv.get('amount', 0) - inv.get('baselineAmount', 0), 2)
        if overage > 0:
            new_findings.append(_create_finding(agent=agent_name, finding_id='FND_BSS_01', finding_type='billing-variance', severity='high' if overage > 50 else 'medium', title='Invoice variance detected', detail=f"Bill shock of {overage} GBP identified.", evidence_ids=['EVD_0001'], llm_summary=llm_response.content))
            new_recommendations.append(f"Apply credit for {overage} GBP if technical error is confirmed.")

    elif agent_name == 'sla_validator':
        service = new_context.get('service', {})
        if service.get('slaBreach'):
            new_findings.append(_create_finding(agent=agent_name, finding_id='FND_ASR_01', finding_type='sla-breach', severity='high', title='SLA Breach confirmed', detail='Network monitoring confirms service degradation during billing period.', evidence_ids=['EVD_0004'], llm_summary=llm_response.content))
            new_recommendations.append("Issue SLA compensation credit.")

    elif agent_name == 'network_auditor':
        cp = new_context.get('charging_plane')
        if cp and cp.get('smf', {}).get('status') == 'released' and cp.get('chf', {}).get('status') == 'active':
            new_findings.append(_create_finding(agent=agent_name, finding_id='FND_RES_01', finding_type='zombie-session', severity='high', title='Standard-Aligned Zombie PDU Detection', detail='SMF CTF released session at 23:59, but CHF (Nchf interface) remained active until 08:00 due to signaling timeout.', evidence_ids=['SMF_LOG_99', 'CHF_CDR_42'], llm_summary=llm_response.content))
            new_recommendations.append("Reverse CHF usage charges for the 8-hour zombie window.")

    return {
        'context': new_context,
        'findings': new_findings,
        'recommendations': new_recommendations,
        'toolCalls': new_tool_calls,
        'promptCatalog': [agent_name],
        'llmOutputs': {agent_name: llm_response.content},
        'completedAgents': [agent_name]
    }

