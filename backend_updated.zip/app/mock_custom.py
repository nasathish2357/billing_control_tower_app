from __future__ import annotations

from app.db import get_store


def get_partner_settlement(invoice_id: str) -> dict:
    return get_store().seed['partner_settlements'].get(invoice_id, {})


def get_entitlements(customer_id: str) -> dict:
    return get_store().seed['entitlements'].get(customer_id, {})


def get_payment_profile(account_id: str) -> dict:
    return get_store().seed['payments'].get(account_id, {})


def get_collections_profile(account_id: str) -> dict:
    return get_store().seed['collections'].get(account_id, {})


def get_service_assurance(account_id: str) -> dict:
    return get_store().seed['service_assurance'].get(account_id, {})


def get_product_inventory(customer_id: str) -> dict:
    return get_store().seed['product_inventory'].get(customer_id, {})


def get_tax_profile(customer_id: str) -> dict:
    return get_store().seed['tax_profiles'].get(customer_id, {})


def get_fraud_alert(customer_id: str) -> dict:
    return get_store().seed['fraud_alerts'].get(customer_id, {})


def get_identity_event(customer_id: str) -> dict:
    return get_store().seed['identity_events'].get(customer_id, {})


def get_retention_offer(customer_id: str) -> dict:
    return get_store().seed['retention_offers'].get(customer_id, {})


def get_schedule(customer_id: str) -> dict:
    return get_store().seed['schedules'].get(customer_id, {})

def get_charging_plane(customer_id: str) -> dict:
    return get_store().seed['charging_plane'].get(customer_id, {})
