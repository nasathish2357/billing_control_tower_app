from __future__ import annotations

import json
from datetime import datetime, UTC
from typing import Any, List, Optional

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.db.repository import PostgresRepository
from app.mock_tmf import get_bill
from app.core.orchestrator import InvestigationOrchestrator
from app.core.retrieval import get_retriever
from app.settings import settings


class ControlTowerService:
    def __init__(self, db: Session):
        self.repo = PostgresRepository(db)
        self.db = db

    def list_usecases(self) -> list[dict[str, Any]]:
        ucs = self.repo.get_usecases()
        return [
            {
                'usecaseId': uc.usecase_id,
                'title': uc.title,
                'description': uc.description,
                'category': uc.category,
                'recommendedPriority': uc.recommended_priority,
                'workflow': uc.workflow,
                **uc.metadata_json
            }
            for uc in ucs
        ]

    def get_usecase(self, usecase_id: str) -> dict[str, Any]:
        uc = self.repo.get_usecase(usecase_id)
        if not uc:
            raise HTTPException(status_code=404, detail=f'Use case {usecase_id} not found')
        return {
            'usecaseId': uc.usecase_id,
            'title': uc.title,
            'description': uc.description,
            'category': uc.category,
            'recommendedPriority': uc.recommended_priority,
            'workflow': uc.workflow,
            **uc.metadata_json
        }

    def list_cases(self) -> list[dict[str, Any]]:
        cases = self.repo.db.query(self.repo.CaseModel).all()
        return [self._serialize_case(c) for c in cases]

    def create_case(self, payload: dict[str, Any]) -> dict[str, Any]:
        # Validate usecase
        self.get_usecase(payload['usecaseId'])
        
        # In a real app we'd validate customer/account/invoice too
        case_id = f"CASE_{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
        payload['caseId'] = case_id
        
        case = self.repo.create_case(payload)
        return self._serialize_case(case)

    def get_case(self, case_id: str) -> dict[str, Any]:
        case = self.repo.get_case(case_id)
        if not case:
            raise HTTPException(status_code=404, detail=f'Case {case_id} not found')
        return self._serialize_case(case)

    def _serialize_case(self, case: Any) -> dict[str, Any]:
        return {
            'caseId': case.case_id,
            'usecaseId': case.usecase_id,
            'title': case.title,
            'customerId': case.customer_id,
            'accountId': case.account_id,
            'invoiceId': case.invoice_id,
            'status': case.status,
            'priority': case.priority,
            'notes': case.notes,
            'latestRunId': case.latest_run_id,
            'createdAt': case.created_at.isoformat() if case.created_at else None,
            'telecomContext': case.telecom_context,
            'chatHistory': case.chat_history,
            'backendActions': case.backend_actions
        }

    def patch_case(self, case_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        case = self.repo.update_case(case_id, payload)
        if not case:
            raise HTTPException(status_code=404, detail=f'Case {case_id} not found')
        return self._serialize_case(case)

    def investigate_case(self, case_id: str) -> dict[str, Any]:
        case = self.repo.get_case(case_id)
        if not case:
            raise HTTPException(status_code=404, detail=f'Case {case_id} not found')
            
        run_id = f"RUN_{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
        orchestrator = InvestigationOrchestrator(self.db)
        
        # This will now use the real LangGraph
        result = orchestrator.run(case_id, run_id)
        
        run_data = {
            'runId': run_id,
            'caseId': case_id,
            'status': result.get('status', 'running'),
            'completedAgents': result.get('completedAgents', []),
            'findings': result.get('findings', []),
            'recommendations': result.get('recommendations', []),
            'toolCalls': result.get('toolCalls', []),
            'trace': result.get('trace', []),
            'promptCatalog': result.get('promptCatalog', []),
            'llmOutputs': result.get('llmOutputs', {})
        }
        run = self.repo.create_run(run_data)
        
        self.repo.update_case(case_id, {
            'latest_run_id': run_id,
            'status': 'investigated'
        })
        
        return run_data

    def get_run(self, case_id: str, run_id: str) -> dict[str, Any]:
        run = self.repo.get_run(run_id)
        if not run or run.case_id != case_id:
            raise HTTPException(status_code=404, detail=f'Run {run_id} not found for case {case_id}')
        return {
            'runId': run.run_id,
            'caseId': run.case_id,
            'status': run.status,
            'completedAgents': run.completed_agents,
            'findings': run.findings,
            'recommendations': run.recommendations,
            'toolCalls': run.tool_calls,
            'trace': run.trace,
            'promptCatalog': run.prompt_catalog
        }

    async def stream_events(self, case_id: str, run_id: str):
        orchestrator = InvestigationOrchestrator(self.db)
        async for event in orchestrator.astream_run(case_id, run_id):
            if event["type"] == "token":
                yield f"event: token\ndata: {json.dumps({'content': event['content'], 'node': event['node']})}\n\n"
            elif event["type"] == "node_start":
                yield f"event: node_start\ndata: {json.dumps({'node': event['node']})}\n\n"
            elif event["type"] == "node_end":
                yield f"event: node_end\ndata: {json.dumps({'node': event['node'], 'output': event['output']})}\n\n"
            elif event["type"] == "done":
                # Save final state
                state = event["state"]
                run_data = {
                    'runId': run_id,
                    'caseId': case_id,
                    'status': state.get('status', 'running'),
                    'completedAgents': state.get('completedAgents', []),
                    'findings': state.get('findings', []),
                    'recommendations': state.get('recommendations', []),
                    'toolCalls': state.get('toolCalls', []),
                    'trace': state.get('trace', []),
                    'promptCatalog': state.get('promptCatalog', []),
                    'llmOutputs': state.get('llmOutputs', {})
                }
                self.repo.create_run(run_data)
                self.repo.update_case(case_id, {'latest_run_id': run_id, 'status': 'investigated' if state.get('status') != 'completed' else 'completed'})
                yield f"event: done\ndata: {json.dumps(run_data)}\n\n"

    def remediate_case(self, case_id: str) -> dict[str, Any]:
        case = self.get_case(case_id)
        run_id = case.get('latestRunId')
        if not run_id:
            raise HTTPException(status_code=400, detail="No active investigation found to remediate.")
            
        orchestrator = InvestigationOrchestrator(self.db)
        config = {"configurable": {"thread_id": run_id}}
        
        # Resume the graph (null input resumes from breakpoint)
        result = orchestrator.graph.invoke(None, config=config)
        
        action = {
            'type': 'remediate',
            'timestamp': datetime.now(UTC).isoformat(),
            'detail': f"Human approved remediation for {case['usecaseId']}. Graph resumed."
        }
        
        backend_actions = case.get('backendActions', [])
        backend_actions.append(action)
        
        # Update run in DB with results after resumption
        run_data = {
            'runId': run_id,
            'status': result.get('status', 'completed'),
            'completedAgents': result.get('completedAgents', []),
            'findings': result.get('findings', []),
            'recommendations': result.get('recommendations', []),
            'trace': result.get('trace', [])
        }
        self.repo.create_run(run_data) # This will update if it exists or create new if we use a different repo method, but create_run usually handles it
        
        self.repo.update_case(case_id, {
            'status': 'remediated',
            'backend_actions': backend_actions
        })
        
        return {'status': 'success', 'action': action, 'result': run_data}

    def chat_case(self, case_id: str, message: str) -> dict[str, Any]:
        case_data = self.get_case(case_id)
        runs = self.repo.get_runs_for_case(case_id)
        latest_run = runs[0] if runs else None
        
        # Gather context for the chat agent
        findings = latest_run.findings if latest_run else []
        recommendations = latest_run.recommendations if latest_run else []
        
        # Search playbooks for the user's message
        retriever = get_retriever()
        relevant_playbooks = retriever.search(message, top_k=2)
        playbook_context = "\n".join([p['text'] for p in relevant_playbooks])
        
        # Build prompt
        history = case_data.get('chatHistory', [])
        
        from app.core.llm import get_llm_provider
        llm = get_llm_provider()
        
        system_prompt = f"""You are the Billing Control Tower Assistant. 
You help users understand billing investigations and can execute remediation.
Current Case: {case_data['title']} ({case_data['usecaseId']})
Findings: {json.dumps(findings)}
Recommendations: {json.dumps(recommendations)}

Standard Playbook Guidance:
{playbook_context}

Be concise, technical, and helpful. Use the standard terms (CHF, SMF, TMF) if applicable.
If the user explicitly asks to solve, fix, remediate, or apply credit based on recommendations, you MUST include the exact string `[ACTION:REMEDIATE]` anywhere in your response. This will trigger the UI to present a remediation approval flow.
"""
        user_prompt = f"Previous History: {json.dumps(history[-5:])}\nUser Message: {message}"
        
        response = llm.complete(
            agent_name="chat_assistant",
            system_prompt=system_prompt,
            user_prompt=user_prompt
        )
        
        chat_entry = {
            'role': 'assistant',
            'content': response.content,
            'timestamp': datetime.now(UTC).isoformat()
        }
        
        # Update history
        history.append({'role': 'user', 'content': message, 'timestamp': datetime.now(UTC).isoformat()})
        history.append(chat_entry)
        
        self.repo.update_case(case_id, {'chat_history': history})
        return chat_entry

    def search(self, q: str, entity_type: str | None = None) -> dict[str, Any]:
        retriever = get_retriever()
        results = retriever.search(q, top_k=5)
        return {'query': q, 'results': results}

    def reindex(self) -> dict[str, Any]:
        retriever = get_retriever()
        retriever._initialize_index()  # Re-scans data/playbooks
        return {
            'status': 'completed', 
            'indexedDocuments': len(retriever.documents), 
            'indexedAt': datetime.now(UTC).isoformat()
        }

