backend code final correction and FE correction(Note both FE and backend integration not complete):

Overall expectation:
1. front end missing layer architecture and correct agent sequence in agent in action trace. refer those sections alone based on reference/tmforum_billing_dispue_ui_pack and add the same in FE code.   Note frontend package tech stack remain same no change.FE is standalone already working with mock data. 
2. Explore both backend and frontend(most of the details present in files itself), 
       a) plan  how to streamline data mismatches between fe mock and backend seed.
       b) Assess layering of agents and agent flow mismatches across FE and backend
       c) Truly agentic is expected. As of now latency not matters.
       
       
3. Final integration of working FE and backend 

there is existing implementation_plan.md and integration_plan.md partially correct, parially stale as well. please refactor based on ur assessment. 


In case if would like to verify what was original usecases please refer the reference folder first sheet of telecom_billing_dispute_network_usecases_v0.4_updated excel

I will give what will be UI user experience look like. so that backend can become more robust, currently i see disconnection in seed data which is present and UI mock. Agent reasoning is not utilizing playbook/kg in full potential, i could see it is more like  rule based db state changes only. Db state changes are fine, but it should make meaningful state transitions based on reasoning by agents., not simple rule based state changes.

1. Here UI will have drop down of all 10 issues each corresponding respective usecases. There will simulate button, to simulate the issue. This will act as simulation of issues where we injecting issues in the respective layer backend system. Once simulation complete, it is now ready for remediation. for example network layer induced billing issue is a cross domain issue, so network event already triggered and also bss event also already triggered from different layers. Now event db has the states of events. Please refer below what simulation will look like, but think logically based telecom tmforum,3gpp standards and layer architecture i provided

Simulation contains below sequence(network layer induced billing issue is a cross domain issue):

1.  SMF triggers CTF twice in network layer
2.  This induces duplicate records in L4(Network layer)  and L2(BSS layer) in respective systems
3.  Now event each layer raises duplicate event separately on  eventdb. 
 

2. Issues will also have remediate button, once we click remediate button, mid section of UI will start streaming the agent trace in action, not exactly look like this rathe it should show the exact sequence and time and tool calls and its thought process etc.
      
           L1 Monitoring Agent will correlate the events based playbooks. Once create the issue events state become correlated/in progress so that it again this events will not become correlated - Details of though
           L1 Monitoring Agent creating issue - Details of issue.
           Handing over to L1 Master agent to collect the evidence
           L1 Master agent collecting customer/account details from L2 BSS Orchestration agent
           L2 BSS Orchestration agent internally will collect this details from its own sub agent via tmforum apis
           then L1 Master Agent calling L4 Orchestration Agent asking relevant details for understanding network issues
           L4 Orchestration Agent calling its sub agent to collect the network related evidence details
           L1 master agent analysis the issues based on the details and remediate CDR replay via L3 OSS Orchetration Agent
           L3 OSS Orchestration Agent replay the CDR and solve duplicate usage details or delayed usage details due to network zombie PDU sessions 
           Once issue reolved L3 OSS Orchestration agent will handover to L1 master agent to validate the fix and close the issue
           L1 master agent validate the issue and close the ticket and events state will become closed.
            
Notes that: reasoning will happen through tool calls, playbooks(vector db calls), KG calls. That also will be shown.

3.  Post this trace section, there will final section will show the summary of finding and resolution and next steps of any.
4.  Above steps applicable for all usecases, where for few usecases remediation may require human approval, where UI will prompt for human approval once done then trace will continue
5.  Chat window will be separate section where as a csp ops team, i can ask any questions.


Over all high level functionality:

Simulate the issues, Remediate the issues via agentic systems by reasoning within layer or across layers, chat functionality.


Please clarify with me any questions which you are not clear before ur assessment. This will help u we come in common understanding.
            