# Extensive Integration Plan: Billing Control Tower MVP3

This document outlines the comprehensive strategy to integrate the stable MVP3 agentic backend with the draft React frontend. This ensures all telecom dispute use cases (P1-P10) are handled seamlessly by the hierarchical LangGraph agentic architecture and accurately reflected in the user interface.

## 1. Comprehensive Use Case Assessment

The control tower resolves the following 10 telecom billing disputes using a deterministic multi-agent graph, triggered via a unified remediation endpoint (`POST /issues/{id}/remediate`).

*   **P1: Missing/Delayed Usage Feed**: Mediation backlog causes late billing. Handled by `simulation/inject?simulation_type=usage_delay`. Triggers L1 Supervisor → L3 Service Assurance.
*   **P2: Duplicate Charging**: Rating engine records the same usage twice. Handled by `duplicate_charge` simulation.
*   **P3: Zombie PDU Session**: Data charges accrued after session termination. Handled by `zombie_pdu_session` simulation.
*   **P4: QoS/Slice Entitlement Mismatch**: Premium charge for standard performance. Handled by `qos_mismatch` simulation.
*   **P5: Service Degradation SLA Breach**: Requires commercial compensation. Handled by `sla_breach` simulation. Triggers Human Approval (`requires_human_approval=True`).
*   **P6: Collections Hold**: Halting dunning while dispute is active. Uses `CollectionsHold` record.
*   **P7: Partner/Wholesale Discrepancy**: Roaming or MVNO charge mismatch. Handled by `partner_discrepancy` simulation.
*   **P8: Confusing Invoice**: Technically valid charges but opaque. Routed via SSE Streaming (`POST /chat/stream`).
*   **P9: Internal Anomaly (Proactive Risk)**: Caught before bill generation. Handled by `proactive_risk` simulation.
*   **P10: Governed B2B Multi-Site Dispute**: Cross-domain dispute requiring multi-layered audit and approvals.

All use cases (except P8) route through the **same agentic backbone**, removing the need for frontend-side logic branches.

---

## 2. API Layer Modifications (`frontend/src/api.js`)

We will completely rewrite `api.js` to map to the new `/api/v1/` routes.

**Updates:**
*   `baseURL`: Change from `http://localhost:8000/api` to `http://localhost:8000/api/v1`.
*   `getIssues()`: `GET /issues` (replaces `getCases()`).
*   `getUseCases()`: `GET /use-cases`.
*   `remediateIssue(id)`: `POST /issues/{id}/remediate` (Triggers the LangGraph agentic flow).
*   `chatWithAgent(conversation_id, msg, customer_id, account_id)`: `POST /chat` (Fallback for SSE, non-streaming integration).
*   **New - Dashboard APIs**:
    *   `getDashboardSummary()`: `GET /dashboard/summary`
    *   `getLayerHealth()`: `GET /dashboard/layer-health`
    *   `getPostbillDisputes()`: `GET /dashboard/postbill-disputes`
    *   `getPrebillRisks()`: `GET /dashboard/prebill-risks`
    *   `getAuditSummary()`: `GET /dashboard/audit-summary`
*   **New - Evidence & Context**:
    *   `getControlCaseEvidence(control_case_id)`: `GET /control-cases/{control_case_id}/evidence`
*   **New - Approval APIs**:
    *   `getPendingApprovals()`: `GET /approvals/pending`
    *   `approveAction(approval_id, payload)`: `POST /approvals/{approval_id}/approve`
    *   `resumeRemediation(issue_id)`: `POST /issues/{issue_id}/remediate/resume`
*   **New - Simulation APIs**:
    *   `injectSimulation(type)`: `POST /simulation/inject`
*   **New - Mock TMF APIs**:
    *   `getCustomerBills(account_id)`: `GET /mock-tmf/customer-bill`
    *   `getBillLineItems(bill_id)`: `GET /mock-tmf/customer-bill/{bill_id}/line-items`
    *   `getBillContext(account_id)`: `GET /billing-accounts/{account_id}/bill-comparison`

---

## 3. UI Component Modifications

### A. Dashboard View (`frontend/src/views/Dashboard.jsx`)
Replace the static demo values with real-time backend state.
*   **Top Strip (KPIs)**:
    *   `Protected Revenue`: Derived from `financial_exposure.total_disputed_usd`.
    *   `Avoided Impact`: Derived from `issues.remediation_rate_pct`.
    *   `Active Cases`: Derived from `control_cases.active`.
    *   `Approval Backlog`: Derived from `approvals.pending`.
    *   `Pre-Bill Cases`: Derived from `getPrebillRisks()`.
*   **Billing Portfolio**: Map to `issues.by_use_case` distribution.
*   **Actionable Focus**: Populate using `getPendingApprovals()`. Each focus item will render a pending human interrupt task, showing the `risk_reason` and `amount`.
*   **Resolution Mix / API Mapping**: Dynamically populated based on `getAuditSummary()`.

### B. Agentic Tower View (`frontend/src/views/AgenticTower.jsx`)
This view controls the agentic remediation flow.
*   **Issue Selector**: Populated via `getIssues()`. Add a "Simulate Scenario" button beside the selector to quickly generate a new issue using `POST /simulation/inject`.
*   **Run Investigation**: Calls `remediateIssue(id)`. 
    *   If the response returns `status: "remediated"`, we populate the final summary. We will call `getControlCaseEvidence(control_case_id)` to map `EvidencePack` objects (`source_layer`, `summary`) into the frontend's `runData.trace` array so the Agentic Flow UI renders perfectly.
    *   If the response returns `status: "pending_approval"`, we pause the trace and show the **"Approve Remediation"** button.
*   **Approve Remediation**: Calls `approveAction(approval_id)` and immediately follows up with `resumeRemediation(issue_id)` to unblock and finish the agentic graph. We then refresh the evidence.
*   **AI Assistant**: Connect the chat input to `POST /chat` to allow users to ask questions about the RCA.

### C. Bills Drilldown View (`frontend/src/views/BillsDrilldown.jsx`)
Move away from mocking usecases in the bill drilldown.
*   **Bill List (Left Pane)**: Call `getPostbillDisputes()` or `getCustomerBills()` to list all active bills in the system.
*   **Detail Grid**: Show customer/account summary utilizing `GET /customers/{id}/billing-context`.
*   **Invoice Lines**: Map the table to `getBillLineItems(bill_id)`. Display the TMF678 `chargeType`, `amount`, and `disputeFlag`. Render "Disputed" or "Valid" badges based on `disputeFlag`.

---

## 4. Verification & Testing Strategy

1.  **Backend Pre-requisites**: Run the backend with `uvicorn app.main:app --reload`.
2.  **Simulation Check**: From the UI (or Swagger), inject `usage_delay` and `sla_breach`.
3.  **End-to-End Test 1 (Autonomous)**: Select the injected P1 (usage delay) issue in Agentic Tower. Click "Run Investigation". Validate that it resolves automatically without human intervention and the trace populates from Evidence Packs.
4.  **End-to-End Test 2 (Human-in-the-loop)**: Select the injected P5 (SLA breach) issue. Click "Run Investigation". Validate that the UI correctly stops and prompts for Approval. Click "Approve Remediation" and verify that it calls `resumeRemediation`, the graph finishes, and marks the issue as resolved.
5.  **Dashboard Check**: Navigate to the Dashboard and verify that KPIs, Pre-bill Risks, and Actionable Focus lists update dynamically.

---

## 5. UI Trace Streaming Strategy

Currently, the `POST /issues/{issue_id}/remediate` endpoint is synchronously blocking, meaning the UI freezes until the entire LangGraph execution completes (or pauses). To provide a live streaming experience of the agentic trace for all use cases, we will refactor the trigger mechanism:

1. **Backend Refactor**: Modify `/remediate` to create a `ControlCase`, launch `asyncio.create_task` to run the agentic graph in the background, and return immediately with `{"status": "investigating", "control_case_id": cc_id}`. 
2. **Database State Persistence**: The background task will update the `ControlCase` status to `remediated` or `pending_approval` upon completion.
3. **Frontend Polling**: In `AgenticTower.jsx`, while `isInvestigating` is true, the frontend will poll `GET /control-cases/{control_case_id}/evidence` to stream the trace incrementally to the UI. It will also poll `GET /control-cases/{control_case_id}` to detect when the graph reaches a terminal state (`remediated` or `pending_approval`).
