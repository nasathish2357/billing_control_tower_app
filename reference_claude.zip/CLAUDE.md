# Billing Control Tower — Codebase Guide

## What this system is

TMForum Catalyst demonstration of an **Agentic AI Billing Dispute** platform.
10 use cases (P1–P10) cover the full lifecycle: pre-bill prevention → post-bill dispute → governed resolution.
Every issue flows through a multi-layer LangGraph agent graph; the FE streams and visualises it live.

---

## Repository layout

```
billing_control_tower_app/
├── backend/
│   ├── app/
│   │   ├── api/v1/           ← FastAPI routers (one file per domain)
│   │   ├── agents/           ← LangGraph graph + tools
│   │   │   ├── graph_builder.py      ← 22-node hierarchical graph definition
│   │   │   ├── agent_state.py        ← TypedDict AgentState
│   │   │   ├── chat_graph.py         ← P8 chat/explain SSE generator
│   │   │   ├── approval_manager.py   ← HITL approval helpers
│   │   │   ├── checkpoint_setup.py   ← AsyncPostgresSaver / MemorySaver switch
│   │   │   └── tools/
│   │   │       ├── l1_tools.py       ← L1 tools: risk, policy, audit, simulation, events
│   │   │       ├── shared_tools.py   ← Tools shared across L2/L3/L4 agents
│   │   │       └── factory.py        ← Agent factory (creates ReAct agents)
│   │   ├── kg/               ← Knowledge Graph (NetworkX DiGraph)
│   │   │   ├── kg_builder.py         ← build_graph() + 60s cache
│   │   │   └── kg_queries.py         ← 4 query functions
│   │   ├── models/models.py  ← All SQLAlchemy ORM models
│   │   └── db/               ← database.py + seed scripts
│   └── tests/                ← pytest-asyncio tests
├── frontend/
│   ├── src/
│   │   ├── views/            ← 6 page components (one per nav item)
│   │   ├── components/       ← Layout.jsx (sidebar + nav)
│   │   ├── data/usecases.js  ← Static canonical use-case data (source of truth for FE)
│   │   └── api.js            ← All axios calls (single file)
│   └── public/
└── CLAUDE.md                 ← This file
```

---

## Agent graph topology

```
START → l1_monitoring → l1_master → (router) ──┬── l2_bss_orchestration ──┐
                                                ├── l3_oss_orchestration ──┤→ l1_master → l1_human_approval → l1_audit → END
                                                └── l4_network_orchestration ─┘
```

- **l1_monitoring** — correlates TMF events, scores severity
- **l1_master** — orchestrates domain assignments; can loop back after each domain completes
- **l2/l3/l4 sub-graphs** — each has an entry node + domain specialists + a `done` node
- **l1_human_approval** — LangGraph `interrupt()` — pauses until `Command(resume={decision, reason})`
- **l1_audit** — writes `AuditTrace` + closes `ControlCase`

Approval use cases: **P1, P5, P7, P10**

---

## SSE streaming contract (8 event types)

| Event | Key fields |
|-------|-----------|
| `step_start` | `step_id, time, agent, layer, action, node` |
| `agent_thought` | `step_id, delta` |
| `tool_call` | `step_id, tool, tool_key, input_summary` |
| `tool_result` | `step_id, tool, tool_key, output_summary, duration_ms` |
| `step_complete` | `step_id, node, outcome` |
| `awaiting_approval` | `step_id, approval_id, issue_id, why, proposed_action, financial_impact, evidence_refs` |
| `summary` | `findings, resolution, next_steps, architecture_rule, final_state, audit_trace_id` |
| `error` | `message, issue_id` |

---

## Critical field names (verified against DB models)

### Issue IDs
- Format: `ISSUE-P{n}-001` (e.g. `ISSUE-P2-001`)
- `usecases.js` has `issueId` field with this format — **always use `selected.issueId`**, not `selected.id` ("P2")

### Dashboard endpoints and their response field names
| Endpoint | Key fields |
|----------|-----------|
| `GET /dashboard/summary` | `issues.{total,open,remediated,remediation_rate_pct}`, `control_cases.active`, `approvals.pending`, `financial_exposure.total_disputed_usd` |
| `GET /dashboard/layer-health` | Object `{L1,L2,L3,L4}` — L1:`pending_approvals`, L2:`open_trouble_tickets`, L3:`open_service_problems/sla_breach_active`, L4:`network_functions` |
| `GET /dashboard/postbill-disputes` | `disputes[].{bill_id, billing_account_id, amount_due, status, use_case_id, billing_period}` |
| `GET /dashboard/prebill-risks` | `accounts[].{billing_account_id, customer_id, risk_level, risk_score, signal_count}` |
| `GET /dashboard/audit-summary` | `recent_audit_count`, `recent_traces[].{id, action_type, actor, summary, control_case_id, created_at}` |
| `GET /approvals/pending` | `ApprovalOut.{id, thread_id, issue_id, control_case_id, action, risk_reason, status, amount}` — field is `amount` NOT `financial_impact` |

### Bill dispute fields
- `Bill.amount_due` — the actual amount (NOT `financial_impact`, which doesn't exist on Bill model)
- `Approval.amount` — Optional[float], the financial amount on approvals

### Mock TMF bill response shape (camelCase)
- `/mock-tmf/customer-bill` returns `{id, billingPeriod, amountDue: {amount, units}, status, ...}` — nested
- `/billing-accounts/{id}/bill-comparison` returns `{current_bill: {id, period, amount_due, status}, delta_amount, delta_pct, comparison_summary}` — flat snake_case

---

## Frontend views → backend API mapping

| View | Endpoints used |
|------|---------------|
| `Dashboard.jsx` | 6 dashboard + approvals endpoints |
| `AgenticTower.jsx` | `POST /issues/{id}/simulate`, `POST /issues/{id}/remediate/stream` (SSE), `POST /issues/{id}/approve` |
| `Chat.jsx` | `POST /chat` |
| `KnowledgeGraph.jsx` | `POST /kg/rebuild`, `GET /kg/issue/{id}/relationships`, drill-downs: `/kg/customer/{id}/billing-context`, `/kg/control-case/{id}/impact`, `/kg/trace/bill/{id}` |
| `BillsDrilldown.jsx` | `GET /mock-tmf/customer-bill?billing_account_id=`, `GET /mock-tmf/customer-bill/{id}/line-items`, `GET /billing-accounts/{id}/bill-comparison` — with static fallback if empty |
| `KpiGuide.jsx` | Static content only |

---

## Backend routers registered in main.py

All under prefix `/api/v1`:
- `endpoints.py` — issues, use-cases, remediate, simulate, approve, chat
- `approvals.py` — `/approvals/*`, `/issues/{id}/remediate/resume`
- `dashboard.py` — `/dashboard/*`
- `kg.py` — `/kg/*`
- `context.py` — `/customers/{id}/billing-context`, `/billing-accounts/{id}/bill-comparison`, `/control-cases/{id}/evidence`
- `mock_tmf.py` — `/mock-tmf/*` (TMF620/621/638/656/678/688/700 stubs)
- `events.py` — `/events/*`
- `audit.py` — `/audit/*`
- `self_service.py` — `/self-service/*`
- `simulation.py` — `/simulation/*` (global simulation injection)

---

## Test setup

- `backend/.venv/Scripts/python.exe` — always use this python
- `pytest-asyncio` in `auto` mode
- `conftest.py` injects `MemorySaver` (not `AsyncPostgresSaver`) for HITL tests
- Test files: `test_approval`, `test_audit`, `test_chat`, `test_dashboard`, `test_events`, `test_health`, `test_kg`, `test_remediation`, `test_remediation_stream`, `test_self_service`, `test_simulation`, `test_tmf_mock`
- Run all: `cd backend && .venv/Scripts/python.exe -m pytest tests/ -v`

---

## Known design decisions

1. `ChatRequest.customer_id` and `billing_account_id` are **Optional** — FE has display names ("Emma W."), not internal UUIDs. Chat agent falls back gracefully.
2. `LayerHealth` returns a **keyed object** `{L1:{...}, L2:{...}}` not an array — each layer has different operational field names so type-aware rendering is required.
3. `BillsDrilldown` falls back to `usecases.js` static data when backend returns empty (account IDs in usecases.js may differ from DB seed IDs).
4. `KnowledgeGraph` uses synchronous 160-iteration force simulation (no D3) — runs once per graph load.
5. Recursion limits: master graph `50`, sub-agents `8` — sized to worst-case P10 flow with HITL.
