# Holistic Implementation Plan: UI Refactoring & Agent Trace Streaming

This plan details the full refactoring of the frontend based on the `tmforum_billing_dispute_final_ui_pack` mock, along with the deep backend modifications to support issue simulation, real-time streaming of the LangGraph agentic trace via SSE, and enhanced agent reasoning.

## Goal Description
1. **Frontend Refactoring**: Overhaul the React application to implement the HTML/CSS/JS mock provided in `reference/tmforum_billing_dispute_final_ui_pack`. The stack (React/Vite/Tailwind) remains the same, but the UI aesthetics, styling, layout, and component structure will perfectly mirror the mock.
2. **Backend Simulation Capability**: Implement a `POST /simulate` endpoint to inject issues into the respective layer backend system (creating duplicate network records and BSS events).
3. **Backend Data Seed Overhaul**: Completely rewrite `backend/app/db/seed.py` to match the exact UK-based narratives, personas (e.g., Daniel K., Sophie R.), financial figures, and domain specifics defined in the UI JSON and Excel specification, ensuring agents have rich, contextual data to reason over.
4. **Real-time Agent Trace Streaming**: Modify the remediation process from a blocking `ainvoke` call to an asynchronous Server-Sent Events (SSE) stream using LangGraph's `astream_events`. This streams the execution of agents, tools, and supervisors in real-time.
5. **Enhanced Agent Reasoning**: Update the agent prompts to strictly enforce the use of `retrieve_playbook` and `query_knowledge_graph` tools before resolving cases, avoiding hardcoded "rule-based" database updates in favor of true autonomous reasoning.

## Proposed Changes

### 1. Frontend Refactoring (React/Vite)
We will completely overhaul the `frontend/src` directory to mirror the HTML and Vanilla CSS mock precisely.

#### [MODIFY] frontend/src/index.css
- Replace current contents with the exact CSS from `reference/tmforum_billing_dispute_final_ui_pack/styles.css`. Ensure it integrates with the existing Tailwind directives.

#### [MODIFY] frontend/src/App.jsx
- Redefine routes to match the new UI sections: `/dashboard`, `/agents`, `/chat`, `/kpi-guide`, `/bills`.

#### [MODIFY] frontend/src/components/Layout.jsx
- Build the exact sidebar with gradient `linear-gradient(180deg,#06142d,#12306a 55%,#2e1065)`, brand logos, and top header as seen in the mock `index.html`.

#### [MODIFY] frontend/src/views/AgenticTower.jsx
- Implement the "Agent in Action" view. Add the dropdown for the 10 issues, the "Simulate" button, and the "Remediate" button.
- Wire the "Simulate" button to call `POST /api/v1/issues/{issue_id}/simulate`.
- Wire the "Remediate" button to connect to `POST /api/v1/issues/{issue_id}/remediate/stream`. Implement SSE parsing to dynamically render `.step` blocks, the progress bar, and `.tool-call` boxes in real-time.

#### [NEW] Chat.jsx & KpiGuide.jsx
- Build `Chat.jsx` for the case assistant chat UI with message history and quick actions.
- Build `KpiGuide.jsx` for the static KPI definitions page.

#### [MODIFY] frontend/src/api.js
- Add functions: `simulateIssue(issueId)` and `streamRemediation(issueId, onEventCallback)` using `fetch` with streaming readers or `EventSource`.

---

### 2. Backend Enhancements: Trace Streaming & Simulation

#### [MODIFY] backend/app/api/v1/endpoints.py
- **New Endpoint `POST /issues/{issue_id}/simulate`**:
  - Implements the logic to inject cross-domain events. E.g., for P2 (duplicate charging), it injects "SMF CTF Trigger 1" and "SMF CTF Trigger 2" into the `TMFEventModel` or local state, changing the `Issue` state to `simulated`.
- **New Endpoint `POST /issues/{issue_id}/remediate/stream`**:
  - Sets up `graph.astream_events(initial_state, version="v2")`.
  - Parses `on_tool_start`, `on_tool_end`, `on_chat_model_stream`, and `on_chain_start` events.
  - Formats these as SSE payloads `event: tool_call\ndata: {"tool": "query_knowledge_graph", "input": ...}\n\n`.
  - Captures the final DB commit state (`ControlCase` and `AuditTrace`) at the end of the generator.

#### [MODIFY] backend/app/agents/graph_builder.py
- Ensure boundaries between `l1_supervisor`, `l2_supervisor`, etc., emit clean node transitions for `astream_events` to capture, allowing the UI to show "Handing over to L1 Master agent to collect evidence".

#### [MODIFY] backend/app/agents/prompts/templates.py
- **Enhanced Agent Reasoning Prompts**: Update system prompts for the supervisors (L1/L2/L3/L4) to explicitly mandate using `retrieve_playbook` and `query_knowledge_graph`.
- This forces the LLM to emit tool calls for playbooks/KG, which will subsequently be captured by the SSE stream and rendered on the UI, fulfilling the user's request for true agentic reasoning.

### 3. Backend Data Seed Overhaul

#### [MODIFY] backend/app/db/seed.py
- Completely rewrite the seed data to resolve the massive disconnections between the backend and the UI/Excel references.
- Create 10 distinct, unique customers perfectly matching the UI (Emma W., Daniel K., Sophie R., NorthField Warehousing Ltd., Oliver P., Glasgow Retail Subscriber, Roaming Traveler, Hannah T., Subscriber Cohort A12, Enterprise Multi-Site Account).
- Align the financial amounts across the board (e.g. $39 disputed for Daniel K., £28 for Glasgow Retail mapped properly to USD representation).
- Adjust the core scenarios: P2 becomes a travel data add-on, P5 becomes mobile broadband latency spikes (not complete voice outage), and P8 becomes a confusing family plan invoice. This rich data will force the agents to analyze nuanced contexts.

---

## Verification Plan

### Automated Verification
- Create/update unit tests for `/simulate` to ensure mock events are properly created in the database.
- Create tests for `/remediate/stream` to verify the generator yields correctly formatted SSE frames containing tool actions and node transitions.

### Manual Verification
- Start the entire stack (`npm run dev` and `python main.py`).
- Select a P1-P10 issue in the UI. Click **Simulate**; verify the DB records the injected events.
- Click **Remediate**; visually verify the agent trace streams correctly in the "Agent Trace" component, clearly showing Playbook and KG tool invocations, and updating the progress bar dynamically.
- Confirm the UI matches the original static HTML mock pixel-perfectly.
