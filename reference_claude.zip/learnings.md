# Learnings — Billing Control Tower

---

## 1. `httpx.ASGITransport` does not run the ASGI lifespan

**Context:** FastAPI tests using `AsyncClient(transport=ASGITransport(app=app))`.

**Problem:** `ASGITransport` only handles HTTP requests. It never sends `startup` / `shutdown` lifespan events to the app. Any FastAPI `lifespan()` setup code (e.g. `setup_checkpointer()`, DB init) is skipped entirely during tests.

In this project, `setup_checkpointer()` runs inside the lifespan and initialises the LangGraph checkpointer singleton (`_checkpointer`). Because the lifespan never fired, `_checkpointer` stayed `None`, the agentic graph was built with `checkpointer=None`, and `interrupt()` / `Command(resume=...)` failed with:

```
RuntimeError: Cannot use Command(resume=...) without checkpointer
```

**Fix:** Inject the checkpointer directly in the test fixture instead of relying on the lifespan:

```python
@pytest_asyncio.fixture
async def client():
    from langgraph.checkpoint.memory import MemorySaver
    import app.agents.checkpoint_setup as _cs
    from app.agents.graph_builder import reset_agentic_graph

    _cs._checkpointer = MemorySaver()
    reset_agentic_graph()          # discard any None-checkpointer singleton

    async with AsyncClient(transport=ASGITransport(app=app), ...) as c:
        yield c

    reset_agentic_graph()
    _cs._checkpointer = None
```

**Rule:** Never rely on FastAPI lifespan side-effects in `httpx` ASGI tests. Either inject dependencies directly or use `asgi-lifespan.LifespanManager` if you need the full lifecycle.

---

## 2. LangGraph silently drops TypedDict keys not declared in the state schema

**Context:** `StateGraph(MyState)` where `MyState` is a `TypedDict`.

**Problem:** LangGraph uses `MyState.__annotations__` to define the valid graph state schema. Any key passed in the initial state dict that is **not declared** in the TypedDict is **silently dropped** before the first node runs. Nodes that then access those keys via `state["key"]` raise `KeyError`.

In this project, `ChatState` was missing `messages`, `thread_id`, `evidence_summary`, `final_response`, and `error`. The `chat_stream_generator` passed all of them in `initial_state`, but LangGraph stripped them. `classify_intent` crashed on `state["messages"]` with `KeyError`.

Non-streaming chat tests hid this bug because the `chat_simple` endpoint returns a hardcoded fallback string when no `final` SSE event is received — assertions like `assert data["final_response"]` passed on the fallback. The dedicated SSE test caught it by checking `assert "final" in event_types` explicitly.

**Fix:** Declare every key actually used by graph nodes in the TypedDict schema:

```python
class ChatState(TypedDict, total=False):
    thread_id: str
    messages: List[Any]          # LangChain Message objects
    evidence_summary: str
    final_response: Optional[str]
    error: Optional[str]
    # ... rest of fields
```

**Rule:** If a graph node accesses `state["x"]`, `x` must be in the TypedDict. If you add a key to the initial state dict, add it to the schema. Fallback-based tests (`data.get("x") or "fallback"`) can mask missing schema fields — write at least one test that checks the real output path.

---

## 3. LangGraph `interrupt()` + `Command(resume=...)` — checkpointer requirements

**Context:** Human-in-the-loop (HITL) approval flows using `interrupt()` and `Command(resume=...)`.

**How it works:**
- `interrupt(payload)` raises `GraphInterrupt` inside a node, signalling the runtime to save a checkpoint and halt.
- The checkpoint is stored in the graph's checkpointer (keyed by `thread_id`).
- On resume, `graph.ainvoke(Command(resume={"decision": "approved"}), config={"configurable": {"thread_id": "..."}})` replays from the checkpoint.
- `Command(resume=...)` requires that `graph.checkpointer` is a real `BaseCheckpointSaver` (not `None` or `True`).

**Key detail for subgraphs:** Subgraphs compiled with `checkpointer=True` inherit the parent graph's checkpointer at runtime via `config[CONFIG_KEY_CHECKPOINTER]`. The master graph must be compiled with the real saver: `builder.compile(checkpointer=real_saver)`.

**In tests:** Use `MemorySaver` — it is fully in-process and has no asyncio event-loop binding issues. `AsyncPostgresSaver` captures the running loop at `__init__` time and breaks across different test event loops.

---
