# Billing Control Tower — Active Work Tasks

## Status Legend
- [ ] pending
- [~] in_progress
- [x] done

---

## Backend

- [x] #1 Rewrite `graph_builder.py` — START → l1_monitoring → l1_master → l4/l3/l2 orchestrations → l1_human_approval → l1_audit → END
- [x] #2 Create `backend/app/api/v1/stream.py` — LangGraph `astream_events(v2)` → 8-type SSE contract
- [x] #3 Update `backend/app/api/v1/endpoints.py` — add `POST /issues/{id}/remediate/stream` and `POST /issues/{id}/approve`
- [x] #4 `main.py` — stream endpoints are in the existing api_v1_router, no separate registration needed

## Frontend

- [x] #5 Rewrite `frontend/src/views/AgenticTower.jsx` — SSE-driven trace, layer colours, tool chips, approval block, summary panel
- [x] #6 Update `frontend/src/api.js` — all KG, context, approval, dashboard, mock-tmf functions present
- [x] #24 `KnowledgeGraph.jsx` — NEW view: SVG force-directed graph, zoom/pan, 23 node types, edge labels, NodeDetail panel
- [x] #25 `App.jsx` + `Layout.jsx` — Knowledge Graph nav item and route wired at /knowledge-graph
- [x] #26 `BillsDrilldown.jsx` — wired to real backend APIs: getCustomerBills, getBillLineItems, getBillContext; static fallback if no data
- [x] #27 `KnowledgeGraph.jsx` — drill-down buttons in NodeDetail panel for Bill (bill trace), Customer (billing context), ControlCase (impact); back-navigation history stack; normaliseKgResponse handles all 4 KG response shapes

## Backend Schema / DB

- [x] #10 Apply 20 DDL patches (missing columns: issues.correlation_key, approvals.financial_impact, etc.)
- [x] #11 Fix `approve_issue` endpoint — thread_id lookup fixed to `order_by(CC.created_at.desc())` + filter `resolved_at IS NULL`
- [x] #12 Add fallback guard in `l1_audit_node` — if `control_case_id` is empty, look it up by `issue_id`

## Testing

- [x] #13 Refactor `tests/` into domain-specific files
- [x] #14 Create `tests/conftest.py` — MemorySaver injection pattern
- [~] #15 Full test suite — 55 non-LLM PASSED; remediation P2-P10 PASSED; approval & stream tests ran

## Integration Fixes (2026-05-07)

- [x] #17 `usecases.js` — `issueId: "ISSUE-P{n}-001"` added to all 10 use cases
- [x] #18 Backend `endpoints.py` — P8 added to `AGENTIC_USE_CASES`; hardcoded 400 removed
- [x] #19 Backend `endpoints.py` — `POST /issues/{id}/simulate` endpoint added
- [x] #20 `AgenticTower.jsx` — `handleSimulate` calls real API
- [x] #21 `Dashboard.jsx` — all 6 backend APIs wired; all field names verified
- [x] #22 `Chat.jsx` — wired to `POST /chat`; graceful error display
- [x] #23 `schemas.py` — `customer_id` and `billing_account_id` Optional in `ChatRequest`

## Documentation

- [x] #28 `CLAUDE.md` — codebase guide: topology, SSE contract, field names, view→API mapping, test setup, design decisions

## Verification

- [x] #7 Syntax check: all changed files parse without errors
- [~] #8 test_inline_approve_p5_full_cycle and test_inline_reject_p7 — approval tests ran
- [ ] #9 Manual: P2 remediate/stream emits ordered SSE events in browser
- [ ] #16 Manual: P5 stream pauses on awaiting_approval; approve/reject resumes
- [ ] #29 Manual: BillsDrilldown loads real bills from backend (requires matching account IDs in DB seed)
- [ ] #30 Manual: KnowledgeGraph drill-down on Bill/Customer/ControlCase nodes loads specialised KG view

---

## Integration Audit Summary (2026-05-07)

All UI↔backend integrations verified:
| View | Status |
|------|--------|
| AgenticTower | ✅ SSE + approve correct |
| Dashboard | ✅ All 6 endpoints + field names correct |
| Chat | ✅ POST /chat correct |
| KnowledgeGraph | ✅ Issue relationships + drill-downs wired |
| BillsDrilldown | ✅ Wired (static fallback if DB account IDs differ) |
| KpiGuide | ✅ Static by design |

*Last updated: 2026-05-07 — Full integration audit complete; BillsDrilldown + KG drill-downs wired; CLAUDE.md created*
