# Federated Evidence Plane and Digital Twin Projection

## Purpose
This document explains in depth how to implement a **federated evidence plane** and a **digital twin projection** to accelerate cross-domain reasoning for the CSP Control Tower architecture.

The goal is to support **fast, policy-governed, cross-domain reasoning** without violating the ownership rules of the layered model:
- **L1** = CSP Control Tower / cross-domain governor
- **L2** = BSS owner
- **L3** = OSS / service assurance owner
- **L4** = network / resource owner

The design principle remains:

> **Write-local, read-federated, orchestrate-through-owner**

That means:
- authoritative writes remain in the owning layer
- L1 reasons across domains using federated evidence and twin projections
- L1 does not bypass owner systems for operational actions

---

# 1) Why You Need a Federated Evidence Plane

## 1.1 Problem in direct orchestration-only model
If L1 needs to query L2, L3, and L4 synchronously for every reasoning step:
- investigation latency increases
- orchestrators become bottlenecks
- repeated evidence retrieval causes unnecessary load
- reasoning quality depends too much on synchronous round-trips
- proactive correlation becomes too slow for high-volume operations

## 1.2 What the federated evidence plane solves
The federated evidence plane acts as a **read-optimized, policy-governed evidence exchange layer** that gives L1 and other approved consumers access to:
- normalized evidence summaries
- evidence references and provenance
- issue-linked topology facts
- current domain state snapshots
- impact scopes
- freshness metadata
- correlation-ready identifiers

Instead of repeatedly asking each domain for raw records, L1 can:
1. reason using federated evidence first
2. identify what additional authoritative verification is needed
3. ask owner domains only for high-value or sensitive confirmation

This makes reasoning much faster and more scalable.

---

# 2) What the Federated Evidence Plane Is

## 2.1 Definition
The federated evidence plane is a **read-only logical plane** built from evidence published by L2, L3, and L4.

It is not a replacement for source systems.
It is a **projection and exchange mechanism** designed to support:
- cross-domain reasoning
- issue correlation
- impact estimation
- evidence packaging
- human review preparation
- simulation and what-if analysis

## 2.2 What it contains
The evidence plane should contain:
- compact evidence objects
- evidence references to source records
- summary facts
- normalized identifiers
- state snapshots
- correlation hints
- graph edges / digital twin relationships
- freshness and confidence metadata
- masking and data classification status

## 2.3 What it should not contain
It should **not** become:
- the operational system of record
- the execution layer
- the source of authoritative writes
- a place where raw unrestricted customer/network data is broadly copied
- a bypass around owner domains

---

# 3) Relationship Between Evidence Plane, Digital Twin, KG, and RAG

## 3.1 Evidence plane
The **evidence plane** is the operational exchange layer for structured, normalized, read-only evidence.

## 3.2 Digital twin
The **digital twin projection** is the near-real-time state model built from evidence and source projections.
It models current operational state and relationships.

## 3.3 Knowledge graph
The **knowledge graph** models semantic relationships across entities, incidents, topology, and history.
It is stronger on relationship reasoning and historical context.

## 3.4 RAG
**RAG** handles unstructured retrieval such as:
- runbooks
- prior incident records
- SOPs
- policy documentation
- known error knowledge

## 3.5 Practical relationship
A strong implementation uses all four together:
- **Evidence plane** = structured operational evidence exchange
- **Digital twin** = current state projection
- **Knowledge graph** = semantic relationship and impact reasoning
- **RAG** = unstructured knowledge support

---

# 4) How the Federated Evidence Plane Works

## 4.1 Publish-subscribe evidence flow
Each domain publishes evidence into the plane through an **evidence publisher**.

### L2 publishes evidence such as:
- ticket summary
- billing exposure summary
- customer/account/product relationship facts
- collections status
- entitlement validation outcome
- adjustment recommendation

### L3 publishes evidence such as:
- service problem summary
- service topology references
- SLA/QoS validation result
- mediation replay status
- service impact estimate

### L4 publishes evidence such as:
- alarm summary
- KPI anomaly summary
- session anomaly facts
- resource health status
- remediation recommendation
- rollback readiness state

## 4.2 Evidence ingestion flow
A typical flow is:
1. owner layer produces evidence object
2. evidence object is validated against schema
3. masking/classification policy is applied
4. metadata and references are stored
5. digital twin and graph projections are updated
6. event is published to indicate evidence availability

---

# 5) Evidence Object Model

## 5.1 Mandatory evidence fields
Every evidence object should include the following core fields:

```json
{
  "evidenceId": "evd-L4-20260428-0001",
  "traceId": "trc-12345",
  "caseId": "case-7890",
  "sourceLayer": "L4",
  "sourceDomain": "network",
  "sourceSystem": "SMF-Cluster-A",
  "entityRefs": [
    {"type": "billingAccount", "id": "BA-100001"},
    {"type": "service", "id": "svc-5g-001"},
    {"type": "session", "id": "pdu-99812"}
  ],
  "evidenceType": "sessionAnomalySummary",
  "summary": "Zombie PDU session suspected; release missing after inactivity timeout.",
  "confidence": 0.91,
  "severity": "high",
  "producedAt": "2026-04-28T09:40:00Z",
  "validatedAt": "2026-04-28T09:40:04Z",
  "ttlSeconds": 300,
  "classification": "internal-sensitive",
  "maskingStatus": "masked",
  "payloadRef": "obj://evidence/l4/session/evd-L4-20260428-0001.json",
  "sourceRecordRefs": [
    {"system": "SMF", "id": "smf-rec-8891"},
    {"system": "AlarmManager", "id": "alm-00291"}
  ]
}
```

## 5.2 Important design rules
- keep evidence objects compact
- keep raw payloads separate behind references
- include freshness and TTL
- include confidence and severity
- include entity references that are canonical across domains
- include data classification and masking status

---

# 6) Digital Twin Projection – Concept

## 6.1 What the digital twin is
The digital twin is a **projection layer** representing the current cross-domain operational state of business, service, and resource entities relevant to monetization and dispute handling.

It is not one giant copy of all systems.
It is a **targeted operational twin** containing only what is needed for:
- correlation
- blast radius estimation
- cross-domain diagnosis
- scenario simulation
- controlled orchestration

## 6.2 Why it is useful
It allows L1 to quickly answer questions like:
- which services and customers are impacted by this L4 anomaly?
- does the affected session map to a premium slice customer?
- is there already an open L2 ticket and an L3 service problem?
- is the issue pre-bill or already customer-visible post-bill?
- what is the likely billing exposure if the issue persists for 2 hours?

---

# 7) Digital Twin Ontology – Core Domains

The digital twin ontology should cover **business**, **service**, **resource**, **charging**, **issue**, **policy**, and **workflow** domains.

## 7.1 Party and account domain
Key entity types:
- `Party`
- `Customer`
- `BillingAccount`
- `CustomerAccount`
- `Agreement`
- `Consent`
- `EnterpriseHierarchy`

Key relationships:
- `Customer` -> owns -> `BillingAccount`
- `Customer` -> subscribesTo -> `ProductSubscription`
- `BillingAccount` -> billedBy -> `Bill`
- `Party` -> authorizedFor -> `Consent`

Typical attributes:
- customer segment
- VIP flag
- enterprise hierarchy level
- privacy profile
- consent state
- risk classification

## 7.2 Product and monetization domain
Key entity types:
- `ProductOffering`
- `ProductSubscription`
- `Entitlement`
- `PricePlan`
- `AllowanceBucket`
- `Charge`
- `Bill`
- `BillItem`
- `Adjustment`
- `CollectionHold`

Key relationships:
- `BillingAccount` -> hasSubscription -> `ProductSubscription`
- `ProductSubscription` -> includes -> `Entitlement`
- `Bill` -> contains -> `BillItem`
- `BillItem` -> derivedFrom -> `UsageRecord`
- `Adjustment` -> appliesTo -> `BillItem`
- `CollectionHold` -> protects -> `BillingAccount`

Typical attributes:
- product type
- premium tier
- slice entitlement
- roaming eligibility
- recurring charge vs usage charge
- adjustment state

## 7.3 Service domain
Key entity types:
- `Service`
- `ServiceInstance`
- `ServiceProblem`
- `ServiceOrder`
- `ServiceQualityIndicator`
- `SLATarget`

Key relationships:
- `ProductSubscription` -> realizes -> `ServiceInstance`
- `ServiceInstance` -> impactedBy -> `ServiceProblem`
- `ServiceInstance` -> supportedBy -> `Resource`
- `ServiceInstance` -> measuredBy -> `ServiceQualityIndicator`

Typical attributes:
- service class
- SLA tier
- service state
- service impact severity
- QoS/SLA breach window

## 7.4 Resource and network domain
Key entity types:
- `Resource`
- `NetworkFunction`
- `Alarm`
- `PerformanceMetric`
- `Session`
- `TopologyLink`
- `RemediationAction`
- `RollbackAction`

Key relationships:
- `ServiceInstance` -> supportedBy -> `Resource`
- `Resource` -> emits -> `Alarm`
- `Resource` -> measuredBy -> `PerformanceMetric`
- `Session` -> traverses -> `NetworkFunction`
- `RemediationAction` -> targets -> `Resource`
- `RollbackAction` -> reverses -> `RemediationAction`

Typical attributes:
- alarm severity
- resource health
- session state
- topology domain
- remediation blast radius

## 7.5 Charging and usage domain
Key entity types:
- `UsageRecord`
- `RatedUsage`
- `ChargingTrigger`
- `QuotaEvent`
- `SessionChargeContext`
- `ChargingCorrelationFinding`

Key relationships:
- `Session` -> generates -> `ChargingTrigger`
- `ChargingTrigger` -> contributesTo -> `UsageRecord`
- `UsageRecord` -> becomes -> `RatedUsage`
- `RatedUsage` -> contributesTo -> `BillItem`
- `ChargingCorrelationFinding` -> explains -> `BillItem`

Typical attributes:
- duplicate flag
- late-arrival flag
- missing release flag
- usage period
- quota exhaustion
- rating state

## 7.6 Issue and case domain
Key entity types:
- `SuspectedEvent`
- `ControlCase`
- `TroubleTicket`
- `Incident`
- `RootCauseHypothesis`
- `EvidencePack`
- `ApprovalTask`

Key relationships:
- `SuspectedEvent` -> triggers -> `ControlCase`
- `ControlCase` -> linksTo -> `TroubleTicket`
- `ControlCase` -> linksTo -> `ServiceProblem`
- `ControlCase` -> supportedBy -> `EvidencePack`
- `ApprovalTask` -> governs -> `RemediationAction`

Typical attributes:
- case state
- confidence score
- owner layer
- escalation reason
- approval outcome
- closure reason

## 7.7 Policy and governance domain
Key entity types:
- `PolicyRule`
- `ActionClass`
- `ApprovalPolicy`
- `DataClassification`
- `AccessPurpose`

Key relationships:
- `PolicyRule` -> governs -> `RemediationAction`
- `ApprovalPolicy` -> appliesTo -> `ActionClass`
- `DataClassification` -> constrains -> `EvidencePack`

Typical attributes:
- allowed action types
- approval threshold
- data masking rule
- expiry / version

---

# 8) Digital Twin State Layers

The twin should model not only entities, but also state categories.

## 8.1 Static state
Relatively stable data such as:
- customer-account-service-resource mappings
- product and entitlement structure
- topology relationships

## 8.2 Dynamic state
Frequently changing operational data such as:
- session state
- alarm state
- bill-run phase
- collections hold state
- service problem state
- case state

## 8.3 Derived state
AI or rule-computed values such as:
- blast radius estimate
- likely root cause domain
- customer impact score
- billing exposure score
- remediation readiness score

---

# 9) Projection Patterns for the Digital Twin

## 9.1 Source-aligned projection
Each owner domain publishes projections into the twin.

### L2 projection examples
- current disputed accounts
- premium product and entitlement mapping
- open trouble tickets
- pending bill adjustments

### L3 projection examples
- active service problems
- service-to-resource topology links
- SLA breach windows
- replay backlog state

### L4 projection examples
- active alarms
- active abnormal sessions
- impacted network functions
- remediation candidate state

## 9.2 Projection update patterns
Use a mix of:
- event-driven updates for high-change state
- scheduled reconciliation for slower-changing reference data
- on-demand authoritative refresh for high-risk actions

---

# 10) Twin Freshness and Trust Model

## 10.1 Trust levels
Not all twin facts are equally trustworthy.
Model trust explicitly:
- **Authoritative** = directly refreshed from owner system
- **Projected** = current projection based on recent event or snapshot
- **Derived** = inferred or computed from other facts
- **Stale** = beyond freshness threshold

## 10.2 Freshness metadata
Every twin node or edge should carry:
- `sourceSystem`
- `lastObservedAt`
- `lastProjectedAt`
- `freshUntil`
- `trustLevel`
- `sourceLayer`

## 10.3 High-risk decision rule
For action classes C and D, the master agent should revalidate critical facts against owner systems before execution.

---

# 11) Suggested Ontology Examples

## 11.1 Example: zombie session case
Twin relationships may look like:

```text
Customer -> BillingAccount -> ProductSubscription -> ServiceInstance -> Session
Session -> traverses -> SMF
Session -> associatedWith -> ChargingTrigger
ChargingTrigger -> contributesTo -> UsageRecord
UsageRecord -> contributesTo -> BillItem
Session -> impactedBy -> SuspectedEvent
SuspectedEvent -> triggers -> ControlCase
ControlCase -> supportedBy -> EvidencePack
```

## 11.2 Example: premium slice entitlement mismatch
Twin relationships may look like:

```text
Customer -> BillingAccount -> ProductSubscription -> Entitlement
Entitlement -> expects -> SLATarget
ProductSubscription -> realizes -> ServiceInstance
ServiceInstance -> supportedBy -> NetworkSlice
NetworkSlice -> measuredBy -> ServiceQualityIndicator
ServiceQualityIndicator -> violates -> SLATarget
BillItem -> chargesFor -> PremiumTier
ControlCase -> questions -> PremiumTierCharge
```

---

# 12) How L1 Uses the Evidence Plane and Twin

## 12.1 Fast reasoning path
Typical L1 reasoning sequence:
1. monitoring agent receives suspected event
2. lookup affected entities in twin
3. retrieve linked evidence packs from evidence plane
4. identify likely impacted accounts/services/resources
5. check if related case, service problem, or ticket already exists
6. estimate likely business impact
7. decide whether additional authoritative queries are needed
8. orchestrate owner-layer follow-up

## 12.2 Benefits
This makes L1 faster at:
- deduplicating cases
- scoping impact
- deciding escalation path
- preparing evidence for human review
- prioritizing pre-bill vs post-bill actions

---

# 13) Implementation Guidance for Evidence Plane / Twin

## 13.1 Storage and runtime choices
Recommended split:
- **Evidence metadata store**: PostgreSQL / document DB
- **Evidence payload store**: object storage
- **Twin graph store**: graph database
- **Fast cache**: Redis
- **Search / semantic retrieval**: vector index / search engine

## 13.2 APIs to expose
Recommended read APIs:
- `GET /evidence/{caseId}`
- `GET /evidence/entity/{entityType}/{id}`
- `GET /twin/entity/{entityType}/{id}`
- `GET /twin/case/{caseId}/impact`
- `GET /twin/account/{accountId}/openIssues`
- `POST /evidence/query`

## 13.3 Security controls
- read-only access for consumers
- purpose-of-use validation
- field-level masking
- traceable access logs
- owner-layer access policies

---

# 14) Final Guidance

## Best design interpretation
Think of the architecture as follows:

- **Evidence plane** = normalized operational fact exchange
- **Digital twin** = current cross-domain state projection
- **Knowledge graph** = semantic relationship model
- **RAG** = unstructured knowledge retrieval

## Best production rule
Use the twin and evidence plane to **accelerate reasoning**, but use owner systems to **authorize truth for action**.

That gives you:
- low latency
- strong reasoning quality
- clean ownership
- safer automation
- better human explainability
