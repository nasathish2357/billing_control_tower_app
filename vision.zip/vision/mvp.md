# Simplified MVP for CSP Control Tower Demo

## Goal of this MVP
Build a **simple, demo-friendly version** of the CSP Control Tower that proves the main idea without implementing the full enterprise architecture.

The MVP should show only these core capabilities:
1. **Issue comes from one layer** (for example L4 network or L2 care).  
2. **L1 Control Tower correlates and decides** whether it is cross-domain.  
3. **L1 asks other layers for evidence** through their orchestrators.  
4. **One action is triggered in the owner layer**.  
5. **Everything is logged** for demo visibility.  

This is enough to demonstrate the value of:
- layered agentic design
- cross-domain reasoning
- owner-based orchestration
- evidence-driven resolution
- auditability

---

# 1) MVP Scope

## Include only 4 layers
- **L1** – Control Tower
- **L2** – BSS
- **L3** – OSS
- **L4** – Network

## But simplify the implementation
For demo, each layer can be represented by **just one orchestrator agent**.

So instead of many sub-agents, use:
- `L1 Master Agent`
- `L2 BSS Orchestrator`
- `L3 OSS Orchestrator`
- `L4 Network Orchestrator`

Optional lightweight shared services:
- `Event Store`
- `Audit Store`
- `Evidence Store`

That is enough for a convincing MVP.

---

# 2) Simplified MVP Architecture

## Components

### L1 – Control Tower
Use only 2 agents:
1. **Master Agent**
   - receives issue
   - asks other layers for evidence
   - decides resolution path
2. **Monitoring Agent**
   - watches event stream
   - detects cross-domain suspicion

### L2 – BSS
Use only 1 agent:
1. **BSS Orchestrator**
   - returns customer/bill/account evidence
   - performs bill correction or dispute hold

### L3 – OSS
Use only 1 agent:
1. **OSS Orchestrator**
   - returns service-impact evidence
   - optionally triggers replay or service problem update

### L4 – Network
Use only 1 agent:
1. **Network Orchestrator**
   - returns alarm/session/network evidence
   - optionally performs technical remediation

### Shared stores
1. **Event Store**
   - holds suspected issue events
2. **Audit Store**
   - logs all requests/responses/actions
3. **Evidence Store**
   - stores normalized evidence packs for demo

---

# 3) Best Demo Use Cases

For MVP, do **not** implement all ten use cases.
Use only **two**:

## Use Case A – Pre-bill network-driven issue
**Zombie session / duplicate charging suspicion**

Why this is good for demo:
- starts in L4
- needs cross-domain reasoning
- L1 becomes meaningful
- ends with network fix + bill protection

### Demo flow
1. L4 publishes a suspected event
2. L1 Monitoring sees it
3. L1 Master asks L4 for technical evidence
4. L1 Master asks L2 for billing impact
5. L1 decides issue is valid
6. L4 performs session cleanup
7. L2 applies bill protection
8. Audit log shows complete closed loop

---

## Use Case B – Post-bill customer complaint
**Customer disputes premium charge / duplicate charge**

Why this is good for demo:
- starts in L2
- shows customer journey
- shows L2-first triage
- shows L1 only when cross-domain needed

### Demo flow
1. Customer complaint enters L2
2. L2 checks bill context
3. L2 escalates to L1 only if cross-domain suspicion exists
4. L1 asks L3/L4 for evidence if needed
5. L1 decides outcome
6. L2 applies credit / no-credit / explanation
7. Audit log shows decision trace

---

# 4) MVP Functional Requirements

## Must-have
1. Ability to create an issue/event  
2. Ability for L1 to request evidence from L2/L3/L4  
3. Ability to display returned evidence  
4. Ability to trigger one corrective action  
5. Ability to show end-to-end audit trail  

## Nice-to-have
1. Basic confidence score  
2. Basic human approval step  
3. A simple dashboard for issue status  

## Do not include in MVP
- full digital twin implementation
- full knowledge graph implementation
- all agents from final architecture
- full TM Forum API coverage
- advanced simulation
- full event taxonomy
- autonomous remediation across all domains

---

# 5) Simplified Data Model for MVP

Use only a few objects.

## 5.1 Control Case
```json
{
  "caseId": "CASE-1001",
  "issueType": "ZombieSessionSuspected",
  "originLayer": "L4",
  "status": "Validated",
  "customerId": "CUST-001",
  "billingAccountId": "BA-001",
  "serviceId": "SVC-001",
  "severity": "High"
}
```

## 5.2 Evidence Pack
```json
{
  "evidenceId": "EVD-2001",
  "caseId": "CASE-1001",
  "sourceLayer": "L4",
  "summary": "Session release missing after inactivity timeout",
  "confidence": 0.92
}
```

## 5.3 Action Record
```json
{
  "actionId": "ACT-3001",
  "caseId": "CASE-1001",
  "ownerLayer": "L4",
  "actionType": "TerminateZombieSession",
  "status": "Completed"
}
```

## 5.4 Audit Record
```json
{
  "auditId": "AUD-4001",
  "caseId": "CASE-1001",
  "step": "L1 requested billing impact from L2",
  "timestamp": "2026-04-28T12:00:00Z"
}
```

---

# 6) Simplified Integration Model

For demo, do **not** integrate real CRM/billing/network systems unless easily available.

Use one of these patterns:

## Option 1 – Fully mocked backend (best for demo)
- mock L2 responses
- mock L3 responses
- mock L4 responses
- focus on orchestration and UI

## Option 2 – Hybrid demo
- use real ticketing or billing sample API if available
- mock remaining domains

## Option 3 – Static scenario playback
- preload two scenarios
- let user click “Run” and show sequence, evidence, and action outcome

**Recommended for demo:** Option 1 or Option 3.

---

# 7) Simplified Event Model for MVP

Use only one event type initially:

## SuspectedEvent
```json
{
  "eventId": "EVT-5001",
  "eventType": "SuspectedEvent",
  "originLayer": "L4",
  "issueType": "ZombieSessionSuspected",
  "caseId": "CASE-1001",
  "customerId": "CUST-001",
  "billingAccountId": "BA-001",
  "serviceId": "SVC-001",
  "summary": "Possible stale session causing unfair charging"
}
```

This is enough for L1 Monitoring Agent to consume.

---

# 8) Simplified Knowledge / Evidence for MVP

Do not implement a full knowledge graph in MVP.

Instead use a **mini evidence model**:
- customer info
- bill info
- service info
- session/alarm info
- simple relationship mapping

If you want demo-level “knowledge graph effect”, just keep:
- `customer -> account -> service -> session -> bill item`

This can be stored as simple JSON or a tiny graph table.

---

# 9) Suggested UI for MVP Demo

Use one single-page UI with 4 sections:

## Section 1 – Architecture view
Show the 4 layers:
- L1 Control Tower
- L2 BSS
- L3 OSS
- L4 Network

## Section 2 – Use case selector
Buttons:
- Pre-bill issue
- Post-bill issue

## Section 3 – Sequence flow viewer
Show step-by-step flow:
- issue raised
- evidence requested
- evidence returned
- action executed
- case closed

## Section 4 – Audit and evidence panel
Show:
- evidence returned by each layer
- final decision
- action taken
- audit entries

This is enough for a very effective demo.

---

# 10) Suggested Technical Stack for MVP

Keep the stack minimal.

## Frontend
- **HTML + CSS + JavaScript** (best for quick demo)
or
- React if you want richer UI

## Backend
Choose one:
- **Node.js / Express**
- **Python / FastAPI**
- **Spring Boot** if your team already has it

## Storage
Use simple local/mock stores:
- JSON files
or
- SQLite / PostgreSQL lightweight instance

## Event handling
For MVP, you do not need full Kafka.
Use either:
- in-memory event bus
- lightweight queue simulation
- local JSON/event array

## Audit logging
Simple database table or JSON file is enough.

## Recommended fastest path
- Frontend: HTML/CSS/JS
- Backend: Node.js or Python FastAPI
- Storage: JSON / SQLite

---

# 11) Suggested Demo Script

## Demo 1 – Pre-bill
1. Click **Run Pre-bill Case**
2. Show L4 creates suspected event
3. Show L1 Monitoring picks it up
4. Show L1 Master asks L4 and L2 for evidence
5. Show evidence comes back
6. Show L1 decides “valid issue”
7. Show L4 performs remediation
8. Show L2 applies bill protection
9. Show final audit trail

## Demo 2 – Post-bill
1. Click **Run Post-bill Case**
2. Show customer complaint enters L2
3. Show L2 checks billing context
4. Show escalation to L1
5. Show L1 requests cross-domain evidence
6. Show final correction or explanation
7. Show audit trail and closure

---

# 12) What the MVP Proves

A successful MVP should prove only these things:

## Business proof
- cross-domain control tower adds value
- customer and technical domains can be linked
- disputes can be resolved with evidence, not manual guesswork

## Architecture proof
- layer ownership works
- L1 can coordinate without bypassing ownership
- evidence-based orchestration is possible
- auditability is feasible

## Demo proof
- the concept is understandable by business and technical stakeholders
- the architecture can be evolved into full-scale production later

---

# 13) What to Add After MVP

After MVP success, the next upgrades should be:
1. add more layer sub-agents
2. add real event backbone
3. add evidence plane
4. add mini knowledge graph
5. add approval flow
6. add more use cases
7. connect to real enterprise APIs
8. add simulation and rollback patterns

---

# 14) Final MVP Recommendation

## Best simplified MVP architecture
Use:
- **1 L1 Master Agent**
- **1 L1 Monitoring Agent**
- **1 L2 BSS Orchestrator**
- **1 L3 OSS Orchestrator**
- **1 L4 Network Orchestrator**
- **1 Event Store**
- **1 Audit Store**
- **1 Evidence Store**
- **2 demo use cases**

## Best delivery approach
- mock everything first
- focus on story and visibility
- make the orchestration flow clear
- keep ownership boundaries visible
- do not overbuild

## One-line summary

> **For the MVP, show only one issue, one control path, one evidence flow, and one corrective action — that is enough to make the concept real.**
