# Production Recommendations for CSP Control Tower Agentic Architecture

## Purpose
This document provides production-focused best practices to reduce architectural failure modes in a multi-layer agentic CSP control tower model spanning:
- **L1** Control Tower
- **L2** BSS
- **L3** OSS / Service Assurance
- **L4** Network / Resource

The recommendations below are intended to make the architecture operationally safe, scalable, auditable, resilient, and governable in production.

---

## 1) Governance and Ownership

### 1.1 Keep strict domain ownership
- Define a **single owner layer** for every system, data domain, API, event type, and remediation action.
- Enforce the rule: **write-local, read-federated, orchestrate-through-owner**.
- Prevent L1 from becoming a hidden super-user layer.
- Maintain an explicit **system ownership matrix** approved by architecture, security, and operations teams.

### 1.2 Separate control plane from execution plane
- Treat **L1 as a governance and coordination plane**, not as a universal execution plane.
- Keep actual domain execution inside L2/L3/L4 orchestration agents.
- Limit L1 direct access to shared control-plane services such as:
  - Event DB / event mesh
  - Audit DB
  - policy engine
  - compliance services
  - simulation platform
  - federated evidence plane

### 1.3 Enforce architecture guardrails in runtime
- Register allowed tools, APIs, and connectors in a central **policy-controlled registry**.
- Block any unapproved direct connector from one layer into another layer’s owned systems.
- Introduce architecture conformance checks in CI/CD and at runtime.

---

## 2) API and Integration Best Practices

### 2.1 Prefer TM Forum APIs first
- Use TM Forum APIs wherever practical as the default contract boundary.
- Only introduce custom APIs when TM Forum coverage is insufficient.
- For every custom API, document:
  - business purpose
  - owner layer
  - request/response schema
  - versioning strategy
  - authorization model
  - fallback/deprecation plan

### 2.2 Use orchestration facades, not direct peer access
- L2, L3, and L4 should expose **domain orchestration facades** for:
  - evidence retrieval
  - local RCA request
  - remediation request
  - state query
- Do **not** allow arbitrary direct peer-to-peer system access across layers.

### 2.3 Design APIs for idempotency and replay safety
- All write APIs and remediation commands should support:
  - idempotency keys
  - deduplication checks
  - retry-safe semantics
  - correlation IDs
- This is essential for billing corrections, replay operations, and network remediations.

### 2.4 Use schema governance for payloads
- Standardize event and evidence payload contracts.
- Version schemas explicitly.
- Reject malformed payloads early.
- Enforce field-level masking for sensitive data.

---

## 3) Event-Driven Reliability

### 3.1 Use an event mesh with durability guarantees
- Use durable messaging with:
  - retries
  - dead-letter queues
  - replay capability
  - consumer lag monitoring
  - delivery confirmation
- Each layer orchestrator should implement the **outbox pattern** for guaranteed event publication.

### 3.2 Reduce event noise before L1
- Avoid flooding L1 with raw anomalies.
- Add local filtering at L2/L3/L4 before escalating to L1.
- Require each suspected event to include:
  - confidence score
  - impact estimate
  - evidence references
  - ownership hints
  - deduplication key

### 3.3 Standardize event taxonomy
- Create a canonical taxonomy for:
  - suspected events
  - transaction events
  - system events
  - remediation events
  - approval events
  - closure events
- This prevents ambiguity during cross-domain correlation.

---

## 4) Evidence, Data, and Knowledge Controls

### 4.1 Build a federated evidence plane
- Use a read-optimized evidence plane instead of giving L1 direct system-level access.
- Each layer should publish compact evidence packs or evidence references.
- Evidence packs should contain:
  - fact summary
  - source system reference
  - freshness timestamp
  - trace ID
  - confidence level
  - masking/redaction status

### 4.2 Treat KG/RAG as assistive, not authoritative
- Layer-local KG/RAG and federated KG/RAG should assist reasoning but must not replace authoritative system-of-record checks.
- For high-impact actions, the master agent must revalidate critical facts using owner-layer evidence.

### 4.3 Manage freshness aggressively
- Every evidence object should include:
  - produced-at timestamp
  - last-validated timestamp
  - TTL / expiry
  - source-of-truth reference
- High-risk decision paths must reject stale evidence.

### 4.4 Normalize identifiers across layers
- Use shared identifiers and mapping for:
  - customer
  - billing account
  - subscription/product
  - service instance
  - resource
  - session
  - ticket/problem/case
- This reduces cross-domain correlation failure and duplicate-case creation.

---

## 5) Security, Privacy, and Compliance

### 5.1 Enforce least privilege by layer
- Each agent should have only the minimum permissions needed for its own layer.
- Use separate service identities for:
  - evidence retrieval
  - orchestration
  - remediation
  - audit logging
  - simulation

### 5.2 Apply purpose-based access control
- Access to CRM, billing, network, and audit evidence should be governed not only by identity but also by **purpose of use**.
- Require explicit access purpose for cross-layer evidence requests.

### 5.3 Protect sensitive customer and network data
- Apply field-level masking, tokenization, and redaction before exposing evidence to L1 or other layers.
- Keep raw sensitive records in owner domains whenever possible.

### 5.4 Make audit immutable and complete
- Log:
  - prompts
  - reasoning references
  - tool actions
  - API calls
  - evidence reads
  - decisions
  - approvals
  - remediation execution
  - rollback actions
- Use append-only or tamper-evident audit design.

---

## 6) Safe Autonomy and Human Oversight

### 6.1 Introduce risk-based action classes
Define action classes such as:
- **Class A**: read-only / explanation only
- **Class B**: low-risk automated local correction
- **Class C**: cross-domain remediation with policy gating
- **Class D**: high-risk action requiring human approval

This helps automate safely without overusing human approvals.

### 6.2 Always support dry-run and simulation
- Before enabling a new closed-loop remediation, test it in simulation.
- Dry-run mode should show:
  - proposed actions
  - impacted entities
  - blast radius
  - rollback path
  - policy checks

### 6.3 Require explicit approval for high-risk changes
Use human approval for:
- high-value financial adjustments
- mass corrections
- network-impacting remediations
- policy overrides
- actions with weak or conflicting evidence

### 6.4 Always design rollback
Every remediation should specify:
- rollback trigger
- rollback owner
- rollback timeout
- rollback API/workflow
- expected post-rollback verification

---

## 7) Resilience and High Availability

### 7.1 Avoid single points of failure
Deploy HA for:
- L1 master and monitoring agents
- layer orchestration agents
- event mesh
- audit pipeline
- policy engine
- evidence cache
- identity/authorization services

### 7.2 Add degraded-mode behavior
Every layer should define what happens when another dependency is unavailable.
Examples:
- If Event DB is down, use local outbox buffer.
- If L1 is unavailable, allow local RCA and local remediation within policy scope.
- If a peer orchestrator is unavailable, queue evidence requests and expose partial investigation state.

### 7.3 Use circuit breakers and bulkheads
- Prevent a failing domain from cascading across all layers.
- Separate workloads for:
  - customer-driven requests
  - proactive monitoring
  - remediation jobs
  - audit ingestion
  - simulation

### 7.4 Capacity-plan for bursts
- Size eventing, orchestration, and audit infrastructure for peak anomaly storms and billing-cycle spikes.
- Perform chaos and stress testing before production rollout.

---

## 8) Operational Excellence

### 8.1 Introduce observability by trace ID
Every cross-layer case should carry a shared trace ID across:
- events
- orchestration requests
- evidence packs
- tickets/problems
- audit records
- remediation workflows

### 8.2 Track production SLOs
At minimum monitor:
- event ingestion lag
- evidence retrieval latency
- orchestration success rate
- false-positive escalation rate
- duplicate-case rate
- automation rollback rate
- audit completeness rate
- approval turnaround time

### 8.3 Maintain runbooks for degraded modes
Document operator runbooks for:
- orchestrator outage
- event mesh outage
- stale evidence detection
- duplicate correction issue
- approval backlog
- simulation drift
- KG/RAG inconsistency

### 8.4 Establish release control for automation rules
- Version all policies, prompts, workflows, and tool bindings.
- Roll out new closed-loop logic gradually.
- Use canary release for automations before wide enablement.

---

## 9) Data Quality and Case Management

### 9.1 Prevent duplicate cases
- Use global correlation IDs and deduplication keys.
- Match based on account, service, session, issue type, time window, and symptom fingerprint.
- Merge related cases instead of opening parallel cases across layers.

### 9.2 Separate suspicion from confirmed RCA
- Do not convert every suspicion into a confirmed issue.
- Model explicit states such as:
  - suspected
  - correlated
  - validated
  - remediation in progress
  - resolved
  - closed
  - rolled back

### 9.3 Keep customer-facing records aligned with technical records
- L2 trouble ticket, L3 service problem, L4 network issue, and L1 control case should remain linked by reference IDs.
- This prevents fragmented resolution and inconsistent customer communication.

---

## 10) Organization and Operating Model

### 10.1 Create a cross-domain architecture board
Establish a lightweight governance forum for:
- API approvals
- ownership disputes
- event taxonomy changes
- KG/RAG ontology changes
- automation risk review
- simulation signoff

### 10.2 Define clear RACI per failure mode
For every major failure mode, document:
- owner
- detector
- approver
- executor
- rollback owner
- post-incident reviewer

### 10.3 Train teams on the operating model
- BSS, OSS, network, SRE, and security teams should understand the boundary rules.
- Most production failures happen when teams bypass the model for convenience.

---

## 11) Suggested Production Rollout Strategy

### Phase 1: Visibility and audit first
- Start with event ingestion, audit trail, evidence federation, and dashboards.
- No autonomous remediation yet.

### Phase 2: Guided investigation
- Enable L1 correlation and evidence collection.
- Keep actions human-approved.

### Phase 3: Low-risk local automation
- Automate low-blast-radius actions inside owner layers.
- Measure rollback and false-positive rates.

### Phase 4: Controlled cross-domain closed loop
- Enable selective L1-coordinated automation for approved scenarios only.
- Require simulation and canary validation before wide rollout.

---

## 12) Final Production Principles

Use these as non-negotiable production principles:

1. **L1 governs, correlates, and coordinates — it does not bypass ownership.**
2. **Every system has one owner layer.**
3. **Writes stay local; reads are federated through contracts.**
4. **Use event-driven suspicion propagation, not hidden point-to-point coupling.**
5. **TM Forum APIs first; custom APIs only with governance.**
6. **KG/RAG assists reasoning, but authoritative systems decide.**
7. **Every action must be traceable, reversible, and policy-checked.**
8. **Automation without simulation and rollback is not production-ready.**
9. **Customer journeys start in the owner domain and escalate only when needed.**
10. **If a shortcut violates ownership, it will become a production failure later.**
