# Event-Native Backbone and Event Schema for CSP Control Tower

## Purpose
This document explains how to implement the **event-native backbone** for the CSP Control Tower architecture, including:
- how suspicion propagation works
- how state transitions should be modeled
- what event types are needed
- how event schemas should look
- what metadata is mandatory for safe production operation

The architecture is based on the optimized hybrid model:
- federated domain control towers in L2/L3/L4
- L1 as case federation and governance layer
- event-driven suspicion propagation
- evidence plane and digital twin projection
- policy-controlled cross-domain orchestration

---

# 1) Why an Event-Native Backbone Is Needed

## 1.1 Problem with purely synchronous orchestration
If all coordination is synchronous:
- the system becomes tightly coupled
- L1 becomes a bottleneck
- retries become hard to manage
- transient outages break investigations
- proactive anomaly handling does not scale well

## 1.2 What the event-native backbone provides
An event-native backbone gives you:
- loose coupling
- retry and replay capability
- durable suspicion propagation
- asynchronous state transitions
- scalable monitoring and correlation
- strong auditability through event history

The backbone should carry:
- suspected anomaly events
- evidence-ready events
- control case lifecycle events
- approval events
- remediation events
- rollback events
- closure events

---

# 2) Event Design Principles

## 2.1 Core rule
Use events for:
- state transitions
- notifications
- suspicion propagation
- evidence availability signaling
- asynchronous workflow progression

Do not use events as a replacement for every query.
Use APIs for targeted retrieval and commands where synchronous confirmation is required.

## 2.2 Key event principles
Each event must be:
- versioned
- traceable
- idempotent where needed
- schema-validated
- classified for data sensitivity
- minimal but complete enough for routing and correlation

## 2.3 Canonical event metadata
Every event should carry:
- `eventId`
- `eventType`
- `eventVersion`
- `eventTime`
- `traceId`
- `correlationId`
- `caseId` (if known)
- `sourceLayer`
- `sourceDomain`
- `producer`
- `entityRefs`
- `classification`
- `payload`

---

# 3) Event Categories

A production-ready CSP control tower should define at least the following event categories.

## 3.1 Suspected events
Used when a domain detects an issue whose RCA may or may not stay local.

Examples:
- delayed usage feed suspected
- zombie session suspected
- duplicate charging suspected
- QoS mismatch suspected
- service degradation suspected

## 3.2 Evidence events
Used when a domain has produced an evidence pack or updated a fact relevant to a case.

Examples:
- evidence pack ready
- billing impact computed
- service impact validated
- remediation readiness available

## 3.3 Control case lifecycle events
Used to drive cross-domain case management.

Examples:
- case created
- case promoted
- case correlated
- case validated
- case paused for approval
- case resolved
- case closed

## 3.4 Remediation lifecycle events
Used for controlled action execution and traceability.

Examples:
- remediation requested
- remediation approved
- remediation started
- remediation succeeded
- remediation failed
- rollback started
- rollback completed

## 3.5 Approval events
Used for human-in-the-loop governance.

Examples:
- approval requested
- approval delegated
- approval granted
- approval rejected
- approval timed out

## 3.6 Synchronization / reference events
Used to refresh reference state in the evidence plane or digital twin.

Examples:
- account context updated
- topology projection updated
- service inventory projection refreshed
- alarm state changed

---

# 4) Suggested Event Topic / Stream Layout

A practical topic layout could look like this:

```text
suspected-event.l2
suspected-event.l3
suspected-event.l4
control-case.lifecycle
evidence.ready
approval.lifecycle
remediation.lifecycle
projection.refresh
system.health
```

You may also partition topics by use-case family or business capability, for example:

```text
billing-risk.prebill
billing-risk.postbill
service-impact
network-anomaly
charging-correlation
collections-dispute
```

---

# 5) Canonical Base Event Envelope

Every event should follow a canonical envelope.

## 5.1 Base envelope example

```json
{
  "eventId": "evt-20260428-0000123",
  "eventType": "SuspectedEvent",
  "eventSubType": "ZombieSessionSuspected",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:00:00Z",
  "traceId": "trc-99112233",
  "correlationId": "corr-session-88912",
  "caseId": null,
  "sourceLayer": "L4",
  "sourceDomain": "network",
  "producer": "network-orchestrator",
  "tenantId": "csp-001",
  "classification": "internal-sensitive",
  "schemaRef": "urn:csp:events:suspected-event:1.0.0",
  "entityRefs": [
    {"type": "billingAccount", "id": "BA-100001"},
    {"type": "service", "id": "svc-5g-001"},
    {"type": "session", "id": "pdu-88912"}
  ],
  "payload": {}
}
```

## 5.2 Why this envelope matters
This envelope lets the platform:
- route the event correctly
- correlate by trace and entity IDs
- apply schema validation
- classify data
- rebuild timelines from audit logs

---

# 6) Suspected Event Schema

## 6.1 Purpose
A suspected event is emitted by a domain when it detects an anomaly that may need cross-domain correlation.

## 6.2 Suspected event payload example

```json
{
  "eventId": "evt-20260428-0000123",
  "eventType": "SuspectedEvent",
  "eventSubType": "ZombieSessionSuspected",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:00:00Z",
  "traceId": "trc-99112233",
  "correlationId": "corr-session-88912",
  "sourceLayer": "L4",
  "sourceDomain": "network",
  "producer": "network-orchestrator",
  "classification": "internal-sensitive",
  "entityRefs": [
    {"type": "billingAccount", "id": "BA-100001"},
    {"type": "session", "id": "pdu-88912"},
    {"type": "service", "id": "svc-5g-001"}
  ],
  "payload": {
    "issueFamily": "charging-integrity",
    "suspectedRootCauseDomain": "L4",
    "impactHypothesis": "continued usage charging after expected release",
    "confidence": 0.91,
    "severity": "high",
    "businessImpactEstimate": {
      "type": "potentialOvercharge",
      "value": "medium"
    },
    "timeWindow": {
      "start": "2026-04-28T09:50:00Z",
      "end": "2026-04-28T10:00:00Z"
    },
    "evidenceRefs": [
      "evd-L4-20260428-0001",
      "evd-L4-20260428-0002"
    ],
    "dedupKey": "L4|ZombieSession|pdu-88912|2026-04-28T09:50"
  }
}
```

## 6.3 Mandatory payload fields
Recommended mandatory fields:
- `issueFamily`
- `confidence`
- `severity`
- `timeWindow`
- `evidenceRefs`
- `dedupKey`
- `suspectedRootCauseDomain`
- `impactHypothesis`

---

# 7) Evidence Ready Event Schema

## 7.1 Purpose
Signals that a domain has produced or updated an evidence pack for a case or entity.

## 7.2 Example

```json
{
  "eventId": "evt-20260428-0000455",
  "eventType": "EvidenceReadyEvent",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:01:10Z",
  "traceId": "trc-99112233",
  "correlationId": "corr-session-88912",
  "caseId": "case-70012",
  "sourceLayer": "L3",
  "sourceDomain": "service",
  "producer": "oss-orchestrator",
  "classification": "internal-sensitive",
  "entityRefs": [
    {"type": "service", "id": "svc-5g-001"}
  ],
  "payload": {
    "evidencePackId": "epk-L3-0042",
    "evidenceType": "serviceImpactValidation",
    "summary": "Service impact confirmed for 5G enterprise slice service.",
    "confidence": 0.87,
    "ttlSeconds": 600,
    "evidenceRefs": [
      "evd-L3-20260428-0110"
    ]
  }
}
```

---

# 8) Control Case Lifecycle Event Schema

## 8.1 Purpose
Tracks the state of a cross-domain control case.

## 8.2 Suggested case states
Recommended states:
- `suspected`
- `correlated`
- `validated`
- `awaitingApproval`
- `remediationInProgress`
- `resolved`
- `rolledBack`
- `closed`

## 8.3 Example event

```json
{
  "eventId": "evt-20260428-0000881",
  "eventType": "ControlCaseLifecycleEvent",
  "eventSubType": "CaseValidated",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:03:00Z",
  "traceId": "trc-99112233",
  "correlationId": "corr-session-88912",
  "caseId": "case-70012",
  "sourceLayer": "L1",
  "sourceDomain": "control-tower",
  "producer": "master-agent",
  "classification": "internal-sensitive",
  "entityRefs": [
    {"type": "billingAccount", "id": "BA-100001"},
    {"type": "service", "id": "svc-5g-001"}
  ],
  "payload": {
    "previousState": "correlated",
    "currentState": "validated",
    "resolutionPath": "cross-domain",
    "primaryOwnerLayer": "L4",
    "requiredActionClasses": ["C", "D"],
    "evidencePackIds": ["epk-L3-0042", "epk-L4-0081"],
    "summary": "Root cause validated as stale session release with customer billing exposure."
  }
}
```

---

# 9) Approval Lifecycle Event Schema

## 9.1 Purpose
Tracks high-risk actions that require human approval.

## 9.2 Example

```json
{
  "eventId": "evt-20260428-0001101",
  "eventType": "ApprovalLifecycleEvent",
  "eventSubType": "ApprovalRequested",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:04:10Z",
  "traceId": "trc-99112233",
  "correlationId": "corr-session-88912",
  "caseId": "case-70012",
  "sourceLayer": "L1",
  "sourceDomain": "control-tower",
  "producer": "approval-coordinator",
  "classification": "internal-sensitive",
  "entityRefs": [
    {"type": "remediationAction", "id": "rem-8891"}
  ],
  "payload": {
    "approvalTaskId": "apr-5511",
    "actionClass": "D",
    "approvalType": "networkAndFinancial",
    "approverGroups": ["noc-lead", "billing-ops-lead"],
    "expiresAt": "2026-04-28T10:34:10Z",
    "summary": "Approve session cleanup and targeted financial correction for affected enterprise account."
  }
}
```

---

# 10) Remediation Lifecycle Event Schema

## 10.1 Purpose
Tracks the execution of remediation actions.

## 10.2 Example

```json
{
  "eventId": "evt-20260428-0001250",
  "eventType": "RemediationLifecycleEvent",
  "eventSubType": "RemediationSucceeded",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:10:00Z",
  "traceId": "trc-99112233",
  "correlationId": "corr-session-88912",
  "caseId": "case-70012",
  "sourceLayer": "L4",
  "sourceDomain": "network",
  "producer": "remediation-agent",
  "classification": "internal-sensitive",
  "entityRefs": [
    {"type": "resource", "id": "smf-node-22"},
    {"type": "session", "id": "pdu-88912"}
  ],
  "payload": {
    "remediationActionId": "rem-8891",
    "actionType": "sessionCleanup",
    "status": "succeeded",
    "startedAt": "2026-04-28T10:08:10Z",
    "completedAt": "2026-04-28T10:09:59Z",
    "rollbackReady": true,
    "verificationRefs": ["evd-L4-20260428-0201"],
    "summary": "Stale session terminated successfully; no residual technical anomaly observed."
  }
}
```

---

# 11) Rollback Event Schema

## 11.1 Purpose
Tracks rollback when a remediation fails or creates unacceptable outcome.

## 11.2 Example

```json
{
  "eventId": "evt-20260428-0001400",
  "eventType": "RollbackLifecycleEvent",
  "eventSubType": "RollbackCompleted",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:12:30Z",
  "traceId": "trc-99112233",
  "correlationId": "corr-session-88912",
  "caseId": "case-70012",
  "sourceLayer": "L4",
  "sourceDomain": "network",
  "producer": "rollback-verifier",
  "classification": "internal-sensitive",
  "entityRefs": [
    {"type": "remediationAction", "id": "rem-8891"}
  ],
  "payload": {
    "rollbackActionId": "rbk-4411",
    "originalActionId": "rem-8891",
    "reason": "post-remediation verification failed",
    "status": "completed",
    "verificationRefs": ["evd-L4-20260428-0210"],
    "summary": "Rollback completed and system returned to last stable configuration."
  }
}
```

---

# 12) Projection Refresh Event Schema

## 12.1 Purpose
Used to update evidence plane / digital twin projections.

## 12.2 Example

```json
{
  "eventId": "evt-20260428-0001600",
  "eventType": "ProjectionRefreshEvent",
  "eventSubType": "TopologyProjectionUpdated",
  "eventVersion": "1.0.0",
  "eventTime": "2026-04-28T10:15:00Z",
  "traceId": "trc-topo-7711",
  "correlationId": "corr-topo-7711",
  "caseId": null,
  "sourceLayer": "L3",
  "sourceDomain": "service",
  "producer": "topology-adapter",
  "classification": "internal",
  "entityRefs": [
    {"type": "service", "id": "svc-5g-001"}
  ],
  "payload": {
    "projectionType": "serviceResourceTopology",
    "projectionVersion": "2026-04-28T10:15:00Z",
    "changeType": "incremental",
    "summary": "Service-to-resource mapping refreshed for impacted 5G service."
  }
}
```

---

# 13) Event Routing and Processing Logic

## 13.1 Producer rules
- L2/L3/L4 produce suspected events when local RCA may not be sufficient
- owner domains produce evidence ready events when evidence packs are available
- L1 produces case lifecycle and approval events
- owner domains produce remediation and rollback events

## 13.2 Consumer rules
- L1 monitoring consumes suspected events
- case federation consumes lifecycle events
- evidence plane consumers update twin and graph from evidence events
- dashboards consume lifecycle and remediation events
- audit pipeline consumes all events

## 13.3 Correlation rules
Correlation should use:
- traceId
- correlationId
- entityRefs
- dedupKey
- timeWindow overlap
- issueFamily

---

# 14) Event Schema Governance

## 14.1 Versioning strategy
Use semantic or controlled versioning:
- `1.0.0` for initial stable schema
- minor version for additive non-breaking changes
- major version for breaking changes

## 14.2 Schema registry
Store schemas in registry with:
- owner layer
- event type
- version
- validation rules
- backward compatibility rules

## 14.3 Payload classification
Each event should carry classification such as:
- public
- internal
- internal-sensitive
- confidential

This supports masking, routing, and access control.

---

# 15) Topic Partitioning and Ordering Guidance

## 15.1 Partition keys
Use entity-aware partitioning such as:
- billingAccountId
- serviceId
- sessionId
- caseId

This keeps related events ordered for the same operational unit.

## 15.2 Ordering note
Global ordering is not required.
Entity-level ordering is what matters.

## 15.3 Replay guidance
Keep replay support for:
- missed consumers
- twin reconstruction
- forensic audit
- incident re-simulation

---

# 16) Best Practices for Suspicion Propagation

## 16.1 Do not publish low-value noise
Before publishing suspected events, local domains should filter noise and attach:
- confidence
- severity
- impact hypothesis
- dedupKey
- evidence references

## 16.2 Separate suspicion from validation
A suspected event should not mean the issue is confirmed.
The control case must still go through:
- correlation
- validation
- evidence confirmation
- policy evaluation

## 16.3 Make events small and link-rich
Store heavy evidence in evidence plane and refer to it from events.
Do not overload event payloads with large raw records.

---

# 17) Final Guidance

## Best mental model
Think of the event-native backbone as the **circulatory system** of the architecture.

It carries:
- suspicion
- evidence availability
- lifecycle changes
- approvals
- remediation results
- rollback signals

## Best production rule
Use events to move **state and coordination**, not to replace every API call.

That gives you:
- scalable propagation
- reliable retries
- lower coupling
- better observability
- safer cross-domain orchestration
