import { test, expect } from '@playwright/test';

test.describe('Billing Control Tower - Exhaustive UI E2E Test Suite', () => {
  // Give the entire suite a massive timeout (45 minutes) to account for 10 sequential LLM runs
  test.setTimeout(2700000);

  test('1. Dashboard (Control Tower) Verification', async ({ page }) => {
    console.log('Navigating to Dashboard...');
    await page.goto('http://localhost:5173/csp');
    
    // Check Top KPIs
    await expect(page.locator('text=Financial Exposure')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('text=Auto-Remediation')).toBeVisible();
    await expect(page.locator('text=Active Cases')).toBeVisible();
    await expect(page.locator('text=Approval Backlog')).toBeVisible();
    
    // Check main panels
    await expect(page.locator('text=Actionable Focus')).toBeVisible();
    await expect(page.locator('text=Billing Portfolio')).toBeVisible();
    await expect(page.locator('text=TM Forum API Mapping')).toBeVisible();
    
    console.log('Dashboard verified successfully.');
  });

  const useCases = [
    'usage_delay',         // P1
    'duplicate_charge',    // P2
    'zombie_pdu_session',  // P3
    'qos_mismatch',        // P4
    'sla_breach',          // P5
    'collections_hold',    // P6
    'partner_discrepancy', // P7
    'confusing_invoice',   // P8 (Might use chat instead, but we can inject it)
    'proactive_risk',      // P9
    'governed_b2b_dispute' // P10
  ];

  test('2. Agentic Tower Verification - Sequential Execution of All Use Cases', async ({ page }) => {
    console.log('Navigating to Agentic Tower...');
    await page.goto('http://localhost:5173/agents');
    
    for (const uc of useCases) {
      console.log(`\n================================`);
      console.log(`Starting Use Case: ${uc}`);
      console.log(`================================`);

      // 1. Inject Scenario
      const injectDropdown = page.locator('select', { hasText: '-- Inject Scenario --' });
      await injectDropdown.waitFor({ state: 'visible' });
      
      // Check if option exists in dropdown before selecting, some MVP3 mocks might not have all 10 in the UI dropdown.
      // If it doesn't exist, we skip
      const optionExists = await page.evaluate((val) => {
        const select = document.querySelector('select:first-of-type');
        if (!select) return false;
        return Array.from(select.options).some(opt => opt.value === val);
      }, uc);

      if (!optionExists) {
         console.log(`[WARNING] Option ${uc} not found in inject dropdown. Skipping UI test for this use case.`);
         continue;
      }

      await injectDropdown.selectOption(uc);
      await page.locator('button', { hasText: 'Inject' }).click();
      
      // Wait for injection success message
      await expect(page.locator(`text=Successfully injected ${uc} scenario.`)).toBeVisible({ timeout: 15000 });

      // 2. Select the issue from the Investigation dropdown
      console.log(`Selecting the injected issue for ${uc}...`);
      const issueDropdown = page.locator('select', { hasText: '-- Choose Issue to Investigate --' });
      
      // Wait for dropdown to update
      await page.waitForTimeout(2000); 

      // Select the last option in the dropdown (which is typically the most recently injected)
      const targetValue = await page.evaluate(() => {
        const select = document.querySelectorAll('select.picker')[1]; // Second dropdown
        if (!select || select.options.length <= 1) return null;
        // Find the last option that corresponds to this use case type. Or just the last option.
        return select.options[select.options.length - 1].value;
      });

      if (!targetValue) {
        console.log(`[ERROR] Could not find injected issue for ${uc}.`);
        continue;
      }

      await issueDropdown.selectOption(targetValue);

      // 3. Run Investigation
      console.log(`Running investigation for ${targetValue}...`);
      await page.locator('button', { hasText: 'Run Investigation' }).click();

      // 4. Wait for LLM (up to 4 minutes per use case)
      console.log(`Waiting for agentic graph to execute (can take 2-4 minutes)...`);
      
      // It will either finish and show "Resolution Summary" OR pause and show "Approve Remediation Action"
      const approveBtn = page.locator('button', { hasText: 'Approve Remediation Action' });
      const resolutionText = page.locator('text=Resolution Summary');

      // We race them
      try {
        await Promise.race([
          expect(approveBtn).toBeVisible({ timeout: 240000 }),
          expect(resolutionText).toBeVisible({ timeout: 240000 })
        ]);
      } catch (e) {
        console.log(`[ERROR] Timeout waiting for ${uc} graph to respond.`);
        continue;
      }

      const needsApproval = await approveBtn.isVisible();
      if (needsApproval) {
        console.log(`Graph paused. Clicking 'Approve Remediation Action'...`);
        await approveBtn.click();
        console.log(`Waiting for resumed graph to resolve...`);
        await expect(resolutionText).toBeVisible({ timeout: 240000 });
      }

      console.log(`Use Case ${uc} fully resolved and verified!`);
    }
  });

  test('3. Bills Drilldown (Billing Tower) Verification', async ({ page }) => {
    console.log('\nNavigating to Bills Drilldown...');
    await page.goto('http://localhost:5173/bills');
    
    // Check list of bills
    await expect(page.locator('text=Disputed Bills')).toBeVisible({ timeout: 10000 });
    
    // Wait for at least one bill card
    const firstBill = page.locator('.bill-card').first();
    await firstBill.waitFor({ state: 'visible', timeout: 10000 });
    
    // Click the bill
    console.log('Selecting a disputed bill...');
    await firstBill.click();

    // Check Customer details and TMF678 lines
    await expect(page.locator('text=Customer & Account')).toBeVisible();
    await expect(page.locator('text=Invoice Lines (TMF678)')).toBeVisible();
    await expect(page.locator('text=Service / Description')).toBeVisible();
    
    console.log('Bills Drilldown verified successfully.');
  });
});
