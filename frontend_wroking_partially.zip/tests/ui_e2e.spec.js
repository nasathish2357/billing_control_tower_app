import { test, expect } from '@playwright/test';

test.describe('Agentic Billing Tower UI E2E Tests', () => {
  // Increase test timeout to 6 minutes for LLM processing
  test.setTimeout(360000);

  test('E2E Flow: P5 SLA Breach injection, investigation, and approval', async ({ page }) => {
    // 1. Navigate to the agents page
    console.log('Navigating to Agentic Tower...');
    await page.goto('http://localhost:5173/agents');
    
    // 2. Inject SLA Breach Scenario
    console.log('Injecting P5 SLA Breach scenario...');
    const injectDropdown = page.locator('select', { hasText: '-- Inject Scenario --' });
    await injectDropdown.waitFor({ state: 'visible' });
    await injectDropdown.selectOption('sla_breach');
    
    const injectButton = page.locator('button', { hasText: 'Inject' });
    await injectButton.click();

    // Wait for the success message in the chat assistant
    await expect(page.locator('text=Successfully injected sla_breach scenario.')).toBeVisible({ timeout: 10000 });

    // 3. Select the newly injected issue
    console.log('Selecting the injected P5 issue...');
    const issueDropdown = page.locator('select', { hasText: '-- Choose Issue to Investigate --' });
    
    // Since there might be multiple, we grab the option containing "P5"
    // Wait for the dropdown to populate with the P5 issue
    await page.waitForFunction(() => {
      const select = document.querySelector('select.picker:nth-child(2)'); // The issue dropdown
      if (!select) return false;
      const options = Array.from(select.options);
      return options.some(opt => opt.text.includes('P5'));
    }, { timeout: 10000 });

    // Get the exact value of the P5 option
    const p5OptionValue = await page.evaluate(() => {
      const select = document.querySelector('select.picker:nth-child(2)');
      const options = Array.from(select.options);
      const p5Opt = options.find(opt => opt.text.includes('P5'));
      return p5Opt ? p5Opt.value : null;
    });
    
    expect(p5OptionValue).not.toBeNull();
    await issueDropdown.selectOption(p5OptionValue);

    // 4. Run Investigation
    console.log('Running investigation...');
    const runBtn = page.locator('button', { hasText: 'Run Investigation' });
    await runBtn.click();

    // 5. Wait for the approval prompt (LLM wait time!)
    console.log('Waiting for the agentic graph to pause for human approval (can take 2-3 mins)...');
    const approveBtn = page.locator('button', { hasText: 'Approve Remediation Action' });
    await expect(approveBtn).toBeVisible({ timeout: 300000 }); // 5 minutes max wait
    
    console.log('Graph paused successfully. Clicking Approve...');
    await approveBtn.click();

    // 6. Wait for the final resolution
    console.log('Waiting for the graph to resume and resolve...');
    await expect(page.locator('text=Resolution Summary')).toBeVisible({ timeout: 240000 });

    console.log('Graph execution fully completed!');

    // 7. Check Bills Drilldown
    console.log('Navigating to Bills Drilldown...');
    await page.goto('http://localhost:5173/bills');
    
    // Wait for the list of disputes to load
    console.log('Verifying bill drilldown visibility...');
    await expect(page.locator('text=Disputed Bills')).toBeVisible();
    
    console.log('E2E Test Passed Successfully!');
  });
});
