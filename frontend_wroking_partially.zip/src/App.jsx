import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './views/Dashboard';
import AgenticTower from './views/AgenticTower';
import Chat from './views/Chat';
import KpiGuide from './views/KpiGuide';
import BillsDrilldown from './views/BillsDrilldown';
import KnowledgeGraph from './views/KnowledgeGraph';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="agents" element={<AgenticTower />} />
          <Route path="chat" element={<Chat />} />
          <Route path="kpi-guide" element={<KpiGuide />} />
          <Route path="bills" element={<BillsDrilldown />} />
          <Route path="knowledge-graph" element={<KnowledgeGraph />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;
