import React, { useEffect, useState } from 'react';
import { apiMap } from '../data/usecases';
import {
  getDashboardSummary,
  getLayerHealth,
  getPostbillDisputes,
  getPrebillRisks,
  getAuditSummary,
  getPendingApprovals,
} from '../api';

const Badge = ({ children, color }) => (
  <span className="badge" style={color ? { background: color, color: '#fff' } : {}}>
    {String(children)}
  </span>
);

// Layer health fields differ by layer — each has distinct operational data
const LAYER_META = {
  L1: { label: 'L1 Control Tower', color: '#2563eb', bg: '#eff6ff' },
  L2: { label: 'L2 BSS',           color: '#059669', bg: '#f0fdf4' },
  L3: { label: 'L3 OSS',           color: '#7c3aed', bg: '#f5f3ff' },
  L4: { label: 'L4 Network',       color: '#f97316', bg: '#fff7ed' },
};

function LayerCard({ layer, data }) {
  const meta = LAYER_META[layer] || { label: layer, color: '#64748b', bg: '#f8fafc' };
  const isHealthy = data.status === 'healthy';
  return (
    <div style={{
      border: `2px solid ${isHealthy ? meta.color : '#f59e0b'}`,
      borderRadius: '.75rem', padding: '.85rem',
      background: isHealthy ? meta.bg : '#fffbeb',
    }}>
      <div style={{ fontWeight: 900, fontSize: '.75rem', color: meta.color, textTransform: 'uppercase', letterSpacing: '.08em' }}>
        {layer}
      </div>
      <div style={{ fontWeight: 700, fontSize: '.85rem', marginTop: '.15rem', color: '#0f172a' }}>
        {meta.label}
      </div>
      <div style={{ marginTop: '.4rem' }}>
        <Badge color={isHealthy ? '#059669' : '#d97706'}>{data.status}</Badge>
      </div>
      {/* Per-layer operational details */}
      {layer === 'L1' && data.pending_approvals > 0 && (
        <div style={{ fontSize: '.72rem', color: '#92400e', marginTop: '.3rem' }}>
          {data.pending_approvals} approval(s) pending
        </div>
      )}
      {layer === 'L2' && (
        <div style={{ fontSize: '.72rem', color: '#64748b', marginTop: '.3rem' }}>
          {data.open_trouble_tickets ?? 0} open tickets
        </div>
      )}
      {layer === 'L3' && (
        <div style={{ fontSize: '.72rem', color: data.sla_breach_active ? '#dc2626' : '#64748b', marginTop: '.3rem' }}>
          {data.open_service_problems ?? 0} service problems
          {data.sla_breach_active ? ' · SLA breach!' : ''}
        </div>
      )}
      {layer === 'L4' && data.network_functions && (
        <div style={{ fontSize: '.72rem', color: '#64748b', marginTop: '.3rem' }}>
          {Object.keys(data.network_functions).length} NF type(s)
        </div>
      )}
    </div>
  );
}

const Dashboard = () => {
  const [summary, setSummary]           = useState(null);
  const [layerHealth, setLayerHealth]   = useState(null);   // raw object {L1,L2,L3,L4}
  const [disputes, setDisputes]         = useState([]);
  const [risks, setRisks]               = useState([]);
  const [auditSummary, setAuditSummary] = useState(null);
  const [pendingApprovals, setPendingApprovals] = useState([]);
  const [loading, setLoading]           = useState(true);
  const [errors, setErrors]             = useState({});

  useEffect(() => {
    const load = async () => {
      const [sumRes, layerRes, dispRes, riskRes, auditRes, apprRes] = await Promise.allSettled([
        getDashboardSummary(),
        getLayerHealth(),
        getPostbillDisputes(),
        getPrebillRisks(15),
        getAuditSummary(),
        getPendingApprovals(),
      ]);

      const errs = {};
      if (sumRes.status   === 'fulfilled') setSummary(sumRes.value.data);
      else errs.summary = sumRes.reason?.message;

      // Backend returns keyed object {L1:{...},L2:{...},L3:{...},L4:{...}}
      // Each layer has different operational fields — we keep the object as-is
      // and render per layer with LayerCard which knows each layer's field names.
      if (layerRes.status === 'fulfilled') setLayerHealth(layerRes.value.data);
      else errs.layer = layerRes.reason?.message;

      // disputes[].amount_due is the bill amount (not financial_impact — that field doesn't exist)
      if (dispRes.status  === 'fulfilled') setDisputes(dispRes.value.data?.disputes || []);
      else errs.disputes = dispRes.reason?.message;

      // accounts[].risk_score, .billing_account_id, .customer_id, .risk_level are exact field names
      if (riskRes.status  === 'fulfilled') setRisks(riskRes.value.data?.accounts || []);
      else errs.risks = riskRes.reason?.message;

      if (auditRes.status === 'fulfilled') setAuditSummary(auditRes.value.data);
      else errs.audit = auditRes.reason?.message;

      // Approval model field is `amount` (Optional[float]), not financial_impact
      if (apprRes.status  === 'fulfilled') setPendingApprovals(apprRes.value.data || []);
      else errs.approvals = apprRes.reason?.message;

      setErrors(errs);
      setLoading(false);
    };
    load();
  }, []);

  if (loading) return <div className="empty">Loading dashboard…</div>;

  const s = summary || {};
  const issues = s.issues || {};
  const exposure = s.financial_exposure || {};

  return (
    <>
      {/* ─── KPI Grid ─────────────────────────────────────────────── */}
      <div className="kpi-grid">
        <div className="kpi"><span>Total Issues</span><strong>{issues.total ?? '—'}</strong></div>
        <div className="kpi"><span>Remediated</span><strong>{issues.remediated ?? '—'}</strong></div>
        <div className="kpi"><span>Remediation Rate</span><strong>{issues.remediation_rate_pct != null ? `${issues.remediation_rate_pct}%` : '—'}</strong></div>
        <div className="kpi"><span>Open Issues</span><strong>{issues.open ?? '—'}</strong></div>
        <div className="kpi"><span>Pending Approvals</span><strong>{s.approvals?.pending ?? pendingApprovals.length}</strong></div>
        <div className="kpi"><span>Active Control Cases</span><strong>{s.control_cases?.active ?? '—'}</strong></div>
        <div className="kpi"><span>Disputed Bills (USD)</span><strong>{exposure.total_disputed_usd != null ? `$${exposure.total_disputed_usd.toLocaleString()}` : '—'}</strong></div>
        <div className="kpi"><span>Audit Traces</span><strong>{auditSummary?.recent_audit_count ?? '—'}</strong></div>
      </div>

      {/* ─── Layer Health ─────────────────────────────────────────── */}
      {layerHealth && (
        <section className="card">
          <h2>Layer Health</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '.65rem' }}>
            {['L1','L2','L3','L4'].map(layer =>
              layerHealth[layer] ? (
                <LayerCard key={layer} layer={layer} data={layerHealth[layer]} />
              ) : null
            )}
          </div>
          {errors.layer && <div style={{ fontSize: '.72rem', color: '#dc2626', marginTop: '.4rem' }}>Layer health unavailable: {errors.layer}</div>}
        </section>
      )}

      {/* ─── Pending Approvals ────────────────────────────────────── */}
      {pendingApprovals.length > 0 && (
        <section className="card">
          <h2>Pending Approvals ({pendingApprovals.length})</h2>
          <div className="usecase-list">
            {pendingApprovals.map((a) => (
              <article key={a.id} className="usecase row">
                <div className="tag">
                  <Badge>{a.id?.slice(0, 12)}</Badge>
                  <Badge>{a.status}</Badge>
                </div>
                <div>
                  <strong>{a.issue_id}</strong>
                  <p className="issue-copy">{a.action || a.risk_reason || 'Awaiting approval decision.'}</p>
                </div>
                {/* Field name is `amount` in ApprovalOut, not financial_impact */}
                <div className="row-meta">
                  <span>Amount</span>
                  <strong>{a.amount != null ? `£${a.amount}` : '—'}</strong>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* ─── Post-bill Disputes ───────────────────────────────────── */}
      {disputes.length > 0 && (
        <section className="card">
          <h2>Post-bill Disputes ({disputes.length})</h2>
          <div className="usecase-list">
            {disputes.map((d, i) => (
              <article key={d.bill_id || i} className="usecase row">
                <div className="tag">
                  <Badge>{d.use_case_id || '—'}</Badge>
                  <Badge>{d.status}</Badge>
                </div>
                <div>
                  <strong>{d.billing_account_id}</strong>
                  <p className="issue-copy">Bill {d.bill_id} · {d.billing_period}</p>
                </div>
                {/* Field name is `amount_due` — the actual bill amount under dispute */}
                <div className="row-meta">
                  <span>Amount due</span>
                  <strong>{d.amount_due != null ? `$${d.amount_due}` : '—'}</strong>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* ─── Pre-bill Risks ───────────────────────────────────────── */}
      {risks.length > 0 && (
        <section className="card">
          <h2>Pre-bill Risks ({risks.length})</h2>
          <div className="usecase-list">
            {risks.map((r, i) => (
              <article key={r.billing_account_id || i} className="usecase row">
                <div className="tag">
                  {/* risk_level and risk_score are the exact field names from get_high_risk_accounts */}
                  <Badge color={r.risk_level === 'CRITICAL' ? '#dc2626' : r.risk_level === 'HIGH' ? '#d97706' : '#64748b'}>
                    {r.risk_level}
                  </Badge>
                  <Badge>Score {r.risk_score}</Badge>
                </div>
                <div>
                  <strong>{r.billing_account_id}</strong>
                  <p className="issue-copy">Customer: {r.customer_id} · {r.signal_count} signal(s)</p>
                </div>
                <div className="row-meta">
                  <span>Risk score</span>
                  <strong>{r.risk_score}/100</strong>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* ─── Recent Audit Traces ──────────────────────────────────── */}
      {auditSummary?.recent_traces?.length > 0 && (
        <section className="card">
          <h2>Recent Audit Traces</h2>
          <div className="usecase-list">
            {auditSummary.recent_traces.slice(0, 5).map((t) => (
              <article key={t.id} className="usecase row">
                <div className="tag"><Badge>{t.action_type}</Badge></div>
                <div>
                  <strong>{t.actor}</strong>
                  <p className="issue-copy">{t.summary}</p>
                </div>
                <div className="row-meta">
                  <span>{t.control_case_id}</span>
                  <strong style={{ fontSize: '.7rem', color: '#64748b' }}>
                    {t.created_at ? new Date(t.created_at).toLocaleString() : '—'}
                  </strong>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* ─── TMForum APIs ─────────────────────────────────────────── */}
      <section className="card tmf-bottom">
        <h2>TMForum APIs Utilized</h2>
        <div className="api-list bottom">
          {apiMap.map((a, i) => (
            <div key={i} className="api">
              <strong>{a[0]}</strong>
              <span className="muted">{a[1]}</span>
              <small>{a[2]}</small>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Dashboard;
