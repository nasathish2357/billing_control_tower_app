/**
 * Knowledge Graph View
 *
 * Surfaces the backend /kg/* endpoints as an interactive SVG graph.
 * Nodes are coloured by entity type. Edges show directed relationships.
 * Click a node to inspect its properties in the detail panel.
 * Scroll to zoom · drag background to pan.
 *
 * Drill-down: clicking a Bill, Customer, or ControlCase node exposes
 * context-specific KG queries in the inspector panel:
 *   Bill       → GET /kg/trace/bill/{id}
 *   Customer   → GET /kg/customer/{id}/billing-context
 *   ControlCase → GET /kg/control-case/{id}/impact
 *
 * No D3 or external graph library required — plain SVG + React state.
 */
import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  rebuildKg,
  getKgIssueRelationships,
  getKgCustomerContext,
  getKgControlCaseImpact,
  getKgBillTrace,
} from '../api';
import { usecases } from '../data/usecases';

// ── Node type colour palette ──────────────────────────────────────────────────
const NODE_COLOR = {
  Customer:         '#1d4ed8',
  BillingAccount:   '#047857',
  Bill:             '#c2410c',
  Issue:            '#dc2626',
  ControlCase:      '#7c3aed',
  EvidencePack:     '#0f766e',
  AuditTrace:       '#b45309',
  Approval:         '#a16207',
  TMFEvent:         '#0e7490',
  TroubleTicket:    '#be185d',
  ServiceProblem:   '#be123c',
  BillLineItem:     '#ea580c',
  RatedUsage:       '#16a34a',
  UsageEvent:       '#15803d',
  MediationRecord:  '#0369a1',
  PDUSession:       '#6d28d9',
  ServiceInventory: '#0891b2',
  NetworkFunction:  '#9333ea',
  Product:          '#4338ca',
  ProductOffering:  '#7c3aed',
  Device:           '#64748b',
  PaymentRecord:    '#854d0e',
  PartnerAccount:   '#1e40af',
  PartnerSettlement:'#065f46',
};
const DEFAULT_COLOR = '#475569';

function nodeColor(type) {
  return NODE_COLOR[type] || DEFAULT_COLOR;
}

// ── Force-directed layout (synchronous, runs once per data load) ──────────────
function computeLayout(nodes, edges, W = 900, H = 620) {
  if (!nodes.length) return {};

  const pos = {};
  nodes.forEach((n, i) => {
    const angle = (i / nodes.length) * 2 * Math.PI;
    const r = Math.min(W, H) * 0.35;
    pos[n.id] = {
      x: W / 2 + r * Math.cos(angle),
      y: H / 2 + r * Math.sin(angle),
      vx: 0, vy: 0,
    };
  });

  const REPULSION = 4000;
  const SPRING    = 100;
  const STIFFNESS = 0.04;
  const DAMPING   = 0.75;
  const ITERS     = 160;

  for (let iter = 0; iter < ITERS; iter++) {
    const ids = Object.keys(pos);
    for (let i = 0; i < ids.length; i++) {
      for (let j = i + 1; j < ids.length; j++) {
        const a = pos[ids[i]];
        const b = pos[ids[j]];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d  = Math.sqrt(dx * dx + dy * dy) || 0.1;
        const f  = REPULSION / (d * d);
        const fx = (dx / d) * f;
        const fy = (dy / d) * f;
        a.vx -= fx; a.vy -= fy;
        b.vx += fx; b.vy += fy;
      }
    }

    for (const e of edges) {
      const a = pos[e.from];
      const b = pos[e.to];
      if (!a || !b) continue;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d  = Math.sqrt(dx * dx + dy * dy) || 0.1;
      const f  = (d - SPRING) * STIFFNESS;
      const fx = (dx / d) * f;
      const fy = (dy / d) * f;
      a.vx += fx; a.vy += fy;
      b.vx -= fx; b.vy -= fy;
    }

    for (const id of Object.keys(pos)) {
      const p = pos[id];
      p.vx += (W / 2 - p.x) * 0.002;
      p.vy += (H / 2 - p.y) * 0.002;
    }

    for (const id of Object.keys(pos)) {
      const p = pos[id];
      p.x  += p.vx;
      p.y  += p.vy;
      p.vx *= DAMPING;
      p.vy *= DAMPING;
      p.x = Math.max(40, Math.min(W - 40, p.x));
      p.y = Math.max(30, Math.min(H - 30, p.y));
    }
  }

  return pos;
}

// ── Normalise any KG response shape into {nodes, edges, total_nodes, total_edges}
function normaliseKgResponse(data) {
  if (!data) return { nodes: [], edges: [], total_nodes: 0, total_edges: 0 };

  // Issue relationships — already correct shape
  if (data.nodes && data.edges) {
    return {
      nodes: data.nodes,
      edges: data.edges,
      total_nodes: data.total_nodes ?? data.nodes.length,
      total_edges: data.total_edges ?? data.edges.length,
    };
  }

  // Customer billing context — {customer, billing_accounts, bills, issues, control_cases, edges}
  if (data.billing_accounts) {
    const nodes = [];
    const edges = data.edges || [];
    if (data.customer)          nodes.push(data.customer);
    if (data.billing_accounts)  nodes.push(...data.billing_accounts);
    if (data.bills)             nodes.push(...data.bills);
    if (data.issues)            nodes.push(...data.issues);
    if (data.control_cases)     nodes.push(...data.control_cases);
    return { nodes, edges, total_nodes: nodes.length, total_edges: edges.length };
  }

  // Control case impact / bill trace — may have similar flat structures
  const nodes = [];
  const edges = data.edges || data.relationships || [];
  for (const key of Object.keys(data)) {
    const val = data[key];
    if (key === 'edges' || key === 'relationships' || key === 'error' || key === 'warning') continue;
    if (Array.isArray(val)) nodes.push(...val);
    else if (val && typeof val === 'object' && val.id && val.type) nodes.push(val);
  }
  return { nodes, edges, total_nodes: nodes.length, total_edges: edges.length };
}

// ── Node detail + drill-down panel ────────────────────────────────────────────
function NodeDetail({ node, edges, onDrillDown, drillLoading }) {
  if (!node) return (
    <div style={{ padding: '1.2rem', color: '#94a3b8', fontSize: '.85rem' }}>
      Click a node to inspect its properties and relationships.
      <div style={{ marginTop: '.75rem', fontSize: '.75rem', color: '#cbd5e1' }}>
        Bill, Customer, and ControlCase nodes support drill-down queries.
      </div>
    </div>
  );

  const color    = nodeColor(node.type);
  const outEdges = edges.filter(e => e.from === node.id);
  const inEdges  = edges.filter(e => e.to   === node.id);
  const props    = Object.entries(node).filter(([k]) => k !== 'id' && k !== 'type');

  const drillActions = {
    Bill:        { label: 'Trace Bill → Usage Chain', mode: 'bill_trace',   icon: '🔍' },
    Customer:    { label: 'Customer Billing Context',  mode: 'customer',     icon: '👤' },
    ControlCase: { label: 'Show Control Case Impact',  mode: 'impact',       icon: '📊' },
  };
  const action = drillActions[node.type];

  return (
    <div style={{ padding: '.9rem', overflowY: 'auto', maxHeight: '100%' }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: '.5rem', marginBottom: '.75rem',
        paddingBottom: '.6rem', borderBottom: '1px solid #e2e8f0',
      }}>
        <div style={{ width: 14, height: 14, borderRadius: '50%', background: color, flexShrink: 0 }} />
        <div>
          <div style={{ fontSize: '.65rem', fontWeight: 900, color, textTransform: 'uppercase', letterSpacing: '.08em' }}>
            {node.type}
          </div>
          <div style={{ fontSize: '.8rem', fontWeight: 700, color: '#0f172a', wordBreak: 'break-all' }}>
            {node.id}
          </div>
        </div>
      </div>

      {/* Drill-down action button */}
      {action && (
        <button
          className="btn primary"
          style={{ width: '100%', marginBottom: '.75rem', fontSize: '.75rem', justifyContent: 'center' }}
          onClick={() => onDrillDown(node, action.mode)}
          disabled={drillLoading}
        >
          {drillLoading ? 'Loading…' : `${action.icon} ${action.label}`}
        </button>
      )}

      {/* Properties */}
      {props.length > 0 && (
        <>
          <div style={{ fontSize: '.65rem', fontWeight: 900, color: '#64748b', textTransform: 'uppercase', marginBottom: '.35rem' }}>
            Properties
          </div>
          {props.map(([k, v]) => (
            <div key={k} style={{ display: 'flex', gap: '.4rem', marginBottom: '.25rem', flexWrap: 'wrap' }}>
              <span style={{ fontSize: '.7rem', color: '#94a3b8', minWidth: '7rem' }}>{k}</span>
              <span style={{ fontSize: '.72rem', color: '#0f172a', fontWeight: 600, wordBreak: 'break-all' }}>
                {v != null ? String(v) : '—'}
              </span>
            </div>
          ))}
        </>
      )}

      {/* Outgoing relationships */}
      {outEdges.length > 0 && (
        <div style={{ marginTop: '.7rem' }}>
          <div style={{ fontSize: '.65rem', fontWeight: 900, color: '#64748b', textTransform: 'uppercase', marginBottom: '.35rem' }}>
            Outgoing ({outEdges.length})
          </div>
          {outEdges.map((e, i) => (
            <div key={i} style={{
              fontSize: '.7rem', padding: '.25rem .4rem', borderRadius: '.35rem',
              background: '#f1f5f9', marginBottom: '.2rem', display: 'flex', gap: '.4rem',
            }}>
              <span style={{ color: '#7c3aed', fontWeight: 700 }}>{e.rel}</span>
              <span style={{ color: '#64748b' }}>→</span>
              <span style={{ color: '#0f172a', wordBreak: 'break-all' }}>{e.to}</span>
            </div>
          ))}
        </div>
      )}

      {/* Incoming relationships */}
      {inEdges.length > 0 && (
        <div style={{ marginTop: '.7rem' }}>
          <div style={{ fontSize: '.65rem', fontWeight: 900, color: '#64748b', textTransform: 'uppercase', marginBottom: '.35rem' }}>
            Incoming ({inEdges.length})
          </div>
          {inEdges.map((e, i) => (
            <div key={i} style={{
              fontSize: '.7rem', padding: '.25rem .4rem', borderRadius: '.35rem',
              background: '#f8fafc', marginBottom: '.2rem', display: 'flex', gap: '.4rem',
            }}>
              <span style={{ color: '#64748b', wordBreak: 'break-all' }}>{e.from}</span>
              <span style={{ color: '#64748b' }}>→</span>
              <span style={{ color: '#7c3aed', fontWeight: 700 }}>{e.rel}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
const W = 900;
const H = 620;
const NODE_R = 18;

const KnowledgeGraph = () => {
  const [selectedIssue, setSelectedIssue] = useState(usecases[1]);
  const [nodes, setNodes]               = useState([]);
  const [edges, setEdges]               = useState([]);
  const [positions, setPositions]       = useState({});
  const [selectedNode, setSelectedNode] = useState(null);
  const [hoveredEdge, setHoveredEdge]   = useState(null);
  const [loading, setLoading]           = useState(false);
  const [drillLoading, setDrillLoading] = useState(false);
  const [error, setError]               = useState(null);
  const [stats, setStats]               = useState(null);
  const [viewLabel, setViewLabel]       = useState('');
  const [history, setHistory]           = useState([]);

  const [transform, setTransform] = useState({ scale: 1, x: 0, y: 0 });
  const panRef = useRef({ active: false, startX: 0, startY: 0, tx: 0, ty: 0 });

  const applyGraph = useCallback((raw, label) => {
    const g = normaliseKgResponse(raw);
    setNodes(g.nodes);
    setEdges(g.edges);
    setPositions(computeLayout(g.nodes, g.edges, W, H));
    setStats({ total_nodes: g.total_nodes, total_edges: g.total_edges });
    setViewLabel(label);
    setSelectedNode(null);
    setTransform({ scale: 1, x: 0, y: 0 });
  }, []);

  const loadGraph = useCallback(async (issue) => {
    setLoading(true);
    setError(null);
    setHistory([]);
    try {
      const res = await getKgIssueRelationships(issue.issueId);
      applyGraph(res.data, `Issue Relationships — ${issue.id}`);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Failed to load graph');
    } finally {
      setLoading(false);
    }
  }, [applyGraph]);

  useEffect(() => { loadGraph(selectedIssue); }, [selectedIssue, loadGraph]);

  // ── Drill-down from node inspector ────────────────────────────────
  const handleDrillDown = async (node, mode) => {
    setDrillLoading(true);
    setError(null);

    // Push current view onto history stack
    setHistory(h => [...h, { nodes, edges, positions, stats, viewLabel, selectedNode: null }]);

    try {
      let res;
      let label;
      if (mode === 'bill_trace') {
        res = await getKgBillTrace(node.id);
        label = `Bill Trace — ${node.id}`;
      } else if (mode === 'customer') {
        res = await getKgCustomerContext(node.id);
        label = `Customer Context — ${node.id}`;
      } else if (mode === 'impact') {
        res = await getKgControlCaseImpact(node.id);
        label = `Control Case Impact — ${node.id}`;
      }
      applyGraph(res.data, label);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Drill-down failed');
      // Pop history back on failure
      setHistory(h => h.slice(0, -1));
    } finally {
      setDrillLoading(false);
    }
  };

  const handleBack = () => {
    if (!history.length) return;
    const prev = history[history.length - 1];
    setNodes(prev.nodes);
    setEdges(prev.edges);
    setPositions(prev.positions);
    setStats(prev.stats);
    setViewLabel(prev.viewLabel);
    setSelectedNode(null);
    setHistory(h => h.slice(0, -1));
  };

  const handleRebuild = async () => {
    setLoading(true);
    setError(null);
    try {
      await rebuildKg();
      await loadGraph(selectedIssue);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'Rebuild failed');
      setLoading(false);
    }
  };

  // ── Zoom ──────────────────────────────────────────────────────────
  const handleWheel = (e) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.12 : 0.89;
    setTransform(t => ({
      ...t,
      scale: Math.max(0.25, Math.min(4, t.scale * factor)),
    }));
  };

  // ── Pan ───────────────────────────────────────────────────────────
  const handleMouseDown = (e) => {
    if (e.target.closest('circle') || e.target.closest('text')) return;
    panRef.current = { active: true, startX: e.clientX, startY: e.clientY, tx: transform.x, ty: transform.y };
    e.currentTarget.style.cursor = 'grabbing';
  };
  const handleMouseMove = (e) => {
    if (!panRef.current.active) return;
    const dx = e.clientX - panRef.current.startX;
    const dy = e.clientY - panRef.current.startY;
    setTransform(t => ({ ...t, x: panRef.current.tx + dx, y: panRef.current.ty + dy }));
  };
  const handleMouseUp = (e) => {
    panRef.current.active = false;
    if (e.currentTarget) e.currentTarget.style.cursor = 'grab';
  };

  const handleNodeClick = (node, e) => {
    e.stopPropagation();
    setSelectedNode(prev => prev?.id === node.id ? null : node);
  };

  function edgeMid(e) {
    const src = positions[e.from];
    const tgt = positions[e.to];
    if (!src || !tgt) return null;
    return { x: (src.x + tgt.x) / 2, y: (src.y + tgt.y) / 2 };
  }

  function edgeEndpoints(e) {
    const src = positions[e.from];
    const tgt = positions[e.to];
    if (!src || !tgt) return null;
    const dx = tgt.x - src.x;
    const dy = tgt.y - src.y;
    const d  = Math.sqrt(dx * dx + dy * dy) || 1;
    return {
      x1: src.x + (dx / d) * NODE_R,
      y1: src.y + (dy / d) * NODE_R,
      x2: tgt.x - (dx / d) * (NODE_R + 8),
      y2: tgt.y - (dy / d) * (NODE_R + 8),
    };
  }

  function nodeLabel(n) {
    return n.name || n.event_type || n.nf_type || n.action_type || n.ticket_type || n.problem_type || n.id?.slice(-8) || n.type;
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: '.75rem', height: 'calc(100vh - 12rem)' }}>

      {/* ── Left: Graph canvas ──────────────────────────────────── */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '.5rem' }}>

        {/* Toolbar */}
        <section className="card" style={{ padding: '.75rem 1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '.65rem', flexWrap: 'wrap' }}>
            <h2 style={{ margin: 0, fontSize: '.95rem' }}>Knowledge Graph</h2>

            <select
              className="select"
              value={selectedIssue.id}
              onChange={e => {
                const uc = usecases.find(u => u.id === e.target.value);
                setSelectedIssue(uc);
              }}
            >
              {usecases.map(u => (
                <option key={u.id} value={u.id}>{u.id} — {u.customer} ({u.title.slice(0, 28)}…)</option>
              ))}
            </select>

            <button className="btn primary" onClick={() => loadGraph(selectedIssue)} disabled={loading}>
              {loading ? 'Loading…' : 'Load Issue'}
            </button>
            <button className="btn" onClick={handleRebuild} disabled={loading}>Rebuild KG</button>
            {history.length > 0 && (
              <button className="btn" onClick={handleBack}>← Back</button>
            )}
            <button className="btn" onClick={() => setTransform({ scale: 1, x: 0, y: 0 })}>Reset Zoom</button>

            {stats && (
              <span style={{ fontSize: '.72rem', color: '#64748b' }}>
                {stats.total_nodes} nodes · {stats.total_edges} edges
              </span>
            )}
          </div>

          {viewLabel && (
            <div style={{ fontSize: '.72rem', color: '#7c3aed', marginTop: '.35rem', fontWeight: 700 }}>
              {viewLabel}
            </div>
          )}
          {error && (
            <div style={{ marginTop: '.4rem', fontSize: '.75rem', color: '#dc2626' }}>
              Error: {error}
            </div>
          )}
        </section>

        {/* SVG canvas */}
        <section className="card" style={{ flex: 1, padding: 0, overflow: 'hidden', position: 'relative' }}>
          {loading && (
            <div style={{
              position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
              justifyContent: 'center', background: 'rgba(255,255,255,.7)', zIndex: 10,
              fontSize: '.9rem', color: '#64748b',
            }}>
              Building graph…
            </div>
          )}

          {!loading && nodes.length === 0 && (
            <div className="empty">No graph data. Select an issue and click Load Issue.</div>
          )}

          <svg
            width="100%" height="100%"
            viewBox={`0 0 ${W} ${H}`}
            style={{ cursor: 'grab', display: 'block', userSelect: 'none' }}
            onWheel={handleWheel}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onClick={() => setSelectedNode(null)}
          >
            <defs>
              <marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#94a3b8" />
              </marker>
              <marker id="arrow-hover" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#7c3aed" />
              </marker>
            </defs>

            <g transform={`translate(${transform.x},${transform.y}) scale(${transform.scale})`}>

              {/* Edges */}
              {edges.map((e, i) => {
                const ep  = edgeEndpoints(e);
                if (!ep) return null;
                const isHov = hoveredEdge === i;
                const mid   = edgeMid(e);
                return (
                  <g key={i}>
                    <line
                      x1={ep.x1} y1={ep.y1} x2={ep.x2} y2={ep.y2}
                      stroke={isHov ? '#7c3aed' : '#cbd5e1'}
                      strokeWidth={isHov ? 2 : 1.2}
                      markerEnd={isHov ? 'url(#arrow-hover)' : 'url(#arrow)'}
                      style={{ cursor: 'pointer' }}
                      onMouseEnter={() => setHoveredEdge(i)}
                      onMouseLeave={() => setHoveredEdge(null)}
                    />
                    {isHov && mid && (
                      <g>
                        <rect x={mid.x - 40} y={mid.y - 10} width={80} height={18} rx={4} fill="#7c3aed" opacity={0.9} />
                        <text x={mid.x} y={mid.y + 4} textAnchor="middle" fontSize={9} fill="white" fontWeight="700">
                          {e.rel}
                        </text>
                      </g>
                    )}
                    {!isHov && mid && (
                      <text x={mid.x} y={mid.y - 3} textAnchor="middle" fontSize={7} fill="#94a3b8" style={{ pointerEvents: 'none' }}>
                        {e.rel}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Nodes */}
              {nodes.map(n => {
                const p = positions[n.id];
                if (!p) return null;
                const color      = nodeColor(n.type);
                const isSelected = selectedNode?.id === n.id;
                const label      = nodeLabel(n);
                return (
                  <g key={n.id} style={{ cursor: 'pointer' }} onClick={e => handleNodeClick(n, e)}>
                    {isSelected && (
                      <circle cx={p.x} cy={p.y} r={NODE_R + 5} fill="none" stroke={color} strokeWidth={2.5} opacity={0.4} />
                    )}
                    <circle
                      cx={p.x} cy={p.y} r={NODE_R}
                      fill={color}
                      stroke={isSelected ? '#fff' : 'rgba(255,255,255,0.25)'}
                      strokeWidth={isSelected ? 2.5 : 1.5}
                      opacity={0.92}
                    />
                    <text
                      x={p.x} y={p.y + 1}
                      textAnchor="middle" dominantBaseline="middle"
                      fontSize={10} fill="white" fontWeight="900"
                      style={{ pointerEvents: 'none' }}
                    >
                      {n.type?.[0] || '?'}
                    </text>
                    <text
                      x={p.x} y={p.y + NODE_R + 11}
                      textAnchor="middle" fontSize={9} fill="#334155" fontWeight="600"
                      style={{ pointerEvents: 'none' }}
                    >
                      {label.length > 14 ? label.slice(0, 13) + '…' : label}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>
        </section>

        {/* Legend */}
        <section className="card" style={{ padding: '.6rem 1rem' }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '.35rem' }}>
            {Object.entries(NODE_COLOR).slice(0, 14).map(([type, color]) => (
              <div key={type} style={{ display: 'flex', alignItems: 'center', gap: '.25rem', fontSize: '.65rem', color: '#475569' }}>
                <div style={{ width: 9, height: 9, borderRadius: '50%', background: color }} />
                {type}
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* ── Right: Inspector ────────────────────────────────────── */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '.5rem', overflow: 'hidden' }}>
        <section className="card" style={{ flex: 1, overflow: 'hidden', padding: 0 }}>
          <div style={{
            padding: '.65rem .9rem', borderBottom: '1px solid #e2e8f0',
            fontWeight: 800, fontSize: '.82rem', color: '#0f172a',
          }}>
            {selectedNode ? `${selectedNode.type} Inspector` : 'Node Inspector'}
          </div>
          <NodeDetail
            node={selectedNode}
            edges={edges}
            onDrillDown={handleDrillDown}
            drillLoading={drillLoading}
          />
        </section>

        <section className="card" style={{ padding: '.65rem .9rem' }}>
          <div style={{ fontSize: '.68rem', color: '#64748b', lineHeight: 1.7 }}>
            <strong>Scroll</strong> to zoom · <strong>Drag</strong> background to pan<br />
            <strong>Click node</strong> to inspect · <strong>Hover edge</strong> for relation<br />
            <strong style={{ color: '#7c3aed' }}>Bill / Customer / ControlCase</strong> nodes support drill-down queries
          </div>
        </section>
      </div>
    </div>
  );
};

export default KnowledgeGraph;
