import React, { useState } from 'react';
import { usecases } from '../data/usecases';
import { chatWithAgent } from '../api';

const Badge = ({ children }) => (
  <span className="badge">{String(children)}</span>
);

const Chat = () => {
  const [selected, setSelected] = useState(usecases[0]);
  const [messages, setMessages] = useState([
    {
      role: 'system',
      html: '<strong>Case assistant ready.</strong><br>Select a case or ask for evidence, next action, customer explanation, approval status, or remediation plan.',
    },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);

  const send = async (text) => {
    if (!text.trim() || sending) return;
    const userMsg = { role: 'user', html: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSending(true);

    try {
      const res = await chatWithAgent({
        message: text,
        conversation_id: `CHAT-${selected.issueId || selected.id}`,
        billing_account_id: selected.account,
        context: {
          issue_id: selected.issueId || selected.id,
          use_case_id: selected.id,
          customer: selected.customer,
          bill_no: selected.billNo,
        },
      });
      const data = res.data;
      const reply = data.final_response || data.response || 'No response from agent.';
      setMessages((prev) => [...prev, { role: 'assistant', html: reply.replace(/\n/g, '<br>') }]);
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || 'Chat error';
      setMessages((prev) => [...prev, { role: 'assistant', html: `<span style="color:#dc2626">Error: ${msg}</span>` }]);
    } finally {
      setSending(false);
    }
  };

  const handleCaseChange = (e) => {
    const uc = usecases.find((u) => u.id === e.target.value);
    setSelected(uc);
  };

  return (
    <section className="chat-page">
      {/* ─── Main chat panel ──────────────────────────────────── */}
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', marginBottom: '.8rem' }}>
          <h2 style={{ margin: 0 }}>Case Assistant</h2>
          <select
            className="select"
            value={selected.id}
            onChange={handleCaseChange}
          >
            {usecases.map((u) => (
              <option key={u.id} value={u.id}>
                {u.id} · {u.title}
              </option>
            ))}
          </select>
        </div>

        {/* Case snapshot */}
        <div className="case-snapshot">
          <div className="tag">
            <Badge>{selected.id}</Badge>
            <Badge>{selected.severity}</Badge>
            <Badge>{selected.financialImpactType}</Badge>
          </div>
          <strong>{selected.title}</strong>
          <div className="snapshot-grid">
            <div><span>Customer</span><strong>{selected.customer}</strong></div>
            <div><span>Account</span><strong>{selected.account}</strong></div>
            <div><span>Financial impact</span><strong>{selected.disputed === '$0.00' ? 'No direct dispute' : selected.disputed}</strong></div>
            <div><span>Next action</span><strong>{selected.nextBestAction}</strong></div>
          </div>
          <p style={{ marginTop: '.5rem', color: '#475569', fontSize: '.88rem' }}>{selected.issueNarrative}</p>
        </div>

        {/* Messages */}
        <div className="messages professional">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`msg ${m.role}`}
              dangerouslySetInnerHTML={{ __html: m.html }}
            />
          ))}
          {sending && (
            <div className="msg assistant" style={{ color: '#94a3b8', fontStyle: 'italic' }}>
              Agent thinking…
            </div>
          )}
        </div>

        {/* Quick actions */}
        <div className="quick-actions" style={{ marginTop: '.65rem' }}>
          <button className="btn" disabled={sending} onClick={() => send(`Summarize case ${selected.id}`)}>Summarize case</button>
          <button className="btn" disabled={sending} onClick={() => send('What evidence is needed?')}>Show evidence needed</button>
          <button className="btn" disabled={sending} onClick={() => send('Draft a customer explanation for this bill')}>Draft customer explanation</button>
          <button className="btn" disabled={sending} onClick={() => send('What is the next action?')}>What is the next action?</button>
          <button className="btn" disabled={sending} onClick={() => send('What approvals are pending?')}>Show approval cases</button>
        </div>

        {/* Composer */}
        <div className="composer" style={{ marginTop: '.6rem' }}>
          <input
            className="input"
            placeholder="Ask about selected case, bill lines, evidence, approval, or remediation"
            value={input}
            disabled={sending}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && send(input)}
          />
          <button className="btn primary" disabled={sending} onClick={() => send(input)}>
            {sending ? 'Sending…' : 'Send'}
          </button>
        </div>
      </div>

      {/* ─── Right sidebar: Active Work Queue ─────────────────── */}
      <aside className="card">
        <h2>Active Work Queue</h2>
        <div className="queue-list">
          {usecases
            .filter((u) => u.status !== 'Protected')
            .slice(0, 6)
            .map((u) => (
              <button
                key={u.id}
                className="queue-item"
                onClick={() => {
                  setSelected(u);
                  send(`Summarize ${u.id}`);
                }}
              >
                <span>{u.id}</span>
                <strong>{u.financialImpactType}</strong>
                <em>{u.status}</em>
              </button>
            ))}
        </div>
        <div className="queue-note">
          <strong>Priority signal</strong>
          <span>High severity and approval-required items should be reviewed first.</span>
        </div>
      </aside>
    </section>
  );
};

export default Chat;
