import React, { useReducer, useRef, useState } from 'react';
import { usecases } from '../data/usecases';
import { streamRemediation, simulateIssue, approveIssue } from '../api';

// ── Layer colours ────────────────────────────────────────────────────────────
const LAYER_COLOR = {
  L1: { border: '#2563eb', bg: '#eff6ff', label: '#1d4ed8', badge: '#dbeafe' },
  L2: { border: '#059669', bg: '#f0fdf4', label: '#047857', badge: '#bbf7d0' },
  L3: { border: '#7c3aed', bg: '#f5f3ff', label: '#6d28d9', badge: '#ede9fe' },
  L4: { border: '#f97316', bg: '#fff7ed', label: '#c2410c', badge: '#fed7aa' },
};

const TOOL_ICON = {
  vector: '📚', kg: '🔗', event: '⚡', cmdb: '🗄️',
  policy: '🛡️', audit: '📝', tmf: '📡', tool: '🔧',
};

// ── SSE state reducer ─────────────────────────────────────────────────────────
const INITIAL = {
  steps: [],       // array of Step objects
  status: 'idle',  // idle | simulated | running | awaiting_approval | done | error
  progress: 0,
  label: 'Waiting for simulation',
  summary: null,   // { findings, resolution, next_steps, architecture_rule, final_state }
  approval: null,  // awaiting_approval payload
  error: null,
  threadId: null,
};

function reducer(state, action) {
  switch (action.type) {
    case 'RESET':
      return { ...INITIAL };

    case 'SIMULATED':
      return { ...state, status: 'simulated', progress: 100, label: 'Simulation complete · 100%' };

    case 'STREAM_START':
      return { ...state, status: 'running', steps: [], progress: 2, label: 'Starting remediation…', summary: null, approval: null, error: null };

    case 'STEP_START': {
      const step = {
        id: action.payload.step_id,
        time: action.payload.time,
        agent: action.payload.agent,
        layer: action.payload.layer,
        action: action.payload.action,
        node: action.payload.node,
        thought: '',
        toolCalls: [],
        outcome: null,
        status: 'running',
      };
      return {
        ...state,
        steps: [...state.steps, step],
        label: `${action.payload.agent}`,
        progress: Math.min(state.progress + 8, 88),
      };
    }

    case 'AGENT_THOUGHT': {
      const steps = state.steps.map(s =>
        s.id === action.payload.step_id
          ? { ...s, thought: s.thought + action.payload.delta }
          : s
      );
      return { ...state, steps };
    }

    case 'TOOL_CALL': {
      const tc = {
        id: `${action.payload.tool}_${Date.now()}`,
        tool: action.payload.tool,
        tool_key: action.payload.tool_key,
        input_summary: action.payload.input_summary,
        output_summary: null,
        duration_ms: null,
        status: 'running',
      };
      const steps = state.steps.map(s =>
        s.id === action.payload.step_id
          ? { ...s, toolCalls: [...s.toolCalls, tc] }
          : s
      );
      return { ...state, steps };
    }

    case 'TOOL_RESULT': {
      const steps = state.steps.map(s => {
        if (s.id !== action.payload.step_id) return s;
        const toolCalls = s.toolCalls.map((tc, i) =>
          i === s.toolCalls.length - 1 && tc.tool === action.payload.tool
            ? { ...tc, output_summary: action.payload.output_summary, duration_ms: action.payload.duration_ms, status: 'done' }
            : tc
        );
        return { ...s, toolCalls };
      });
      return { ...state, steps };
    }

    case 'STEP_COMPLETE': {
      const steps = state.steps.map(s =>
        s.id === action.payload.step_id
          ? { ...s, status: 'done', outcome: action.payload.outcome }
          : s
      );
      return { ...state, steps, progress: Math.min(state.progress + 4, 94) };
    }

    case 'AWAITING_APPROVAL':
      return {
        ...state,
        status: 'awaiting_approval',
        approval: action.payload,
        label: 'Awaiting human approval…',
        progress: 80,
        steps: state.steps.map((s, i) =>
          i === state.steps.length - 1 ? { ...s, status: 'waiting' } : s
        ),
      };

    case 'SUMMARY':
      return {
        ...state,
        status: 'done',
        summary: action.payload,
        progress: 100,
        label: 'Agent orchestration complete · 100%',
        approval: null,
      };

    case 'ERROR':
      return {
        ...state,
        status: 'error',
        error: action.payload.message,
        label: 'Error during remediation',
        progress: 0,
      };

    default:
      return state;
  }
}

// ── Layer architecture strip ──────────────────────────────────────────────────
const LAYERS = [
  { id: 'L1', label: 'L1 Control Tower', agents: ['Monitoring', 'Master', 'Human Approval', 'Audit'] },
  { id: 'L2', label: 'L2 BSS', agents: ['BSS Orch', 'Bill Insight', 'Usage Integrity', 'Backoffice Adj', 'Collections', 'Partner Settlement', 'Ticketing'] },
  { id: 'L3', label: 'L3 OSS', agents: ['OSS Orch', 'Service Problem', 'Mediation Replay', 'QoS/Slice', 'Service Topology'] },
  { id: 'L4', label: 'L4 Network', agents: ['Network Orch', 'Charging NF', 'Core Session', 'Resource RCA', 'Remediation Orch'] },
];

function LayerArchitecture({ steps }) {
  const activeLayers = new Set(steps.map(s => s.layer));
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '.65rem', marginBottom: '.8rem' }}>
      {LAYERS.map(l => {
        const c = LAYER_COLOR[l.id];
        const active = activeLayers.has(l.id);
        return (
          <div key={l.id} style={{
            border: `2px solid ${active ? c.border : '#dfe7f2'}`,
            borderRadius: '.75rem', padding: '.7rem',
            background: active ? c.bg : '#f8fafc',
            transition: 'all .4s',
          }}>
            <div style={{ fontWeight: 900, fontSize: '.72rem', textTransform: 'uppercase', color: active ? c.label : '#94a3b8', letterSpacing: '.08em' }}>
              {l.id}
            </div>
            <div style={{ fontWeight: 700, fontSize: '.82rem', marginTop: '.2rem', color: active ? c.label : '#64748b' }}>
              {l.label}
            </div>
            <div style={{ marginTop: '.45rem', display: 'flex', flexWrap: 'wrap', gap: '.25rem' }}>
              {l.agents.map(a => {
                const isRunning = steps.some(s => s.layer === l.id && s.status === 'running' && s.agent.includes(a.split(' ')[0]));
                const isDone = steps.some(s => s.layer === l.id && s.status === 'done' && s.agent.includes(a.split(' ')[0]));
                return (
                  <span key={a} style={{
                    fontSize: '.65rem', fontWeight: 800, padding: '.18rem .4rem',
                    borderRadius: '.35rem', border: `1px solid ${active ? c.border : '#dfe7f2'}`,
                    background: isRunning ? c.border : isDone ? c.badge : 'white',
                    color: isRunning ? 'white' : isDone ? c.label : '#94a3b8',
                    transition: 'all .3s',
                  }}>{a}</span>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Step card ─────────────────────────────────────────────────────────────────
function StepCard({ step, index }) {
  const c = LAYER_COLOR[step.layer] || LAYER_COLOR.L1;
  const borderColor = step.status === 'running' ? c.border
    : step.status === 'done' ? '#059669'
    : step.status === 'waiting' ? '#f59e0b' : c.border;

  return (
    <div style={{
      border: `1px solid ${borderColor}`,
      borderLeft: `4px solid ${c.border}`,
      background: step.status === 'done' ? c.bg : step.status === 'waiting' ? '#fffbeb' : 'white',
      borderRadius: '.75rem 1.3rem', padding: '.9rem', transition: 'all .4s',
      boxShadow: step.status === 'running' ? `0 0 0 4px ${c.badge}` : 'none',
    }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '.45rem', marginBottom: '.4rem' }}>
        <span style={{
          fontSize: '.65rem', fontWeight: 900, padding: '.2rem .45rem',
          borderRadius: '.35rem', background: c.badge, color: c.label,
        }}>{step.layer}</span>
        <span style={{ fontSize: '.68rem', color: '#64748b', fontWeight: 700 }}>
          STEP {index + 1}
        </span>
        <span style={{ marginLeft: 'auto', fontSize: '.68rem', color: '#94a3b8' }}>
          {step.time ? new Date(step.time).toLocaleTimeString() : ''}
        </span>
      </div>

      <div style={{ fontWeight: 800, fontSize: '.9rem', color: c.label, marginBottom: '.2rem' }}>
        {step.agent}
      </div>
      <div style={{ fontSize: '.8rem', color: '#64748b', marginBottom: '.5rem' }}>
        {step.action}
      </div>

      {/* Live thought stream */}
      {step.thought && (
        <div style={{
          fontSize: '.78rem', color: '#475569', background: '#f8fafc',
          border: '1px solid #e2e8f0', borderRadius: '.55rem', padding: '.5rem',
          marginBottom: '.5rem', fontStyle: 'italic', maxHeight: '4.5rem', overflow: 'auto',
        }}>
          {step.thought}
          {step.status === 'running' && <span style={{ animation: 'pulse 1s infinite' }}>▌</span>}
        </div>
      )}

      {/* Tool calls */}
      {step.toolCalls.length > 0 && (
        <div>
          <div style={{ fontSize: '.65rem', textTransform: 'uppercase', color: '#64748b', fontWeight: 900, marginBottom: '.3rem' }}>
            Tool calls
          </div>
          {step.toolCalls.map((tc) => (
            <div key={tc.id} style={{
              border: `1px solid ${c.badge}`,
              background: `linear-gradient(180deg,white,${c.bg})`,
              padding: '.45rem .6rem', borderRadius: '.5rem', marginBottom: '.3rem',
              display: 'flex', alignItems: 'flex-start', gap: '.5rem',
            }}>
              <span style={{ fontSize: '1rem' }}>{TOOL_ICON[tc.tool_key] || '🔧'}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '.72rem', fontWeight: 900, color: c.label, textTransform: 'uppercase' }}>
                  {tc.tool_key}
                </div>
                <div style={{ fontSize: '.8rem', fontWeight: 600, color: '#0f172a' }}>
                  {tc.tool}
                </div>
                {tc.output_summary && (
                  <div style={{ fontSize: '.73rem', color: '#64748b', marginTop: '.15rem', wordBreak: 'break-word' }}>
                    {tc.output_summary.slice(0, 150)}{tc.output_summary.length > 150 ? '…' : ''}
                  </div>
                )}
              </div>
              {tc.duration_ms != null && (
                <span style={{ fontSize: '.65rem', color: '#94a3b8', whiteSpace: 'nowrap' }}>
                  {tc.duration_ms}ms
                </span>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Outcome */}
      {step.outcome && step.status === 'done' && (
        <div style={{ fontSize: '.78rem', color: '#047857', marginTop: '.4rem', borderTop: '1px solid #bbf7d0', paddingTop: '.35rem' }}>
          {step.outcome.slice(0, 200)}
        </div>
      )}

      {/* Footer badge */}
      <div style={{ marginTop: '.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{
          fontSize: '.65rem', fontWeight: 900, padding: '.18rem .4rem',
          borderRadius: '.35rem', background: c.badge, color: c.label,
        }}>
          {step.status === 'running' ? 'Running…' : step.status === 'done' ? 'Done' : step.status === 'waiting' ? 'Awaiting approval' : step.status}
        </span>
      </div>
    </div>
  );
}

// ── Approval block ────────────────────────────────────────────────────────────
function ApprovalBlock({ approval, onDecide }) {
  const [reason, setReason] = useState('');
  const [showReject, setShowReject] = useState(false);

  return (
    <div style={{
      background: '#fffbeb', border: '2px solid #f59e0b',
      borderRadius: '.75rem', padding: '1rem', marginTop: '.8rem',
    }}>
      <div style={{ fontWeight: 900, fontSize: '.95rem', color: '#92400e', marginBottom: '.5rem' }}>
        Human Approval Required
      </div>
      <div style={{ fontSize: '.84rem', color: '#78350f', marginBottom: '.7rem', lineHeight: 1.6 }}>
        {approval.why}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.65rem', marginBottom: '.7rem' }}>
        <div style={{ background: 'white', border: '1px solid #fde68a', borderRadius: '.6rem', padding: '.65rem' }}>
          <div style={{ fontSize: '.65rem', fontWeight: 900, color: '#b45309', textTransform: 'uppercase' }}>Proposed Action</div>
          <div style={{ fontSize: '.82rem', color: '#0f172a', marginTop: '.2rem' }}>{approval.proposed_action}</div>
        </div>
        <div style={{ background: 'white', border: '1px solid #fde68a', borderRadius: '.6rem', padding: '.65rem' }}>
          <div style={{ fontSize: '.65rem', fontWeight: 900, color: '#b45309', textTransform: 'uppercase' }}>Financial Impact</div>
          <div style={{ fontSize: '1.25rem', fontWeight: 900, color: '#0f172a', marginTop: '.2rem' }}>
            £{typeof approval.financial_impact === 'number' ? approval.financial_impact.toFixed(2) : approval.financial_impact}
          </div>
        </div>
      </div>

      {showReject && (
        <textarea
          placeholder="Rejection reason (required)…"
          value={reason}
          onChange={e => setReason(e.target.value)}
          style={{
            width: '100%', borderRadius: '.55rem', border: '1px solid #fde68a',
            padding: '.6rem', fontSize: '.82rem', marginBottom: '.5rem',
            resize: 'vertical', minHeight: '3.5rem', boxSizing: 'border-box',
          }}
        />
      )}

      <div style={{ display: 'flex', gap: '.6rem', flexWrap: 'wrap' }}>
        <button
          className="btn success"
          onClick={() => onDecide('approved', '')}
        >
          ✓ Approve
        </button>
        {!showReject ? (
          <button className="btn" style={{ background: '#fef2f2', color: '#991b1b', border: '1px solid #fca5a5' }}
            onClick={() => setShowReject(true)}>
            ✕ Reject
          </button>
        ) : (
          <button className="btn" style={{ background: '#dc2626', color: 'white' }}
            onClick={() => { if (reason.trim()) onDecide('rejected', reason); }}>
            Confirm Rejection
          </button>
        )}
      </div>
    </div>
  );
}

// ── Summary panel ─────────────────────────────────────────────────────────────
function SummaryPanel({ summary }) {
  if (!summary) return null;
  return (
    <div style={{ background: '#ecfdf5', border: '1px solid #bbf7d0', borderRadius: '.75rem', padding: '1rem' }}>
      <div style={{ fontWeight: 900, fontSize: '.95rem', color: '#065f46', marginBottom: '.65rem' }}>
        Remediation Complete
      </div>
      {[
        ['Findings', summary.findings],
        ['Resolution', summary.resolution],
        ['Next Steps', summary.next_steps],
        ['Architecture Rule', summary.architecture_rule],
        ['Final State', summary.final_state],
      ].map(([label, val]) => val ? (
        <div key={label} style={{ marginBottom: '.55rem' }}>
          <div style={{ fontSize: '.65rem', fontWeight: 900, color: '#047857', textTransform: 'uppercase', letterSpacing: '.08em' }}>
            {label}
          </div>
          <div style={{ fontSize: '.84rem', color: '#0f172a', marginTop: '.15rem' }}>{val}</div>
        </div>
      ) : null)}
      {summary.audit_trace_id && (
        <div style={{ marginTop: '.5rem', fontSize: '.72rem', color: '#64748b', borderTop: '1px solid #bbf7d0', paddingTop: '.4rem' }}>
          Audit trace: <code style={{ fontFamily: 'monospace' }}>{summary.audit_trace_id}</code>
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
const AgenticTower = () => {
  const [selected, setSelected] = useState(usecases[1]);
  const [state, dispatch] = useReducer(reducer, INITIAL);
  const abortRef = useRef(null);
  const [pendingApproval, setPendingApproval] = useState(null);

  const handleSelect = (e) => {
    const uc = usecases.find(u => u.id === e.target.value);
    setSelected(uc);
    handleReset();
  };

  const handleReset = () => {
    if (abortRef.current) { abortRef.current.abort(); abortRef.current = null; }
    dispatch({ type: 'RESET' });
    setPendingApproval(null);
  };

  const handleSimulate = async () => {
    const issueId = selected.issueId || selected.id;
    try {
      await simulateIssue(issueId);
    } catch (err) {
      console.warn('Simulate returned error (non-blocking):', err.message);
    }
    dispatch({ type: 'SIMULATED' });
  };

  const handleRemediate = async () => {
    // Find the issue_id for the selected use case — uses the first matching issue from the backend.
    // For demo, we use the use_case_id as issue_id directly if the backend seeds them that way.
    const issueId = selected.issueId || selected.id;

    dispatch({ type: 'STREAM_START' });

    try {
      const controller = await streamRemediation(issueId, (eventType, data) => {
        switch (eventType) {
          case 'step_start':
            dispatch({ type: 'STEP_START', payload: data });
            break;
          case 'agent_thought':
            dispatch({ type: 'AGENT_THOUGHT', payload: data });
            break;
          case 'tool_call':
            dispatch({ type: 'TOOL_CALL', payload: data });
            break;
          case 'tool_result':
            dispatch({ type: 'TOOL_RESULT', payload: data });
            break;
          case 'step_complete':
            dispatch({ type: 'STEP_COMPLETE', payload: data });
            break;
          case 'awaiting_approval':
            dispatch({ type: 'AWAITING_APPROVAL', payload: data });
            setPendingApproval(data);
            break;
          case 'summary':
            dispatch({ type: 'SUMMARY', payload: data });
            break;
          case 'error':
            dispatch({ type: 'ERROR', payload: data });
            break;
          default:
            break;
        }
      });
      abortRef.current = controller;
    } catch (err) {
      dispatch({ type: 'ERROR', payload: { message: err.message || 'Stream failed' } });
    }
  };

  const handleDecide = async (decision, reason) => {
    if (!pendingApproval) return;
    const { approval_id, issue_id } = pendingApproval;
    const issueId = issue_id || selected.issueId || selected.id;
    try {
      await approveIssue(issueId, approval_id, decision, reason);
      setPendingApproval(null);
      dispatch({ type: 'STREAM_START' });
      // Re-stream — the backend continues the graph from where it left off
      // via the /approve endpoint which calls graph.ainvoke(Command(resume={...}))
      // The summary will come back via a second streamRemediation call
      const controller = await streamRemediation(issueId, (eventType, data) => {
        switch (eventType) {
          case 'step_start': dispatch({ type: 'STEP_START', payload: data }); break;
          case 'agent_thought': dispatch({ type: 'AGENT_THOUGHT', payload: data }); break;
          case 'tool_call': dispatch({ type: 'TOOL_CALL', payload: data }); break;
          case 'tool_result': dispatch({ type: 'TOOL_RESULT', payload: data }); break;
          case 'step_complete': dispatch({ type: 'STEP_COMPLETE', payload: data }); break;
          case 'summary': dispatch({ type: 'SUMMARY', payload: data }); break;
          case 'error': dispatch({ type: 'ERROR', payload: data }); break;
          default: break;
        }
      });
      abortRef.current = controller;
    } catch (err) {
      dispatch({ type: 'ERROR', payload: { message: err.message || 'Approve/reject failed' } });
    }
  };

  const { steps, status, progress, label, summary, approval, error } = state;

  return (
    <>
      {/* ── Toolbar ──────────────────────────────────────────────────────── */}
      <section className="card">
        <div className="toolbar">
          <select className="select" value={selected.id} onChange={handleSelect}>
            {usecases.map(u => (
              <option key={u.id} value={u.id}>{u.id} — {u.title}</option>
            ))}
          </select>
          <button className="btn primary" onClick={handleSimulate}
            disabled={status === 'running' || status === 'awaiting_approval'}>
            Simulate
          </button>
          <button className="btn success" onClick={handleRemediate}
            disabled={status === 'running' || status === 'awaiting_approval' || status === 'idle'}>
            Remediate
          </button>
          <button className="btn" onClick={handleReset}>Reset</button>
        </div>

        {/* Issue brief */}
        <div style={{ marginTop: '.8rem' }}>
          <div className="tag">
            <span className="badge">{selected.id}</span>
            <span className="badge">{selected.severity}</span>
            <span className="badge">{selected.timing}</span>
          </div>
          <h3>{selected.title}</h3>
          <p className="muted">
            <strong>{selected.financialImpactType}</strong> — {selected.issueNarrative}
          </p>
        </div>

        {/* Context strip */}
        <div className="agent-context">
          <div><span>Customer</span><strong>{selected.customer}</strong></div>
          <div><span>Financial impact</span><strong>{selected.disputed === '$0.00' ? 'No direct dispute' : selected.disputed}</strong></div>
          <div><span>Status</span><strong>{selected.status}</strong></div>
          <div><span>Next action</span><strong>{selected.nextBestAction}</strong></div>
        </div>
      </section>

      {/* ── Layer Architecture ───────────────────────────────────────────── */}
      <section className="card">
        <h2 style={{ marginBottom: '.6rem' }}>Agent Layer Architecture</h2>
        <LayerArchitecture steps={steps} />
      </section>

      {/* ── Agent Trace ──────────────────────────────────────────────────── */}
      <section className="card">
        <h2>Agent Trace</h2>

        {/* Progress bar */}
        <div className="trace-status">
          <span className="muted">{label}</span>
          <div className="progress">
            <div className="bar" style={{ width: `${progress}%` }} />
          </div>
        </div>

        {status === 'idle' && (
          <div className="empty">Select a use case and click Simulate, then Remediate.</div>
        )}

        {status === 'simulated' && (
          <div className="summary-box">
            <strong>Simulation ready</strong> — {selected.id} scenario seeded.
            Financial impact: <strong>{selected.disputed}</strong>.
            Recommended path: <strong>{selected.nextBestAction}</strong>.
            Click <strong>Remediate</strong> to start the agentic trace.
          </div>
        )}

        {error && (
          <div style={{ background: '#fef2f2', border: '1px solid #fca5a5', borderRadius: '.75rem', padding: '.85rem', color: '#991b1b' }}>
            <strong>Error:</strong> {error}
          </div>
        )}

        {steps.length > 0 && (
          <div className="trace-flow">
            {steps.map((s, i) => (
              <StepCard key={s.id} step={s} index={i} />
            ))}
          </div>
        )}

        {/* Approval block inline in trace */}
        {status === 'awaiting_approval' && approval && (
          <ApprovalBlock approval={approval} onDecide={handleDecide} />
        )}

        {/* Summary panel */}
        {status === 'done' && summary && (
          <div style={{ marginTop: '.8rem' }}>
            <SummaryPanel summary={summary} />
          </div>
        )}
      </section>
    </>
  );
};

export default AgenticTower;
