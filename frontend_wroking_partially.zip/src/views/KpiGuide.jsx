import React from 'react';
import { summary } from '../data/usecases';

const kpiDefinitions = [
  [
    'Billing Revenue Protected',
    summary.protectedRevenue,
    'Estimated at-risk invoice value covered by controls and governed reviews.',
    'sum(contested + prevented exposure + adjustment exposure)',
  ],
  [
    'Proactive Issues Solved',
    summary.proactiveSolved,
    'Cases resolved or contained before customer bill impact.',
    'count(pre-bill protected/resolved path)',
  ],
  [
    'Post Billing Issues Solved',
    summary.postBillSolved,
    'Issues corrected, clarified, compensated, or governed after invoice.',
    'count(post-bill corrected/clarified/held/approved path)',
  ],
  [
    'Total Usecases Modelled',
    summary.usecasesModelled,
    'Operational scenarios across BSS, OSS, network, collections, and governance.',
    'count(usecase catalogue)',
  ],
  [
    'Avg Triage Time',
    summary.avgTriage,
    'Average time to classify, gather evidence, check policy, and propose next action.',
    'avg(detect + analyze + decision + recommended path)',
  ],
  [
    'Customer Contacts Avoided',
    summary.contactsAvoided,
    'Estimated reduction in avoidable assisted contacts.',
    '(baseline contacts - projected contacts) / baseline contacts',
  ],
  [
    'Approval Backlog',
    summary.approvalBacklog,
    'Open cases requiring governance or human approval.',
    'count(manual approval cases not closed)',
  ],
  [
    'Invoice Risk Cleared',
    summary.invoiceRiskCleared,
    'Identified invoice-risk items routed to a controlled outcome.',
    'cleared risk items / total risk items',
  ],
];

const KpiGuide = () => {
  return (
    <section className="card">
      <h2>KPI Guide</h2>
      <p className="muted">
        Metric definitions and calculation logic used by the Billing Control Tower.
      </p>
      <div className="kpi-guide-grid">
        {kpiDefinitions.map(([name, value, description, formula], i) => (
          <article key={i} className="guide-card">
            <span>{name}</span>
            <strong>{value}</strong>
            <p>{description}</p>
            <code>{formula}</code>
          </article>
        ))}
      </div>
    </section>
  );
};

export default KpiGuide;
