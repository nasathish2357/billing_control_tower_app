import React, { useState } from 'react';
import { usecases } from '../data/usecases';
import { getCustomerBills, getBillLineItems, getBillContext } from '../api';

const Badge = ({ children }) => (
  <span className="badge">{String(children)}</span>
);

const BillsDrilldown = () => {
  const [search, setSearch]       = useState('');
  const [openId, setOpenId]       = useState(null);
  const [billData, setBillData]   = useState(null);
  const [loadingId, setLoadingId] = useState(null);

  const filtered = usecases.filter((u) =>
    JSON.stringify(u).toLowerCase().includes(search.toLowerCase())
  );

  const toggleBill = async (id) => {
    if (openId === id) {
      setOpenId(null);
      setBillData(null);
      return;
    }

    setOpenId(id);
    setBillData(null);
    setLoadingId(id);

    const uc = usecases.find(u => u.id === id);

    const [billsRes, compRes] = await Promise.allSettled([
      getCustomerBills(uc.account),
      getBillContext(uc.account),
    ]);

    const bills      = billsRes.status === 'fulfilled' ? (billsRes.value.data ?? []) : [];
    const comparison = compRes.status  === 'fulfilled' ? compRes.value.data : null;

    // Line items for the most recent bill
    let lineItems = [];
    if (bills.length > 0) {
      try {
        const liRes  = await getBillLineItems(bills[0].id);
        lineItems = liRes.data.lineItems ?? [];
      } catch { /* no line items, use fallback */ }
    }

    setBillData({ bills, lineItems, comparison });
    setLoadingId(null);
  };

  const detail = openId ? usecases.find(u => u.id === openId) : null;

  return (
    <>
      {/* ─── Table ────────────────────────────────────────── */}
      <section className="table-wrap">
        <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', marginBottom: '.8rem' }}>
          <h2 style={{ margin: 0 }}>Bills DrillDown</h2>
          <input
            className="input"
            placeholder="Search customer, issue id, bill no"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="table-scroll">
          <table className="bill-table">
            <thead>
              <tr>
                <th>Customer / Account</th>
                <th>Issue ID</th>
                <th>Bill / Issue</th>
                <th>Issue Type</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id}>
                  <td>
                    <strong>{u.account}</strong>
                    <br />
                    <span className="muted">{u.customer}</span>
                  </td>
                  <td><Badge>{u.id}</Badge></td>
                  <td>
                    {u.billNo}
                    <br />
                    <span className="muted">{u.title}</span>
                  </td>
                  <td>
                    <Badge>{u.financialImpactType}</Badge>
                    <br />
                    <span className="muted">{u.status}</span>
                  </td>
                  <td>
                    <button className="link-btn" onClick={() => toggleBill(u.id)}>
                      {loadingId === u.id ? 'Loading…' : openId === u.id ? 'Close details' : 'Open details'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ─── Detail panel ─────────────────────────────────── */}
      {detail && (
        <section className="bill-detail open">

          {/* Customer Details */}
          <div className="card" style={{ borderTop: '5px solid var(--blue)' }}>
            <h2>Customer Details</h2>
            <div className="detail-grid">
              <div><span className="field-label">Customer</span><strong>{detail.customer}</strong></div>
              <div><span className="field-label">Account</span><strong>{detail.account}</strong></div>
              <div><span className="field-label">Service</span><strong>{detail.service}</strong></div>
              <div><span className="field-label">Bill No</span><strong>{detail.billNo}</strong></div>
            </div>
            <div className="info-strip">
              <div>
                <span>Bill amount / undisputed</span>
                <strong>
                  {billData?.comparison
                    ? `$${billData.comparison.current_bill?.amount_due?.toFixed(2) ?? detail.undisputed}`
                    : detail.undisputed}
                </strong>
              </div>
              <div>
                <span>Contested / adjustment amount</span>
                <strong>{detail.disputed}</strong>
              </div>
            </div>

            {/* Bill comparison from backend */}
            {billData?.comparison && (
              <div style={{
                marginTop: '.75rem', background: '#f0fdf4', border: '1px solid #bbf7d0',
                borderRadius: '.55rem', padding: '.7rem',
              }}>
                <strong style={{ fontSize: '.82rem', color: '#065f46' }}>Live Bill Comparison</strong>
                <p style={{ color: '#475569', fontSize: '.82rem', margin: '.3rem 0 .3rem' }}>
                  {billData.comparison.comparison_summary}
                </p>
                {billData.comparison.delta_pct != null && (
                  <span style={{
                    fontSize: '.82rem', fontWeight: 700,
                    color: billData.comparison.delta_pct > 0 ? '#dc2626' : '#059669',
                  }}>
                    {billData.comparison.delta_pct > 0 ? '↑' : '↓'} {Math.abs(billData.comparison.delta_pct)}% vs previous bill
                  </span>
                )}
              </div>
            )}

            {loadingId === null && !billData?.comparison && (
              <div style={{ fontSize: '.75rem', color: '#94a3b8', marginTop: '.5rem' }}>
                No bill comparison data from backend for account {detail.account}
              </div>
            )}

            <p style={{ color: '#475569', marginTop: '.5rem' }}>{detail.issueNarrative}</p>
          </div>

          {/* Issue and Resolution Details */}
          <div className="card" style={{ borderTop: '5px solid var(--orange)' }}>
            <h2>Issue and Resolution Details</h2>
            <div className="detail-grid">
              <div><span className="field-label">Issue type</span><strong>{detail.financialImpactType}</strong></div>
              <div><span className="field-label">Resolution</span><strong>{detail.status}</strong></div>
              <div><span className="field-label">Timing</span><strong>{detail.timing}</strong></div>
              <div><span className="field-label">Next action</span><strong>{detail.nextBestAction}</strong></div>
            </div>
            <div style={{ marginTop: '.75rem', padding: '.75rem', background: '#f8fafc', borderRadius: '.55rem', border: '1px solid var(--line)' }}>
              <strong>Operational interpretation</strong>
              <br />
              {detail.issueNarrative}
            </div>
          </div>

          {/* Bill Details */}
          <div className="card" style={{ borderTop: '5px solid var(--green)' }}>
            <h2>Bill Details</h2>
            <div className="detail-grid">
              <div><span className="field-label">Price Plan</span><strong>{detail.service}</strong></div>
              <div>
                <span className="field-label">Charging Model</span>
                <strong>Recurring / usage / adjustment</strong>
              </div>
              {billData?.bills?.[0] && (
                <div>
                  <span className="field-label">Bill Status</span>
                  <strong>{billData.bills[0].status}</strong>
                </div>
              )}
              {billData?.bills?.[0]?.dueDate && (
                <div>
                  <span className="field-label">Due Date</span>
                  <strong>{new Date(billData.bills[0].dueDate).toLocaleDateString()}</strong>
                </div>
              )}
            </div>

            {/* Current bill line items — backend or fallback */}
            <h3 style={{ marginTop: '1rem' }}>Current Bill Line Items</h3>
            <table className="mini-table">
              <tbody>
                {billData?.lineItems?.length > 0 ? (
                  billData.lineItems.map(li => (
                    <tr key={li.id}>
                      <td>{li.description}</td>
                      <td style={{ color: li.disputeFlag ? '#dc2626' : undefined }}>
                        ${(li.amount?.amount ?? li.amount ?? 0).toFixed(2)}
                      </td>
                      <td>{li.disputeFlag ? 'Disputed' : li.chargeType ?? 'Valid'}</td>
                    </tr>
                  ))
                ) : (
                  <>
                    <tr><td>{detail.service}</td><td>{detail.total}</td><td>Current</td></tr>
                    <tr><td>{detail.financialImpactType}</td><td>{detail.disputed}</td><td>Contested / Reviewed</td></tr>
                    <tr><td>Taxes &amp; fees</td><td>$10.00</td><td>Valid</td></tr>
                  </>
                )}
              </tbody>
            </table>

            {/* Previous bills — backend or fallback */}
            <h3 style={{ marginTop: '1rem' }}>Previous Bill Details</h3>
            <table className="mini-table">
              <tbody>
                {billData?.bills?.length > 1 ? (
                  billData.bills.slice(1, 4).map(b => (
                    <tr key={b.id}>
                      <td>{b.billingPeriod}</td>
                      <td>${(b.amountDue?.amount ?? 0).toFixed(2)}</td>
                      <td>{b.status}</td>
                    </tr>
                  ))
                ) : (
                  <>
                    <tr><td>Mar 2026</td><td>{detail.undisputed}</td><td>Reviewed</td></tr>
                    <tr><td>Feb 2026</td><td>{detail.undisputed}</td><td>Closed</td></tr>
                  </>
                )}
              </tbody>
            </table>

            {billData?.bills?.length > 0 && (
              <div style={{ fontSize: '.68rem', color: '#94a3b8', marginTop: '.5rem' }}>
                Live data from /mock-tmf/customer-bill · {billData.bills.length} bill(s) found
              </div>
            )}
          </div>
        </section>
      )}
    </>
  );
};

export default BillsDrilldown;
