import axios from 'axios';

const API_BASE = 'http://localhost:8000/api/v1';

const api = axios.create({
  baseURL: API_BASE,
});

// ─── Issues & Usecases ──────────────────────────────────────────────
export const getIssues = () => api.get('/issues');
export const getUsecases = () => api.get('/use-cases');
export const getIssue = (id) => api.get(`/issues/${id}`);

// ─── Simulation ─────────────────────────────────────────────────────
export const simulateIssue = (issueId) =>
  api.post(`/issues/${issueId}/simulate`);

// ─── Agentic Remediation (SSE stream) ───────────────────────────────
/**
 * Connects to the SSE stream for agentic remediation.
 * Calls onEvent(eventType, data) for each parsed SSE frame.
 * Returns an abort controller so the caller can cancel.
 */
export const streamRemediation = async (issueId, onEvent) => {
  const controller = new AbortController();

  const response = await fetch(`${API_BASE}/issues/${issueId}/remediate/stream`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    signal: controller.signal,
  });

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  const processStream = async () => {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // Process complete SSE frames (each ends with \n\n)
      while (buffer.includes('\n\n')) {
        const [frame, rest] = buffer.split('\n\n', 2);
        buffer = rest || '';

        let eventType = 'message';
        let dataStr = null;

        for (const line of frame.split('\n')) {
          if (line.startsWith('event:')) eventType = line.slice(6).trim();
          else if (line.startsWith('data:')) dataStr = line.slice(5).trim();
        }

        if (dataStr) {
          try {
            onEvent(eventType, JSON.parse(dataStr));
          } catch {
            onEvent(eventType, { raw: dataStr });
          }
        }
      }
    }
  };

  processStream().catch((err) => {
    if (err.name !== 'AbortError') console.error('Stream error:', err);
  });

  return controller;
};

// ─── Agentic Graph Execution (legacy blocking) ─────────────────────
export const remediateIssue = (id) => api.post(`/issues/${id}/remediate`);

// ─── Chat Interface ─────────────────────────────────────────────────
export const chatWithAgent = (data) => api.post('/chat', data);

// ─── Dashboard & KPIs ───────────────────────────────────────────────
export const getDashboardSummary = () => api.get('/dashboard/summary');
export const getLayerHealth = () => api.get('/dashboard/layer-health');
export const getPostbillDisputes = () => api.get('/dashboard/postbill-disputes');
export const getPrebillRisks = (minRiskScore = 15) =>
  api.get(`/dashboard/prebill-risks?min_risk_score=${minRiskScore}`);
export const getAuditSummary = () => api.get('/dashboard/audit-summary');

// ─── Evidence & Context ─────────────────────────────────────────────
export const getControlCaseEvidence = (controlCaseId) =>
  api.get(`/control-cases/${controlCaseId}/evidence`);
export const getBillingAccountComparison = (billingAccountId) =>
  api.get(`/billing-accounts/${billingAccountId}/bill-comparison`);
export const getCustomerBillingContext = (customerId) =>
  api.get(`/customers/${customerId}/billing-context`);

// ─── Knowledge Graph ────────────────────────────────────────────────
export const rebuildKg = () => api.post('/kg/rebuild');
export const getKgIssueRelationships = (issueId) =>
  api.get(`/kg/issue/${issueId}/relationships`);
export const getKgCustomerContext = (customerId) =>
  api.get(`/kg/customer/${customerId}/billing-context`);
export const getKgControlCaseImpact = (controlCaseId) =>
  api.get(`/kg/control-case/${controlCaseId}/impact`);
export const getKgBillTrace = (billId) =>
  api.get(`/kg/trace/bill/${billId}`);

// ─── Approvals & Interrupts ─────────────────────────────────────────
export const getPendingApprovals = () => api.get('/approvals/pending');
export const approveAction = (approvalId, payload) =>
  api.post(`/approvals/${approvalId}/approve`, payload);
export const resumeRemediation = (issueId) =>
  api.post(`/issues/${issueId}/remediate/resume`);

/** Inline graph-resume approve/reject — used by AgenticTower after awaiting_approval SSE */
export const approveIssue = (issueId, approvalId, decision, reason = '') =>
  api.post(`/issues/${issueId}/approve`, { approval_id: approvalId, decision, reason });

// ─── Simulation Injection (legacy) ──────────────────────────────────
export const injectSimulation = (simulationType, dryRun = false) =>
  api.post(`/simulation/inject?simulation_type=${simulationType}&dry_run=${dryRun}`);
export const getSimulationTypes = () => api.get('/simulation/types');

// ─── Mock TMF Data ──────────────────────────────────────────────────
export const getCustomerBills = (accountId) =>
  api.get(`/mock-tmf/customer-bill?billing_account_id=${accountId}`);
export const getBillLineItems = (billId) =>
  api.get(`/mock-tmf/customer-bill/${billId}/line-items`);
export const getBillContext = (accountId) =>
  api.get(`/billing-accounts/${accountId}/bill-comparison`);
export const getBillingContext = (customerId) =>
  api.get(`/customers/${customerId}/billing-context`);

export default api;
