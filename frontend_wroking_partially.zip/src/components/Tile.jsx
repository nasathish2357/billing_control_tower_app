import React from 'react';

const Tile = ({ label, value, sub }) => (
  <div className="tile">
    <div className="label">{label}</div>
    <div className="value">{value}</div>
    {sub && <div className="sub">{sub}</div>}
  </div>
);

export default Tile;
