import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';

const navItems = [
  { to: '/dashboard', label: 'Billing Control Tower Dashboard' },
  { to: '/agents',    label: 'Agent in Action' },
  { to: '/chat',      label: 'Chat' },
  { to: '/kpi-guide', label: 'KPI Guide' },
  { to: '/bills',          label: 'Bills DrillDown' },
  { to: '/knowledge-graph', label: 'Knowledge Graph' },
];

const logos = ['TCS', 'etiya', 'CALVI', 'TM Forum', 'vodafone', 'turk telecom', 'orange', 'stc'];

const Layout = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="app">
      {/* ─── Sidebar ──────────────────────────────────────────────── */}
      <aside>
        <div className="brand">
          <small>TMForum Catalyst</small>
          <strong>Agentic AI Billing Dispute</strong>
        </div>

        <button
          id="mobileMenu"
          onClick={() => setMenuOpen(o => !o)}
        >
          ☰ Menu
        </button>

        <nav className={menuOpen ? 'open' : ''}>
          {navItems.map(({ to, label }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) => isActive ? 'active' : ''}
              onClick={() => setMenuOpen(false)}
            >
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="note">
          <b>Operations workspace</b>
          <span>Revenue protection · dispute resolution · governed remediation</span>
        </div>
      </aside>

      {/* ─── Main content ─────────────────────────────────────────── */}
      <main>
        <header>
          <div className="logos">
            {logos.map(l => <span key={l}>{l}</span>)}
          </div>
          <p>Control Tower</p>
          <h1>TMForum Catalyst Agentic AI Driven Billing Dispute</h1>
        </header>

        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
