import React from 'react';

const Panel = ({ title, className, children }) => (
  <section className={`panel ${className || ''}`}>
    <div className="panel-head">
      <h2>{title}</h2>
    </div>
    {children}
  </section>
);

export default Panel;
