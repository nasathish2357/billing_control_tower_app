import React from 'react';

const Chip = ({ align, children }) => {
  const alignClass = align === 'right' ? 'right' : 'left';
  return (
    <span className={`chip ${alignClass}`}>
      {children}
    </span>
  );
};

export default Chip;
