/**
 * Static use-case data — single source of truth for the frontend.
 * Mirrors the embedded JSON from reference/tmforum_billing_dispute_final_ui_pack/index.html.
 * When the backend is connected, the Dashboard can optionally hydrate from the API,
 * but the Agent, Chat, KPI, and Bills views always use this canonical dataset.
 */

export const summary = {
  protectedRevenue: "$620K",
  proactiveSolved: 4,
  postBillSolved: 6,
  usecasesModelled: 10,
  avgTriage: "9.5 min",
  contactsAvoided: "24%",
  approvalBacklog: 3,
  invoiceRiskCleared: "97.8%",
};

export const usecases = [
  {
    id: "P1",
    issueId: "ISSUE-P1-001",
    title: "Missing or delayed usage feed into billing",
    financialImpactType: "Potential dispute",
    disputed: "$24.00",
    nextBestAction: "Prevent billing error",
    status: "Open",
    severity: "Medium",
    segment: "Consumer",
    customer: "Emma W.",
    account: "ACC-100100",
    service: "40 GB Mobile Plan",
    billNo: "INV-2026-0401-001",
    issueNarrative:
      "A mediation feed arrived after billing cut-off. The bill is not necessarily wrong yet; the control prevents late usage from being rated incorrectly.",
    timing: "Pre-bill",
    undisputed: "$130.00",
    total: "$154.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P2",
    issueId: "ISSUE-P2-001",
    title: "Duplicate charging / duplicate usage rating",
    financialImpactType: "Bill dispute",
    disputed: "$39.00",
    nextBestAction: "Credit correction",
    status: "Investigating",
    severity: "High",
    segment: "Consumer",
    customer: "Daniel K.",
    account: "ACC-100101",
    service: "Travel Data Add-on",
    billNo: "INV-2026-0401-002",
    issueNarrative:
      "The same travel add-on was rated twice after replay. This is a true financial dispute requiring event correlation, duplicate proof, credit memo, and audit trail.",
    timing: "Pre + Post-bill",
    undisputed: "$189.00",
    total: "$228.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P3",
    issueId: "ISSUE-P3-001",
    title: "Zombie PDU session causing unfair data charge",
    financialImpactType: "Bill dispute",
    disputed: "$31.00",
    nextBestAction: "Reverse unfair usage",
    status: "Auto-resolved",
    severity: "Critical",
    segment: "Consumer",
    customer: "Sophie R.",
    account: "ACC-100102",
    service: "5G Unlimited Lite",
    billNo: "INV-2026-0401-003",
    issueNarrative:
      "A stale network session continued producing chargeable usage after expected release. Network evidence is linked and unfair usage is reversed.",
    timing: "Pre + Post-bill",
    undisputed: "$103.00",
    total: "$134.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P4",
    issueId: "ISSUE-P4-001",
    title: "QoS or slice entitlement mismatch",
    financialImpactType: "Under review",
    disputed: "$1,600.00",
    nextBestAction: "Approval likely",
    status: "Open",
    severity: "High",
    segment: "Enterprise",
    customer: "NorthField Warehousing Ltd.",
    account: "ENT-100103",
    service: "Premium 5G Warehouse Slice",
    billNo: "INV-2026-0401-004",
    issueNarrative:
      "Enterprise premium uplift may not match observed QoS. Entitlement, performance, and topology evidence must be compared before a decision.",
    timing: "Pre + Post-bill",
    undisputed: "$9,640.00",
    total: "$11,240.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Approve", "Human Approval Board", "Governance approval required", "Manual"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P5",
    issueId: "ISSUE-P5-001",
    title: "Service degradation compensation",
    financialImpactType: "Compensation",
    disputed: "$0.00",
    nextBestAction: "Approval required",
    status: "Pending approval",
    severity: "Medium",
    segment: "Consumer",
    customer: "Oliver P.",
    account: "ACC-100104",
    service: "Mobile Broadband",
    billNo: "INV-2026-0401-005",
    issueNarrative:
      "The bill can be technically valid while service degradation evidence qualifies the customer for goodwill or SLA compensation.",
    timing: "Post-bill",
    undisputed: "$249.00",
    total: "$249.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Approve", "Human Approval Board", "Governance approval required", "Manual"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P6",
    issueId: "ISSUE-P6-001",
    title: "Collections hold during dispute",
    financialImpactType: "Partial hold",
    disputed: "$360.00",
    nextBestAction: "Protect disputed balance",
    status: "Hold applied",
    severity: "High",
    segment: "Consumer",
    customer: "Glasgow Retail Subscriber",
    account: "ACC-100105",
    service: "International Usage Plan",
    billNo: "INV-2026-0401-006",
    issueNarrative:
      "The objective is to prevent dunning on the contested amount only while collections continue for the undisputed balance.",
    timing: "Post-bill",
    undisputed: "$900.00",
    total: "$1,260.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P7",
    issueId: "ISSUE-P7-001",
    title: "Partner or wholesale charge discrepancy",
    financialImpactType: "Partner review",
    disputed: "$260.00",
    nextBestAction: "Interim remedy",
    status: "Open",
    severity: "Medium",
    segment: "Consumer",
    customer: "Roaming Traveler",
    account: "ACC-100106",
    service: "International Roaming",
    billNo: "INV-2026-0401-007",
    issueNarrative:
      "Retail roaming charges are checked against partner settlement feed evidence; retail remedy can proceed before wholesale closure.",
    timing: "Post-bill",
    undisputed: "$624.00",
    total: "$884.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Approve", "Human Approval Board", "Governance approval required", "Manual"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P8",
    issueId: "ISSUE-P8-001",
    title: "Opaque invoice with valid charges",
    financialImpactType: "No dispute",
    disputed: "$0.00",
    nextBestAction: "Explain bill",
    status: "Explanation ready",
    severity: "Low",
    segment: "Consumer",
    customer: "Hannah T.",
    account: "ACC-100107",
    service: "Family Plan + Add-ons",
    billNo: "INV-2026-0401-008",
    issueNarrative:
      "Charges are valid but confusing because of proration, bundles, add-ons, and device repayment. The outcome is explanation, not credit.",
    timing: "Post-bill",
    undisputed: "$552.00",
    total: "$552.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P9",
    issueId: "ISSUE-P9-001",
    title: "Pre-bill monitoring anomaly",
    financialImpactType: "No dispute",
    disputed: "$0.00",
    nextBestAction: "Protect invoices",
    status: "Protected",
    severity: "Critical",
    segment: "Operations",
    customer: "Subscriber Cohort A12",
    account: "ACC-100108",
    service: "Charging Stream",
    billNo: "Pre-bill prevention",
    issueNarrative:
      "Monitoring detected an anomaly before invoices were sent. This is internal prevention with no customer-facing dispute.",
    timing: "Pre-bill",
    undisputed: "$0.00",
    total: "$0.00 impact",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
  {
    id: "P10",
    issueId: "ISSUE-P10-001",
    title: "Governed multi-domain dispute",
    financialImpactType: "Governed review",
    disputed: "$5,100.00",
    nextBestAction: "Approval required",
    status: "In progress",
    severity: "High",
    segment: "Enterprise",
    customer: "Enterprise Multi-Site Account",
    account: "ENT-100109",
    service: "Premium Connectivity Sites",
    billNo: "INV-2026-0401-010",
    issueNarrative:
      "The case spans billing, service evidence, enterprise governance, and finance. A single evidence pack is required for aligned decisioning.",
    timing: "Pre + Post-bill",
    undisputed: "$27,700.00",
    total: "$32,800.00",
    flow: [
      ["Detect", "Monitoring Agent", "Signal identified", "Auto"],
      ["Analyze", "Domain Agent", "Evidence pack assembled", "Auto"],
      ["Decide", "Policy Engine", "Resolution path selected", "Guarded"],
      ["Approve", "Human Approval Board", "Governance approval required", "Manual"],
      ["Resolve", "Billing Agent", "Outcome prepared", "Guarded"],
    ],
    tmf: [
      "TMF678 Customer Bill Management",
      "TMF621 Trouble Ticket Management",
      "TMF688 Event Management",
    ],
    recommendation:
      "Apply governed resolution path, preserve evidence, publish customer-safe notes, and monitor recurrence.",
  },
];

export const apiMap = [
  ["TMF678 Customer Bill Management", "Bill retrieval and line-item review", "All use cases"],
  ["TMF621 Trouble Ticket Management", "Case status, notes and escalation", "Dispute/governance cases"],
  ["TMF688 Event Management", "Operational event trigger and notification", "Pre-bill and anomaly cases"],
  ["TMF635 Product Usage Management", "Usage reconciliation context", "Usage-linked cases"],
  ["TMF656 Service Problem Management", "Technical/service impact evidence", "Network/service cases"],
  ["TMF628 Performance Management", "QoS/SLA performance evidence", "Premium entitlement"],
  ["TMF638 Service Inventory Management", "Service/topology context", "Enterprise review"],
  ["TMF640 Service Activation Management", "Safe remediation action reference", "Network remediation"],
];

/** Helper: tools emitted at each orchestration step */
export function toolsForStep(action) {
  if (action === "Detect")
    return [
      ["Event subscription", "TMF688 Event Management", "Operational signal received"],
      ["Vector search", "Vector Evidence Index", "Similar historical billing patterns retrieved"],
      ["Control rule", "Revenue Assurance Policy", "Severity classified"],
    ];
  if (action === "Analyze")
    return [
      ["Bill lookup", "TMF678 Customer Bill Management", "Bill and lines retrieved"],
      ["Knowledge graph reasoning", "Billing-Service Knowledge Graph", "Customer, product, usage and service relationships resolved"],
      ["Evidence query", "Domain Evidence Store", "Evidence attached"],
    ];
  if (action === "Decide")
    return [
      ["Policy evaluation", "Policy Engine", "Guardrails checked"],
      ["Vector search", "Resolution Playbook Index", "Nearest resolution playbooks retrieved"],
      ["Knowledge graph reasoning", "Decision Knowledge Graph", "Next-best-action path inferred"],
      ["Risk scoring", "Decision Service", "Impact scored"],
    ];
  if (action === "Approve")
    return [
      ["Approval task", "Governance Workbench", "Decision packet routed"],
      ["Knowledge graph reasoning", "Policy Obligation Graph", "Obligations and affected parties identified"],
      ["Audit record", "Compliance Ledger", "Approval captured"],
    ];
  return [
    ["Adjustment action", "Billing Adjustment Service", "Outcome prepared"],
    ["Ticket update", "TMF621 Trouble Ticket Management", "Resolution note posted"],
    ["Knowledge graph update", "Case Knowledge Graph", "Resolved state persisted"],
  ];
}

/** Post-resolution state per use case */
export function postState(u) {
  const map = {
    P1: ["Protected", "Late usage window quarantined", "Monitor next bill run"],
    P2: ["Corrected", "Duplicate rating isolated; credit memo prepared", "Post credit and notify customer"],
    P3: ["Corrected", "Stale session linked; unfair usage reversal prepared", "Close after bill adjustment"],
    P4: ["Approved review", "Approval captured; evidence pack routed", "Apply governed enterprise adjustment"],
    P5: ["Approved compensation", "Approval captured; compensation decision ready", "Issue goodwill/SLA credit"],
    P6: ["Hold confirmed", "Collections hold applied to contested amount", "Continue undisputed balance collection"],
    P7: ["Interim remedy approved", "Retail remedy approved while settlement remains under review", "Apply interim customer remedy"],
    P8: ["Explained", "Bill explanation generated and attached", "Send explanation to customer"],
    P9: ["Protected", "Pre-bill risk suppressed before invoice generation", "Continue monitoring cohort"],
    P10: ["Governed decision ready", "Evidence pack approved for finance action", "Release governed decision"],
  };
  return map[u.id] || ["Resolved", "Outcome prepared", "Close case"];
}
